/*    */ package fr.paladium.palamod.decorative.block;
/*    */ 
/*    */ public class BlockInvisible extends BlockInvisibleCollide {
/*    */   public BlockInvisible(String unlocalizedName) {
/*  5 */     super(unlocalizedName);
/*    */   }
/*    */   
/*    */   public boolean canCollideCheck(int p_149678_1_, boolean p_149678_2_)
/*    */   {
/* 10 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\decorative\block\BlockInvisible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */