/*    */ package fr.paladium.palamod.decorative.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.material.MapColor;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockInvisibleCollide
/*    */   extends BaseBlock
/*    */ {
/* 13 */   private static final Material inviGlass = new Material(MapColor.airColor);
/*    */   
/*    */   public BlockInvisibleCollide(String unlocalizedName) {
/* 16 */     super(unlocalizedName, inviGlass);
/*    */     
/* 18 */     setBlockTextureName("palamod:invisible_block");
/*    */     
/* 20 */     setResistance(6000000.0F);
/*    */     
/* 22 */     setLightOpacity(0);
/* 23 */     setBlockUnbreakable();
/*    */     
/* 25 */     disableStats();
/*    */     
/* 27 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean isOpaqueCube()
/*    */   {
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public int getRenderType()
/*    */   {
/* 37 */     return -1;
/*    */   }
/*    */   
/*    */   public int quantityDropped(Random r)
/*    */   {
/* 42 */     return 0;
/*    */   }
/*    */   
/*    */   public void dropBlockAsItemWithChance(World p_149690_1_, int p_149690_2_, int p_149690_3_, int p_149690_4_, int p_149690_5_, float p_149690_6_, int p_149690_7_) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\decorative\block\BlockInvisibleCollide.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */