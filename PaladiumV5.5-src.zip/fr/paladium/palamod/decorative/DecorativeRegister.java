/*    */ package fr.paladium.palamod.decorative;
/*    */ 
/*    */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import fr.paladium.palamod.decorative.block.BlockInvisible;
/*    */ import fr.paladium.palamod.decorative.block.BlockInvisibleCollide;
/*    */ import fr.paladium.palamod.decorative.item.ItemBlockInvisible;
/*    */ import fr.paladium.palamod.library.Register;
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class DecorativeRegister
/*    */   extends Register
/*    */ {
/*    */   public static BaseBlock PALADIUM_BLOCK;
/*    */   public static BaseBlock PALADIUM_GREEN_BLOCK;
/*    */   public static BaseBlock TITANE_BLOCK;
/*    */   public static BaseBlock AMETHYST_BLOCK;
/*    */   public static BlockInvisible INVISIBLE_BLOCK;
/*    */   public static BlockInvisibleCollide COLLIDE_INVISIBLE_BLOCK;
/*    */   
/*    */   public void preInit(FMLPreInitializationEvent event)
/*    */   {
/* 29 */     register();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void init(FMLInitializationEvent event)
/*    */   {
/* 36 */     registerRecipes();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void postInit(FMLPostInitializationEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private void register()
/*    */   {
/* 49 */     registerBlock((PALADIUM_BLOCK = new BaseBlock("paladium_block", Material.iron)).setHardness(5.0F).setResistance(10.0F));
/* 50 */     registerBlock((PALADIUM_GREEN_BLOCK = new BaseBlock("paladium_green_block", Material.iron)).setHardness(5.0F).setResistance(10.0F));
/* 51 */     registerBlock((TITANE_BLOCK = new BaseBlock("titane_block", Material.iron)).setHardness(5.0F).setResistance(10.0F));
/* 52 */     registerBlock((AMETHYST_BLOCK = new BaseBlock("amethyst_block", Material.iron)).setHardness(5.0F).setResistance(10.0F));
/*    */     
/* 54 */     registerBlock(INVISIBLE_BLOCK = new BlockInvisible("invisible_block"), ItemBlockInvisible.class);
/* 55 */     registerBlock(COLLIDE_INVISIBLE_BLOCK = new BlockInvisibleCollide("collide_invisible_block"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void registerRecipes()
/*    */   {
/* 62 */     String[] patBlock = { "###", "###", "###" };
/*    */     
/* 64 */     GameRegistry.addRecipe(new ItemStack(PALADIUM_BLOCK), new Object[] { patBlock, 
/*    */     
/* 66 */       Character.valueOf('#'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*    */     
/* 68 */     GameRegistry.addRecipe(new ItemStack(PALADIUM_GREEN_BLOCK), new Object[] { patBlock, 
/*    */     
/* 70 */       Character.valueOf('#'), new ItemStack(MaterialRegister.PALADIUM_GREEN_INGOT) });
/*    */     
/* 72 */     GameRegistry.addRecipe(new ItemStack(TITANE_BLOCK), new Object[] { patBlock, 
/*    */     
/* 74 */       Character.valueOf('#'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*    */     
/* 76 */     GameRegistry.addRecipe(new ItemStack(AMETHYST_BLOCK), new Object[] { patBlock, 
/*    */     
/* 78 */       Character.valueOf('#'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\decorative\DecorativeRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */