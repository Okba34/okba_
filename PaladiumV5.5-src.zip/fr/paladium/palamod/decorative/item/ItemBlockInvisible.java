/*    */ package fr.paladium.palamod.decorative.item;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemBlockInvisible extends ItemBlock
/*    */ {
/*    */   public ItemBlockInvisible(Block block)
/*    */   {
/* 13 */     super(block);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 18 */     super.addInformation(stack, player, list, b);
/* 19 */     list.add(net.minecraft.util.EnumChatFormatting.RED + "Warning : unbreakable by hand.");
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\decorative\item\ItemBlockInvisible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */