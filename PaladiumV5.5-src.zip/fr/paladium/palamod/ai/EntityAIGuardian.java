/*    */ package fr.paladium.palamod.ai;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ import net.minecraft.command.IEntitySelector;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityCreature;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.ai.EntityAINearestAttackableTarget.Sorter;
/*    */ import net.minecraft.entity.ai.EntityAITarget;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityAIGuardian extends EntityAITarget
/*    */ {
/*    */   private final Class<?> targetClass;
/*    */   private final int targetChance;
/*    */   private EntityGuardianGolem golem;
/*    */   private final EntityAINearestAttackableTarget.Sorter theNearestAttackableTargetSorter;
/*    */   private final IEntitySelector targetEntitySelector;
/*    */   private EntityLivingBase targetEntity;
/*    */   
/*    */   public EntityAIGuardian(EntityGuardianGolem p_i1663_1_, Class p_i1663_2_, int p_i1663_3_, boolean p_i1663_4_)
/*    */   {
/* 27 */     this(p_i1663_1_, p_i1663_2_, p_i1663_3_, p_i1663_4_, false);
/* 28 */     this.golem = p_i1663_1_;
/*    */   }
/*    */   
/*    */   public EntityAIGuardian(EntityGuardianGolem p_i1664_1_, Class p_i1664_2_, int p_i1664_3_, boolean p_i1664_4_, boolean p_i1664_5_) {
/* 32 */     this(p_i1664_1_, p_i1664_2_, p_i1664_3_, p_i1664_4_, p_i1664_5_, (IEntitySelector)null);
/* 33 */     this.golem = p_i1664_1_;
/*    */   }
/*    */   
/*    */   public EntityAIGuardian(EntityCreature p_i1665_1_, Class p_i1665_2_, int p_i1665_3_, boolean p_i1665_4_, boolean p_i1665_5_, IEntitySelector p_i1665_6_) {
/* 37 */     super(p_i1665_1_, p_i1665_4_, p_i1665_5_);
/* 38 */     this.targetClass = p_i1665_2_;
/* 39 */     this.targetChance = p_i1665_3_;
/* 40 */     this.theNearestAttackableTargetSorter = new EntityAINearestAttackableTarget.Sorter(p_i1665_1_);
/* 41 */     setMutexBits(1);
/*    */     
/* 43 */     this.targetEntitySelector = new IEntitySelector() {
/*    */       public boolean isEntityApplicable(Entity entity) {
/* 45 */         if ((entity instanceof EntityPlayer)) {
/* 46 */           EntityPlayer player = (EntityPlayer)entity;
/* 47 */           if ((!EntityAIGuardian.this.golem.checkWhitelist((EntityPlayer)entity)) && (!player.capabilities.isCreativeMode)) {
/* 48 */             return true;
/*    */           }
/*    */         }
/* 51 */         return false;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public boolean shouldExecute() {
/* 57 */     if ((this.targetChance > 0) && (this.taskOwner.getRNG().nextInt(this.targetChance) != 0)) {
/* 58 */       return false;
/*    */     }
/*    */     
/* 61 */     double d0 = getTargetDistance();
/* 62 */     List list = this.taskOwner.worldObj.selectEntitiesWithinAABB(this.targetClass, this.taskOwner.boundingBox.expand(d0, 4.0D, d0), this.targetEntitySelector);
/* 63 */     java.util.Collections.sort(list, this.theNearestAttackableTargetSorter);
/*    */     
/* 65 */     if (list.isEmpty()) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     this.targetEntity = ((EntityLivingBase)list.get(0));
/* 70 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public void startExecuting()
/*    */   {
/* 76 */     this.taskOwner.setAttackTarget(this.targetEntity);
/* 77 */     super.startExecuting();
/*    */   }
/*    */   
/*    */   public static class Sorter implements java.util.Comparator<Object> {
/*    */     private final Entity theEntity;
/*    */     
/*    */     public Sorter(Entity p_i1662_1_) {
/* 84 */       this.theEntity = p_i1662_1_;
/*    */     }
/*    */     
/*    */     public int compare(Entity p_compare_1_, Entity p_compare_2_) {
/* 88 */       double d0 = this.theEntity.getDistanceSqToEntity(p_compare_1_);
/* 89 */       double d1 = this.theEntity.getDistanceSqToEntity(p_compare_2_);
/* 90 */       return d0 > d1 ? 1 : d0 < d1 ? -1 : 0;
/*    */     }
/*    */     
/*    */     public int compare(Object p_compare_1_, Object p_compare_2_) {
/* 94 */       return compare((Entity)p_compare_1_, (Entity)p_compare_2_);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\ai\EntityAIGuardian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */