/*    */ package fr.paladium.palamod.library.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ 
/*    */ public class BaseItem extends net.minecraft.item.Item
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   
/*    */   public BaseItem(String unlocalizedName)
/*    */   {
/* 11 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 13 */     setUnlocalizedName(this.unlocalizedName);
/* 14 */     setTextureName("palamod:" + this.unlocalizedName);
/*    */     
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\item\BaseItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */