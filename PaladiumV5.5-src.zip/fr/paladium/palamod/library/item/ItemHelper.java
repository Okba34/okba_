/*     */ package fr.paladium.palamod.library.item;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraftforge.event.entity.living.LivingDropsEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ItemHelper
/*     */ {
/*     */   public static Object getStaticItem(String name, String classPackage)
/*     */   {
/*     */     try
/*     */     {
/*  19 */       Class<?> clazz = Class.forName(classPackage);
/*  20 */       java.lang.reflect.Field field = clazz.getDeclaredField(name);
/*  21 */       Object ret = field.get(null);
/*  22 */       if ((ret != null) && (((ret instanceof ItemStack)) || ((ret instanceof net.minecraft.item.Item))))
/*  23 */         return ret;
/*  24 */       return null;
/*     */     }
/*     */     catch (Exception e) {
/*  27 */       fr.paladium.palamod.PalaMod.logger.warn("Could not find " + name + "from " + classPackage); }
/*  28 */     return null;
/*     */   }
/*     */   
/*     */   public static void addDrops(LivingDropsEvent event, ItemStack dropStack)
/*     */   {
/*  33 */     net.minecraft.entity.item.EntityItem entityitem = new net.minecraft.entity.item.EntityItem(event.entityLiving.worldObj, event.entityLiving.posX, event.entityLiving.posY, event.entityLiving.posZ, dropStack);
/*  34 */     entityitem.delayBeforeCanPickup = 10;
/*  35 */     event.drops.add(entityitem);
/*     */   }
/*     */   
/*     */   public static void renderStandardInvBlock(RenderBlocks renderblocks, Block block, int meta) {
/*  39 */     Tessellator tessellator = Tessellator.instance;
/*  40 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*  41 */     tessellator.startDrawingQuads();
/*  42 */     tessellator.setNormal(0.0F, -1.0F, 0.0F);
/*  43 */     renderblocks.renderFaceYNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(0, meta)));
/*  44 */     tessellator.draw();
/*  45 */     tessellator.startDrawingQuads();
/*  46 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/*  47 */     renderblocks.renderFaceYPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(1, meta)));
/*  48 */     tessellator.draw();
/*  49 */     tessellator.startDrawingQuads();
/*  50 */     tessellator.setNormal(0.0F, 0.0F, -1.0F);
/*  51 */     renderblocks.renderFaceZNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(2, meta)));
/*  52 */     tessellator.draw();
/*  53 */     tessellator.startDrawingQuads();
/*  54 */     tessellator.setNormal(0.0F, 0.0F, 1.0F);
/*  55 */     renderblocks.renderFaceZPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(3, meta)));
/*  56 */     tessellator.draw();
/*  57 */     tessellator.startDrawingQuads();
/*  58 */     tessellator.setNormal(-1.0F, 0.0F, 0.0F);
/*  59 */     renderblocks.renderFaceXNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(4, meta)));
/*  60 */     tessellator.draw();
/*  61 */     tessellator.startDrawingQuads();
/*  62 */     tessellator.setNormal(1.0F, 0.0F, 0.0F);
/*  63 */     renderblocks.renderFaceXPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(5, meta)));
/*  64 */     tessellator.draw();
/*  65 */     GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/*     */   }
/*     */   
/*     */   public static void renderInvBlockFace(RenderBlocks renderblocks, Block block, int meta) {
/*  69 */     Tessellator tessellator = Tessellator.instance;
/*  70 */     GL11.glScalef(2.0F, 2.0F, 2.0F);
/*  71 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*  72 */     GL11.glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
/*  73 */     GL11.glRotatef(60.0F, 1.0F, 0.0F, 0.0F);
/*  74 */     tessellator.startDrawingQuads();
/*  75 */     tessellator.setNormal(0.0F, -1.0F, 0.0F);
/*  76 */     renderblocks.renderFaceYNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(0, meta)));
/*  77 */     tessellator.draw();
/*  78 */     tessellator.startDrawingQuads();
/*  79 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/*  80 */     renderblocks.renderFaceYPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(1, meta)));
/*  81 */     tessellator.draw();
/*  82 */     tessellator.startDrawingQuads();
/*  83 */     tessellator.setNormal(0.0F, 0.0F, -1.0F);
/*  84 */     renderblocks.renderFaceZNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(2, meta)));
/*  85 */     tessellator.draw();
/*  86 */     tessellator.startDrawingQuads();
/*  87 */     tessellator.setNormal(0.0F, 0.0F, 1.0F);
/*  88 */     renderblocks.renderFaceZPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(3, meta)));
/*  89 */     tessellator.draw();
/*  90 */     tessellator.startDrawingQuads();
/*  91 */     tessellator.setNormal(-1.0F, 0.0F, 0.0F);
/*  92 */     renderblocks.renderFaceXNeg(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(4, meta)));
/*  93 */     tessellator.draw();
/*  94 */     tessellator.startDrawingQuads();
/*  95 */     tessellator.setNormal(1.0F, 0.0F, 0.0F);
/*  96 */     renderblocks.renderFaceXPos(block, 0.0D, 0.0D, 0.0D, getIconSafe(block.getIcon(5, meta)));
/*  97 */     tessellator.draw();
/*  98 */     GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/*     */   }
/*     */   
/*     */   public static IIcon getIconSafe(IIcon icon) {
/* 102 */     if (icon != null) {
/* 103 */       return icon;
/*     */     }
/* 105 */     return ((TextureMap)net.minecraft.client.Minecraft.getMinecraft().getTextureManager().getTexture(TextureMap.locationBlocksTexture)).getAtlasSprite("missingno");
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\item\ItemHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */