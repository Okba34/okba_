/*     */ package fr.paladium.palamod.library.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.NEIServerUtils;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
/*     */ import fr.paladium.palamod.paladium.gui.PaladiumMachineGui;
/*     */ import fr.paladium.palamod.recipies.PaladiumMachineRecipies;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class PaladiumMachineRecipeHandler extends TemplateRecipeHandler
/*     */ {
/*     */   public static final String IDENTIFIER = "palamod.paladium_machine";
/*  25 */   private static final String BACKGROUND_TEXTURE = PaladiumMachineGui.background.toString();
/*     */   
/*     */   public String getRecipeName()
/*     */   {
/*  29 */     return StatCollector.translateToLocal("crafters.PaladiumMachine");
/*     */   }
/*     */   
/*     */   public String getGuiTexture()
/*     */   {
/*  34 */     return BACKGROUND_TEXTURE;
/*     */   }
/*     */   
/*     */   public Class<? extends GuiContainer> getGuiClass()
/*     */   {
/*  39 */     return PaladiumMachineGui.class;
/*     */   }
/*     */   
/*     */   public String getOverlayIdentifier()
/*     */   {
/*  44 */     return "palamod.paladium_machine";
/*     */   }
/*     */   
/*     */   public void loadTransferRects()
/*     */   {
/*  49 */     this.transferRects.add(new codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect(new Rectangle(79, 56, 8, 11), "palamod.paladium_machine", new Object[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawExtras(int recipe)
/*     */   {
/*  58 */     drawProgressBar(76, 55, 201, 105, 20, 16, 48, 1);
/*     */   }
/*     */   
/*     */   public int recipiesPerPage()
/*     */   {
/*  63 */     return 1;
/*     */   }
/*     */   
/*     */   public void drawBackground(int recipe)
/*     */   {
/*  68 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  70 */     GuiDraw.changeTexture(getGuiTexture());
/*  71 */     GuiDraw.drawTexturedModalRect(10, 26, 24, 94, 146, 69);
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results)
/*     */   {
/*  76 */     if ((outputId.equals("palamod.paladium_machine")) && (getClass() == PaladiumMachineRecipeHandler.class)) {
/*  77 */       Map<ItemStack[], ItemStack> recipes = PaladiumMachineRecipies.getManager().getSmeltingList();
/*  78 */       for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  79 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */     else {
/*  83 */       super.loadCraftingRecipes(outputId, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result)
/*     */   {
/*  89 */     Map<ItemStack[], ItemStack> recipes = PaladiumMachineRecipies.getManager().getSmeltingList();
/*  90 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  91 */       if (NEIServerUtils.areStacksSameType((ItemStack)recipe.getValue(), result)) {
/*  92 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(String inputId, Object... ingredients)
/*     */   {
/*  99 */     super.loadUsageRecipes(inputId, ingredients);
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient)
/*     */   {
/* 104 */     Map<ItemStack[], ItemStack> recipes = PaladiumMachineRecipies.getManager().getSmeltingList();
/* 105 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/* 106 */       for (ItemStack stack : (ItemStack[])recipe.getKey())
/* 107 */         if (NEIServerUtils.areStacksSameTypeCrafting(stack, ingredient)) {
/* 108 */           SmeltingPair arecipe = new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue());
/* 109 */           arecipe.setIngredientPermutation(arecipe.ingreds, ingredient);
/* 110 */           this.arecipes.add(arecipe);
/*     */         }
/*     */     }
/*     */   }
/*     */   
/*     */   public class SmeltingPair extends TemplateRecipeHandler.CachedRecipe {
/*     */     List<PositionedStack> ingreds;
/*     */     PositionedStack result;
/*     */     
/*     */     public SmeltingPair(ItemStack[] ingreds, ItemStack result) {
/* 120 */       super();
/* 121 */       if (ingreds[0].getItem() == result.getItem()) {
/* 122 */         ingreds[0].setItemDamage(ingreds[0].getMaxDamage() / 2);
/*     */       }
/*     */       
/* 125 */       this.ingreds = new ArrayList();
/*     */       
/* 127 */       this.ingreds.add(new PositionedStack(ingreds[0], 75, 27));
/* 128 */       this.ingreds.add(new PositionedStack(ingreds[1], 11, 35));
/* 129 */       this.ingreds.add(new PositionedStack(ingreds[2], 39, 55));
/* 130 */       this.ingreds.add(new PositionedStack(ingreds[3], 111, 55));
/* 131 */       this.ingreds.add(new PositionedStack(ingreds[4], 139, 35));
/*     */       
/* 133 */       this.result = new PositionedStack(result, 75, 78);
/*     */     }
/*     */     
/*     */     public List<PositionedStack> getIngredients() {
/* 137 */       return getCycledIngredients(PaladiumMachineRecipeHandler.this.cycleticks / 48, this.ingreds);
/*     */     }
/*     */     
/*     */     public PositionedStack getResult() {
/* 141 */       return this.result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\nei\PaladiumMachineRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */