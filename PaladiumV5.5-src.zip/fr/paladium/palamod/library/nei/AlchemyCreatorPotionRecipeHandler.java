/*     */ package fr.paladium.palamod.library.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.NEIServerUtils;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
/*     */ import fr.paladium.palamod.paladium.gui.AlchemyCreatorPotionGui;
/*     */ import fr.paladium.palamod.recipies.AlchemyCreatorPotionRecipies;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class AlchemyCreatorPotionRecipeHandler extends TemplateRecipeHandler
/*     */ {
/*     */   public static final String IDENTIFIER = "palamod.alchemy_creator_potion";
/*  23 */   private static final String BACKGROUND_TEXTURE = AlchemyCreatorPotionGui.background.toString();
/*  24 */   private static final String WIDGET_TEXTURE = AlchemyCreatorPotionGui.widgets.toString();
/*     */   
/*     */   public String getRecipeName()
/*     */   {
/*  28 */     return "AlchemyCreator Potion";
/*     */   }
/*     */   
/*     */   public String getGuiTexture()
/*     */   {
/*  33 */     return BACKGROUND_TEXTURE;
/*     */   }
/*     */   
/*     */   public Class<? extends net.minecraft.client.gui.inventory.GuiContainer> getGuiClass()
/*     */   {
/*  38 */     return AlchemyCreatorPotionGui.class;
/*     */   }
/*     */   
/*     */   public String getOverlayIdentifier()
/*     */   {
/*  43 */     return "palamod.alchemy_creator_potion";
/*     */   }
/*     */   
/*     */   public void loadTransferRects()
/*     */   {
/*  48 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(143, 15, 18, 18), "palamod.alchemy_creator_potion", new Object[0]));
/*  49 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(143, 35, 18, 18), "palamod.alchemy_creator_arrow", new Object[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawExtras(int recipe)
/*     */   {
/*  58 */     GuiDraw.changeTexture(WIDGET_TEXTURE);
/*  59 */     drawProgressBar(119, 24, 0, 89, 10, 30, 48, 1);
/*  60 */     drawProgressBar(30, 22, 10, 89, 14, 29, 100, 1);
/*     */   }
/*     */   
/*     */   public int recipiesPerPage()
/*     */   {
/*  65 */     return 2;
/*     */   }
/*     */   
/*     */   public void drawBackground(int recipe)
/*     */   {
/*  70 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  71 */     GuiDraw.changeTexture(getGuiTexture());
/*  72 */     GuiDraw.drawTexturedModalRect(0, 0, 5, 14, 166, 64);
/*  73 */     GuiDraw.changeTexture(WIDGET_TEXTURE);
/*  74 */     GuiDraw.drawTexturedModalRect(143, 15, 0, 56, 18, 18);
/*  75 */     GuiDraw.drawTexturedModalRect(143, 35, 0, 74, 18, 16);
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results)
/*     */   {
/*  80 */     if ((outputId.equals("palamod.alchemy_creator_potion")) && (getClass() == AlchemyCreatorPotionRecipeHandler.class)) {
/*  81 */       Map<ItemStack[], ItemStack> recipes = AlchemyCreatorPotionRecipies.getManager().getSmeltingList();
/*  82 */       for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  83 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */     else {
/*  87 */       super.loadCraftingRecipes(outputId, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result)
/*     */   {
/*  93 */     Map<ItemStack[], ItemStack> recipes = AlchemyCreatorPotionRecipies.getManager().getSmeltingList();
/*     */     
/*  95 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  96 */       if (NEIServerUtils.areStacksSameType((ItemStack)recipe.getValue(), result)) {
/*  97 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(String inputId, Object... ingredients)
/*     */   {
/* 104 */     super.loadUsageRecipes(inputId, ingredients);
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient)
/*     */   {
/* 109 */     Map<ItemStack[], ItemStack> recipes = AlchemyCreatorPotionRecipies.getManager().getSmeltingList();
/*     */     
/* 111 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/* 112 */       for (ItemStack stack : (ItemStack[])recipe.getKey())
/* 113 */         if (NEIServerUtils.areStacksSameTypeCrafting(stack, ingredient)) {
/* 114 */           SmeltingPair arecipe = new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue());
/* 115 */           arecipe.setIngredientPermutation(arecipe.ingreds, ingredient);
/* 116 */           this.arecipes.add(arecipe);
/*     */         }
/*     */     }
/*     */   }
/*     */   
/*     */   public class SmeltingPair extends TemplateRecipeHandler.CachedRecipe {
/*     */     List<PositionedStack> ingreds;
/*     */     PositionedStack result;
/*     */     
/*     */     public SmeltingPair(ItemStack[] ingreds, ItemStack result) {
/* 126 */       super();
/* 127 */       this.ingreds = new ArrayList();
/*     */       
/* 129 */       this.ingreds.add(new PositionedStack(ingreds[0], 45, 21));
/* 130 */       this.ingreds.add(new PositionedStack(ingreds[1], 74, 3));
/* 131 */       this.ingreds.add(new PositionedStack(ingreds[2], 103, 21));
/*     */       
/* 133 */       this.result = new PositionedStack(result, 74, 39);
/*     */     }
/*     */     
/*     */     public List<PositionedStack> getIngredients() {
/* 137 */       return getCycledIngredients(AlchemyCreatorPotionRecipeHandler.this.cycleticks / 48, this.ingreds);
/*     */     }
/*     */     
/*     */     public PositionedStack getResult() {
/* 141 */       return this.result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\nei\AlchemyCreatorPotionRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */