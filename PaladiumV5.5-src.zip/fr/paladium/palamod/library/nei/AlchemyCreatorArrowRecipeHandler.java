/*     */ package fr.paladium.palamod.library.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.NEIServerUtils;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
/*     */ import fr.paladium.palamod.paladium.gui.AlchemyCreatorArrowGui;
/*     */ import fr.paladium.palamod.recipies.AlchemyCreatorArrowRecipies;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class AlchemyCreatorArrowRecipeHandler extends TemplateRecipeHandler
/*     */ {
/*     */   public static final String IDENTIFIER = "palamod.alchemy_creator_arrow";
/*  23 */   private static final String BACKGROUND_TEXTURE = AlchemyCreatorArrowGui.background.toString();
/*  24 */   private static final String WIDGET_TEXTURE = AlchemyCreatorArrowGui.widgets.toString();
/*     */   
/*     */   public String getRecipeName()
/*     */   {
/*  28 */     return "AlchemyCreator Arrow";
/*     */   }
/*     */   
/*     */   public String getGuiTexture()
/*     */   {
/*  33 */     return BACKGROUND_TEXTURE;
/*     */   }
/*     */   
/*     */   public Class<? extends net.minecraft.client.gui.inventory.GuiContainer> getGuiClass()
/*     */   {
/*  38 */     return AlchemyCreatorArrowGui.class;
/*     */   }
/*     */   
/*     */   public String getOverlayIdentifier()
/*     */   {
/*  43 */     return "palamod.alchemy_creator_arrow";
/*     */   }
/*     */   
/*     */   public void loadTransferRects()
/*     */   {
/*  48 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(143, 15, 18, 18), "palamod.alchemy_creator_potion", new Object[0]));
/*  49 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(143, 35, 18, 18), "palamod.alchemy_creator_arrow", new Object[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawExtras(int recipe)
/*     */   {
/*  58 */     GuiDraw.changeTexture(WIDGET_TEXTURE);
/*  59 */     drawProgressBar(92, 36, 0, 89, 10, 30, 48, 1);
/*  60 */     drawProgressBar(58, 35, 10, 89, 14, 29, 100, 1);
/*     */   }
/*     */   
/*     */   public int recipiesPerPage()
/*     */   {
/*  65 */     return 2;
/*     */   }
/*     */   
/*     */   public void drawBackground(int recipe)
/*     */   {
/*  70 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  72 */     GuiDraw.changeTexture(getGuiTexture());
/*  73 */     GuiDraw.drawTexturedModalRect(0, 0, 5, 14, 166, 64);
/*     */     
/*  75 */     GuiDraw.changeTexture(WIDGET_TEXTURE);
/*  76 */     GuiDraw.drawTexturedModalRect(143, 15, 0, 56, 18, 18);
/*  77 */     GuiDraw.drawTexturedModalRect(143, 35, 0, 74, 18, 16);
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results)
/*     */   {
/*  82 */     if ((outputId.equals("palamod.alchemy_creator_arrow")) && (getClass() == AlchemyCreatorArrowRecipeHandler.class)) {
/*  83 */       Map<ItemStack[], ItemStack> recipes = AlchemyCreatorArrowRecipies.getManager().getSmeltingList();
/*     */       
/*  85 */       for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  86 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */     else {
/*  90 */       super.loadCraftingRecipes(outputId, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result)
/*     */   {
/*  96 */     Map<ItemStack[], ItemStack> recipes = AlchemyCreatorArrowRecipies.getManager().getSmeltingList();
/*     */     
/*  98 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  99 */       if (NEIServerUtils.areStacksSameType((ItemStack)recipe.getValue(), result)) {
/* 100 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(String inputId, Object... ingredients)
/*     */   {
/* 107 */     super.loadUsageRecipes(inputId, ingredients);
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient)
/*     */   {
/* 112 */     Map<ItemStack[], ItemStack> recipes = AlchemyCreatorArrowRecipies.getManager().getSmeltingList();
/*     */     
/* 114 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/* 115 */       for (ItemStack stack : (ItemStack[])recipe.getKey())
/* 116 */         if (NEIServerUtils.areStacksSameTypeCrafting(stack, ingredient)) {
/* 117 */           SmeltingPair arecipe = new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue());
/* 118 */           arecipe.setIngredientPermutation(arecipe.ingreds, ingredient);
/* 119 */           this.arecipes.add(arecipe);
/*     */         }
/*     */     }
/*     */   }
/*     */   
/*     */   public class SmeltingPair extends TemplateRecipeHandler.CachedRecipe {
/*     */     List<PositionedStack> ingreds;
/*     */     PositionedStack result;
/*     */     
/*     */     public SmeltingPair(ItemStack[] ingreds, ItemStack result) {
/* 129 */       super();
/* 130 */       this.ingreds = new ArrayList();
/*     */       
/* 132 */       this.ingreds.add(new PositionedStack(ingreds[0], 50, 2));
/* 133 */       this.ingreds.add(new PositionedStack(ingreds[1], 74, 2));
/* 134 */       this.ingreds.add(new PositionedStack(ingreds[2], 98, 2));
/* 135 */       this.ingreds.add(new PositionedStack(ingreds[3], 74, 24));
/*     */       
/* 137 */       this.result = new PositionedStack(result, 74, 46);
/*     */     }
/*     */     
/*     */     public List<PositionedStack> getIngredients() {
/* 141 */       return getCycledIngredients(AlchemyCreatorArrowRecipeHandler.this.cycleticks / 48, this.ingreds);
/*     */     }
/*     */     
/*     */     public PositionedStack getResult() {
/* 145 */       return this.result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\nei\AlchemyCreatorArrowRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */