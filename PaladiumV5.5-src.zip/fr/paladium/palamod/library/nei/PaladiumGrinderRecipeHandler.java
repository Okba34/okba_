/*     */ package fr.paladium.palamod.library.nei;
/*     */ 
/*     */ import codechicken.lib.gui.GuiDraw;
/*     */ import codechicken.nei.NEIServerUtils;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
/*     */ import fr.paladium.palamod.smeltery.crafting.GrinderRecipe;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class PaladiumGrinderRecipeHandler extends TemplateRecipeHandler
/*     */ {
/*     */   public static final String IDENTIFIER = "palamod.grinder";
/*  25 */   private static final String BACKGROUND_TEXTURE = new ResourceLocation("palamod:textures/gui/nei/grinder.png").toString();
/*     */   
/*     */   public String getRecipeName()
/*     */   {
/*  29 */     return StatCollector.translateToLocal("crafters.Grinder");
/*     */   }
/*     */   
/*     */   public String getGuiTexture()
/*     */   {
/*  34 */     return BACKGROUND_TEXTURE;
/*     */   }
/*     */   
/*     */   public Class<? extends GuiContainer> getGuiClass()
/*     */   {
/*  39 */     return fr.paladium.palamod.smeltery.gui.GrinderGui.class;
/*     */   }
/*     */   
/*     */   public String getOverlayIdentifier()
/*     */   {
/*  44 */     return "palamod.grinder";
/*     */   }
/*     */   
/*     */   public void loadTransferRects()
/*     */   {
/*  49 */     this.transferRects.add(new codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect(new Rectangle(35, 19, 29, 15), "palamod.grinder", new Object[0]));
/*     */   }
/*     */   
/*     */   public void drawExtras(int recipe)
/*     */   {
/*  54 */     drawProgressBar(35, 20, 152, 0, 30, 15, 50, 0);
/*     */     
/*  56 */     ItemStack key = GrinderRecipe.getManager().getSmeltingResult(new ItemStack[] { ((PositionedStack)((TemplateRecipeHandler.CachedRecipe)this.arecipes.get(recipe)).getIngredients().get(0)).item, ((PositionedStack)((TemplateRecipeHandler.CachedRecipe)this.arecipes.get(recipe)).getIngredients().get(1)).item });
/*  57 */     int ammount = GrinderRecipe.getManager().getSmeltingAmmount(key);
/*  58 */     GuiDraw.drawTexturedModalRect(106, 4, 0, 60, 53, 54 - ammount * 54 / 100);
/*     */     
/*  60 */     int k = (GuiDraw.displaySize().width - 175) / 2;
/*  61 */     int l = (GuiDraw.displaySize().height - 165) / 2;
/*  62 */     GuiDraw.drawString("" + ammount, k + 3, l - 11, 16733440, true);
/*     */   }
/*     */   
/*     */   public int recipiesPerPage()
/*     */   {
/*  67 */     return 2;
/*     */   }
/*     */   
/*     */   public void drawBackground(int recipe)
/*     */   {
/*  72 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*  74 */     GuiDraw.changeTexture(getGuiTexture());
/*  75 */     GuiDraw.drawTexturedModalRect(10, 2, 0, 0, 152, 60);
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results)
/*     */   {
/*  80 */     if ((outputId.equals("palamod.grinder")) && (getClass() == PaladiumGrinderRecipeHandler.class)) {
/*  81 */       Map<ItemStack[], ItemStack> recipes = GrinderRecipe.getManager().getSmeltingList();
/*     */       
/*  83 */       for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  84 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */     else {
/*  88 */       super.loadCraftingRecipes(outputId, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result)
/*     */   {
/*  94 */     Map<ItemStack[], ItemStack> recipes = GrinderRecipe.getManager().getSmeltingList();
/*     */     
/*  96 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/*  97 */       if (NEIServerUtils.areStacksSameType((ItemStack)recipe.getValue(), result)) {
/*  98 */         this.arecipes.add(new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(String inputId, Object... ingredients)
/*     */   {
/* 105 */     super.loadUsageRecipes(inputId, ingredients);
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient)
/*     */   {
/* 110 */     Map<ItemStack[], ItemStack> recipes = GrinderRecipe.getManager().getSmeltingList();
/*     */     
/* 112 */     for (Map.Entry<ItemStack[], ItemStack> recipe : recipes.entrySet()) {
/* 113 */       for (ItemStack stack : (ItemStack[])recipe.getKey())
/* 114 */         if (NEIServerUtils.areStacksSameTypeCrafting(stack, ingredient)) {
/* 115 */           SmeltingPair arecipe = new SmeltingPair((ItemStack[])recipe.getKey(), (ItemStack)recipe.getValue());
/* 116 */           arecipe.setIngredientPermutation(arecipe.ingreds, ingredient);
/* 117 */           this.arecipes.add(arecipe);
/*     */         }
/*     */     }
/*     */   }
/*     */   
/*     */   public class SmeltingPair extends TemplateRecipeHandler.CachedRecipe {
/*     */     List<PositionedStack> ingreds;
/*     */     PositionedStack result;
/*     */     
/*     */     public SmeltingPair(ItemStack[] ingreds, ItemStack result) {
/* 127 */       super();
/* 128 */       this.ingreds = new ArrayList();
/*     */       
/* 130 */       this.ingreds.add(new PositionedStack(ingreds[0], 15, 13));
/* 131 */       this.ingreds.add(new PositionedStack(ingreds[1], 15, 31));
/*     */       
/* 133 */       this.result = new PositionedStack(result, 69, 22);
/*     */     }
/*     */     
/*     */     public List<PositionedStack> getIngredients() {
/* 137 */       return getCycledIngredients(PaladiumGrinderRecipeHandler.this.cycleticks / 48, this.ingreds);
/*     */     }
/*     */     
/*     */     public PositionedStack getResult() {
/* 141 */       return this.result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\nei\PaladiumGrinderRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */