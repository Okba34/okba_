/*    */ package fr.paladium.palamod.library.nei;
/*    */ 
/*    */ import codechicken.nei.api.API;
/*    */ import codechicken.nei.api.IConfigureNEI;
/*    */ import fr.paladium.palamod.recipies.PaladiumFurnaceRecipeHandler;
/*    */ 
/*    */ public class NEIPluginConfig implements IConfigureNEI
/*    */ {
/*    */   public void loadConfig()
/*    */   {
/* 11 */     API.registerRecipeHandler(new PaladiumFurnaceRecipeHandler());
/* 12 */     API.registerUsageHandler(new PaladiumFurnaceRecipeHandler());
/*    */     
/* 14 */     API.registerRecipeHandler(new PaladiumMachineRecipeHandler());
/* 15 */     API.registerUsageHandler(new PaladiumMachineRecipeHandler());
/*    */     
/* 17 */     API.registerRecipeHandler(new PaladiumGrinderRecipeHandler());
/* 18 */     API.registerUsageHandler(new PaladiumGrinderRecipeHandler());
/*    */     
/* 20 */     API.registerRecipeHandler(new AlchemyCreatorArrowRecipeHandler());
/* 21 */     API.registerUsageHandler(new AlchemyCreatorArrowRecipeHandler());
/*    */     
/* 23 */     API.registerRecipeHandler(new AlchemyCreatorPotionRecipeHandler());
/* 24 */     API.registerUsageHandler(new AlchemyCreatorPotionRecipeHandler());
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 29 */     return "palamodneiplugin";
/*    */   }
/*    */   
/*    */   public String getVersion()
/*    */   {
/* 34 */     return "1.0";
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\nei\NEIPluginConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */