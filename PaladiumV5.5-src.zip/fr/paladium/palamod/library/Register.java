/*    */ package fr.paladium.palamod.library;
/*    */ 
/*    */ import cpw.mods.fml.common.IWorldGenerator;
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.fluids.Fluid;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ public class Register
/*    */ {
/*    */   protected static void registerBlock(Block block)
/*    */   {
/* 18 */     GameRegistry.registerBlock(block, block.getUnlocalizedName());
/*    */     
/* 20 */     PalaMod.logger.info("Registered Block : " + block.getUnlocalizedName());
/*    */   }
/*    */   
/*    */   protected static void registerBlock(Block block, Class<? extends ItemBlock> clazz) {
/* 24 */     GameRegistry.registerBlock(block, clazz, block.getUnlocalizedName());
/*    */     
/* 26 */     PalaMod.logger.info("Registered Block : " + block.getUnlocalizedName());
/*    */   }
/*    */   
/*    */   protected static void registerTileEntity(Class<? extends TileEntity> clazz, String unlocalizedName) {
/* 30 */     GameRegistry.registerTileEntity(clazz, "palamod:" + unlocalizedName);
/*    */     
/* 32 */     PalaMod.logger.info("Registered Logic : " + unlocalizedName);
/*    */   }
/*    */   
/*    */   protected static void registerItem(Item item) {
/* 36 */     GameRegistry.registerItem(item, item.getUnlocalizedName());
/*    */     
/* 38 */     PalaMod.logger.info("Registered Item : " + item.getUnlocalizedName());
/*    */   }
/*    */   
/*    */   protected static void registerFluid(Fluid fluid) {
/* 42 */     net.minecraftforge.fluids.FluidRegistry.registerFluid(fluid);
/*    */     
/* 44 */     PalaMod.logger.info("Registered Fuild : " + fluid.getUnlocalizedName());
/*    */   }
/*    */   
/*    */   protected static void registerEntity(Class<? extends Entity> clazz, int id, String unlocalizedName, int var1, int var2, boolean var3) {
/* 48 */     cpw.mods.fml.common.registry.EntityRegistry.registerModEntity(clazz, unlocalizedName, id, PalaMod.instance, var1, var2, var3);
/*    */   }
/*    */   
/*    */   protected static void registerWorldGenerator(IWorldGenerator generator, int modGenerationWeight, String name) {
/* 52 */     GameRegistry.registerWorldGenerator(generator, modGenerationWeight);
/*    */     
/* 54 */     PalaMod.logger.info("Registered World Generator : " + name);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\Register.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */