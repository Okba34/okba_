/*    */ package fr.paladium.palamod.library.block;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ 
/*    */ public class BaseBlock extends Block
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   
/*    */   public BaseBlock(String unlocalizedName, Material mat)
/*    */   {
/* 12 */     super(mat);
/*    */     
/* 14 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 16 */     setBlockName(this.unlocalizedName);
/* 17 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*    */     
/* 19 */     setResistance(10.0F);
/* 20 */     setHardness(2.2F);
/*    */     
/* 22 */     setHarvestLevel("pickaxe", 0);
/*    */     
/* 24 */     if (mat == Material.rock) {
/* 25 */       setStepSound(Block.soundTypeStone);
/*    */     }
/* 27 */     else if (mat == Material.wood) {
/* 28 */       setStepSound(Block.soundTypeWood);
/*    */     }
/*    */     else {
/* 31 */       setStepSound(Block.soundTypeMetal);
/*    */     }
/*    */     
/* 34 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\library\block\BaseBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */