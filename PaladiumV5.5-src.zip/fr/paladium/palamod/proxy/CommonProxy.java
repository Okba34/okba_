/*     */ package fr.paladium.palamod.proxy;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ClientRegistry;
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.common.eventhandler.EventBus;
/*     */ import cpw.mods.fml.common.network.NetworkRegistry;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.blocks.fluids.ModFluids;
/*     */ import fr.paladium.palamod.common.ArmorMaterials;
/*     */ import fr.paladium.palamod.common.EventHandler;
/*     */ import fr.paladium.palamod.common.GuiHandler;
/*     */ import fr.paladium.palamod.common.KeyHandler;
/*     */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*     */ import fr.paladium.palamod.common.gui.ModGuiUnified;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.enchants.EnchantHandler;
/*     */ import fr.paladium.palamod.enchants.ModEnchants;
/*     */ import fr.paladium.palamod.entities.ModEntities;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.items.armors.EventHandlerArmor;
/*     */ import fr.paladium.palamod.job.EventHandlerJobs;
/*     */ import fr.paladium.palamod.job.EventHandlerJobsNetwork;
/*     */ import fr.paladium.palamod.job.JobRegister;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.potion.ModPotions;
/*     */ import fr.paladium.palamod.potion.PotionExtender;
/*     */ import fr.paladium.palamod.potion.PotionHandler;
/*     */ import fr.paladium.palamod.recipies.ModRecipies;
/*     */ import fr.paladium.palamod.smeltery.SmelteryRegister;
/*     */ import fr.paladium.palamod.tiles.ModTiles;
/*     */ import fr.paladium.palamod.util.UpgradeHelper;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ public class CommonProxy
/*     */ {
/*  46 */   public static MaterialRegister materialRegister = new MaterialRegister();
/*  47 */   public static WorldRegister worldRegister = new WorldRegister();
/*  48 */   public static DecorativeRegister decorativeRegister = new DecorativeRegister();
/*  49 */   public static SmelteryRegister smelteryRegister = new SmelteryRegister();
/*  50 */   public static PaladiumRegister paladiumRegister = new PaladiumRegister();
/*  51 */   public static JobRegister jobRegister = new JobRegister();
/*     */   
/*  53 */   public static PacketPipeline packetPipeline = new PacketPipeline();
/*     */   public static final boolean DEV = false;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/*  58 */     PotionExtender.preInit();
/*     */     
/*  60 */     ToolMaterialPaladium.init();
/*  61 */     ArmorMaterials.init();
/*  62 */     ModEntities.init();
/*  63 */     ModPotions.init();
/*  64 */     ModTiles.init();
/*  65 */     ModEnchants.init();
/*  66 */     ModItems.init();
/*  67 */     UpgradeHelper.init();
/*     */     
/*  69 */     materialRegister.preInit(event);
/*  70 */     worldRegister.preInit(event);
/*  71 */     decorativeRegister.preInit(event);
/*  72 */     smelteryRegister.preInit(event);
/*  73 */     paladiumRegister.preInit(event);
/*  74 */     jobRegister.preInit(event);
/*     */     
/*  76 */     if (event.getSide().equals(Side.CLIENT)) {
/*  77 */       FMLCommonHandler.instance().bus().register(this);
/*  78 */       MinecraftForge.EVENT_BUS.register(this);
/*     */       
/*  80 */       ClientRegistry.registerKeyBinding(ClientProxy.BACKPACK_KEY);
/*  81 */       ClientRegistry.registerKeyBinding(ClientProxy.NEXT_CAMERA_KEY);
/*  82 */       FMLCommonHandler.instance().bus().register(new KeyHandler());
/*     */     }
/*     */   }
/*     */   
/*     */   public void init(FMLInitializationEvent event) {
/*  87 */     materialRegister.init(event);
/*  88 */     worldRegister.init(event);
/*  89 */     decorativeRegister.init(event);
/*  90 */     smelteryRegister.init(event);
/*  91 */     paladiumRegister.init(event);
/*  92 */     jobRegister.init(event);
/*     */     
/*  94 */     ModFluids.init();
/*     */     
/*  96 */     registerEvents();
/*     */     
/*  98 */     PalaMod.proxy.registerItemRender();
/*  99 */     PalaMod.proxy.registerEntityRender();
/* 100 */     PalaMod.proxy.registerOverlay();
/* 101 */     PalaMod.proxy.registerBlockRender();
/* 102 */     PalaMod.proxy.registerClientCommand();
/*     */     
/* 104 */     NetworkRegistry.INSTANCE.registerGuiHandler(PalaMod.instance, new GuiHandler());
/*     */     
/* 106 */     packetPipeline.initalise();
/*     */     
/* 108 */     if (event.getSide().isClient()) {
/* 109 */       ModGuiUnified.init();
/*     */     }
/*     */     
/* 112 */     ModJobs.init();
/* 113 */     ModRecipies.init();
/*     */   }
/*     */   
/*     */   private void registerEvents()
/*     */   {
/* 118 */     MinecraftForge.EVENT_BUS.register(new PotionHandler());
/*     */     
/* 120 */     MinecraftForge.EVENT_BUS.register(new EnchantHandler());
/*     */     
/* 122 */     MinecraftForge.EVENT_BUS.register(new EventHandlerArmor());
/*     */     
/* 124 */     MinecraftForge.EVENT_BUS.register(new EventHandler());
/*     */     
/* 126 */     MinecraftForge.EVENT_BUS.register(new EventHandlerJobs());
/*     */     
/* 128 */     FMLCommonHandler.instance().bus().register(new EventHandlerJobsNetwork());
/*     */     
/* 130 */     FMLCommonHandler.instance().bus().register(new EventHandler());
/*     */   }
/*     */   
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 134 */     materialRegister.postInit(event);
/* 135 */     worldRegister.postInit(event);
/* 136 */     decorativeRegister.postInit(event);
/* 137 */     smelteryRegister.postInit(event);
/* 138 */     paladiumRegister.postInit(event);
/* 139 */     jobRegister.postInit(event);
/*     */     
/* 141 */     packetPipeline.postInitialise();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean shouldAddParticles(Random random)
/*     */   {
/* 149 */     return false;
/*     */   }
/*     */   
/*     */   public void generateCustomParticles(int type, Entity theEntity, int custom) {}
/*     */   
/*     */   public void generateCustomParticles(int type, Entity theEntity) {}
/*     */   
/*     */   public void registerRender() {}
/*     */   
/*     */   public void registerItemRender() {}
/*     */   
/*     */   public void registerBlockRender() {}
/*     */   
/*     */   public void registerEntityRender() {}
/*     */   
/*     */   public void registerOverlay() {}
/*     */   
/*     */   public void registerClientCommand() {}
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\proxy\CommonProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */