/*     */ package fr.paladium.palamod.proxy;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ClientRegistry;
/*     */ import cpw.mods.fml.client.registry.RenderingRegistry;
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import cpw.mods.fml.common.eventhandler.EventBus;
/*     */ import fr.paladium.palamod.client.TickHandlerClient;
/*     */ import fr.paladium.palamod.client.model.ModelGarag;
/*     */ import fr.paladium.palamod.client.model.ModelTobalt;
/*     */ import fr.paladium.palamod.client.overlay.OverlayCamera;
/*     */ import fr.paladium.palamod.client.overlay.OverlayUnclaimFinder;
/*     */ import fr.paladium.palamod.client.render.block.RenderObsidianUpgrader;
/*     */ import fr.paladium.palamod.client.render.block.RenderTurret;
/*     */ import fr.paladium.palamod.client.render.entity.RenderEntityPotion;
/*     */ import fr.paladium.palamod.client.render.entity.RenderGuardianGolem;
/*     */ import fr.paladium.palamod.client.render.tile.RenderCamera;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCustomWitherSkull;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGarag;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import fr.paladium.palamod.entities.mobs.EntityTobalt;
/*     */ import fr.paladium.palamod.entities.projectiles.EntityPotionGun;
/*     */ import fr.paladium.palamod.entities.projectiles.EntitySplashPotion;
/*     */ import fr.paladium.palamod.entities.projectiles.EntityTurretBullet;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.tiles.TileEntityCamera;
/*     */ import fr.paladium.palamod.tiles.TileEntityTurret;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.entity.RenderSnowball;
/*     */ import net.minecraft.client.renderer.tileentity.RenderWitherSkull;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraftforge.client.ClientCommandHandler;
/*     */ import net.minecraftforge.client.MinecraftForgeClient;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ public class ClientProxy extends CommonProxy
/*     */ {
/*     */   public static int renderBlockSpikeId;
/*     */   public static int renderObsidianUpgraderId;
/*  43 */   public static final KeyBinding BACKPACK_KEY = new KeyBinding("key.backpack.open", 37, "key.category.paladium");
/*  44 */   public static final KeyBinding NEXT_CAMERA_KEY = new KeyBinding("key.camera.next", 205, "key.category.paladium");
/*     */   
/*     */   public void registerItemRender()
/*     */   {
/*  48 */     MinecraftForgeClient.registerItemRenderer(ModItems.paladiumBow, new fr.paladium.palamod.client.render.item.ItemBowRenderer());
/*  49 */     MinecraftForgeClient.registerItemRenderer(Item.getItemFromBlock(fr.paladium.palamod.paladium.PaladiumRegister.CAMERA_BLOCK), new fr.paladium.palamod.client.render.item.RenderItemCamera(new RenderCamera(), new TileEntityCamera()));
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerBlockRender()
/*     */   {
/*  55 */     renderBlockSpikeId = RenderingRegistry.getNextAvailableRenderId();
/*  56 */     renderObsidianUpgraderId = RenderingRegistry.getNextAvailableRenderId();
/*  57 */     RenderingRegistry.registerBlockHandler(new fr.paladium.palamod.client.render.block.RenderBlockSpike());
/*  58 */     RenderingRegistry.registerBlockHandler(new RenderObsidianUpgrader());
/*  59 */     RenderingRegistry.registerBlockHandler(new fr.paladium.palamod.client.render.block.RenderSkullUpgrade());
/*     */     
/*     */ 
/*  62 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityCamera.class, new RenderCamera());
/*  63 */     ClientRegistry.bindTileEntitySpecialRenderer(TileEntityTurret.class, new RenderTurret());
/*     */   }
/*     */   
/*     */   public void registerEntityRender()
/*     */   {
/*  68 */     RenderingRegistry.registerEntityRenderingHandler(EntitySplashPotion.class, new RenderEntityPotion());
/*  69 */     RenderingRegistry.registerEntityRenderingHandler(EntityGuardianGolem.class, new RenderGuardianGolem());
/*  70 */     RenderingRegistry.registerEntityRenderingHandler(EntityPotionGun.class, new RenderSnowball(Items.potionitem, 16449));
/*  71 */     RenderingRegistry.registerEntityRenderingHandler(EntityGarag.class, new fr.paladium.palamod.client.render.entity.RenderGarag(new ModelGarag(), 0.8F));
/*  72 */     RenderingRegistry.registerEntityRenderingHandler(EntityTobalt.class, new fr.paladium.palamod.client.render.entity.RenderTobalt(new ModelTobalt(), 0.8F));
/*  73 */     RenderingRegistry.registerEntityRenderingHandler(fr.paladium.palamod.entities.mobs.EntityCustomWither.class, new fr.paladium.palamod.client.render.entity.RenderCustomWither());
/*  74 */     RenderingRegistry.registerEntityRenderingHandler(EntityCustomWitherSkull.class, new RenderWitherSkull());
/*     */     
/*  76 */     RenderingRegistry.registerEntityRenderingHandler(EntityTurretBullet.class, new RenderSnowball(Items.fire_charge));
/*     */   }
/*     */   
/*     */   public void registerOverlay()
/*     */   {
/*  81 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayBoss());
/*  82 */     MinecraftForge.EVENT_BUS.register(new OverlayUnclaimFinder());
/*  83 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayBow());
/*  84 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayMessage());
/*  85 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayMessageBoss());
/*  86 */     MinecraftForge.EVENT_BUS.register(new OverlayCamera());
/*  87 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayGolem());
/*     */     
/*     */ 
/*  90 */     MinecraftForge.EVENT_BUS.register(new fr.paladium.palamod.client.overlay.OverlayNotification());
/*     */   }
/*     */   
/*     */   public boolean shouldAddParticles(Random random)
/*     */   {
/*  95 */     int setting = Minecraft.getMinecraft().gameSettings.particleSetting;
/*  96 */     if (setting == 2) {
/*  97 */       return false;
/*     */     }
/*  99 */     if (setting == 0) {
/* 100 */       return true;
/*     */     }
/* 102 */     return random.nextInt(2 * (setting + 1)) == 0;
/*     */   }
/*     */   
/*     */   public void generateCustomParticles(int type, Entity theEntity, int custom)
/*     */   {
/* 107 */     switch (type) {
/*     */     case 0: 
/* 109 */       fr.paladium.palamod.util.ParticlesHandler.generateCustomExplosion(theEntity, custom);
/* 110 */       return;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerClientCommand()
/*     */   {
/* 118 */     FMLCommonHandler.instance().bus().register(new TickHandlerClient());
/*     */     
/* 120 */     ClientCommandHandler.instance.registerCommand(new fr.paladium.palamod.client.command.CommandHideBoss());
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\proxy\ClientProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */