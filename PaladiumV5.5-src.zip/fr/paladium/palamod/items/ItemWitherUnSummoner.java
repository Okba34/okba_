/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ public class ItemWitherUnSummoner
/*    */   extends Item
/*    */ {
/*    */   public ItemWitherUnSummoner()
/*    */   {
/* 12 */     setUnlocalizedName("witherunsumoner");
/* 13 */     setTextureName("palamod:WitherUnSummoner");
/* 14 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemWitherUnSummoner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */