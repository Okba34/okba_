/*    */ package fr.paladium.palamod.items.core;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemWing extends Item
/*    */ {
/*    */   public ItemWing()
/*    */   {
/* 10 */     setUnlocalizedName("wing");
/* 11 */     setTextureName("palamod:Wing");
/* 12 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\core\ItemWing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */