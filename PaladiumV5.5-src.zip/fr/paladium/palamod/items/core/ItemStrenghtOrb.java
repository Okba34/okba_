/*    */ package fr.paladium.palamod.items.core;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemStrenghtOrb extends Item
/*    */ {
/*    */   public ItemStrenghtOrb()
/*    */   {
/* 10 */     setUnlocalizedName("strenghtorb");
/* 11 */     setTextureName("palamod:StrenghtOrb");
/* 12 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\core\ItemStrenghtOrb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */