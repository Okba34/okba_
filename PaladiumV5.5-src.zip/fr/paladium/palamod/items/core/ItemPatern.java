/*    */ package fr.paladium.palamod.items.core;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemPatern
/*    */   extends Item
/*    */ {
/*  9 */   public static int SOCKET = -1;
/*    */   
/* 11 */   public static int BROADSWORD = 0;
/* 12 */   public static int FASTSWORD = 1;
/* 13 */   public static int SWORD = 2;
/* 14 */   public static int PICKAXE = 3;
/* 15 */   public static int HAMMER = 4;
/* 16 */   public static int SHOVEL = 5;
/* 17 */   public static int AXE = 6;
/* 18 */   public static int INGOT = 7;
/*    */   
/*    */   public static final int BLOCK = 8;
/*    */   int type;
/*    */   
/*    */   public ItemPatern(String name, String texture, int type)
/*    */   {
/* 25 */     setUnlocalizedName(name);
/* 26 */     setTextureName("palamod:" + texture);
/* 27 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 28 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\core\ItemPatern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */