/*    */ package fr.paladium.palamod.items.core;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemMagicalAnvilMiddle extends Item
/*    */ {
/*    */   public ItemMagicalAnvilMiddle()
/*    */   {
/* 10 */     setUnlocalizedName("magicalanvilmiddle");
/* 11 */     setTextureName("palamod:MagicalAnvilMiddle");
/* 12 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\core\ItemMagicalAnvilMiddle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */