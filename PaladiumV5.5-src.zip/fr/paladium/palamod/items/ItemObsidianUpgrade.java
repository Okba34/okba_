/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemObsidianUpgrade
/*    */   extends Item
/*    */ {
/*    */   public Upgrade type;
/*    */   
/*    */   public static enum Upgrade
/*    */   {
/* 12 */     Explode, 
/* 13 */     Fake, 
/* 14 */     TwoLife, 
/* 15 */     Camouflage;
/*    */     
/*    */     private Upgrade() {}
/*    */   }
/*    */   
/*    */   public ItemObsidianUpgrade(Upgrade upgrade) {
/* 21 */     this.type = upgrade;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemObsidianUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */