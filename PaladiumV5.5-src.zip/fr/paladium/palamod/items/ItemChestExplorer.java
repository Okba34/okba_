/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class ItemChestExplorer
/*    */   extends Item
/*    */ {
/*    */   public ItemChestExplorer()
/*    */   {
/* 18 */     setMaxStackSize(1);
/* 19 */     setUnlocalizedName("chestexplorer");
/* 20 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 21 */     setTextureName("palamod:ChestExplorer");
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ)
/*    */   {
/* 27 */     if (!world.isRemote)
/*    */     {
/* 29 */       TileEntity tile = world.getTileEntity(x, y, z);
/*    */       
/* 31 */       if (tile == null) {
/* 32 */         return false;
/*    */       }
/* 34 */       if (((tile instanceof IInventory)) && (tile.getClass().toString().contains("Chest")) && 
/* 35 */         (!tile.getClass().toString().contains("PaladiumChest"))) {
/* 36 */         player.openGui(PalaMod.instance, 13, world, x, y, z);
/* 37 */         return true;
/*    */       }
/*    */     }
/* 40 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemChestExplorer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */