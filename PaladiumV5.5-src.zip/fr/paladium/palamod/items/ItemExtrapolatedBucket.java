/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.util.MovingObjectPosition.MovingObjectType;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemExtrapolatedBucket extends net.minecraft.item.Item
/*    */ {
/*    */   public ItemExtrapolatedBucket()
/*    */   {
/* 16 */     setMaxStackSize(1);
/* 17 */     setMaxDamage(16);
/* 18 */     setUnlocalizedName("extrapolatedbucket");
/* 19 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 20 */     setTextureName("palamod:ExtrapolatedBucket");
/*    */   }
/*    */   
/*    */ 
/*    */   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
/*    */   {
/* 26 */     MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, true);
/*    */     
/*    */ 
/* 29 */     if (movingobjectposition == null) {
/* 30 */       return par1ItemStack;
/*    */     }
/* 32 */     if (movingobjectposition.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
/* 33 */       int i = movingobjectposition.blockX;
/* 34 */       int j = movingobjectposition.blockY;
/* 35 */       int k = movingobjectposition.blockZ;
/*    */       
/* 37 */       if (!par2World.canMineBlock(par3EntityPlayer, i, j, k)) {
/* 38 */         return par1ItemStack;
/*    */       }
/* 40 */       if (!par3EntityPlayer.canPlayerEdit(i, j, k, movingobjectposition.sideHit, par1ItemStack))
/*    */       {
/* 42 */         return par1ItemStack;
/*    */       }
/* 44 */       Material material = par2World.getBlock(i, j, k).getMaterial();
/* 45 */       int l = par2World.getBlockMetadata(i, j, k);
/*    */       
/* 47 */       if ((material == Material.water) && (l == 0)) {
/* 48 */         par2World.setBlockToAir(i, j, k);
/* 49 */         par1ItemStack.damageItem(1, par3EntityPlayer);
/* 50 */         return par1ItemStack;
/*    */       }
/*    */       
/* 53 */       if ((material == Material.lava) && (l == 0)) {
/* 54 */         par2World.setBlockToAir(i, j, k);
/* 55 */         par1ItemStack.damageItem(1, par3EntityPlayer);
/* 56 */         return par1ItemStack;
/*    */       }
/*    */     }
/*    */     
/* 60 */     return par1ItemStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemExtrapolatedBucket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */