/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemStartBook
/*    */   extends Item
/*    */ {
/*    */   public ItemStartBook()
/*    */   {
/* 15 */     setMaxStackSize(1);
/* 16 */     setUnlocalizedName("startbook");
/* 17 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 18 */     setTextureName("palamod:StartBook");
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 23 */     if (!world.isRemote) {
/* 24 */       player.openGui(PalaMod.instance, 11, world, 0, 0, 0);
/*    */     }
/* 26 */     return stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemStartBook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */