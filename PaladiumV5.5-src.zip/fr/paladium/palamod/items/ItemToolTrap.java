/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemToolTrap extends Item
/*    */ {
/*    */   public ItemToolTrap()
/*    */   {
/* 10 */     setMaxStackSize(1);
/* 11 */     setUnlocalizedName("tooltrap");
/* 12 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 13 */     setTextureName("palamod:ToolTrap");
/*    */   }
/*    */   
/*    */   public boolean isFull3D()
/*    */   {
/* 18 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemToolTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */