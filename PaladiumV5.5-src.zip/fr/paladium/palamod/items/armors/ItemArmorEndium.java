/*    */ package fr.paladium.palamod.items.armors;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.items.weapons.ItemBroadsword;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemArmorEndium extends RepairableArmor
/*    */ {
/* 17 */   static int[] maxRepair = { 9000, 13000, 11000, 8000 };
/*    */   
/*    */   public ItemArmorEndium(int type, String name, String textureName) {
/* 20 */     super(type, maxRepair);
/* 21 */     setUnlocalizedName(name);
/* 22 */     setTextureName("palamod:" + textureName);
/* 23 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
/* 27 */     if (slot == 2) {
/* 28 */       return "palamod:textures/models/EndiumArmor_2.png";
/*    */     }
/* 30 */     return "palamod:textures/models/EndiumArmor_1.png";
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 34 */     if (repair.getItem() == MaterialRegister.ENDIUM_INGOT) {
/* 35 */       return true;
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */   
/*    */   public void onArmorTick(World world, EntityPlayer player, ItemStack stack) {
/* 41 */     if ((world.getTotalWorldTime() % 20L == 0L) && 
/* 42 */       (stack.hasTagCompound()) && 
/* 43 */       (stack.getTagCompound().hasKey("AttributeModifiers"))) {
/* 44 */       NBTTagList list = stack.getTagCompound().getTagList("AttributeModifiers", 10);
/* 45 */       NBTTagList newList = new NBTTagList();
/* 46 */       for (int i = 0; i < list.tagCount(); i++) {
/* 47 */         NBTTagCompound comp = list.getCompoundTagAt(i);
/* 48 */         if (comp.getDouble("Amount") > 0.3D) {
/* 49 */           comp.setDouble("Amount", 0.3D);
/*    */         }
/* 51 */         newList.appendTag(comp);
/*    */       }
/* 53 */       stack.getTagCompound().setTag("AttributeModifiers", newList);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 58 */     switch (this.armorType) {
/*    */     case 0: 
/* 60 */       player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 220, 1));
/* 61 */       if ((player.getCurrentArmor(1) != null) && 
/* 62 */         (player.getCurrentArmor(2) != null) && 
/* 63 */         (player.getCurrentArmor(3) != null) && 
/* 64 */         ((player.getCurrentArmor(1).getItem() instanceof ItemArmorEndium)) && 
/* 65 */         ((player.getCurrentArmor(2).getItem() instanceof ItemArmorEndium)) && 
/* 66 */         ((player.getCurrentArmor(3).getItem() instanceof ItemArmorEndium)))
/* 67 */         player.addPotionEffect(new PotionEffect(Potion.invisibility.id, 10, 256));
/*    */       break;
/*    */     case 1: 
/* 70 */       player.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 50, 0));
/* 71 */       break;
/*    */     case 2: 
/* 73 */       if ((player.getHeldItem() != null) && (!(player.getHeldItem().getItem() instanceof ItemBroadsword)))
/* 74 */         player.addPotionEffect(new PotionEffect(Potion.digSpeed.id, 10, 0));
/*    */       break;
/*    */     case 3: 
/* 77 */       player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 50, 0));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getCost()
/*    */   {
/* 83 */     switch (this.armorType) {
/*    */     case 0: 
/* 85 */       return 5;
/*    */     case 1: 
/* 87 */       return 8;
/*    */     case 2: 
/* 89 */       return 7;
/*    */     case 3: 
/* 91 */       return 4;
/*    */     }
/*    */     
/* 94 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\ItemArmorEndium.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */