/*     */ package fr.paladium.palamod.items.armors;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.items.ItemBackpack;
/*     */ import fr.paladium.palamod.items.ItemHangGlider;
/*     */ import fr.paladium.palamod.items.ItemStuffSwitcher;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
/*     */ import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
/*     */ 
/*     */ 
/*     */ public class EventHandlerArmor
/*     */ {
/*  27 */   public final int BP_TIME = 60;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLiving(LivingEvent.LivingUpdateEvent event) {
/*  31 */     if ((event.entityLiving instanceof EntityPlayer)) {
/*  32 */       EntityPlayer player = (EntityPlayer)event.entityLiving;
/*  33 */       if ((player.getCurrentArmor(3) == null) || (!(player.getCurrentArmor(3).getItem() instanceof ItemArmorTravel)))
/*  34 */         player.stepHeight = 0.5F;
/*  35 */       if ((player.worldObj.isRemote) && 
/*  36 */         (ItemHangGlider.usingHangGliderClient.contains(player)) && ((player.getHeldItem() == null) || 
/*  37 */         (!(player.getHeldItem().getItem() instanceof ItemHangGlider)))) {
/*  38 */         ItemHangGlider.usingHangGliderClient.remove(player);
/*     */       }
/*     */       
/*  41 */       if ((!player.worldObj.isRemote) && 
/*  42 */         (ItemHangGlider.usingHangGliderServer.contains(player)) && ((player.getHeldItem() == null) || 
/*  43 */         (!(player.getHeldItem().getItem() instanceof ItemHangGlider)))) {
/*  44 */         ItemHangGlider.usingHangGliderServer.remove(player);
/*     */       }
/*     */       
/*  47 */       if (player.worldObj.getWorldTime() % 100L == 0L) {
/*  48 */         int backpacks = 0;
/*  49 */         int stuffswitcher = 0;
/*  50 */         int Hanglider = 0;
/*  51 */         for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/*  52 */           ItemStack stack = player.inventory.getStackInSlot(i);
/*  53 */           if ((stack != null) && ((stack.getItem() instanceof ItemBackpack))) {
/*  54 */             backpacks++;
/*  55 */             if (backpacks > 1) {
/*  56 */               player.inventory.setInventorySlotContents(i, null);
/*  57 */               EntityItem eItem = new EntityItem(player.worldObj, player.posX, player.posY, player.posZ, stack);
/*     */               
/*  59 */               if (!player.worldObj.isRemote)
/*  60 */                 player.worldObj.spawnEntityInWorld(eItem);
/*  61 */               player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un sac sur vous !", new Object[0]));
/*     */               
/*  63 */               if (player.worldObj.isRemote) {
/*  64 */                 player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un sac sur vous !", new Object[0]));
/*     */               }
/*     */             }
/*     */           }
/*  68 */           if ((stack != null) && ((stack.getItem() instanceof ItemHangGlider))) {
/*  69 */             Hanglider++;
/*  70 */             if (Hanglider > 1) {
/*  71 */               player.inventory.setInventorySlotContents(i, null);
/*  72 */               EntityItem eItem = new EntityItem(player.worldObj, player.posX, player.posY, player.posZ, stack);
/*     */               
/*  74 */               if (!player.worldObj.isRemote)
/*  75 */                 player.worldObj.spawnEntityInWorld(eItem);
/*  76 */               player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un Hanglider sur vous !", new Object[0]));
/*     */               
/*  78 */               if (player.worldObj.isRemote) {
/*  79 */                 player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un Hanglider sur vous !", new Object[0]));
/*     */               }
/*     */             }
/*     */           }
/*  83 */           if ((stack != null) && ((stack.getItem() instanceof ItemStuffSwitcher))) {
/*  84 */             stuffswitcher++;
/*  85 */             if (stuffswitcher > 1) {
/*  86 */               player.inventory.setInventorySlotContents(i, null);
/*  87 */               EntityItem eItem = new EntityItem(player.worldObj, player.posX, player.posY, player.posZ, stack);
/*     */               
/*  89 */               if (!player.worldObj.isRemote)
/*  90 */                 player.worldObj.spawnEntityInWorld(eItem);
/*  91 */               player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un stuff switcher sur vous !", new Object[0]));
/*     */               
/*  93 */               if (player.worldObj.isRemote) {
/*  94 */                 player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Vous ne pouvez pas avoir plus d'un stuff switcher sur vous !", new Object[0]));
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPickUp(EntityItemPickupEvent event)
/*     */   {
/* 106 */     if ((event.item.getEntityItem().getItem() instanceof ItemBackpack))
/*     */     {
/* 108 */       EntityPlayer player = event.entityPlayer;
/*     */       
/* 110 */       int backpacks = 0;
/* 111 */       for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/* 112 */         ItemStack stack = player.inventory.getStackInSlot(i);
/* 113 */         if ((stack != null) && ((stack.getItem() instanceof ItemBackpack))) {
/* 114 */           backpacks++;
/* 115 */           if (backpacks >= 1) {
/* 116 */             event.setCanceled(true);
/*     */           }
/*     */         }
/*     */       }
/* 120 */       ItemStack bp = event.item.getEntityItem();
/* 121 */       if (!bp.hasTagCompound()) {
/* 122 */         NBTTagCompound tag = new NBTTagCompound();
/* 123 */         tag.setInteger("canPickup", 60);
/* 124 */         bp.setTagCompound(tag);
/*     */       }
/* 126 */       if (!bp.getTagCompound().hasKey("canPickup"))
/* 127 */         bp.getTagCompound().setInteger("canPickup", 60);
/* 128 */       if ((!event.isCanceled()) && (event.entityPlayer.inventory.getFirstEmptyStack() != -1)) {
/* 129 */         int time = bp.getTagCompound().getInteger("canPickup");
/* 130 */         if (time > 0) {
/* 131 */           bp.getTagCompound().setInteger("canPickup", time - 1);
/* 132 */           event.setCanceled(true);
/*     */         }
/*     */         else {
/* 135 */           bp.getTagCompound().setInteger("canPickup", 60);
/*     */         }
/*     */       } else {
/* 138 */         bp.getTagCompound().setInteger("canPickup", 60);
/*     */       }
/*     */     }
/* 141 */     if ((event.item.getEntityItem().getItem() instanceof ItemStuffSwitcher))
/*     */     {
/* 143 */       EntityPlayer player = event.entityPlayer;
/*     */       
/* 145 */       int stuffswitcher = 0;
/* 146 */       for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/* 147 */         ItemStack stack = player.inventory.getStackInSlot(i);
/* 148 */         if ((stack != null) && ((stack.getItem() instanceof ItemStuffSwitcher))) {
/* 149 */           stuffswitcher++;
/* 150 */           if (stuffswitcher >= 1) {
/* 151 */             event.setCanceled(true);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 156 */       ItemStack bp = event.item.getEntityItem();
/* 157 */       if (!bp.hasTagCompound()) {
/* 158 */         NBTTagCompound tag = new NBTTagCompound();
/* 159 */         tag.setInteger("canPickup", 60);
/* 160 */         bp.setTagCompound(tag);
/*     */       }
/* 162 */       if (!bp.getTagCompound().hasKey("canPickup"))
/* 163 */         bp.getTagCompound().setInteger("canPickup", 60);
/* 164 */       if (!event.isCanceled()) {
/* 165 */         int time = bp.getTagCompound().getInteger("canPickup");
/* 166 */         if (time > 0) {
/* 167 */           bp.getTagCompound().setInteger("canPickup", time - 1);
/* 168 */           event.setCanceled(true);
/*     */         }
/*     */         else {
/* 171 */           bp.getTagCompound().setInteger("canPickup", 60);
/*     */         }
/*     */       } }
/* 174 */     if ((event.item.getEntityItem().getItem() instanceof ItemHangGlider))
/*     */     {
/* 176 */       EntityPlayer player = event.entityPlayer;
/*     */       
/* 178 */       int hanglider = 0;
/* 179 */       for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/* 180 */         ItemStack stack = player.inventory.getStackInSlot(i);
/* 181 */         if ((stack != null) && ((stack.getItem() instanceof ItemHangGlider))) {
/* 182 */           hanglider++;
/* 183 */           if (hanglider >= 1) {
/* 184 */             event.setCanceled(true);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 189 */       ItemStack bp = event.item.getEntityItem();
/* 190 */       if (!bp.hasTagCompound()) {
/* 191 */         NBTTagCompound tag = new NBTTagCompound();
/* 192 */         tag.setInteger("canPickup", 60);
/* 193 */         bp.setTagCompound(tag);
/*     */       }
/* 195 */       if (!bp.getTagCompound().hasKey("canPickup"))
/* 196 */         bp.getTagCompound().setInteger("canPickup", 60);
/* 197 */       if (!event.isCanceled()) {
/* 198 */         int time = bp.getTagCompound().getInteger("canPickup");
/* 199 */         if (time > 0) {
/* 200 */           bp.getTagCompound().setInteger("canPickup", time - 1);
/* 201 */           event.setCanceled(true);
/*     */         }
/*     */         else {
/* 204 */           bp.getTagCompound().setInteger("canPickup", 60);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=EventPriority.NORMAL)
/* 212 */   public void nameTag(RenderLivingEvent.Specials.Pre event) { EntityPlayer player = Minecraft.getMinecraft().thePlayer;
/* 213 */     if ((event.entity instanceof EntityPlayer)) {
/* 214 */       ItemStack helmet = ((EntityPlayer)event.entity).inventory.armorItemInSlot(3);
/* 215 */       if ((helmet != null) && ((helmet.getItem() instanceof ItemArmorTravel)) && 
/* 216 */         (((ItemArmorTravel)helmet.getItem()).getType() == 5)) {
/* 217 */         event.setCanceled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\EventHandlerArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */