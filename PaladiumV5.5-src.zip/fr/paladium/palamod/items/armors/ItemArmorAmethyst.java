/*    */ package fr.paladium.palamod.items.armors;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ArmorMaterials;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemArmorAmethyst extends ItemArmor
/*    */ {
/*    */   public ItemArmorAmethyst(int type, String name, String textureName)
/*    */   {
/* 14 */     super(ArmorMaterials.armorAmethyst, 0, type);
/* 15 */     setUnlocalizedName(name);
/* 16 */     setTextureName("palamod:" + textureName);
/* 17 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
/* 21 */     if (slot == 2) {
/* 22 */       return "palamod:textures/models/AmethystArmor_2.png";
/*    */     }
/* 24 */     return "palamod:textures/models/AmethystArmor_1.png";
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 28 */     if (repair.getItem() == MaterialRegister.AMETHYST_INGOT) {
/* 29 */       return true;
/*    */     }
/* 31 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\ItemArmorAmethyst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */