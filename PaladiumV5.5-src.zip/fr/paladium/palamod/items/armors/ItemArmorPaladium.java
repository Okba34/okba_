/*    */ package fr.paladium.palamod.items.armors;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.items.weapons.ItemBroadsword;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemArmorPaladium
/*    */   extends RepairableArmor
/*    */ {
/* 18 */   static int[] maxRepair = { 8000, 12000, 10000, 7000 };
/*    */   
/*    */   public ItemArmorPaladium(int type, String name, String textureName) {
/* 21 */     super(type, maxRepair);
/* 22 */     setUnlocalizedName(name);
/* 23 */     setTextureName("palamod:" + textureName);
/* 24 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
/* 28 */     if (slot == 2) {
/* 29 */       return "palamod:textures/models/PaladiumArmor_2.png";
/*    */     }
/* 31 */     return "palamod:textures/models/PaladiumArmor_1.png";
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 35 */     if (repair.getItem() == MaterialRegister.PALADIUM_INGOT) {
/* 36 */       return true;
/*    */     }
/* 38 */     return false;
/*    */   }
/*    */   
/*    */   public void onArmorTick(World world, EntityPlayer player, ItemStack stack) {
/* 42 */     if ((world.getTotalWorldTime() % 20L == 0L) && 
/* 43 */       (stack.hasTagCompound()) && 
/* 44 */       (stack.getTagCompound().hasKey("AttributeModifiers"))) {
/* 45 */       NBTTagList list = stack.getTagCompound().getTagList("AttributeModifiers", 10);
/* 46 */       NBTTagList newList = new NBTTagList();
/* 47 */       for (int i = 0; i < list.tagCount(); i++) {
/* 48 */         NBTTagCompound comp = list.getCompoundTagAt(i);
/* 49 */         if (comp.getDouble("Amount") > 0.3D) {
/* 50 */           comp.setDouble("Amount", 0.3D);
/*    */         }
/* 52 */         newList.appendTag(comp);
/*    */       }
/* 54 */       stack.getTagCompound().setTag("AttributeModifiers", newList);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 59 */     switch (this.armorType) {
/*    */     case 0: 
/* 61 */       player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 220, 1));
/* 62 */       break;
/*    */     case 1: 
/* 64 */       player.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 50, 0));
/* 65 */       break;
/*    */     case 2: 
/* 67 */       if ((player.getHeldItem() != null) && (!(player.getHeldItem().getItem() instanceof ItemBroadsword)))
/* 68 */         player.addPotionEffect(new PotionEffect(Potion.digSpeed.id, 10, 0));
/*    */       break;
/*    */     case 3: 
/* 71 */       player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 50, 0));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getCost()
/*    */   {
/* 77 */     switch (this.armorType) {
/*    */     case 0: 
/* 79 */       return 5;
/*    */     case 1: 
/* 81 */       return 8;
/*    */     case 2: 
/* 83 */       return 7;
/*    */     case 3: 
/* 85 */       return 4;
/*    */     }
/*    */     
/* 88 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\ItemArmorPaladium.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */