/*    */ package fr.paladium.palamod.items.armors;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemArmor.ArmorMaterial;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ public class ItemArmorTravel extends ItemArmor
/*    */ {
/*    */   public static final int TRAVEL_BOOTS = 0;
/*    */   public static final int TRAVEL_LEGGINGS = 1;
/*    */   public static final int JUMP_CHEST = 2;
/*    */   public static final int SLIMY_HELMET = 3;
/*    */   public static final int SCUBA_HELMET = 4;
/*    */   public static final int HOOD_HELMET = 5;
/*    */   public int id;
/*    */   
/*    */   public ItemArmorTravel(int type, String name, String textureName, int id)
/*    */   {
/* 30 */     super(ItemArmor.ArmorMaterial.IRON, 0, type);
/* 31 */     setUnlocalizedName(name);
/* 32 */     setTextureName("palamod:" + textureName);
/* 33 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/* 34 */     setMaxStackSize(1);
/* 35 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getArmorTexture(ItemStack stack, Entity entity, int slot, String type) {
/* 39 */     switch (this.id) {
/*    */     case 5: 
/* 41 */       return "palamod:textures/models/HoodHelmet.png";
/*    */     case 2: 
/* 43 */       return "palamod:textures/models/JumpArmor.png";
/*    */     case 4: 
/* 45 */       return "palamod:textures/models/ScubaArmor.png";
/*    */     case 3: 
/* 47 */       return "palamod:textures/models/Slimy_Helmet.png";
/*    */     }
/* 49 */     return "palamod:textures/models/PaladiumArmor_1.png";
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 53 */     if (repair.getItem() == net.minecraft.init.Items.iron_ingot) {
/* 54 */       return true;
/*    */     }
/* 56 */     return false;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 60 */     return this.id;
/*    */   }
/*    */   
/*    */   public void onArmorTick(World world, EntityPlayer player, ItemStack stack) {
/* 64 */     switch (this.id) {
/*    */     case 3: 
/* 66 */       player.fallDistance = 0.0F;
/* 67 */       if (world.isRemote) {
/* 68 */         int l = MathHelper.floor_double(player.posX);
/* 69 */         int i1 = MathHelper.floor_double(player.posY + 1.0D);
/* 70 */         int j1 = MathHelper.floor_double(player.posZ);
/* 71 */         if (world.getBlock(l, i1, j1).getMaterial().isSolid()) {
/* 72 */           if (Keyboard.isKeyDown(Minecraft.getMinecraft().gameSettings.keyBindJump.getKeyCode())) {
/* 73 */             player.motionY = 0.1D;
/*    */           } else
/* 75 */             player.motionY *= 0.6D;
/*    */         }
/*    */       }
/* 78 */       break;
/*    */     
/*    */     case 4: 
/* 81 */       player.setAir(300);
/* 82 */       break;
/*    */     case 2: 
/* 84 */       player.addPotionEffect(new PotionEffect(Potion.jump.id, 50, 2));
/* 85 */       break;
/*    */     case 1: 
/* 87 */       player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 10, 2));
/* 88 */       break;
/*    */     case 0: 
/* 90 */       player.stepHeight = 1.0F;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\ItemArmorTravel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */