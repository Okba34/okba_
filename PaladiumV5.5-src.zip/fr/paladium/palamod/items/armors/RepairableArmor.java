/*    */ package fr.paladium.palamod.items.armors;
/*    */ 
/*    */ import fr.paladium.palamod.common.ArmorMaterials;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ public class RepairableArmor
/*    */   extends ItemArmor
/*    */ {
/*    */   int[] maxRepair;
/*    */   
/*    */   public RepairableArmor(int type, int[] maxRepair)
/*    */   {
/* 17 */     super(ArmorMaterials.armorPaladium, 0, type);
/* 18 */     this.maxRepair = maxRepair;
/*    */   }
/*    */   
/*    */   public int getRepair(ItemStack armor) {
/* 22 */     if ((!armor.hasTagCompound()) || (!armor.getTagCompound().hasKey("repaired"))) { NBTTagCompound tag;
/*    */       NBTTagCompound tag;
/* 24 */       if (!armor.hasTagCompound()) {
/* 25 */         tag = new NBTTagCompound();
/*    */       } else
/* 27 */         tag = armor.getTagCompound();
/* 28 */       tag.setInteger("repaired", ((RepairableArmor)armor.getItem()).getMaxRepair(armor));
/* 29 */       armor.setTagCompound(tag);
/*    */     }
/*    */     
/* 32 */     return armor.getTagCompound().getInteger("repaired");
/*    */   }
/*    */   
/*    */   public int getMaxRepair(ItemStack stack) {
/* 36 */     return this.maxRepair[this.armorType];
/*    */   }
/*    */   
/*    */   public void repair(ItemStack armor, ItemStack ring) {
/* 40 */     if ((!armor.hasTagCompound()) || (!armor.getTagCompound().hasKey("repaired"))) { NBTTagCompound tag;
/*    */       NBTTagCompound tag;
/* 42 */       if (!armor.hasTagCompound()) {
/* 43 */         tag = new NBTTagCompound();
/*    */       } else
/* 45 */         tag = armor.getTagCompound();
/* 46 */       tag.setInteger("repaired", ((RepairableArmor)armor.getItem()).getMaxRepair(armor));
/* 47 */       armor.setTagCompound(tag);
/*    */     }
/*    */     
/* 50 */     if ((armor.getItemDamage() > 0) && (ring.getItemDamage() < ring.getMaxDamage()) && 
/* 51 */       (getRepair(armor) > 0)) {
/* 52 */       ring.setItemDamage(ring.getItemDamage() + 1);
/* 53 */       armor.setItemDamage(armor.getItemDamage() - 1);
/* 54 */       armor.getTagCompound().setInteger("repaired", armor.getTagCompound().getInteger("repaired") - 1);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 61 */     super.addInformation(stack, player, list, b);
/* 62 */     list.add("RÃ©paration rÃ©stantes : " + getRepair(stack) + "/" + getMaxRepair(stack));
/*    */   }
/*    */   
/*    */   public static float getFraction(ItemStack stack) {
/* 66 */     if (!(stack.getItem() instanceof RepairableArmor)) {
/* 67 */       return 0.0F;
/*    */     }
/* 69 */     return ((RepairableArmor)stack.getItem()).getRepair(stack) / ((RepairableArmor)stack.getItem()).getMaxRepair(stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\armors\RepairableArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */