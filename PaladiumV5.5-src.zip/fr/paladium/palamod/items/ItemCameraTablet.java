/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.paladium.block.BlockCamera;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemCameraTablet
/*    */   extends Item
/*    */ {
/*    */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ)
/*    */   {
/* 30 */     if ((player.isSneaking()) && ((world.getBlock(x, y, z) instanceof BlockCamera))) {
/* 31 */       if (!stack.hasTagCompound()) {
/* 32 */         stack.setTagCompound(new NBTTagCompound());
/* 33 */         stack.getTagCompound().setBoolean("cam1", false);
/* 34 */         stack.getTagCompound().setBoolean("cam2", false);
/* 35 */         stack.getTagCompound().setBoolean("cam3", false);
/* 36 */         stack.getTagCompound().setInteger("Index", 0);
/*    */       }
/*    */       
/* 39 */       NBTTagCompound compound = stack.getTagCompound();
/* 40 */       boolean flag = false;
/*    */       
/* 42 */       if (!compound.getBoolean("cam1")) {
/* 43 */         compound.setBoolean("cam1", true);
/* 44 */         compound.setInteger("cam1X", x);
/* 45 */         compound.setInteger("cam1Y", y);
/* 46 */         compound.setInteger("cam1Z", z);
/* 47 */         compound.setInteger("cam1Yaw", world.getBlockMetadata(x, y, z));
/* 48 */         flag = true;
/* 49 */       } else if (!compound.getBoolean("cam2")) {
/* 50 */         compound.setBoolean("cam2", true);
/* 51 */         compound.setInteger("cam2X", x);
/* 52 */         compound.setInteger("cam2Y", y);
/* 53 */         compound.setInteger("cam2Z", z);
/* 54 */         compound.setInteger("cam2Yaw", world.getBlockMetadata(x, y, z));
/* 55 */         flag = true;
/* 56 */       } else if (!compound.getBoolean("cam3")) {
/* 57 */         compound.setBoolean("cam3", true);
/* 58 */         compound.setInteger("cam3X", x);
/* 59 */         compound.setInteger("cam3Y", y);
/* 60 */         compound.setInteger("cam3Z", z);
/* 61 */         compound.setInteger("cam3Yaw", world.getBlockMetadata(x, y, z));
/* 62 */         flag = true;
/*    */       }
/*    */       
/* 65 */       if (flag) {
/* 66 */         stack.setTagCompound(compound);
/* 67 */         return true;
/*    */       }
/*    */     }
/* 70 */     return false;
/*    */   }
/*    */   
/*    */   public static boolean isWorking(ItemStack stack) {
/* 74 */     if ((stack != null) && ((stack.getItem() instanceof ItemCameraTablet)) && (stack.hasTagCompound())) {
/* 75 */       return (stack.getTagCompound().getBoolean("cam1")) || (stack.getTagCompound().getBoolean("cam2")) || 
/* 76 */         (stack.getTagCompound().getBoolean("cam3"));
/*    */     }
/* 78 */     return false;
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 83 */     if (!player.isSneaking())
/* 84 */       player.openGui(PalaMod.instance, 27, world, 0, 0, 0);
/* 85 */     return stack;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onBlockDestroyed(ItemStack stack, World world, Block block, int x, int y, int z, EntityLivingBase entity)
/*    */   {
/* 91 */     if ((stack != null) && (stack.hasTagCompound()) && ((entity instanceof EntityPlayer))) {
/* 92 */       ((EntityPlayer)entity).addChatComponentMessage(new ChatComponentText(stack.getTagCompound().toString()));
/* 93 */       return true;
/*    */     }
/* 95 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemCameraTablet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */