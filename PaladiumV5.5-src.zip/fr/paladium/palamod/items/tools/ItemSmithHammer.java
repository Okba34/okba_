/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item.ToolMaterial;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemSmithHammer extends ItemHammer
/*    */ {
/*    */   public ItemSmithHammer()
/*    */   {
/* 15 */     super(Item.ToolMaterial.WOOD);
/* 16 */     setMaxDamage(10);
/* 17 */     setUnlocalizedName("smithhammer");
/* 18 */     setTextureName("palamod:IronSmithHammer");
/* 19 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ)
/*    */   {
/* 25 */     if (!(world.getBlock(x, y, z) instanceof net.minecraft.block.BlockAnvil)) {
/* 26 */       return false;
/*    */     }
/* 28 */     int meta = world.getBlockMetadata(x, y, z);
/* 29 */     if (meta == 0) {
/* 30 */       return false;
/*    */     }
/* 32 */     world.setBlockToAir(x, y, z);
/* 33 */     world.setBlock(x, y, z, net.minecraft.init.Blocks.anvil, meta - 4, 0);
/* 34 */     if (!player.capabilities.isCreativeMode) {
/* 35 */       stack.damageItem(1, player);
/*    */     }
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 41 */     if (repair.getItem() == Items.iron_ingot) {
/* 42 */       return true;
/*    */     }
/* 44 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemSmithHammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */