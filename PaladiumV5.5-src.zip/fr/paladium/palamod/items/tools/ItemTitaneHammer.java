/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ 
/*    */ public class ItemTitaneHammer extends ItemHammer
/*    */ {
/*    */   public ItemTitaneHammer()
/*    */   {
/* 10 */     super(ToolMaterialPaladium.toolTypeTitane);
/* 11 */     setUnlocalizedName("titanehammer");
/* 12 */     setTextureName("palamod:TitaneHammer");
/* 13 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemTitaneHammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */