/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ 
/*    */ public class ItemAmethystHammer extends ItemHammer
/*    */ {
/*    */   public ItemAmethystHammer()
/*    */   {
/* 10 */     super(ToolMaterialPaladium.toolTypeAmethyst);
/* 11 */     setUnlocalizedName("amethysthammer");
/* 12 */     setTextureName("palamod:AmethystHammer");
/* 13 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemAmethystHammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */