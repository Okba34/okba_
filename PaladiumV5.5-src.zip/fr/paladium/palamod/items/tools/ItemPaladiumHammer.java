/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ import fr.paladium.palamod.util.ToolHandler;
/*    */ import fr.paladium.palamod.util.UpgradeHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ 
/*    */ public class ItemPaladiumHammer
/*    */   extends ItemHammer
/*    */ {
/*    */   public ItemPaladiumHammer()
/*    */   {
/* 20 */     super(ToolMaterialPaladium.toolTypePaladium);
/* 21 */     setUnlocalizedName("paladiumhammer");
/* 22 */     setTextureName("palamod:PaladiumHammer");
/* 23 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 28 */     int[] modifiers = UpgradeHelper.getUpgradeAmmount(stack);
/* 29 */     if (modifiers == null)
/* 30 */       return;
/* 31 */     if (modifiers.length != 0) {
/* 32 */       list.add("§l§nUpgrades:");
/* 33 */       list.add("");
/*    */     }
/* 35 */     for (int i = 0; i < modifiers.length; i += 2) {
/* 36 */       if (modifiers[i] != 7) {
/* 37 */         int level = UpgradeHelper.getModifier(stack, modifiers[i]);
/* 38 */         String display = "" + level;
/* 39 */         if (level <= 1)
/* 40 */           display = "";
/* 41 */         list.add(UpgradeHelper.getUpgradeName(modifiers[i]) + " " + display);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void breakOtherBlock(EntityPlayer player, ItemStack stack, int x, int y, int z, int originX, int originY, int originZ, int side)
/*    */   {
/* 50 */     World world = player.worldObj;
/* 51 */     Material mat = world.getBlock(x, y, z).getMaterial();
/*    */     
/* 53 */     if (world.isAirBlock(x, y, z)) {
/* 54 */       return;
/*    */     }
/* 56 */     ForgeDirection direction = ForgeDirection.getOrientation(side);
/* 57 */     int fortune = UpgradeHelper.getModifier(stack, 1);
/* 58 */     boolean smelt = UpgradeHelper.getModifier(stack, 0) == 1;
/* 59 */     boolean obsidian = UpgradeHelper.getModifier(stack, 6) == 1;
/*    */     
/* 61 */     int range = Math.max(0, 1);
/* 62 */     int rangeY = Math.max(1, range);
/*    */     
/* 64 */     boolean doX = direction.offsetX == 0;
/* 65 */     boolean doY = direction.offsetY == 0;
/* 66 */     boolean doZ = direction.offsetZ == 0;
/*    */     
/* 68 */     ToolHandler.removeBlocksInIteration(player, stack, world, x, y, z, doX ? -range : 0, doY ? -1 : 0, doZ ? -range : 0, doX ? range + 1 : 1, doY ? rangeY * 2 : 1, doZ ? range + 1 : 1, null, MATERIALS, smelt, fortune, true, obsidian);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public float getDigSpeed(ItemStack stack, Block block, int meta)
/*    */   {
/* 75 */     return super.getDigSpeed(stack, block, meta) * (UpgradeHelper.getModifier(stack, 2) + 1);
/*    */   }
/*    */   
/*    */   public boolean isBookEnchantable(ItemStack stack, ItemStack book)
/*    */   {
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemPaladiumHammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */