/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ import net.minecraft.item.ItemAxe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemEndiumAxe extends ItemAxe
/*    */ {
/*    */   public ItemEndiumAxe()
/*    */   {
/* 12 */     super(ToolMaterialPaladium.toolTypePaladium);
/* 13 */     setUnlocalizedName("endiumaxe");
/* 14 */     setTextureName("palamod:EndiumAxe");
/* 15 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 19 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemEndiumAxe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */