/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.util.ToolHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item.ToolMaterial;
/*    */ import net.minecraft.item.ItemPickaxe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.util.ForgeDirection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemHammer
/*    */   extends ItemPickaxe
/*    */ {
/* 22 */   protected static final Material[] MATERIALS = { Material.rock, Material.iron, Material.ice, Material.glass, Material.piston, Material.anvil, Material.snow, Material.craftedSnow, Material.clay };
/*    */   
/*    */   public ItemHammer(Item.ToolMaterial material)
/*    */   {
/* 26 */     super(material);
/* 27 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean onBlockStartBreak(ItemStack stack, int x, int y, int z, EntityPlayer player)
/*    */   {
/* 32 */     MovingObjectPosition raycast = ToolHandler.raytraceFromEntity(player.worldObj, player, true, 10.0D);
/* 33 */     if (raycast != null) {
/* 34 */       breakOtherBlock(player, stack, x, y, z, x, y, z, raycast.sideHit);
/* 35 */       stack.damageItem(1, player);
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */   
/*    */   public int getItemEnchantability()
/*    */   {
/* 42 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean isBookEnchantable(ItemStack stack, ItemStack book)
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   public float getDigSpeed(ItemStack stack, Block block, int meta)
/*    */   {
/* 52 */     return super.getDigSpeed(stack, block, meta) / 9.0F;
/*    */   }
/*    */   
/*    */   public void breakOtherBlock(EntityPlayer player, ItemStack stack, int x, int y, int z, int originX, int originY, int originZ, int side)
/*    */   {
/* 57 */     World world = player.worldObj;
/* 58 */     Material mat = world.getBlock(x, y, z).getMaterial();
/*    */     
/* 60 */     if (world.isAirBlock(x, y, z)) {
/* 61 */       return;
/*    */     }
/* 63 */     ForgeDirection direction = ForgeDirection.getOrientation(side);
/*    */     
/* 65 */     int range = Math.max(0, 1);
/* 66 */     int rangeY = Math.max(1, range);
/*    */     
/* 68 */     boolean doX = direction.offsetX == 0;
/* 69 */     boolean doY = direction.offsetY == 0;
/* 70 */     boolean doZ = direction.offsetZ == 0;
/*    */     
/* 72 */     ToolHandler.removeBlocksInIteration(player, stack, world, x, y, z, doX ? -range : 0, doY ? -1 : 0, doZ ? -range : 0, doX ? range + 1 : 1, doY ? rangeY * 2 : 1, doZ ? range + 1 : 1, null, MATERIALS, false, 0, true, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemHammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */