/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.item.ItemSpade;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemTitaneShovel extends ItemSpade
/*    */ {
/*    */   public ItemTitaneShovel()
/*    */   {
/* 13 */     super(ToolMaterialPaladium.toolTypeTitane);
/* 14 */     setUnlocalizedName("titaneshovel");
/* 15 */     setTextureName("palamod:TitaneShovel");
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 20 */     if (repair.getItem() == MaterialRegister.TITANE_INGOT) {
/* 21 */       return true;
/*    */     }
/* 23 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemTitaneShovel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */