/*    */ package fr.paladium.palamod.items.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ import net.minecraft.item.ItemPickaxe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemEndiumPickaxe extends ItemPickaxe
/*    */ {
/*    */   public ItemEndiumPickaxe()
/*    */   {
/* 12 */     super(ToolMaterialPaladium.toolTypePaladium);
/* 13 */     setUnlocalizedName("endiumpickaxe");
/* 14 */     setTextureName("palamod:EndiumPickaxe");
/* 15 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 19 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\tools\ItemEndiumPickaxe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */