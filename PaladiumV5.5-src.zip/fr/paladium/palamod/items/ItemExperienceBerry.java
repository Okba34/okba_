/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemExperienceBerry
/*    */   extends Item
/*    */ {
/*    */   public ItemExperienceBerry()
/*    */   {
/* 14 */     setMaxStackSize(64);
/* 15 */     setUnlocalizedName("experienceberry");
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 17 */     setTextureName("palamod:ExperienceBerry");
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 22 */     stack.stackSize -= 1;
/* 23 */     player.addExperience(10);
/* 24 */     return stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemExperienceBerry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */