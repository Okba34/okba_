/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.entities.projectiles.EntityPotionGun;
/*    */ import fr.paladium.palamod.entities.projectiles.EntitySplashPotion;
/*    */ import fr.paladium.palamod.items.ItemSplashPotion;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemPotion;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemPotionLauncher extends Item
/*    */ {
/*    */   public ItemPotionLauncher()
/*    */   {
/* 19 */     setMaxStackSize(1);
/* 20 */     setUnlocalizedName("potionlauncher");
/* 21 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 22 */     setTextureName("palamod:PotionLauncher");
/* 23 */     setMaxDamage(256);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 28 */     if (checkForPotion(player.inventory) != -1) {
/* 29 */       int potionSlot = checkForPotion(player.inventory);
/* 30 */       ItemStack potionStack = player.inventory.getStackInSlot(potionSlot);
/* 31 */       if (potionStack != null) if (!(potionStack.getItem() instanceof ItemSplashPotion)) { ((ItemPotion)potionStack.getItem()); if (!ItemPotion.isSplash(potionStack.getItemDamage())) {}
/* 32 */         } else { world.playSoundAtEntity(player, "random.bow", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
/* 33 */           potionStack.stackSize -= 1;
/* 34 */           if (!world.isRemote) {
/* 35 */             if ((potionStack.getItem() instanceof ItemPotion)) {
/* 36 */               world.spawnEntityInWorld(new EntityPotionGun(world, player, potionStack));
/*    */             } else
/* 38 */               world.spawnEntityInWorld(new EntitySplashPotion(world, player, potionStack.getItemDamage(), true));
/*    */           }
/* 40 */           if (potionStack.stackSize <= 0)
/* 41 */             potionStack = null;
/* 42 */           player.inventory.setInventorySlotContents(potionSlot, potionStack);
/*    */         }
/* 44 */       return stack;
/*    */     }
/*    */     
/* 47 */     return stack;
/*    */   }
/*    */   
/*    */   public boolean isFull3D()
/*    */   {
/* 52 */     return true;
/*    */   }
/*    */   
/*    */   private int checkForPotion(InventoryPlayer inventory) {
/* 56 */     int i = 0;
/* 57 */     for (i = 0; i < inventory.getSizeInventory(); i++) {
/* 58 */       if ((inventory.getStackInSlot(i) != null) && (((inventory.getStackInSlot(i).getItem() instanceof ItemPotion)) || 
/* 59 */         ((inventory.getStackInSlot(i).getItem() instanceof ItemSplashPotion))))
/* 60 */         return i;
/*    */     }
/* 62 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemPotionLauncher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */