/*     */ package fr.paladium.palamod.items.weapons;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.EventBus;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.entities.projectiles.EntityCustomArrow;
/*     */ import fr.paladium.palamod.items.ItemArrowBase;
/*     */ import fr.paladium.palamod.util.BowHelper;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.entity.projectile.EntityArrow;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.player.ArrowLooseEvent;
/*     */ import net.minecraftforge.event.entity.player.ArrowNockEvent;
/*     */ 
/*     */ public class ItemPaladiumBow extends ItemBow
/*     */ {
/*  30 */   public static final String[] bowPullIconNames = { "PaladiumBow_0", "PaladiumBow_1", "PaladiumBow_2" };
/*     */   private IIcon[] iconArray;
/*     */   public IIcon iconSpeed;
/*     */   public IIcon iconRange;
/*     */   
/*     */   public ItemPaladiumBow()
/*     */   {
/*  37 */     setMaxDamage(900);
/*  38 */     setMaxStackSize(1);
/*  39 */     setUnlocalizedName("paladiumbow");
/*  40 */     setTextureName("palamod:PaladiumBow");
/*  41 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public void onPlayerStoppedUsing(ItemStack stack, World world, EntityPlayer player, int time)
/*     */   {
/*  46 */     int maxItemUse = getMaxItemUseDuration(stack) - time;
/*  47 */     ArrowLooseEvent event = new ArrowLooseEvent(player, stack, maxItemUse);
/*     */     
/*  49 */     if (event.isCanceled()) {
/*  50 */       return;
/*     */     }
/*  52 */     maxItemUse = event.charge;
/*  53 */     MinecraftForge.EVENT_BUS.post(event);
/*  54 */     ItemStack ammo = checkForAmmo(player);
/*  55 */     if ((ammo.getItem() instanceof ItemArrowBase))
/*     */     {
/*  57 */       boolean infiniteAmmo = (!player.capabilities.isCreativeMode) && (EnchantmentHelper.getEnchantmentLevel(Enchantment.infinity.effectId, stack) <= 0);
/*  58 */       if ((ammo == null) && (!infiniteAmmo)) return;
/*     */       int type;
/*     */       int type;
/*  61 */       if (ammo != null) {
/*  62 */         type = ((ItemArrowBase)ammo.getItem()).getEffect();
/*     */       } else
/*  64 */         type = 0;
/*  65 */       float scaledItemUse = maxItemUse / 20.0F;
/*  66 */       if (!BowHelper.canApply(stack, 1))
/*  67 */         scaledItemUse *= 2.0F;
/*  68 */       scaledItemUse = (scaledItemUse * scaledItemUse + scaledItemUse * 2.0F) / 3.0F;
/*  69 */       if (scaledItemUse < 0.1D)
/*  70 */         return;
/*  71 */       if (scaledItemUse > 1.0F)
/*  72 */         scaledItemUse = 1.0F;
/*  73 */       int[] modifiers = BowHelper.getModifiers(stack);
/*  74 */       float range = 1.5F;
/*  75 */       if (BowHelper.canApply(stack, 0))
/*  76 */         range = 2.5F;
/*  77 */       EntityCustomArrow entityarrow = new EntityCustomArrow(world, player, scaledItemUse * range / 2.0F, type, infiniteAmmo);
/*     */       
/*  79 */       if (scaledItemUse == 1.0F)
/*  80 */         entityarrow.setIsCritical(true);
/*  81 */       int powerLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId, stack);
/*  82 */       if (powerLevel > 0)
/*  83 */         entityarrow.setDamage(entityarrow.getDamage() + powerLevel * 0.5D + 0.5D);
/*  84 */       int punchLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.punch.effectId, stack);
/*  85 */       if (punchLevel > 0)
/*  86 */         entityarrow.setKnockbackStrength(punchLevel);
/*  87 */       if (EnchantmentHelper.getEnchantmentLevel(Enchantment.flame.effectId, stack) > 0)
/*  88 */         entityarrow.setFire(100);
/*  89 */       stack.damageItem(1, player);
/*  90 */       world.playSoundAtEntity(player, "random.bow", 1.0F, 1.0F / (itemRand
/*  91 */         .nextFloat() * 0.4F + 1.2F) + scaledItemUse * 0.5F);
/*  92 */       if (infiniteAmmo)
/*  93 */         player.inventory.consumeInventoryItem(ammo.getItem());
/*  94 */       if (!world.isRemote)
/*  95 */         world.spawnEntityInWorld(entityarrow);
/*     */     }
/*  97 */     if (ammo.getItem() == Items.arrow)
/*     */     {
/*  99 */       boolean infiniteAmmo = (!player.capabilities.isCreativeMode) && (EnchantmentHelper.getEnchantmentLevel(Enchantment.infinity.effectId, stack) <= 0);
/* 100 */       if ((ammo == null) && (!infiniteAmmo))
/* 101 */         return;
/* 102 */       float scaledItemUse = maxItemUse / 20.0F;
/* 103 */       if (!BowHelper.canApply(stack, 1))
/* 104 */         scaledItemUse *= 2.0F;
/* 105 */       scaledItemUse = (scaledItemUse * scaledItemUse + scaledItemUse * 2.0F) / 3.0F;
/* 106 */       if (scaledItemUse < 0.1D)
/* 107 */         return;
/* 108 */       if (scaledItemUse > 1.0F)
/* 109 */         scaledItemUse = 1.0F;
/* 110 */       int[] modifiers = BowHelper.getModifiers(stack);
/* 111 */       float range = 3.0F;
/* 112 */       if (BowHelper.canApply(stack, 0))
/* 113 */         range = 4.0F;
/* 114 */       EntityArrow entityarrow = new EntityArrow(world, player, scaledItemUse * range / 2.0F);
/* 115 */       if (scaledItemUse == 1.0F)
/* 116 */         entityarrow.setIsCritical(true);
/* 117 */       int powerLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId, stack);
/* 118 */       if (powerLevel > 0)
/* 119 */         entityarrow.setDamage(entityarrow.getDamage() + powerLevel * 0.5D + 0.5D);
/* 120 */       int punchLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.punch.effectId, stack);
/* 121 */       if (punchLevel > 0)
/* 122 */         entityarrow.setKnockbackStrength(punchLevel);
/* 123 */       if (EnchantmentHelper.getEnchantmentLevel(Enchantment.flame.effectId, stack) > 0)
/* 124 */         entityarrow.setFire(100);
/* 125 */       stack.damageItem(1, player);
/* 126 */       world.playSoundAtEntity(player, "random.bow", 1.0F, 1.0F / (itemRand
/* 127 */         .nextFloat() * 0.4F + 1.2F) + scaledItemUse * 0.5F);
/* 128 */       if (infiniteAmmo)
/* 129 */         player.inventory.consumeInventoryItem(ammo.getItem());
/* 130 */       if (!world.isRemote)
/* 131 */         world.spawnEntityInWorld(entityarrow);
/*     */     }
/*     */   }
/*     */   
/*     */   private ItemStack checkForAmmo(EntityPlayer player) {
/* 136 */     InventoryPlayer inventory = player.inventory;
/*     */     
/* 138 */     for (int i = 0; i < inventory.getSizeInventory(); i++) {
/* 139 */       ItemStack result = inventory.getStackInSlot(i);
/* 140 */       if ((result != null) && (((result.getItem() instanceof ItemArrowBase)) || (result.getItem() == Items.arrow)))
/* 141 */         return result;
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean par4) {
/* 147 */     int[] modifiers = BowHelper.getModifiers(stack);
/* 148 */     if (modifiers == null)
/* 149 */       return;
/* 150 */     if (modifiers.length != 0) {
/* 151 */       list.add("\\u00an Modifiers:");
/* 152 */       list.add("");
/*     */     }
/* 154 */     for (int i = 0; i < modifiers.length; i++) {
/* 155 */       list.add(BowHelper.getModifierName(modifiers[i]));
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack onEaten(ItemStack stack, World world, EntityPlayer player)
/*     */   {
/* 161 */     return stack;
/*     */   }
/*     */   
/*     */   public int getMaxItemUseDuration(ItemStack stack)
/*     */   {
/* 166 */     int time = 72000;
/* 167 */     if (!BowHelper.canApply(stack, 1))
/* 168 */       time = 31000;
/* 169 */     return time;
/*     */   }
/*     */   
/*     */   public EnumAction getItemUseAction(ItemStack p_77661_1_)
/*     */   {
/* 174 */     return EnumAction.bow;
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*     */   {
/* 179 */     ArrowNockEvent event = new ArrowNockEvent(player, stack);
/* 180 */     MinecraftForge.EVENT_BUS.post(event);
/* 181 */     if (event.isCanceled()) {
/* 182 */       return event.result;
/*     */     }
/*     */     
/* 185 */     if ((player.capabilities.isCreativeMode) || (checkForAmmo(player) != null)) {
/* 186 */       player.setItemInUse(stack, getMaxItemUseDuration(stack));
/*     */     }
/*     */     
/* 189 */     return stack;
/*     */   }
/*     */   
/*     */   public int getRenderPasses(int metadata)
/*     */   {
/* 194 */     return 3;
/*     */   }
/*     */   
/*     */   public boolean requiresMultipleRenderPasses()
/*     */   {
/* 199 */     return true;
/*     */   }
/*     */   
/*     */   public int getItemEnchantability()
/*     */   {
/* 204 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean isFull3D()
/*     */   {
/* 209 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerIcons(IIconRegister icons)
/*     */   {
/* 215 */     this.itemIcon = icons.registerIcon(getIconString());
/* 216 */     this.iconArray = new IIcon[bowPullIconNames.length];
/* 217 */     this.iconSpeed = icons.registerIcon("palamod:upgrade_speed");
/* 218 */     this.iconRange = icons.registerIcon("palamod:upgrade_range");
/*     */     
/* 220 */     for (int i = 0; i < this.iconArray.length; i++) {
/* 221 */       this.iconArray[i] = icons.registerIcon(getIconString() + "_" + i);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getItemIconForUseDuration(int par1) {
/* 227 */     return this.iconArray[par1];
/*     */   }
/*     */   
/*     */   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining)
/*     */   {
/* 232 */     if (renderPass == 0) {
/* 233 */       if (player.getItemInUse() == null)
/* 234 */         return this.itemIcon;
/* 235 */       int pulling1 = 18;
/* 236 */       int pulling2 = 13;
/* 237 */       if (!BowHelper.canApply(stack, 1)) {
/* 238 */         pulling1 = 8;
/* 239 */         pulling2 = 7;
/*     */       }
/* 241 */       int pulling = stack.getMaxItemUseDuration() - useRemaining;
/* 242 */       if (pulling >= pulling1)
/* 243 */         return this.iconArray[2];
/* 244 */       if (pulling > pulling2)
/* 245 */         return this.iconArray[1];
/* 246 */       return this.iconArray[0];
/*     */     }
/* 248 */     if (renderPass == 1) {
/* 249 */       if (!BowHelper.canApply(stack, 1)) {
/* 250 */         return this.iconSpeed;
/*     */       }
/* 252 */       return null;
/*     */     }
/* 254 */     if (renderPass == 2) {
/* 255 */       if (!BowHelper.canApply(stack, 0)) {
/* 256 */         return this.iconRange;
/*     */       }
/* 258 */       return null;
/*     */     }
/* 260 */     return this.iconSpeed;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemPaladiumBow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */