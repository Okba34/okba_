/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemTitaneBroadsword
/*    */   extends ItemBroadsword
/*    */ {
/*    */   public ItemTitaneBroadsword()
/*    */   {
/* 12 */     super(10.0F, 2000);
/* 13 */     setUnlocalizedName("titanebroadsword");
/* 14 */     setTextureName("palamod:TitaneBroadsword");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 19 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemTitaneBroadsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */