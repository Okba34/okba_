/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.util.EntityHelper;
/*    */ import fr.paladium.palamod.util.UpgradeHelper;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.EnumAction;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemFastsword extends Item
/*    */ {
/*    */   float damageBase;
/*    */   
/*    */   public ItemFastsword(float damages, int max)
/*    */   {
/* 26 */     setMaxStackSize(1);
/* 27 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 28 */     setMaxDamage(max);
/* 29 */     this.damageBase = damages;
/*    */   }
/*    */   
/*    */   public boolean hitEntity(ItemStack stack, EntityLivingBase base, EntityLivingBase base2) {
/* 33 */     base.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)base2), this.damageBase + 
/* 34 */       UpgradeHelper.getModifier(stack, 3) * 3);
/*    */     
/* 36 */     int flame = UpgradeHelper.getModifier(stack, 4);
/* 37 */     int knockback = UpgradeHelper.getModifier(stack, 5);
/*    */     
/* 39 */     if (flame == 1)
/* 40 */       base.setFire(200);
/* 41 */     if (knockback > 0) {
/* 42 */       EntityHelper.knockbackEntity(base, knockback);
/*    */     }
/* 44 */     stack.damageItem(1, base2);
/* 45 */     return true;
/*    */   }
/*    */   
/*    */   public float getDamages(ItemStack stack) {
/* 49 */     return this.damageBase + UpgradeHelper.getModifier(stack, 3) * 3;
/*    */   }
/*    */   
/*    */   public boolean onBlockDestroyed(ItemStack p_150894_1_, World p_150894_2_, Block p_150894_3_, int p_150894_4_, int p_150894_5_, int p_150894_6_, EntityLivingBase p_150894_7_)
/*    */   {
/* 54 */     if (p_150894_3_.getBlockHardness(p_150894_2_, p_150894_4_, p_150894_5_, p_150894_6_) != 0.0D) {
/* 55 */       p_150894_1_.damageItem(2, p_150894_7_);
/*    */     }
/*    */     
/* 58 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isBookEnchantable(ItemStack stack, ItemStack book)
/*    */   {
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean isFull3D() {
/* 68 */     return true;
/*    */   }
/*    */   
/*    */   public EnumAction getItemUseAction(ItemStack p_77661_1_) {
/* 72 */     return EnumAction.block;
/*    */   }
/*    */   
/*    */   public int getMaxItemUseDuration(ItemStack p_77626_1_) {
/* 76 */     return 72000;
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack p_77659_1_, World p_77659_2_, EntityPlayer p_77659_3_) {
/* 80 */     p_77659_3_.setItemInUse(p_77659_1_, getMaxItemUseDuration(p_77659_1_));
/* 81 */     return p_77659_1_;
/*    */   }
/*    */   
/*    */   public boolean func_150897_b(Block p_150897_1_) {
/* 85 */     return p_150897_1_ == net.minecraft.init.Blocks.web;
/*    */   }
/*    */   
/*    */   public void onUpdate(ItemStack stack, World world, Entity entity, int p_77663_4_, boolean p_77663_5_)
/*    */   {
/* 90 */     if ((entity instanceof EntityPlayer)) {
/* 91 */       EntityPlayer player = (EntityPlayer)entity;
/* 92 */       if ((player.getHeldItem() != null) && 
/* 93 */         ((player.getHeldItem().getItem() instanceof ItemFastsword))) {
/* 94 */         ((EntityPlayer)entity).addPotionEffect(new PotionEffect(Potion.digSpeed.id, 1, 3));
/*    */       }
/*    */     }
/* 97 */     super.onUpdate(stack, world, entity, p_77663_4_, p_77663_5_);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemFastsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */