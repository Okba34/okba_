/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemAmethystFastsword
/*    */   extends ItemFastsword
/*    */ {
/*    */   public ItemAmethystFastsword()
/*    */   {
/* 13 */     super(6.0F, 400);
/* 14 */     setUnlocalizedName("amethystfastsword");
/* 15 */     setTextureName("palamod:AmethystFastsword");
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 21 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemAmethystFastsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */