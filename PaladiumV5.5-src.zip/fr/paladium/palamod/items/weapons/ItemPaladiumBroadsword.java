/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import com.google.common.collect.Multimap;
/*    */ import fr.paladium.palamod.util.UpgradeHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.SharedMonsterAttributes;
/*    */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*    */ import net.minecraft.entity.ai.attributes.IAttribute;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemPaladiumBroadsword
/*    */   extends ItemBroadsword
/*    */ {
/*    */   public ItemPaladiumBroadsword()
/*    */   {
/* 17 */     super(12.0F, 3000);
/* 18 */     setUnlocalizedName("paladiumbroadsword");
/* 19 */     setTextureName("palamod:PaladiumBroadsword");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 24 */     int[] modifiers = UpgradeHelper.getUpgradeAmmount(stack);
/* 25 */     if (modifiers == null)
/* 26 */       return;
/* 27 */     if (modifiers.length != 0) {
/* 28 */       list.add("§l§nUpgrades:");
/* 29 */       list.add("");
/*    */     }
/* 31 */     for (int i = 0; i < modifiers.length; i += 2) {
/* 32 */       int level = UpgradeHelper.getModifier(stack, modifiers[i]);
/* 33 */       String display = "" + level;
/* 34 */       if (level <= 1)
/* 35 */         display = "";
/* 36 */       list.add(UpgradeHelper.getUpgradeName(modifiers[i]) + " " + display);
/*    */     }
/*    */     
/* 39 */     list.add("");
/* 40 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */   
/*    */   public Multimap getItemAttributeModifiers() {
/* 44 */     Multimap multimap = super.getItemAttributeModifiers();
/* 45 */     multimap.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(field_111210_e, "Weapon modifier", this.damageBase, 0));
/* 46 */     return multimap;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemPaladiumBroadsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */