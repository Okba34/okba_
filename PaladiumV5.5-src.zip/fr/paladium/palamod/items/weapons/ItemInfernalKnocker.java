/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemSword;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemInfernalKnocker extends ItemSword
/*    */ {
/*    */   public ItemInfernalKnocker()
/*    */   {
/* 15 */     super(net.minecraft.item.Item.ToolMaterial.WOOD);
/* 16 */     setUnlocalizedName("infernalknocker");
/* 17 */     setTextureName("palamod:InfernalKnocker");
/* 18 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void onCreated(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 23 */     stack.addEnchantment(Enchantment.knockback, 5);
/*    */     
/* 25 */     super.onCreated(stack, world, player);
/*    */   }
/*    */   
/*    */   public void onUpdate(ItemStack stack, World world, Entity player, int p_77663_4_, boolean p_77663_5_) {
/* 29 */     if (!stack.isItemEnchanted()) {
/* 30 */       stack.addEnchantment(Enchantment.knockback, 5);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasEffect(ItemStack stack) {
/* 35 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isBookEnchantable(ItemStack stack, ItemStack book)
/*    */   {
/* 40 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemInfernalKnocker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */