/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.util.UpgradeHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemPaladiumFastsword
/*    */   extends ItemFastsword
/*    */ {
/*    */   public ItemPaladiumFastsword()
/*    */   {
/* 13 */     super(7.0F, 1500);
/* 14 */     setUnlocalizedName("paladiumfastsword");
/* 15 */     setTextureName("palamod:PaladiumFastsword");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 20 */     int[] modifiers = UpgradeHelper.getUpgradeAmmount(stack);
/* 21 */     if (modifiers == null)
/* 22 */       return;
/* 23 */     if (modifiers.length != 0) {
/* 24 */       list.add("§l§nUpgrades:");
/* 25 */       list.add("");
/*    */     }
/* 27 */     for (int i = 0; i < modifiers.length; i += 2) {
/* 28 */       int level = UpgradeHelper.getModifier(stack, modifiers[i]);
/* 29 */       String display = "" + level;
/* 30 */       if (level <= 1)
/* 31 */         display = "";
/* 32 */       list.add(UpgradeHelper.getUpgradeName(modifiers[i]) + " " + display);
/*    */     }
/* 34 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemPaladiumFastsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */