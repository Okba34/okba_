/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemAmethystBroadsword
/*    */   extends ItemBroadsword
/*    */ {
/*    */   public ItemAmethystBroadsword()
/*    */   {
/* 12 */     super(8.0F, 800);
/* 13 */     setUnlocalizedName("amethystbroadsword");
/* 14 */     setTextureName("palamod:AmethystBroadsword");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 19 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemAmethystBroadsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */