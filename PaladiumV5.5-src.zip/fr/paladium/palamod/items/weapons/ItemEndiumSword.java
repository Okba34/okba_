/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemSword;
/*    */ 
/*    */ public class ItemEndiumSword extends ItemSword
/*    */ {
/*    */   public ItemEndiumSword()
/*    */   {
/* 12 */     super(ToolMaterialPaladium.toolTypePaladium);
/* 13 */     setUnlocalizedName("endiumsword");
/* 14 */     setTextureName("palamod:EndiumSword");
/* 15 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 19 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemEndiumSword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */