/*    */ package fr.paladium.palamod.items.weapons;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemTitaneFastsword
/*    */   extends ItemFastsword
/*    */ {
/*    */   public ItemTitaneFastsword()
/*    */   {
/* 13 */     super(5.0F, 1000);
/* 14 */     setUnlocalizedName("titanefastsword");
/* 15 */     setTextureName("palamod:TitaneFastsword");
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 21 */     list.add("§cDamages: " + super.getDamages(stack));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\weapons\ItemTitaneFastsword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */