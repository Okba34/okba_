/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemGuardianWand
/*    */   extends Item
/*    */ {
/*    */   public ItemGuardianWand()
/*    */   {
/* 19 */     setMaxStackSize(1);
/* 20 */     setUnlocalizedName("guardianwand");
/* 21 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 22 */     setTextureName("palamod:GuardianWand");
/*    */   }
/*    */   
/*    */ 
/*    */   public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
/*    */   {
/* 28 */     return itemstack;
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 33 */     EntityGuardianGolem golem = getGolem(stack, player.worldObj);
/*    */     
/* 35 */     if (golem != null)
/* 36 */       list.add("Contient: " + golem.getName());
/* 37 */     super.addInformation(stack, player, list, b);
/*    */   }
/*    */   
/*    */   public static void setGolem(ItemStack stack, EntityGuardianGolem e) {
/* 41 */     if ((e != null) && ((e instanceof EntityGuardianGolem))) {
/* 42 */       if (!stack.hasTagCompound())
/* 43 */         stack.setTagCompound(new NBTTagCompound());
/* 44 */       NBTTagCompound tag = stack.getTagCompound();
/* 45 */       tag.setString("golemUUID", e.getUniqueID().toString());
/* 46 */       tag.setInteger("golemID", e.getEntityId());
/*    */     }
/*    */   }
/*    */   
/*    */   public static boolean isGolemLoaded(ItemStack stack, World world) {
/* 51 */     if (!stack.hasTagCompound()) {
/* 52 */       return false;
/*    */     }
/* 54 */     String uuid = stack.getTagCompound().getString("golemUUID");
/* 55 */     if (!world.isRemote) {
/* 56 */       for (Object obj : world.getLoadedEntityList()) {
/* 57 */         if (((obj instanceof EntityGuardianGolem)) && 
/* 58 */           (((EntityGuardianGolem)obj).getUniqueID().toString().equals(uuid))) {
/* 59 */           return true;
/*    */         }
/*    */       }
/*    */     } else {
/* 63 */       Entity e = world.getEntityByID(stack.getTagCompound().getInteger("golemID"));
/* 64 */       return (e != null) && ((e instanceof EntityGuardianGolem));
/*    */     }
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   public static EntityGuardianGolem getGolem(ItemStack stack, World world) {
/* 70 */     if (!isGolemLoaded(stack, world)) {
/* 71 */       return null;
/*    */     }
/* 73 */     String uuid = stack.getTagCompound().getString("golemUUID");
/* 74 */     if (!world.isRemote) {
/* 75 */       for (Object obj : world.getLoadedEntityList()) {
/* 76 */         if ((obj instanceof EntityGuardianGolem))
/*    */         {
/* 78 */           if (((EntityGuardianGolem)obj).getUniqueID().toString().equals(uuid))
/* 79 */             return (EntityGuardianGolem)obj;
/*    */         }
/*    */       }
/*    */     } else {
/* 83 */       Entity e = world.getEntityByID(stack.getTagCompound().getInteger("golemID"));
/* 84 */       if ((e != null) && ((e instanceof EntityGuardianGolem)))
/* 85 */         return (EntityGuardianGolem)e;
/*    */     }
/* 87 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemGuardianWand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */