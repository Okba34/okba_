/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemVoidStone
/*    */   extends Item
/*    */ {
/*    */   public ItemVoidStone()
/*    */   {
/* 15 */     setMaxStackSize(1);
/* 16 */     setUnlocalizedName("voidstone");
/* 17 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 18 */     setTextureName("palamod:VoidStone");
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 23 */     if (!world.isRemote) {
/* 24 */       player.openGui(PalaMod.instance, 10, world, 0, 0, 0);
/*    */     }
/* 26 */     return stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemVoidStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */