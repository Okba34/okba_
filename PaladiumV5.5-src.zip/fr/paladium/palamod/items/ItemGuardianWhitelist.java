/*     */ package fr.paladium.palamod.items;
/*     */ 
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemGuardianWhitelist
/*     */   extends Item
/*     */ {
/*     */   public ItemGuardianWhitelist()
/*     */   {
/*  21 */     setMaxStackSize(1);
/*  22 */     setUnlocalizedName("guardianwhitelist");
/*  23 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*  24 */     setTextureName("palamod:GuardianWhitelist");
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*     */   {
/*  29 */     if (!stack.hasTagCompound())
/*  30 */       return;
/*  31 */     List<String> players = getList(stack);
/*  32 */     list.add("§6Players:");
/*  33 */     for (int i = 0; i < players.size(); i++) {
/*  34 */       list.add("§c- " + (String)players.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*     */   {
/*  41 */     if (!world.isRemote) {
/*  42 */       player.openGui(PalaMod.instance, 15, world, 0, 0, 0);
/*     */     }
/*  44 */     return stack;
/*     */   }
/*     */   
/*     */   public static List<String> getList(ItemStack stack) {
/*  48 */     List<String> list = new ArrayList();
/*  49 */     if ((stack == null) || (stack.getItem() == null)) {
/*  50 */       return list;
/*     */     }
/*  52 */     if (!(stack.getItem() instanceof ItemGuardianWhitelist)) {
/*  53 */       return list;
/*     */     }
/*  55 */     if (!stack.hasTagCompound()) {
/*  56 */       NBTTagCompound tag = new NBTTagCompound();
/*  57 */       tag.setTag("Names", new NBTTagList());
/*  58 */       stack.setTagCompound(tag);
/*  59 */       return list;
/*     */     }
/*     */     
/*  62 */     NBTTagList nbttaglist = stack.getTagCompound().getTagList("Names", 10);
/*     */     
/*  64 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/*  65 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/*  66 */       list.add(nbttagcompound1.getString("name"));
/*     */     }
/*     */     
/*  69 */     return list;
/*     */   }
/*     */   
/*     */   public static void setList(List<String> list, ItemStack stack) {
/*  73 */     if (!(stack.getItem() instanceof ItemGuardianWhitelist)) {
/*  74 */       return;
/*     */     }
/*  76 */     if (!stack.hasTagCompound()) {
/*  77 */       NBTTagCompound tag = new NBTTagCompound();
/*  78 */       tag.setTag("Names", new NBTTagList());
/*  79 */       stack.setTagCompound(tag);
/*     */     }
/*     */     
/*  82 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/*  84 */     for (int i = 0; i < list.size(); i++) {
/*  85 */       NBTTagCompound tag = new NBTTagCompound();
/*  86 */       tag.setString("name", (String)list.get(i));
/*  87 */       nbttaglist.appendTag(tag);
/*     */     }
/*     */     
/*  90 */     NBTTagCompound tag = new NBTTagCompound();
/*  91 */     tag.setTag("Names", nbttaglist);
/*  92 */     stack.setTagCompound(tag);
/*     */   }
/*     */   
/*     */   public static List<String> addName(String name, List<String> list) {
/*  96 */     list = removeName(name, list);
/*  97 */     list.add(name);
/*  98 */     return list;
/*     */   }
/*     */   
/*     */   public static List<String> removeName(String name, List<String> list) {
/* 102 */     for (int i = 0; i < list.size(); i++) {
/* 103 */       if (((String)list.get(i)).equalsIgnoreCase(name)) {
/* 104 */         list.remove(i);
/*     */       }
/*     */     }
/*     */     
/* 108 */     return list;
/*     */   }
/*     */   
/*     */   public static boolean check(ItemStack stack, String name) {
/* 112 */     List<String> list = getList(stack);
/* 113 */     return list.contains(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemGuardianWhitelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */