/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.EnumAction;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemPotion extends net.minecraft.item.Item
/*    */ {
/*    */   PotionEffect effect;
/*    */   
/*    */   public ItemPotion(String name, String texturename, PotionEffect effect)
/*    */   {
/* 19 */     setMaxStackSize(1);
/* 20 */     setMaxDamage(16);
/* 21 */     setUnlocalizedName(name);
/* 22 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 23 */     setTextureName("palamod:" + texturename);
/* 24 */     this.effect = effect;
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
/* 28 */     player.setItemInUse(stack, getMaxItemUseDuration(stack));
/* 29 */     return stack;
/*    */   }
/*    */   
/*    */   public ItemStack onEaten(ItemStack stack, World world, EntityPlayer player) {
/* 33 */     if (!player.capabilities.isCreativeMode) {
/* 34 */       stack.stackSize -= 1;
/*    */     }
/* 36 */     if (!world.isRemote) {
/* 37 */       player.addPotionEffect(this.effect);
/*    */     }
/* 39 */     if (!player.capabilities.isCreativeMode) {
/* 40 */       if (stack.stackSize <= 0) {
/* 41 */         return new ItemStack(Items.glass_bottle);
/*    */       }
/* 43 */       player.inventory.addItemStackToInventory(new ItemStack(Items.glass_bottle));
/*    */     }
/*    */     
/* 46 */     return stack;
/*    */   }
/*    */   
/*    */   public int getMaxItemUseDuration(ItemStack stack) {
/* 50 */     return 32;
/*    */   }
/*    */   
/*    */   public EnumAction getItemUseAction(ItemStack stack) {
/* 54 */     return EnumAction.drink;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */