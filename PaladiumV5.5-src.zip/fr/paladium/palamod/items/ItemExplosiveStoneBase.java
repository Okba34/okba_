/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemExplosiveStoneBase extends Item
/*    */ {
/*    */   public ItemExplosiveStoneBase(String name, String texture, int color)
/*    */   {
/* 15 */     setMaxStackSize(16);
/* 16 */     setUnlocalizedName(name);
/* 17 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 18 */     setTextureName("palamod:" + texture);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 23 */     PalaMod.proxy.generateCustomParticles(0, player, 0);
/* 24 */     return stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemExplosiveStoneBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */