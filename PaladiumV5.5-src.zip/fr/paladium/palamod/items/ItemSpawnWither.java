/*     */ package fr.paladium.palamod.items;
/*     */ 
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockLiquid;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IEntityLivingData;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ItemSpawnWither extends Item
/*     */ {
/*     */   public ItemSpawnWither()
/*     */   {
/*  24 */     setUnlocalizedName("spawnwither");
/*  25 */     setTextureName("palamod:spawntest");
/*  26 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, World par3World, int par4, int par5, int par6, int par7, float par8, float par9, float par10)
/*     */   {
/*  34 */     if (par3World.isRemote)
/*     */     {
/*  36 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  40 */     Block block = par3World.getBlock(par4, par5, par6);
/*  41 */     par4 += net.minecraft.util.Facing.offsetsXForSide[par7];
/*  42 */     par5 += net.minecraft.util.Facing.offsetsYForSide[par7];
/*  43 */     par6 += net.minecraft.util.Facing.offsetsZForSide[par7];
/*  44 */     double d0 = 0.0D;
/*  45 */     if ((par7 == 1) && (block.getRenderType() == 11))
/*     */     {
/*  47 */       d0 = 0.5D;
/*     */     }
/*  49 */     Entity entity = spawnEntity(par3World, par4 + 0.5D, par5 + d0, par6 + 0.5D);
/*  50 */     if (entity != null)
/*     */     {
/*  52 */       if (((entity instanceof EntityLivingBase)) && (par1ItemStack.hasDisplayName()))
/*     */       {
/*  54 */         ((EntityLiving)entity).setCustomNameTag(par1ItemStack.getDisplayName());
/*     */       }
/*  56 */       if (!par2EntityPlayer.capabilities.isCreativeMode)
/*     */       {
/*  58 */         par1ItemStack.stackSize -= 1;
/*     */       }
/*     */     }
/*  61 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
/*     */   {
/*  78 */     if (par2World.isRemote)
/*     */     {
/*  80 */       return par1ItemStack;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  85 */     MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, true);
/*  86 */     if (movingobjectposition == null)
/*     */     {
/*  88 */       return par1ItemStack;
/*     */     }
/*     */     
/*     */ 
/*  92 */     if (movingobjectposition.typeOfHit == net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK)
/*     */     {
/*     */ 
/*  95 */       int i = movingobjectposition.blockX;
/*  96 */       int j = movingobjectposition.blockY;
/*  97 */       int k = movingobjectposition.blockZ;
/*  98 */       if (!par2World.canMineBlock(par3EntityPlayer, i, j, k))
/*     */       {
/* 100 */         return par1ItemStack;
/*     */       }
/* 102 */       if (!par3EntityPlayer.canPlayerEdit(i, j, k, movingobjectposition.sideHit, par1ItemStack))
/*     */       {
/*     */ 
/* 105 */         return par1ItemStack;
/*     */       }
/* 107 */       if ((par2World.getBlock(i, j, k) instanceof BlockLiquid))
/*     */       {
/* 109 */         Entity entity = spawnEntity(par2World, i, j, k);
/* 110 */         if (entity != null)
/*     */         {
/* 112 */           if (((entity instanceof EntityLivingBase)) && 
/* 113 */             (par1ItemStack.hasDisplayName()))
/*     */           {
/* 115 */             ((EntityLiving)entity).setCustomNameTag(par1ItemStack
/* 116 */               .getDisplayName());
/*     */           }
/* 118 */           if (!par3EntityPlayer.capabilities.isCreativeMode)
/*     */           {
/* 120 */             par1ItemStack.stackSize -= 1;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 125 */     return par1ItemStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Entity spawnEntity(World parWorld, double parX, double parY, double parZ)
/*     */   {
/* 142 */     EntityCustomWither entityToSpawn = null;
/* 143 */     if (!parWorld.isRemote)
/*     */     {
/* 145 */       entityToSpawn = new EntityCustomWither(parWorld, new fr.paladium.palamod.util.WitherData());
/* 146 */       entityToSpawn.setLocationAndAngles(parX, parY, parZ, MathHelper.wrapAngleTo180_float(parWorld.rand.nextFloat() * 360.0F), 0.0F);
/* 147 */       parWorld.spawnEntityInWorld(entityToSpawn);
/* 148 */       entityToSpawn.onSpawnWithEgg((IEntityLivingData)null);
/* 149 */       entityToSpawn.playLivingSound();
/*     */     }
/* 151 */     return entityToSpawn;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemSpawnWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */