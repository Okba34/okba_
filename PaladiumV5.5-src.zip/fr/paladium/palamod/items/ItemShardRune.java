/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemShardRune
/*    */   extends Item
/*    */ {
/*    */   public ItemShardRune(int level)
/*    */   {
/* 11 */     setMaxStackSize(4);
/*    */     
/* 13 */     setUnlocalizedName("shard_" + level);
/* 14 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 15 */     setTextureName("palamod:shard_" + level);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemShardRune.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */