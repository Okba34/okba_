/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ 
/*    */ public class ItemGuardianStone
/*    */   extends Item
/*    */ {
/*    */   public ItemGuardianStone()
/*    */   {
/* 16 */     setMaxStackSize(1);
/* 17 */     setUnlocalizedName("guardianstone");
/* 18 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 19 */     setTextureName("palamod:GuardianStone");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 24 */     if (!stack.hasTagCompound())
/* 25 */       return;
/* 26 */     NBTTagCompound tag = stack.getTagCompound();
/*    */     
/* 28 */     list.add("Contient un golem");
/* 29 */     list.add("Niveau " + tag.getInteger("Levels"));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemGuardianStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */