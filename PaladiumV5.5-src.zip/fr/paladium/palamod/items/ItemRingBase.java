/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.items.armors.RepairableArmor;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemRingBase
/*    */   extends Item
/*    */ {
/*    */   public ItemRingBase(int durability, String name, String texture)
/*    */   {
/* 16 */     setMaxStackSize(1);
/* 17 */     setMaxDamage(durability);
/* 18 */     setUnlocalizedName(name);
/* 19 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 20 */     setTextureName("palamod:" + texture);
/*    */   }
/*    */   
/*    */ 
/*    */   public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean selected)
/*    */   {
/* 26 */     if ((entity instanceof EntityPlayer)) {
/* 27 */       EntityPlayer player = (EntityPlayer)entity;
/* 28 */       for (int i = 0; i < 4; i++) {
/* 29 */         ItemStack armor = player.getCurrentArmor(i);
/* 30 */         if ((armor != null) && ((armor.getItem() instanceof RepairableArmor))) {
/* 31 */           ((RepairableArmor)armor.getItem()).repair(armor, stack);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemRingBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */