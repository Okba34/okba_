/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemFood;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemPaladiumApple extends ItemFood
/*    */ {
/*    */   public ItemPaladiumApple()
/*    */   {
/* 15 */     super(100, true);
/* 16 */     setMaxStackSize(16);
/* 17 */     setUnlocalizedName("paladiumapple");
/* 18 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 19 */     setTextureName("palamod:PaladiumApple");
/* 20 */     setAlwaysEdible();
/*    */   }
/*    */   
/*    */   protected void onFoodEaten(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 25 */     super.onFoodEaten(stack, world, player);
/*    */     
/* 27 */     if (!world.isRemote) {
/* 28 */       player.addPotionEffect(new PotionEffect(Potion.regeneration.id, 10, 2));
/* 29 */       player.setAbsorptionAmount(10.0F);
/* 30 */       player.addPotionEffect(new PotionEffect(Potion.fireResistance.id, 500, 1));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemPaladiumApple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */