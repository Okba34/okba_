/*     */ package fr.paladium.palamod.items;
/*     */ 
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import java.util.Random;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityPotion;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ItemStickBase
/*     */   extends Item
/*     */ {
/*     */   public static final int HEAL = 0;
/*     */   public static final int SPEED = 1;
/*     */   public static final int STRENGHT = 2;
/*     */   public static final int JUMP = 3;
/*     */   public static final int GOD = 4;
/*     */   public static final int DAMAGE = 5;
/*     */   public static final int HYPERJUMP = 6;
/*     */   int type;
/*     */   int cooldown;
/*     */   double[] color;
/*     */   
/*     */   public ItemStickBase(int durability, String name, String texture, int cooldown, int type, double[] color)
/*     */   {
/*  33 */     setMaxStackSize(1);
/*  34 */     setMaxDamage(durability);
/*  35 */     setUnlocalizedName(name);
/*  36 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*  37 */     setTextureName("palamod:" + texture);
/*  38 */     this.type = type;
/*  39 */     this.cooldown = cooldown;
/*  40 */     this.color = color;
/*     */   }
/*     */   
/*     */   public boolean isFull3D()
/*     */   {
/*  45 */     return true;
/*     */   }
/*     */   
/*     */   public void onUpdate(ItemStack item, World world, Entity player, int slotIndex, boolean inHand)
/*     */   {
/*  50 */     if (item.hasTagCompound()) {
/*  51 */       if (item.stackTagCompound.getInteger("timer") > 0) {
/*  52 */         item.stackTagCompound.setInteger("timer", item.stackTagCompound.getInteger("timer") + 1);
/*     */       }
/*  54 */       if (item.stackTagCompound.getInteger("timer") >= this.cooldown * 20) {
/*  55 */         item.stackTagCompound.setInteger("timer", 0);
/*     */       }
/*     */     }
/*  58 */     super.onUpdate(item, world, player, slotIndex, inHand);
/*     */   }
/*     */   
/*     */   public boolean hasEffect(ItemStack item, int pass)
/*     */   {
/*  63 */     if (item.hasTagCompound()) {
/*  64 */       if (item.stackTagCompound.getInteger("timer") == 0) {
/*  65 */         return true;
/*     */       }
/*  67 */       return false; }
/*  68 */     return true;
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack item, World world, EntityPlayer player) {
/*  72 */     if (!item.hasTagCompound()) {
/*  73 */       item.setTagCompound(new NBTTagCompound());
/*  74 */       item.stackTagCompound.setInteger("timer", 0);
/*     */     }
/*  76 */     if (item.stackTagCompound.getInteger("timer") == 0) {
/*  77 */       item.damageItem(1, player);
/*  78 */       getTypeEffect(player);
/*  79 */       for (int i = 0; i < 200; i++)
/*  80 */         world.spawnParticle("reddust", player.posX + world.rand.nextDouble() * 2.0D - 1.0D, player.posY + world.rand.nextDouble() * 2.0D - 2.0D, player.posZ + world.rand.nextDouble() * 2.0D - 1.0D, this.color[0], this.color[1], this.color[2]);
/*  81 */       item.stackTagCompound.setInteger("timer", 1);
/*     */     }
/*  83 */     else if (world.isRemote) {
/*  84 */       player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Tu dois attendre que le baton se recharge !", new Object[0]));
/*     */     }
/*     */     
/*  87 */     return item;
/*     */   }
/*     */   
/*     */   public void getTypeEffect(EntityPlayer player) {
/*  91 */     switch (this.type) {
/*     */     case 0: 
/*  93 */       player.heal(6.0F);
/*  94 */       return;
/*     */     case 1: 
/*  96 */       player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 25, 9));
/*  97 */       return;
/*     */     case 2: 
/*  99 */       player.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 60, 2));
/* 100 */       return;
/*     */     case 3: 
/* 102 */       player.motionY += 1.0D;
/* 103 */       return;
/*     */     case 4: 
/* 105 */       player.heal(10.0F);
/* 106 */       player.setAbsorptionAmount(6.0F);
/* 107 */       player.addPotionEffect(new PotionEffect(Potion.field_76443_y.id, 30, 1));
/* 108 */       player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 50, 11));
/* 109 */       player.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 40, 2));
/* 110 */       return;
/*     */     case 5: 
/* 112 */       if (!player.worldObj.isRemote)
/* 113 */         player.worldObj.spawnEntityInWorld(new EntityPotion(player.worldObj, player, 12));
/* 114 */       return;
/*     */     case 6: 
/* 116 */       player.motionY += 6.0D;
/* 117 */       return;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemStickBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */