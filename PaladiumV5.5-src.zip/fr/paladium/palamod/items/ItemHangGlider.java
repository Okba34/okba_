/*     */ package fr.paladium.palamod.items;
/*     */ 
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class ItemHangGlider
/*     */   extends Item
/*     */ {
/*  16 */   public static List<EntityPlayer> usingHangGliderClient = new ArrayList();
/*     */   
/*  18 */   public static List<EntityPlayer> usingHangGliderServer = new ArrayList();
/*     */   
/*     */   public ItemHangGlider()
/*     */   {
/*  22 */     setMaxStackSize(1);
/*  23 */     setUnlocalizedName("hangglider");
/*  24 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*  25 */     setTextureName("palamod:HangGlider");
/*     */   }
/*     */   
/*     */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*     */   {
/*  30 */     if (world.isRemote) {
/*  31 */       if (!usingHangGliderClient.contains(player)) {
/*  32 */         usingHangGliderClient.add(player);
/*  33 */         return stack;
/*     */       }
/*  35 */       usingHangGliderClient.remove(player);
/*     */     }
/*     */     
/*     */ 
/*  39 */     if (!world.isRemote) {
/*  40 */       if (!usingHangGliderServer.contains(player)) {
/*  41 */         usingHangGliderServer.add(player);
/*  42 */         return stack;
/*     */       }
/*  44 */       usingHangGliderServer.remove(player);
/*     */     }
/*     */     
/*  47 */     return stack;
/*     */   }
/*     */   
/*     */   public void onUpdate(ItemStack stack, World world, Entity entity, int p_77663_4_, boolean p_77663_5_)
/*     */   {
/*  52 */     super.onUpdate(stack, world, entity, p_77663_4_, p_77663_5_);
/*     */     
/*  54 */     if (!(entity instanceof EntityPlayer)) {
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     EntityPlayer player = (EntityPlayer)entity;
/*     */     
/*     */ 
/*  61 */     if (world.isRemote)
/*     */     {
/*  63 */       if (player.isCollidedVertically) {
/*  64 */         usingHangGliderClient.remove(player);
/*     */       }
/*     */       
/*  67 */       if ((usingHangGliderClient.contains(player)) && 
/*  68 */         (player.motionY < 0.0D)) {
/*     */         double verticalSpeed;
/*     */         double horizontalSpeed;
/*     */         double verticalSpeed;
/*  72 */         if (player.isSneaking()) {
/*  73 */           double horizontalSpeed = 0.1D;
/*  74 */           verticalSpeed = 0.9D;
/*     */         } else {
/*  76 */           horizontalSpeed = 0.03D;
/*  77 */           verticalSpeed = 0.7D;
/*     */         }
/*     */         
/*  80 */         player.motionY *= verticalSpeed;
/*  81 */         double x = Math.cos(Math.toRadians(player.rotationYawHead + 90.0F)) * horizontalSpeed;
/*  82 */         double z = Math.sin(Math.toRadians(player.rotationYawHead + 90.0F)) * horizontalSpeed;
/*  83 */         player.motionX += x;
/*  84 */         player.motionZ += z;
/*  85 */         player.fallDistance = 0.0F;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  90 */     if (!world.isRemote)
/*     */     {
/*  92 */       if (player.isCollidedVertically) {
/*  93 */         usingHangGliderServer.remove(player);
/*     */       }
/*     */       
/*  96 */       if ((usingHangGliderServer.contains(player)) && 
/*  97 */         (player.motionY < 0.0D)) {
/*     */         double verticalSpeed;
/*     */         double horizontalSpeed;
/*     */         double verticalSpeed;
/* 101 */         if (player.isSneaking()) {
/* 102 */           double horizontalSpeed = 0.1D;
/* 103 */           verticalSpeed = 0.7D;
/*     */         } else {
/* 105 */           horizontalSpeed = 0.03D;
/* 106 */           verticalSpeed = 0.4D;
/*     */         }
/*     */         
/* 109 */         player.motionY *= verticalSpeed;
/* 110 */         double x = Math.cos(Math.toRadians(player.rotationYawHead + 90.0F)) * horizontalSpeed;
/* 111 */         double z = Math.sin(Math.toRadians(player.rotationYawHead + 90.0F)) * horizontalSpeed;
/* 112 */         player.motionX += x;
/* 113 */         player.motionZ += z;
/* 114 */         player.fallDistance = 0.0F;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemHangGlider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */