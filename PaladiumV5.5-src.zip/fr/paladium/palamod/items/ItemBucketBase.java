/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBucket;
/*    */ 
/*    */ public class ItemBucketBase extends ItemBucket
/*    */ {
/*    */   public ItemBucketBase(Block block, String name, String texture)
/*    */   {
/* 11 */     super(block);
/* 12 */     setUnlocalizedName(name);
/* 13 */     setMaxStackSize(1);
/* 14 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 15 */     setTextureName("palamod:" + texture);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemBucketBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */