/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemBackpack
/*    */   extends Item
/*    */ {
/*    */   public ItemBackpack()
/*    */   {
/* 21 */     setMaxStackSize(1);
/* 22 */     setUnlocalizedName("backpack");
/* 23 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 24 */     setTextureName("palamod:Backpack");
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 29 */     if (!world.isRemote) {
/* 30 */       player.openGui(PalaMod.instance, 8, world, 0, 0, 0);
/*    */     }
/* 32 */     return stack;
/*    */   }
/*    */   
/*    */ 
/*    */   public void onUpdate(ItemStack stack, World world, Entity e, int in, boolean b)
/*    */   {
/* 38 */     if ((stack.hasTagCompound()) && (stack.getTagCompound().hasKey("Open")) && 
/* 39 */       (!b)) {
/* 40 */       stack.getTagCompound().setBoolean("Open", false);
/*    */     }
/* 42 */     super.onUpdate(stack, world, e, in, b);
/*    */   }
/*    */   
/*    */   public void onCreated(ItemStack ItemStack, World World, EntityPlayer EntityPlayer)
/*    */   {
/* 47 */     ItemStack.stackTagCompound = new NBTTagCompound();
/* 48 */     ItemStack.stackTagCompound.setBoolean("Enderchest", false);
/* 49 */     ItemStack.stackTagCompound.setString("Interdit", "Interdit dans les enderchest");
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack itemStack, EntityPlayer player, List list, boolean par4)
/*    */   {
/* 54 */     if (itemStack.stackTagCompound != null) {
/* 55 */       String owner = itemStack.stackTagCompound.getString("Interdit");
/* 56 */       list.add(EnumChatFormatting.RED + owner);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemBackpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */