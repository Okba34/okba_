/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.entities.projectiles.EntitySplashPotion;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class ItemSplashPotion
/*    */   extends Item
/*    */ {
/*    */   PotionEffect effect;
/* 22 */   private String[] type = { "SicknessPotion", "WebPotion" };
/*    */   private IIcon[] iconArray;
/*    */   
/*    */   public ItemSplashPotion(String name, String texturename, PotionEffect effect, int damageValue)
/*    */   {
/* 27 */     setMaxStackSize(1);
/* 28 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 29 */     setHasSubtypes(true);
/* 30 */     this.effect = effect;
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 35 */     if (!world.isRemote) {
/* 36 */       world.spawnEntityInWorld(new EntitySplashPotion(world, player, getDamage(stack)));
/*    */     }
/* 38 */     return stack;
/*    */   }
/*    */   
/*    */   public int getMetadata(int metadata)
/*    */   {
/* 43 */     return metadata;
/*    */   }
/*    */   
/*    */   public String getUnlocalizedName(ItemStack stack)
/*    */   {
/* 48 */     int metadata = stack.getItemDamage();
/* 49 */     if ((metadata > this.type.length) || (metadata < 0))
/*    */     {
/* 51 */       metadata = 0;
/*    */     }
/* 53 */     return "splashpotion." + this.type[metadata].toLowerCase();
/*    */   }
/*    */   
/*    */   public void registerIcons(IIconRegister iconregister)
/*    */   {
/* 58 */     this.iconArray = new IIcon[this.type.length];
/* 59 */     for (int i = 0; i < this.type.length; i++)
/*    */     {
/* 61 */       this.iconArray[i] = iconregister.registerIcon("palamod:" + this.type[i]);
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void getSubItems(Item Item, CreativeTabs creativeTabs, List list)
/*    */   {
/* 68 */     for (int metadata = 0; metadata < this.type.length; metadata++) {
/* 69 */       list.add(new ItemStack(Item, 1, metadata));
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public IIcon getIconFromDamage(int metadata) {
/* 75 */     return (metadata < this.type.length) && (metadata >= 0) ? this.iconArray[metadata] : this.iconArray[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemSplashPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */