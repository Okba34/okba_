/*     */ package fr.paladium.palamod.items;
/*     */ 
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorAmethyst;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorEndium;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorPaladium;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorTitane;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorTravel;
/*     */ import fr.paladium.palamod.items.core.ItemAmethystStick;
/*     */ import fr.paladium.palamod.items.core.ItemBowModifier;
/*     */ import fr.paladium.palamod.items.core.ItemBowRangeModifier;
/*     */ import fr.paladium.palamod.items.core.ItemBowSpeedModifier;
/*     */ import fr.paladium.palamod.items.core.ItemGrinderModifier;
/*     */ import fr.paladium.palamod.items.core.ItemHealOrb;
/*     */ import fr.paladium.palamod.items.core.ItemJumpOrb;
/*     */ import fr.paladium.palamod.items.core.ItemKnockbackOrb;
/*     */ import fr.paladium.palamod.items.core.ItemMagicalAnvilBottom;
/*     */ import fr.paladium.palamod.items.core.ItemMagicalAnvilMiddle;
/*     */ import fr.paladium.palamod.items.core.ItemMagicalAnvilTop;
/*     */ import fr.paladium.palamod.items.core.ItemPaladiumCore;
/*     */ import fr.paladium.palamod.items.core.ItemPaladiumStick;
/*     */ import fr.paladium.palamod.items.core.ItemPatern;
/*     */ import fr.paladium.palamod.items.core.ItemSpeedOrb;
/*     */ import fr.paladium.palamod.items.core.ItemStrenghtOrb;
/*     */ import fr.paladium.palamod.items.core.ItemStringDiamond;
/*     */ import fr.paladium.palamod.items.core.ItemTitaneStick;
/*     */ import fr.paladium.palamod.items.core.ItemToolPart;
/*     */ import fr.paladium.palamod.items.core.ItemWing;
/*     */ import fr.paladium.palamod.items.core.ItemWitherSkullFragment;
/*     */ import fr.paladium.palamod.items.tools.ItemAmethystAxe;
/*     */ import fr.paladium.palamod.items.tools.ItemAmethystHammer;
/*     */ import fr.paladium.palamod.items.tools.ItemAmethystPickaxe;
/*     */ import fr.paladium.palamod.items.tools.ItemAmethystShovel;
/*     */ import fr.paladium.palamod.items.tools.ItemEndiumAxe;
/*     */ import fr.paladium.palamod.items.tools.ItemEndiumPickaxe;
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumAxe;
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumHammer;
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumPickaxe;
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumShovel;
/*     */ import fr.paladium.palamod.items.tools.ItemSmithHammer;
/*     */ import fr.paladium.palamod.items.tools.ItemTitaneAxe;
/*     */ import fr.paladium.palamod.items.tools.ItemTitaneHammer;
/*     */ import fr.paladium.palamod.items.tools.ItemTitanePickaxe;
/*     */ import fr.paladium.palamod.items.tools.ItemTitaneShovel;
/*     */ import fr.paladium.palamod.items.weapons.ItemAmethystBroadsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemAmethystFastsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemAmethystSword;
/*     */ import fr.paladium.palamod.items.weapons.ItemEndiumSword;
/*     */ import fr.paladium.palamod.items.weapons.ItemInfernalKnocker;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumBow;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumBroadsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumFastsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumSword;
/*     */ import fr.paladium.palamod.items.weapons.ItemPotionLauncher;
/*     */ import fr.paladium.palamod.items.weapons.ItemTitaneBroadsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemTitaneFastsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemTitaneSword;
/*     */ import fr.paladium.palamod.potion.ModPotions;
/*     */ import fr.paladium.palamod.potion.PotionFireImbue;
/*     */ import fr.paladium.palamod.potion.PotionPoisonImbue;
/*     */ import fr.paladium.palamod.potion.PotionWitherImbue;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModItems
/*     */ {
/*     */   public static ItemPaladiumPickaxe paladiumPickaxe;
/*     */   public static ItemTitanePickaxe titanePickaxe;
/*     */   public static ItemAmethystPickaxe amethystPickaxe;
/*     */   public static ItemEndiumPickaxe endiumPickaxe;
/*     */   public static ItemPaladiumShovel paladiumShovel;
/*     */   public static ItemTitaneShovel titaneShovel;
/*     */   public static ItemAmethystShovel amethystShovel;
/*     */   public static ItemPaladiumAxe paladiumAxe;
/*     */   public static ItemTitaneAxe titaneAxe;
/*     */   public static ItemAmethystAxe amethystAxe;
/*     */   public static ItemEndiumAxe endiumAxe;
/*     */   public static ItemPaladiumHammer paladiumHammer;
/*     */   public static ItemTitaneHammer titaneHammer;
/*     */   public static ItemAmethystHammer amethystHammer;
/*     */   public static ItemSmithHammer smithHammer;
/*     */   public static ItemPaladiumSword paladiumSword;
/*     */   public static ItemTitaneSword titaneSword;
/*     */   public static ItemAmethystSword amethystSword;
/*     */   public static ItemEndiumSword endiumSword;
/*     */   public static ItemInfernalKnocker infernalKnocker;
/*     */   public static ItemPaladiumBroadsword paladiumBroadsword;
/*     */   public static ItemAmethystBroadsword amethystBroadsword;
/*     */   public static ItemTitaneBroadsword titaneBroadsword;
/*     */   public static ItemPaladiumFastsword paladiumFastSword;
/*     */   public static ItemAmethystFastsword amethystFastSword;
/*     */   public static ItemTitaneFastsword titaneFastSword;
/*     */   public static ItemPaladiumBow paladiumBow;
/*     */   public static ItemArmorPaladium paladiumHelmet;
/*     */   public static ItemArmorPaladium paladiumChestplate;
/*     */   public static ItemArmorPaladium paladiumLeggings;
/*     */   public static ItemArmorPaladium paladiumBoots;
/*     */   public static ItemArmorTitane titaneHelmet;
/*     */   public static ItemArmorTitane titaneChestplate;
/*     */   public static ItemArmorTitane titaneLeggings;
/*     */   public static ItemArmorTitane titaneBoots;
/*     */   public static ItemArmorAmethyst amethystHelmet;
/*     */   public static ItemArmorAmethyst amethystChestplate;
/*     */   public static ItemArmorAmethyst amethystLeggings;
/*     */   public static ItemArmorAmethyst amethystBoots;
/*     */   public static ItemArmorEndium endiumHelmet;
/*     */   public static ItemArmorEndium endiumChestplate;
/*     */   public static ItemArmorEndium endiumLeggings;
/*     */   public static ItemArmorEndium endiumBoots;
/*     */   public static ItemArmorTravel travelLeggings;
/*     */   public static ItemArmorTravel travelBoots;
/*     */   public static ItemArmorTravel jumpChest;
/*     */   public static ItemArmorTravel slimyHelmet;
/*     */   public static ItemArmorTravel scubaHelmet;
/*     */   public static ItemArmorTravel hoodHelmet;
/*     */   public static ItemPaladiumApple paladiumApple;
/*     */   public static ItemHangGlider hangGlider;
/*     */   public static ItemExplosiveStoneBase explosiveStone;
/*     */   public static ItemGuardianStone guardianStone;
/*     */   public static ItemBackpack backpack;
/*     */   public static ItemVoidStone voidStone;
/*     */   public static ItemChestExplorer chestExplorer;
/*     */   public static ItemStuffSwitcher stuffSwitcher;
/*     */   public static ItemGuardianWhitelist guardianWhitelist;
/*     */   public static ItemGuardianUpgrade guardianXpUpgrade;
/*     */   public static ItemGuardianCosmeticUpgrade guardianNametagUpgrade;
/*     */   public static ItemRingBase smallRing;
/*     */   public static ItemRingBase mediumRing;
/*     */   public static ItemRingBase bigRing;
/*     */   public static ItemHealOrb healOrb;
/*     */   public static ItemSpeedOrb speedOrb;
/*     */   public static ItemStrenghtOrb strenghtOrb;
/*     */   public static ItemJumpOrb jumpOrb;
/*     */   public static ItemKnockbackOrb knockbackOrb;
/*     */   public static ItemPaladiumStick paladiumStick;
/*     */   public static Item compressedPaladium;
/*     */   public static Item compressedTitane;
/*     */   public static Item compressedAmethyst;
/*     */   public static ItemWitherSkullFragment witherSkullFragment;
/*     */   public static ItemPaladiumCore paladiumCore;
/*     */   public static ItemAmethystStick amethystStick;
/*     */   public static ItemTitaneStick titaneStick;
/*     */   public static ItemStringDiamond diamondString;
/*     */   public static ItemWing wing;
/*     */   public static ItemBowModifier bowModifer;
/*     */   public static ItemGrinderModifier smeltModifier;
/*     */   public static ItemGrinderModifier fortuneModifier;
/*     */   public static ItemGrinderModifier speedModifier;
/*     */   public static ItemGrinderModifier damageModifier;
/*     */   public static ItemGrinderModifier flameModifier;
/*     */   public static ItemGrinderModifier knockbackModifier;
/*     */   public static ItemGrinderModifier autoRepairModifier;
/*     */   public static ItemToolTrap toolTrap;
/*     */   public static ItemStickBase healStick;
/*     */   public static ItemStickBase speedStick;
/*     */   public static ItemStickBase strenghtStick;
/*     */   public static ItemStickBase jumpStick;
/*     */   public static ItemStickBase godStick;
/*     */   public static ItemStickBase damageStick;
/*     */   public static ItemStickBase hyperJumpStick;
/*     */   public static ItemPotion potionWither;
/*     */   public static ItemPotion potionFire;
/*     */   public static ItemPotion potionPoison;
/*     */   public static ItemSplashPotion sicknessPotion;
/*     */   public static ItemPotionLauncher potionLauncher;
/*     */   public static ItemArrowBase arrowPoison;
/*     */   public static ItemArrowBase arrowSlowness;
/*     */   public static ItemArrowBase arrowWither;
/*     */   public static ItemArrowBase arrowSwitch;
/*     */   public static ItemBowRangeModifier bowRangeModifier;
/*     */   public static ItemBowSpeedModifier bowSpeedModifier;
/*     */   public static ItemPatern paternPickaxe;
/*     */   public static ItemPatern paternBroadsword;
/*     */   public static ItemPatern paternSword;
/*     */   public static ItemPatern paternFastSword;
/*     */   public static ItemPatern paternHammer;
/*     */   public static ItemPatern paternAxe;
/*     */   public static ItemPatern paternShovel;
/*     */   public static ItemPatern paternPaladium;
/*     */   public static ItemPatern paternIngot;
/*     */   public static ItemPatern paternBlock;
/*     */   public static ItemPatern paternSocket;
/*     */   public static ItemToolPart pickaxeHead;
/*     */   public static ItemToolPart broadSwordHead;
/*     */   public static ItemToolPart swordHead;
/*     */   public static ItemToolPart fastSwordHead;
/*     */   public static ItemToolPart hammerHead;
/*     */   public static ItemToolPart shovelHead;
/*     */   public static ItemToolPart axeHead;
/*     */   public static ItemMagicalAnvilTop MagicalAnvilTop;
/*     */   public static ItemMagicalAnvilMiddle MagicalAnvilMiddle;
/*     */   public static ItemMagicalAnvilBottom MagicalAnvilBottom;
/*     */   public static ItemRune itemrune;
/*     */   public static ItemRune itemrune2;
/*     */   public static ItemRune itemrune3;
/*     */   public static ItemRune itemrune4;
/*     */   public static ItemShardRune itemshardrune;
/*     */   public static ItemShardRune itemshardrune2;
/*     */   public static ItemShardRune itemshardrune3;
/*     */   public static ItemShardRune itemshardrune4;
/*     */   public static ItemSpawnWither itemSpawnWither;
/*     */   public static ItemWitherUnSummoner unSummoner;
/*     */   public static Item explode_obsidian_upgrade;
/*     */   public static Item fake_obsidian_upgrade;
/*     */   public static Item twoLife_obsidian_upgrade;
/*     */   public static Item camouflage_obsidian_upgrade;
/*     */   public static Item camera_tablet;
/*     */   public static ItemGuardianWand guardianWand;
/*     */   public static ItemGrinderModifier obsidianUpgrade;
/*     */   public static ItemGrinderModifier moreUpgrade;
/*     */   public static ItemGuardianUpgrade anchorUpgrade;
/*     */   public static ItemGuardianUpgrade regenOneUpgrade;
/*     */   public static ItemGuardianUpgrade regenTwoUpgrade;
/*     */   public static ItemGuardianUpgrade regenThreeUpgrade;
/*     */   public static ItemGuardianUpgrade chestUpgrade;
/*     */   public static ItemGuardianUpgrade guardianMoreUpgrade;
/*     */   public static ItemGuardianUpgrade guardianLifeUpgrade1;
/*     */   public static ItemGuardianUpgrade guardianLifeUpgrade2;
/*     */   public static ItemGuardianUpgrade guardianLifeUpgrade3;
/*     */   public static ItemGuardianUpgrade guardianDamageUpgrade1;
/*     */   public static ItemGuardianUpgrade guardianDamageUpgrade2;
/*     */   public static ItemGuardianUpgrade guardianDamageUpgrade3;
/*     */   public static ItemGuardianUpgrade guardianPeneUpgrade1;
/*     */   public static ItemGuardianUpgrade guardianPeneUpgrade2;
/*     */   public static ItemGuardianUpgrade guardianPeneUpgrade3;
/*     */   public static ItemGuardianUpgrade guardianExplosiveUpgrade;
/*     */   public static ItemGuardianUpgrade guardianThornsUpgrade1;
/*     */   public static ItemGuardianUpgrade guardianThornsUpgrade2;
/*     */   public static ItemGuardianUpgrade guardianThornsUpgrade3;
/*     */   public static ItemGuardianUpgrade guardianWeaponUpgrade;
/*     */   public static ItemGuardianUpgrade guardianFarmUpgrade;
/*     */   public static ItemGuardianUpgrade guardianAutoXPUpgrade;
/*     */   public static ItemGuardianUpgrade guardianHideWandUpgrade;
/*     */   
/*     */   public static void init()
/*     */   {
/* 262 */     itemrune = new ItemRune(1);
/* 263 */     itemrune2 = new ItemRune(2);
/* 264 */     itemrune3 = new ItemRune(3);
/* 265 */     itemrune4 = new ItemRune(4);
/* 266 */     itemshardrune = new ItemShardRune(1);
/* 267 */     itemshardrune2 = new ItemShardRune(2);
/* 268 */     itemshardrune3 = new ItemShardRune(3);
/* 269 */     itemshardrune4 = new ItemShardRune(4);
/*     */     
/* 271 */     paladiumPickaxe = new ItemPaladiumPickaxe();
/* 272 */     titanePickaxe = new ItemTitanePickaxe();
/* 273 */     amethystPickaxe = new ItemAmethystPickaxe();
/* 274 */     endiumPickaxe = new ItemEndiumPickaxe();
/*     */     
/* 276 */     paladiumShovel = new ItemPaladiumShovel();
/* 277 */     titaneShovel = new ItemTitaneShovel();
/* 278 */     amethystShovel = new ItemAmethystShovel();
/*     */     
/* 280 */     paladiumAxe = new ItemPaladiumAxe();
/* 281 */     titaneAxe = new ItemTitaneAxe();
/* 282 */     amethystAxe = new ItemAmethystAxe();
/* 283 */     endiumAxe = new ItemEndiumAxe();
/*     */     
/* 285 */     paladiumHammer = new ItemPaladiumHammer();
/* 286 */     titaneHammer = new ItemTitaneHammer();
/* 287 */     amethystHammer = new ItemAmethystHammer();
/* 288 */     smithHammer = new ItemSmithHammer();
/*     */     
/* 290 */     paladiumSword = new ItemPaladiumSword();
/* 291 */     titaneSword = new ItemTitaneSword();
/* 292 */     amethystSword = new ItemAmethystSword();
/* 293 */     endiumSword = new ItemEndiumSword();
/* 294 */     infernalKnocker = new ItemInfernalKnocker();
/* 295 */     paladiumBroadsword = new ItemPaladiumBroadsword();
/* 296 */     amethystBroadsword = new ItemAmethystBroadsword();
/* 297 */     titaneBroadsword = new ItemTitaneBroadsword();
/* 298 */     paladiumFastSword = new ItemPaladiumFastsword();
/* 299 */     amethystFastSword = new ItemAmethystFastsword();
/* 300 */     titaneFastSword = new ItemTitaneFastsword();
/* 301 */     toolTrap = new ItemToolTrap();
/*     */     
/* 303 */     paladiumBow = new ItemPaladiumBow();
/*     */     
/* 305 */     paladiumHelmet = new ItemArmorPaladium(0, "paladiumhelmet", "PaladiumHelmet");
/* 306 */     paladiumChestplate = new ItemArmorPaladium(1, "paladiumchestplate", "PaladiumChestplate");
/* 307 */     paladiumLeggings = new ItemArmorPaladium(2, "paladiumleggings", "PaladiumLeggings");
/* 308 */     paladiumBoots = new ItemArmorPaladium(3, "paladiumboots", "PaladiumBoots");
/*     */     
/* 310 */     titaneHelmet = new ItemArmorTitane(0, "titanehelmet", "TitaneHelmet");
/* 311 */     titaneChestplate = new ItemArmorTitane(1, "titanechestplate", "TitaneChestplate");
/* 312 */     titaneLeggings = new ItemArmorTitane(2, "titaneleggings", "TitaneLeggings");
/* 313 */     titaneBoots = new ItemArmorTitane(3, "titaneboots", "TitaneBoots");
/*     */     
/* 315 */     amethystHelmet = new ItemArmorAmethyst(0, "amethysthelmet", "AmethystHelmet");
/* 316 */     amethystChestplate = new ItemArmorAmethyst(1, "amethystchestplate", "AmethystChestplate");
/* 317 */     amethystLeggings = new ItemArmorAmethyst(2, "amethystleggings", "AmethystLeggings");
/* 318 */     amethystBoots = new ItemArmorAmethyst(3, "amethystboots", "AmethystBoots");
/*     */     
/* 320 */     endiumHelmet = new ItemArmorEndium(0, "endiumhelmet", "EndiumHelmet");
/* 321 */     endiumChestplate = new ItemArmorEndium(1, "endiumchestplate", "EndiumChestplate");
/* 322 */     endiumLeggings = new ItemArmorEndium(2, "endiumleggings", "EndiumLeggings");
/* 323 */     endiumBoots = new ItemArmorEndium(3, "endiumboots", "EndiumBoots");
/*     */     
/* 325 */     travelLeggings = new ItemArmorTravel(2, "travellegging", "TravelLeggings", 1);
/* 326 */     travelBoots = new ItemArmorTravel(3, "travelboots", "TravelBoots", 0);
/* 327 */     jumpChest = new ItemArmorTravel(1, "jumpchest", "JumpChest", 2);
/* 328 */     slimyHelmet = new ItemArmorTravel(0, "slimyhelmet", "SlimyHelmet", 3);
/* 329 */     scubaHelmet = new ItemArmorTravel(0, "scubahelmet", "ScubaHelmet", 4);
/* 330 */     hoodHelmet = new ItemArmorTravel(0, "hoodhelmet", "HoodHelmet", 5);
/* 331 */     chestExplorer = new ItemChestExplorer();
/*     */     
/* 333 */     paladiumApple = new ItemPaladiumApple();
/* 334 */     hangGlider = new ItemHangGlider();
/* 335 */     explosiveStone = new ItemExplosiveStoneBase("explosivestone", "ExplosiveStone", 0);
/* 336 */     guardianStone = new ItemGuardianStone();
/* 337 */     voidStone = new ItemVoidStone();
/* 338 */     stuffSwitcher = new ItemStuffSwitcher();
/*     */     
/* 340 */     backpack = new ItemBackpack();
/* 341 */     MagicalAnvilTop = new ItemMagicalAnvilTop();
/* 342 */     MagicalAnvilMiddle = new ItemMagicalAnvilMiddle();
/* 343 */     MagicalAnvilBottom = new ItemMagicalAnvilBottom();
/*     */     
/* 345 */     guardianWhitelist = new ItemGuardianWhitelist();
/*     */     
/* 347 */     guardianXpUpgrade = new ItemGuardianUpgrade("guardianxpupgrade", "GuardianExperienceUpgrade", 0, 5);
/*     */     
/* 349 */     guardianNametagUpgrade = new ItemGuardianCosmeticUpgrade("guardiannametagupgrade", "GuardianNametagUpgrade", 0, 0);
/*     */     
/* 351 */     smallRing = new ItemRingBase(500, "smallring", "SmallRing");
/* 352 */     mediumRing = new ItemRingBase(1000, "mediumring", "MediumRing");
/* 353 */     bigRing = new ItemRingBase(3000, "bigring", "BigRing");
/*     */     
/* 355 */     healOrb = new ItemHealOrb();
/* 356 */     speedOrb = new ItemSpeedOrb();
/* 357 */     strenghtOrb = new ItemStrenghtOrb();
/* 358 */     jumpOrb = new ItemJumpOrb();
/* 359 */     knockbackOrb = new ItemKnockbackOrb();
/* 360 */     paladiumStick = new ItemPaladiumStick();
/* 361 */     compressedPaladium = new Item().setUnlocalizedName("compressedpaladium").setTextureName("palamod:CompressedPaladium").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 362 */     compressedTitane = new Item().setUnlocalizedName("compressedtitane").setTextureName("palamod:CompressedTitane").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 363 */     compressedAmethyst = new Item().setUnlocalizedName("compressedamethyst").setTextureName("palamod:CompressedAmethyst").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 364 */     witherSkullFragment = new ItemWitherSkullFragment();
/* 365 */     paladiumCore = new ItemPaladiumCore();
/* 366 */     titaneStick = new ItemTitaneStick();
/* 367 */     amethystStick = new ItemAmethystStick();
/* 368 */     diamondString = new ItemStringDiamond();
/* 369 */     wing = new ItemWing();
/* 370 */     bowModifer = new ItemBowModifier();
/*     */     
/* 372 */     smeltModifier = new ItemGrinderModifier("smeltmodifier", "SmeltModifier");
/* 373 */     fortuneModifier = new ItemGrinderModifier("fortunemodifier", "FortuneModifier");
/* 374 */     speedModifier = new ItemGrinderModifier("speedmodifier", "SpeedModifier");
/* 375 */     damageModifier = new ItemGrinderModifier("damagemodifier", "DamageModifier");
/* 376 */     flameModifier = new ItemGrinderModifier("flamemodifier", "FlameModifier");
/* 377 */     knockbackModifier = new ItemGrinderModifier("knockbackmodifier", "KnockbackModifier");
/* 378 */     autoRepairModifier = new ItemGrinderModifier("autorepairmodifier", "AutoRepairModifier");
/* 379 */     healStick = new ItemStickBase(15, "healstick", "HealStick", 10, 0, new double[] { 255.0D, 0.0D, 0.0D });
/* 380 */     speedStick = new ItemStickBase(15, "speedstick", "SpeedStick", 15, 1, new double[] { 73.0D, 173.0D, 244.0D });
/* 381 */     strenghtStick = new ItemStickBase(15, "strenghtstick", "StrenghtStick", 15, 2, new double[] { 244.0D, 212.0D, 66.0D });
/* 382 */     jumpStick = new ItemStickBase(15, "jumpstick", "JumpStick", 6, 3, new double[] { 244.0D, 143.0D, 66.0D });
/* 383 */     godStick = new ItemStickBase(8, "stickofgod", "StickOfGod", 30, 4, new double[] { 244.0D, 238.0D, 66.0D });
/* 384 */     damageStick = new ItemStickBase(16, "damagestick", "DamageStick", 6, 5, new double[] { 255.0D, 0.0D, 0.0D });
/* 385 */     hyperJumpStick = new ItemStickBase(5, "hyperjumpstick", "HyperJumpStick", 12, 6, new double[] { 80.0D, 244.0D, 66.0D });
/*     */     
/* 387 */     potionWither = new ItemPotion("witherimbue", "PotionWither", new PotionEffect(ModPotions.potionWither.id, 2000, 1));
/* 388 */     potionFire = new ItemPotion("fireimbue", "PotionFire", new PotionEffect(ModPotions.potionFire.id, 2000, 1));
/* 389 */     potionPoison = new ItemPotion("poisonimbue", "PotionPoison", new PotionEffect(ModPotions.potionPoison.id, 2000, 1));
/* 390 */     sicknessPotion = new ItemSplashPotion("sicknesspotion", "SicknessPotion", new PotionEffect(Potion.confusion.id, 200, 1), 0);
/*     */     
/* 392 */     potionLauncher = new ItemPotionLauncher();
/*     */     
/* 394 */     arrowPoison = new ItemArrowBase("arrowpoison", "ArrowPoison", 0);
/* 395 */     arrowSlowness = new ItemArrowBase("arrowslowness", "ArrowSlowness", 2);
/* 396 */     arrowWither = new ItemArrowBase("arrowwither", "ArrowWither", 1);
/* 397 */     arrowSwitch = new ItemArrowBase("arrowswitch", "ArrowSwitch", 3);
/*     */     
/* 399 */     bowRangeModifier = new ItemBowRangeModifier();
/* 400 */     bowSpeedModifier = new ItemBowSpeedModifier();
/*     */     
/* 402 */     paternAxe = new ItemPatern("paternaxe", "PaternAxe", ItemPatern.AXE);
/* 403 */     paternHammer = new ItemPatern("paternhammer", "paternHammer", ItemPatern.HAMMER);
/* 404 */     paternShovel = new ItemPatern("paternshovel", "paternShovel", ItemPatern.SHOVEL);
/* 405 */     paternBroadsword = new ItemPatern("paternbroadsword", "PaternBroadSword", ItemPatern.BROADSWORD);
/* 406 */     paternFastSword = new ItemPatern("paternfastsword", "PaternFastSword", ItemPatern.FASTSWORD);
/* 407 */     paternPickaxe = new ItemPatern("paternpickaxe", "PaternPickaxe", ItemPatern.PICKAXE);
/* 408 */     paternSword = new ItemPatern("paternsword", "PaternSword", ItemPatern.SWORD);
/* 409 */     paternIngot = new ItemPatern("paterningot", "PaternIngot", ItemPatern.INGOT);
/* 410 */     paternBlock = new ItemPatern("paternblock", "PaternBlock", 8);
/* 411 */     paternSocket = new ItemPatern("paternsocket", "PaternSocket", ItemPatern.SOCKET);
/* 412 */     fastSwordHead = new ItemToolPart("FastSwordHead", "fastswordhead");
/* 413 */     broadSwordHead = new ItemToolPart("BroadSwordHead", "broadswordhead");
/* 414 */     pickaxeHead = new ItemToolPart("PickaxeHead", "pickaxehead");
/* 415 */     swordHead = new ItemToolPart("SwordHead", "swordhead");
/* 416 */     hammerHead = new ItemToolPart("HammerHead", "hammerhead");
/* 417 */     axeHead = new ItemToolPart("AxeHead", "axehead");
/* 418 */     shovelHead = new ItemToolPart("ShovelHead", "shovelhead");
/*     */     
/* 420 */     itemSpawnWither = new ItemSpawnWither();
/* 421 */     unSummoner = new ItemWitherUnSummoner();
/*     */     
/* 423 */     explode_obsidian_upgrade = new ItemObsidianUpgrade(ItemObsidianUpgrade.Upgrade.Explode).setUnlocalizedName("explode_obsidian_upgrade").setTextureName("palamod:explode_obsidian_upgrade").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 424 */     fake_obsidian_upgrade = new ItemObsidianUpgrade(ItemObsidianUpgrade.Upgrade.Fake).setUnlocalizedName("fake_obsidian_upgrade").setTextureName("palamod:fake_obsidian_upgrade").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 425 */     twoLife_obsidian_upgrade = new ItemObsidianUpgrade(ItemObsidianUpgrade.Upgrade.TwoLife).setUnlocalizedName("twoLife_obsidian_upgrade").setTextureName("palamod:twoLife_obsidian_upgrade").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 426 */     camouflage_obsidian_upgrade = new ItemObsidianUpgrade(ItemObsidianUpgrade.Upgrade.Camouflage).setUnlocalizedName("camouflage_obsidian_upgrade").setTextureName("palamod:camouflage_obsidian_upgrade").setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */     
/* 428 */     camera_tablet = new ItemCameraTablet().setUnlocalizedName("camera_tablet").setTextureName("palamod:camera_tablet").setCreativeTab(CreativeTabRegister.PALADIUM);
/* 429 */     guardianWand = new ItemGuardianWand();
/* 430 */     obsidianUpgrade = new ItemGrinderModifier("obsidianupgrade", "ObsidianUpgrade");
/* 431 */     moreUpgrade = new ItemGrinderModifier("moreupgrade", "MoreUpgrade");
/* 432 */     anchorUpgrade = new ItemGuardianUpgrade("guardiananchorupgrade", "GuardianAnchorUpgrade", 1, 10);
/* 433 */     regenOneUpgrade = new ItemGuardianUpgrade("guardianregenoneupgrade", "GuardianRegenOneUpgrade", 2, 5);
/* 434 */     regenTwoUpgrade = new ItemGuardianUpgrade("guardianregentwoupgrade", "GuardianRegenTwoUpgrade", 3, 30);
/* 435 */     regenThreeUpgrade = new ItemGuardianUpgrade("guardianregenthreeupgrade", "GuardianRegenThreeUpgrade", 4, 40);
/* 436 */     chestUpgrade = new ItemGuardianUpgrade("guardianchestupgrade", "GuardianChestUpgrade", 5, 30);
/* 437 */     guardianMoreUpgrade = new ItemGuardianUpgrade("guardianmoreupgrade", "GuardianMoreUpgrade", 6, 20);
/* 438 */     guardianLifeUpgrade1 = new ItemGuardianUpgrade("guardianlifeupgradeone", "GuardianLifeUpgradeOne", 7, 5);
/* 439 */     guardianLifeUpgrade2 = new ItemGuardianUpgrade("guardianlifeupgradetwo", "GuardianLifeUpgradeTwo", 8, 20);
/* 440 */     guardianLifeUpgrade3 = new ItemGuardianUpgrade("guardianlifeupgradethree", "GuardianLifeUpgradeThree", 9, 30);
/* 441 */     guardianDamageUpgrade1 = new ItemGuardianUpgrade("guardiandamageupgradeone", "GuardianDamageUpgradeOne", 10, 20);
/* 442 */     guardianDamageUpgrade2 = new ItemGuardianUpgrade("guardiandamageupgradetwo", "GuardianDamageUpgradeTwo", 11, 40);
/* 443 */     guardianDamageUpgrade3 = new ItemGuardianUpgrade("guardiandamageupgradethree", "GuardianDamageUpgradeThree", 12, 60);
/* 444 */     guardianPeneUpgrade1 = new ItemGuardianUpgrade("guardianpeneupgradeone", "GuardianPeneUpgradeOne", 13, 20);
/* 445 */     guardianPeneUpgrade2 = new ItemGuardianUpgrade("guardianpeneupgradetwo", "GuardianPeneUpgradeTwo", 14, 40);
/* 446 */     guardianPeneUpgrade3 = new ItemGuardianUpgrade("guardianpeneupgradethree", "GuardianPeneUpgradeThree", 15, 60);
/* 447 */     guardianExplosiveUpgrade = new ItemGuardianUpgrade("guardianexplosionupgrade", "GuardianExplosionUpgrade", 16, 20);
/* 448 */     guardianThornsUpgrade1 = new ItemGuardianUpgrade("guardianthornsupgradeone", "GuardianThornsUpgradeOne", 17, 10);
/* 449 */     guardianThornsUpgrade2 = new ItemGuardianUpgrade("guardianthornsupgradetwo", "GuardianThornsUpgradeTwo", 18, 20);
/* 450 */     guardianThornsUpgrade3 = new ItemGuardianUpgrade("guardianthornsupgradethree", "GuardianThornsUpgradeThree", 19, 30);
/* 451 */     guardianWeaponUpgrade = new ItemGuardianUpgrade("guardianweaponupgrade", "GuardianWeaponUpgrade", 20, 30);
/* 452 */     guardianFarmUpgrade = new ItemGuardianUpgrade("guardianfarmupgrade", "GuardianFarmUpgrade", 21, 30);
/* 453 */     guardianAutoXPUpgrade = new ItemGuardianUpgrade("guardianautoxpupgrade", "GuardianAutoXPUpgrade", 22, 10);
/*     */     
/* 455 */     GameRegistry.registerItem(paladiumPickaxe, "paladiumPickaxe");
/* 456 */     GameRegistry.registerItem(titanePickaxe, "titanePickaxe");
/* 457 */     GameRegistry.registerItem(amethystPickaxe, "amethystPickaxe");
/* 458 */     GameRegistry.registerItem(endiumPickaxe, "endiumPickaxe");
/*     */     
/* 460 */     GameRegistry.registerItem(paladiumShovel, "paladiumShovel");
/* 461 */     GameRegistry.registerItem(titaneShovel, "titaneShovel");
/* 462 */     GameRegistry.registerItem(amethystShovel, "amethystShovel");
/*     */     
/* 464 */     GameRegistry.registerItem(paladiumAxe, "paladiumAxe");
/* 465 */     GameRegistry.registerItem(titaneAxe, "titaneAxe");
/* 466 */     GameRegistry.registerItem(amethystAxe, "amethystAxe");
/* 467 */     GameRegistry.registerItem(endiumAxe, "endiumAxe");
/*     */     
/* 469 */     GameRegistry.registerItem(paladiumHammer, "paladiumHammer");
/* 470 */     GameRegistry.registerItem(titaneHammer, "titaneHammer");
/* 471 */     GameRegistry.registerItem(amethystHammer, "amethystHammer");
/* 472 */     GameRegistry.registerItem(smithHammer, "smithHammer");
/*     */     
/* 474 */     GameRegistry.registerItem(paladiumSword, "paladiumSword");
/* 475 */     GameRegistry.registerItem(titaneSword, "titaneSword");
/* 476 */     GameRegistry.registerItem(amethystSword, "amethystSword");
/* 477 */     GameRegistry.registerItem(endiumSword, "endiumSword");
/* 478 */     GameRegistry.registerItem(infernalKnocker, "infernalKnocker");
/* 479 */     GameRegistry.registerItem(paladiumBroadsword, "paladiumBroadsword");
/* 480 */     GameRegistry.registerItem(titaneBroadsword, "titaneBroadsword");
/* 481 */     GameRegistry.registerItem(amethystBroadsword, "amethystBroadsword");
/* 482 */     GameRegistry.registerItem(paladiumFastSword, "paladiumFastSword");
/* 483 */     GameRegistry.registerItem(amethystFastSword, "amethystFastSword");
/* 484 */     GameRegistry.registerItem(titaneFastSword, "titaneFastSword");
/* 485 */     GameRegistry.registerItem(toolTrap, "toolTrap");
/*     */     
/* 487 */     GameRegistry.registerItem(paladiumBow, "paladiumBow");
/*     */     
/* 489 */     GameRegistry.registerItem(paladiumHelmet, "paladiumHelmet");
/* 490 */     GameRegistry.registerItem(paladiumChestplate, "paladiumChestplate");
/* 491 */     GameRegistry.registerItem(paladiumLeggings, "paladiumLeggings");
/* 492 */     GameRegistry.registerItem(paladiumBoots, "paladiumBoots");
/*     */     
/* 494 */     GameRegistry.registerItem(titaneHelmet, "titaneHelmet");
/* 495 */     GameRegistry.registerItem(titaneChestplate, "titaneChestplate");
/* 496 */     GameRegistry.registerItem(titaneLeggings, "titaneLeggings");
/* 497 */     GameRegistry.registerItem(titaneBoots, "titaneBoots");
/*     */     
/* 499 */     GameRegistry.registerItem(amethystHelmet, "amethystHelmet");
/* 500 */     GameRegistry.registerItem(amethystChestplate, "amethystChestplate");
/* 501 */     GameRegistry.registerItem(amethystLeggings, "amethystLeggings");
/* 502 */     GameRegistry.registerItem(amethystBoots, "amethystBoots");
/*     */     
/* 504 */     GameRegistry.registerItem(endiumHelmet, "endiumHelmet");
/* 505 */     GameRegistry.registerItem(endiumChestplate, "endiumChestplate");
/* 506 */     GameRegistry.registerItem(endiumLeggings, "endiumLeggings");
/* 507 */     GameRegistry.registerItem(endiumBoots, "endiumBoots");
/*     */     
/* 509 */     GameRegistry.registerItem(travelLeggings, "travelLeggings");
/* 510 */     GameRegistry.registerItem(travelBoots, "travelBoots");
/* 511 */     GameRegistry.registerItem(jumpChest, "jumpChest");
/* 512 */     GameRegistry.registerItem(slimyHelmet, "slimyHelmet");
/* 513 */     GameRegistry.registerItem(scubaHelmet, "scubaHelmet");
/* 514 */     GameRegistry.registerItem(hoodHelmet, "hoodHelmet");
/* 515 */     GameRegistry.registerItem(autoRepairModifier, "autoRepairModifier");
/* 516 */     GameRegistry.registerItem(paladiumApple, "paladiumApple");
/* 517 */     GameRegistry.registerItem(hangGlider, "hangGlider");
/*     */     
/* 519 */     GameRegistry.registerItem(guardianStone, "guardianStone");
/* 520 */     GameRegistry.registerItem(voidStone, "voidStone");
/* 521 */     GameRegistry.registerItem(chestExplorer, "chestExplorer");
/* 522 */     GameRegistry.registerItem(stuffSwitcher, "stuffSwitcher");
/* 523 */     GameRegistry.registerItem(MagicalAnvilTop, "MagicalAnvilTop");
/* 524 */     GameRegistry.registerItem(MagicalAnvilMiddle, "MagicalAnvilMiddle");
/* 525 */     GameRegistry.registerItem(MagicalAnvilBottom, "MagicalAnvilBottom");
/*     */     
/* 527 */     GameRegistry.registerItem(backpack, "backpack");
/*     */     
/* 529 */     GameRegistry.registerItem(guardianWhitelist, "guardianWhitelist");
/*     */     
/* 531 */     GameRegistry.registerItem(guardianXpUpgrade, "guardianXpUpgrade");
/*     */     
/* 533 */     GameRegistry.registerItem(guardianNametagUpgrade, "guardianNametagUpgrade");
/*     */     
/* 535 */     GameRegistry.registerItem(smallRing, "smallRing");
/* 536 */     GameRegistry.registerItem(mediumRing, "mediumRing");
/* 537 */     GameRegistry.registerItem(bigRing, "bigRing");
/*     */     
/* 539 */     GameRegistry.registerItem(healOrb, "healOrb");
/* 540 */     GameRegistry.registerItem(speedOrb, "speedOrb");
/* 541 */     GameRegistry.registerItem(strenghtOrb, "strenghtOrb");
/* 542 */     GameRegistry.registerItem(jumpOrb, "jumpOrb");
/* 543 */     GameRegistry.registerItem(knockbackOrb, "knockbackOrb");
/* 544 */     GameRegistry.registerItem(paladiumStick, "paladiumStick");
/* 545 */     GameRegistry.registerItem(compressedPaladium, "compressedPaladium");
/* 546 */     GameRegistry.registerItem(compressedTitane, "compressedTitane");
/* 547 */     GameRegistry.registerItem(compressedAmethyst, "compressedAmethyst");
/* 548 */     GameRegistry.registerItem(witherSkullFragment, "witherSkullFragment");
/* 549 */     GameRegistry.registerItem(paladiumCore, "paladiumCore");
/* 550 */     GameRegistry.registerItem(amethystStick, "amethystStick");
/* 551 */     GameRegistry.registerItem(titaneStick, "titaneStick");
/* 552 */     GameRegistry.registerItem(diamondString, "diamondString");
/* 553 */     GameRegistry.registerItem(wing, "wing");
/* 554 */     GameRegistry.registerItem(bowModifer, "bowModifer");
/*     */     
/* 556 */     GameRegistry.registerItem(healStick, "healStick");
/* 557 */     GameRegistry.registerItem(speedStick, "speedStick");
/* 558 */     GameRegistry.registerItem(strenghtStick, "strenghtStick");
/* 559 */     GameRegistry.registerItem(jumpStick, "jumpStick");
/* 560 */     GameRegistry.registerItem(godStick, "godStick");
/* 561 */     GameRegistry.registerItem(damageStick, "damageStick");
/* 562 */     GameRegistry.registerItem(hyperJumpStick, "hyperJumpStick");
/*     */     
/* 564 */     GameRegistry.registerItem(potionWither, "potionWither");
/* 565 */     GameRegistry.registerItem(potionFire, "potionFire");
/* 566 */     GameRegistry.registerItem(potionPoison, "potionPoison");
/* 567 */     GameRegistry.registerItem(sicknessPotion, "sicknessPotion");
/*     */     
/* 569 */     GameRegistry.registerItem(potionLauncher, "potionLauncher");
/*     */     
/* 571 */     GameRegistry.registerItem(arrowPoison, "arrowPoison");
/* 572 */     GameRegistry.registerItem(arrowWither, "arrowWither");
/* 573 */     GameRegistry.registerItem(arrowSlowness, "arrowSlowness");
/* 574 */     GameRegistry.registerItem(arrowSwitch, "arrowSpeed");
/*     */     
/* 576 */     GameRegistry.registerItem(bowRangeModifier, "bowRangeModifier");
/* 577 */     GameRegistry.registerItem(bowSpeedModifier, "bowSpeedModifier");
/*     */     
/* 579 */     GameRegistry.registerItem(knockbackModifier, "knockbackModifier");
/* 580 */     GameRegistry.registerItem(flameModifier, "flameModifier");
/* 581 */     GameRegistry.registerItem(fortuneModifier, "fortuneModifier");
/* 582 */     GameRegistry.registerItem(smeltModifier, "smeltModifier");
/* 583 */     GameRegistry.registerItem(damageModifier, "damageModifier");
/* 584 */     GameRegistry.registerItem(speedModifier, "speedModifier");
/*     */     
/* 586 */     GameRegistry.registerItem(paternBroadsword, "paternBroadsword");
/* 587 */     GameRegistry.registerItem(paternFastSword, "paternFastSword");
/* 588 */     GameRegistry.registerItem(paternSword, "paternSword");
/* 589 */     GameRegistry.registerItem(paternPickaxe, "paternPickaxe");
/* 590 */     GameRegistry.registerItem(paternAxe, "paternAxe");
/* 591 */     GameRegistry.registerItem(paternShovel, "paternShovel");
/* 592 */     GameRegistry.registerItem(paternHammer, "paternHammer");
/* 593 */     GameRegistry.registerItem(paternBlock, "paternBlock");
/* 594 */     GameRegistry.registerItem(paternIngot, "paternIngot");
/* 595 */     GameRegistry.registerItem(paternSocket, "paternsocket");
/* 596 */     GameRegistry.registerItem(broadSwordHead, "broadSwordHead");
/* 597 */     GameRegistry.registerItem(fastSwordHead, "fastSwordHead");
/* 598 */     GameRegistry.registerItem(swordHead, "swordHead");
/* 599 */     GameRegistry.registerItem(pickaxeHead, "pickaxeHead");
/* 600 */     GameRegistry.registerItem(hammerHead, "hammerHead");
/* 601 */     GameRegistry.registerItem(axeHead, "axeHead");
/* 602 */     GameRegistry.registerItem(shovelHead, "shovelHead");
/* 603 */     GameRegistry.registerItem(itemrune, "itemrune");
/* 604 */     GameRegistry.registerItem(itemrune2, "itemrune2");
/* 605 */     GameRegistry.registerItem(itemrune3, "itemrune3");
/* 606 */     GameRegistry.registerItem(itemrune4, "itemrune4");
/* 607 */     GameRegistry.registerItem(itemshardrune, "itemshardrune");
/* 608 */     GameRegistry.registerItem(itemshardrune2, "itemshardrune2");
/* 609 */     GameRegistry.registerItem(itemshardrune3, "itemshardrune3");
/* 610 */     GameRegistry.registerItem(itemshardrune4, "itemshardrune4");
/* 611 */     GameRegistry.registerItem(explode_obsidian_upgrade, "explode_obsidian_upgrade");
/* 612 */     GameRegistry.registerItem(fake_obsidian_upgrade, "fake_obsidian_upgrade");
/* 613 */     GameRegistry.registerItem(twoLife_obsidian_upgrade, "twoLife_obsidian_upgrade");
/* 614 */     GameRegistry.registerItem(camouflage_obsidian_upgrade, "camouflage_obsidian_upgrade");
/* 615 */     GameRegistry.registerItem(itemSpawnWither, "spawnwither");
/* 616 */     GameRegistry.registerItem(unSummoner, "unsumoner");
/* 617 */     GameRegistry.registerItem(camera_tablet, "camera_tablet");
/* 618 */     GameRegistry.registerItem(guardianWand, "guardianWand");
/* 619 */     GameRegistry.registerItem(obsidianUpgrade, "obsidianUpgrade");
/* 620 */     GameRegistry.registerItem(moreUpgrade, "moreUpgrade");
/* 621 */     GameRegistry.registerItem(anchorUpgrade, "anchorUpgrade");
/* 622 */     GameRegistry.registerItem(regenOneUpgrade, "regenOneUpgrade");
/* 623 */     GameRegistry.registerItem(regenTwoUpgrade, "regenTwoUpgrade");
/* 624 */     GameRegistry.registerItem(regenThreeUpgrade, "regenThreeUpgrade");
/* 625 */     GameRegistry.registerItem(chestUpgrade, "chestUpgrade");
/* 626 */     GameRegistry.registerItem(guardianWeaponUpgrade, "guardianWeaponUpgrade");
/* 627 */     GameRegistry.registerItem(guardianAutoXPUpgrade, "guardianAutoXpUpgrade");
/* 628 */     GameRegistry.registerItem(guardianDamageUpgrade1, "guardianDamageUpgrade1");
/* 629 */     GameRegistry.registerItem(guardianDamageUpgrade2, "guardianDamageUpgrade2");
/* 630 */     GameRegistry.registerItem(guardianDamageUpgrade3, "guardianDamageUpgrade3");
/* 631 */     GameRegistry.registerItem(guardianExplosiveUpgrade, "guardianExplosiveUpgrade");
/* 632 */     GameRegistry.registerItem(guardianFarmUpgrade, "guardianFarmUpgrade");
/* 633 */     GameRegistry.registerItem(guardianLifeUpgrade1, "guardianLifeUpgrade1");
/* 634 */     GameRegistry.registerItem(guardianLifeUpgrade2, "guardianLifeUpgrade2");
/* 635 */     GameRegistry.registerItem(guardianLifeUpgrade3, "guardianLifeUpgrade3");
/* 636 */     GameRegistry.registerItem(guardianPeneUpgrade1, "guardianPeneUpgrade1");
/* 637 */     GameRegistry.registerItem(guardianPeneUpgrade2, "guardianPeneUpgrade2");
/* 638 */     GameRegistry.registerItem(guardianPeneUpgrade3, "guardianPeneUpgrade3");
/* 639 */     GameRegistry.registerItem(guardianMoreUpgrade, "guardianMoreUpgrade");
/* 640 */     GameRegistry.registerItem(guardianThornsUpgrade1, "guardianThornsUpgrade1");
/* 641 */     GameRegistry.registerItem(guardianThornsUpgrade2, "guardianThornsUpgrade2");
/* 642 */     GameRegistry.registerItem(guardianThornsUpgrade3, "guardianThornsUpgrade3");
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ModItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */