/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ public class ItemGuardianCosmeticUpgrade
/*    */   extends Item
/*    */ {
/*    */   public static final int NAMETAG = 0;
/*    */   public int type;
/*    */   public int level;
/*    */   
/*    */   public ItemGuardianCosmeticUpgrade(String name, String texture, int type, int level)
/*    */   {
/* 16 */     this.type = type;
/* 17 */     this.level = level;
/* 18 */     setMaxStackSize(1);
/* 19 */     setUnlocalizedName(name);
/* 20 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 21 */     setTextureName("palamod:" + texture);
/*    */   }
/*    */   
/*    */   public int getRequiredLevel() {
/* 25 */     return this.level;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 29 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemGuardianCosmeticUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */