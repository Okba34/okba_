/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class ItemStuffSwitcher
/*    */   extends Item
/*    */ {
/*    */   public ItemStuffSwitcher()
/*    */   {
/* 20 */     setMaxStackSize(1);
/* 21 */     setUnlocalizedName("stuffswitcher");
/* 22 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 23 */     setTextureName("palamod:StuffSwitcher");
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {
/* 27 */     if (player.isSneaking()) {
/* 28 */       if (!world.isRemote) {
/* 29 */         player.openGui(PalaMod.instance, 14, world, 0, 0, 0);
/*    */       }
/*    */     } else {
/* 32 */       if ((stack.hasTagCompound()) && (stack.getTagCompound().getInteger("Cooldown") > 0)) {
/* 33 */         if (world.isRemote) {
/* 34 */           player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Tu ne dois pas spammer le stuff switcher !", new Object[0]));
/*    */         }
/* 36 */         return stack;
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 43 */       if (world.isRemote) {
/* 44 */         player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.RED + "Cet item est temporairement bloquÃ© !", new Object[0]));
/*    */       }
/*    */     }
/* 47 */     return stack;
/*    */   }
/*    */   
/*    */   public void onUpdate(ItemStack stack, World world, Entity player, int p_77663_4_, boolean b)
/*    */   {
/* 52 */     if (stack.hasTagCompound()) {
/* 53 */       NBTTagCompound tag = stack.getTagCompound();
/* 54 */       int cd = tag.getInteger("Cooldown");
/* 55 */       if (cd > 0)
/* 56 */         tag.setInteger("Cooldown", cd - 1);
/* 57 */       stack.setTagCompound(tag);
/*    */     }
/*    */     
/* 60 */     if ((stack.hasTagCompound()) && (stack.getTagCompound().hasKey("Open")) && 
/* 61 */       (!b)) {
/* 62 */       stack.getTagCompound().setBoolean("Open", false);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemStuffSwitcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */