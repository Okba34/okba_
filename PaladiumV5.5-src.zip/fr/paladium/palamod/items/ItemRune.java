/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemRune
/*    */   extends Item
/*    */ {
/*    */   public static final int PERCENT = 0;
/*    */   public int level;
/* 17 */   private List<Object> a = new LinkedList();
/*    */   
/*    */   public ItemRune(int level)
/*    */   {
/* 21 */     setMaxStackSize(1);
/* 22 */     this.level = level;
/* 23 */     setUnlocalizedName("rune_" + level);
/* 24 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 25 */     setTextureName("palamod:Rune_" + level);
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 29 */     return this.level;
/*    */   }
/*    */   
/*    */   public String getType(List list) {
/* 33 */     int r = (int)(Math.random() * (this.a.size() - 1));
/* 34 */     return (String)this.a.get(r);
/*    */   }
/*    */   
/*    */   public static String getDisplayType(int type) {
/* 38 */     switch (type) {
/*    */     case 0: 
/* 40 */       return "%";
/*    */     }
/* 42 */     return "";
/*    */   }
/*    */   
/*    */   public static int getLevel(ItemStack stack) {
/* 46 */     if (((stack.getItem() instanceof ItemRune)) && (stack.hasTagCompound()) && (stack.getTagCompound().hasKey("level"))) {
/* 47 */       return stack.getTagCompound().getInteger("level");
/*    */     }
/* 49 */     return 0;
/*    */   }
/*    */   
/*    */   public static double getBonus(ItemStack stack) {
/* 53 */     if (((stack.getItem() instanceof ItemRune)) && (stack.hasTagCompound()) && (stack.getTagCompound().hasKey("Bonus"))) {
/* 54 */       return stack.getTagCompound().getDouble("Bonus");
/*    */     }
/* 56 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public static double getMalus(ItemStack stack) {
/* 60 */     if (((stack.getItem() instanceof ItemRune)) && (stack.hasTagCompound()) && (stack.getTagCompound().hasKey("Malus"))) {
/* 61 */       return stack.getTagCompound().getDouble("Malus");
/*    */     }
/* 63 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public static int getType(ItemStack stack) {
/* 67 */     if (((stack.getItem() instanceof ItemRune)) && (stack.hasTagCompound()) && (stack.getTagCompound().hasKey("Type"))) {
/* 68 */       return stack.getTagCompound().getInteger("Type");
/*    */     }
/* 70 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemRune.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */