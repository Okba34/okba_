/*    */ package fr.paladium.palamod.items;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemArrowBase
/*    */   extends Item
/*    */ {
/*    */   int effect;
/*    */   
/*    */   public ItemArrowBase(String name, String texture, int effect)
/*    */   {
/* 13 */     this.effect = effect;
/* 14 */     setMaxStackSize(64);
/* 15 */     setUnlocalizedName(name);
/* 16 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 17 */     setTextureName("palamod:" + texture);
/*    */   }
/*    */   
/*    */   public int getEffect() {
/* 21 */     return this.effect;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\items\ItemArrowBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */