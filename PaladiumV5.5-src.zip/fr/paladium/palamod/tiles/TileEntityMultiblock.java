/*     */ package fr.paladium.palamod.tiles;
/*     */ 
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TileEntityMultiblock
/*     */   extends TileEntity
/*     */ {
/*  42 */   private boolean hasMaster = false;
/*  43 */   protected boolean isMaster = false;
/*  44 */   private int masterX = 0;
/*  45 */   private int masterY = 0;
/*  46 */   private int masterZ = 0;
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  51 */     super.readFromNBT(compound);
/*  52 */     this.hasMaster = compound.getBoolean("HasMaster");
/*  53 */     this.isMaster = compound.getBoolean("IsMaster");
/*  54 */     this.masterX = compound.getInteger("MasterX");
/*  55 */     this.masterY = compound.getInteger("MasterY");
/*  56 */     this.masterZ = compound.getInteger("MasterZ");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  62 */     super.writeToNBT(compound);
/*  63 */     compound.setBoolean("HasMaster", this.hasMaster);
/*  64 */     compound.setBoolean("IsMaster", this.isMaster);
/*  65 */     compound.setInteger("MasterX", this.masterX);
/*  66 */     compound.setInteger("MasterY", this.masterY);
/*  67 */     compound.setInteger("MasterZ", this.masterZ);
/*     */   }
/*     */   
/*     */   public boolean hasMaster()
/*     */   {
/*  72 */     return this.hasMaster;
/*     */   }
/*     */   
/*     */   public boolean isMaster()
/*     */   {
/*  77 */     return this.isMaster;
/*     */   }
/*     */   
/*     */   public int getMasterX()
/*     */   {
/*  82 */     return this.masterX;
/*     */   }
/*     */   
/*     */   public int getMasterY()
/*     */   {
/*  87 */     return this.masterY;
/*     */   }
/*     */   
/*     */   public int getMasterZ()
/*     */   {
/*  92 */     return this.masterZ;
/*     */   }
/*     */   
/*     */   public void setMaster(int x, int y, int z)
/*     */   {
/*  97 */     this.hasMaster = true;
/*  98 */     this.masterX = x;
/*  99 */     this.masterY = y;
/* 100 */     this.masterZ = z;
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 105 */     this.isMaster = false;
/* 106 */     this.hasMaster = false;
/* 107 */     this.masterX = 0;
/* 108 */     this.masterY = 0;
/* 109 */     this.masterZ = 0;
/*     */   }
/*     */   
/*     */   public void setStructure(int sizeX, int sizeY, int sizeZ)
/*     */   {
/* 114 */     if (this.isMaster)
/*     */     {
/* 116 */       if (!checkStructure(sizeX, sizeY, sizeZ)) {
/* 117 */         resetStructure(sizeX, sizeY, sizeZ);
/*     */       }
/* 119 */     } else if (this.hasMaster)
/*     */     {
/* 121 */       if (!checkForMaster()) {
/* 122 */         reset();
/*     */       }
/* 124 */     } else if (!this.hasMaster)
/*     */     {
/* 126 */       if (checkStructure(sizeX, sizeY, sizeZ))
/* 127 */         setupStructure(sizeX, sizeY, sizeZ);
/*     */     }
/* 129 */     markDirty();
/*     */   }
/*     */   
/*     */   protected boolean checkStructure(int sizeX, int sizeY, int sizeZ)
/*     */   {
/* 134 */     int number = sizeX * sizeY * sizeZ;
/* 135 */     int n = 0;
/* 136 */     for (int x = this.xCoord - 1; x < this.xCoord + sizeX - 1; x++)
/*     */     {
/* 138 */       for (int y = this.yCoord; y < this.yCoord + sizeY; y++)
/*     */       {
/* 140 */         for (int z = this.zCoord - 1; z < this.zCoord + sizeZ - 1; z++)
/*     */         {
/* 142 */           TileEntity tile = this.worldObj.getTileEntity(x, y, z);
/* 143 */           if ((tile != null) && ((tile instanceof TileEntityMultiblock)))
/*     */           {
/* 145 */             TileEntityMultiblock t = (TileEntityMultiblock)tile;
/* 146 */             if (t.hasMaster)
/*     */             {
/* 148 */               if ((this.xCoord == t.getMasterX()) && (this.yCoord == t.getMasterY()) && (this.zCoord == t.getMasterZ())) {
/* 149 */                 n++;
/*     */               }
/*     */             } else {
/* 152 */               n++;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 158 */     if (n == number)
/* 159 */       return true;
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   private void setupStructure(int sizeX, int sizeY, int sizeZ)
/*     */   {
/* 165 */     for (int x = this.xCoord - 1; x < this.xCoord + sizeX - 1; x++)
/*     */     {
/* 167 */       for (int y = this.yCoord; y < this.yCoord + sizeY; y++)
/*     */       {
/* 169 */         for (int z = this.zCoord - 1; z < this.zCoord + sizeZ - 1; z++)
/*     */         {
/* 171 */           TileEntity tile = this.worldObj.getTileEntity(x, y, z);
/* 172 */           if ((tile != null) && ((tile instanceof TileEntityMultiblock)))
/*     */           {
/* 174 */             TileEntityMultiblock t = (TileEntityMultiblock)tile;
/* 175 */             t.setMaster(this.xCoord, this.yCoord, this.zCoord);
/* 176 */             this.isMaster = true;
/* 177 */             this.worldObj.markTileEntityChunkModified(x, y, z, this);
/* 178 */             this.worldObj.markBlockForUpdate(x, y, z);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetStructure(int sizeX, int sizeY, int sizeZ)
/*     */   {
/* 187 */     for (int x = this.xCoord - 1; x < this.xCoord + sizeX - 1; x++)
/*     */     {
/* 189 */       for (int y = this.yCoord; y < this.yCoord + sizeY; y++)
/*     */       {
/* 191 */         for (int z = this.zCoord - 1; z < this.zCoord + sizeZ - 1; z++)
/*     */         {
/* 193 */           TileEntity tile = this.worldObj.getTileEntity(x, y, z);
/* 194 */           if ((tile != null) && ((tile instanceof TileEntityMultiblock)))
/*     */           {
/* 196 */             TileEntityMultiblock t = (TileEntityMultiblock)tile;
/* 197 */             t.reset();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkForMaster()
/*     */   {
/* 206 */     TileEntity tile = this.worldObj.getTileEntity(this.masterX, this.masterY, this.masterZ);
/* 207 */     if ((tile != null) && ((tile instanceof TileEntityMultiblock)))
/*     */     {
/* 209 */       TileEntityMultiblock t = (TileEntityMultiblock)tile;
/* 210 */       if (t.isMaster())
/* 211 */         return true;
/*     */     }
/* 213 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 219 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 220 */     writeToNBT(nbttagcompound);
/* 221 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, getBlockMetadata(), nbttagcompound);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/* 227 */     readFromNBT(pkt.func_148857_g());
/* 228 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityMultiblock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */