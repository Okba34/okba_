/*    */ package fr.paladium.palamod.tiles;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class TileEntityGuardianAnchor extends TileEntity
/*    */ {
/*    */   static final int MAX_RADIUS = 16;
/*    */   int radius;
/*    */   
/*    */   public TileEntityGuardianAnchor()
/*    */   {
/* 15 */     this.radius = 16;
/*    */   }
/*    */   
/*    */   public void setRadius(int radius) {
/* 19 */     this.radius = radius;
/* 20 */     markDirty();
/* 21 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*    */   }
/*    */   
/*    */   public int getRadius() {
/* 25 */     return this.radius;
/*    */   }
/*    */   
/*    */   public boolean inRadius(double x, double y, double z) {
/* 29 */     if (Math.sqrt(Math.pow(x - this.xCoord, 2.0D) + Math.pow(y - this.yCoord, 2.0D) + Math.pow(z - this.zCoord, 2.0D)) > this.radius)
/* 30 */       return false;
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound compound)
/*    */   {
/* 36 */     super.writeToNBT(compound);
/* 37 */     compound.setInteger("radius", this.radius);
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound compound)
/*    */   {
/* 42 */     super.readFromNBT(compound);
/* 43 */     this.radius = compound.getInteger("radius");
/*    */   }
/*    */   
/*    */   public net.minecraft.network.Packet getDescriptionPacket()
/*    */   {
/* 48 */     NBTTagCompound nbtTag = new NBTTagCompound();
/* 49 */     writeToNBT(nbtTag);
/* 50 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, 1, nbtTag);
/*    */   }
/*    */   
/*    */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet) {
/* 54 */     readFromNBT(packet.func_148857_g());
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityGuardianAnchor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */