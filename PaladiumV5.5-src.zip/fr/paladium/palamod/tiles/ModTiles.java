/*    */ package fr.paladium.palamod.tiles;
/*    */ 
/*    */ import cpw.mods.fml.common.registry.GameRegistry;
/*    */ 
/*    */ 
/*    */ public class ModTiles
/*    */ {
/*    */   public static void init()
/*    */   {
/* 10 */     GameRegistry.registerTileEntityWithAlternatives(TileEntityOnlineDetector.class, "palamod:onlinedetector", new String[0]);
/* 11 */     GameRegistry.registerTileEntityWithAlternatives(TileEntityObsidianUpgrader.class, "palamod:obsidianUpgrader", new String[0]);
/* 12 */     GameRegistry.registerTileEntityWithAlternatives(TileEntityUpgradedObsidian.class, "palamod:upgradedObsidian", new String[0]);
/* 13 */     GameRegistry.registerTileEntityWithAlternatives(TileEntityCamera.class, "palamod:camera", new String[0]);
/* 14 */     GameRegistry.registerTileEntityWithAlternatives(TileEntityTurret.class, "palamod:turret", new String[0]);
/* 15 */     GameRegistry.registerTileEntityWithAlternatives(TileHarpagophytumFlower.class, "palamod:harpagophytumFlower", new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\ModTiles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */