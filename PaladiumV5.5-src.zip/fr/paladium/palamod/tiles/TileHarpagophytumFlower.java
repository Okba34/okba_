/*    */ package fr.paladium.palamod.tiles;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class TileHarpagophytumFlower extends TileEntity
/*    */ {
/*    */   public void readFromNBT(NBTTagCompound p_145839_1_)
/*    */   {
/* 10 */     super.readFromNBT(p_145839_1_);
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound p_145841_1_)
/*    */   {
/* 15 */     super.writeToNBT(p_145841_1_);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileHarpagophytumFlower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */