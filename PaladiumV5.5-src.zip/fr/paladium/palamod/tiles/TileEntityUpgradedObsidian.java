/*     */ package fr.paladium.palamod.tiles;
/*     */ 
/*     */ import fr.paladium.palamod.items.ItemObsidianUpgrade.Upgrade;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class TileEntityUpgradedObsidian
/*     */   extends TileEntity
/*     */ {
/*  14 */   private Boolean explode = Boolean.valueOf(false);
/*  15 */   private Boolean fake = Boolean.valueOf(false);
/*  16 */   private Boolean twoLife = Boolean.valueOf(false);
/*  17 */   private Boolean camouflage = Boolean.valueOf(false);
/*  18 */   private int life = 1;
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  23 */     super.writeToNBT(compound);
/*     */     
/*  25 */     compound.setBoolean("Explode", this.explode.booleanValue());
/*  26 */     compound.setBoolean("Fake", this.fake.booleanValue());
/*  27 */     compound.setBoolean("TwoLife", this.twoLife.booleanValue());
/*  28 */     compound.setBoolean("Camouflage", this.camouflage.booleanValue());
/*  29 */     compound.setInteger("Life", this.life);
/*     */   }
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  35 */     super.readFromNBT(compound);
/*     */     
/*  37 */     this.explode = Boolean.valueOf(compound.getBoolean("Explode"));
/*  38 */     this.fake = Boolean.valueOf(compound.getBoolean("Fake"));
/*  39 */     this.twoLife = Boolean.valueOf(compound.getBoolean("TwoLife"));
/*  40 */     this.camouflage = Boolean.valueOf(compound.getBoolean("Camouflage"));
/*  41 */     this.life = compound.getInteger("Life");
/*     */   }
/*     */   
/*     */   public void setInformations(List<ItemObsidianUpgrade.Upgrade> upgrades)
/*     */   {
/*  46 */     for (int i = 0; i < upgrades.size(); i++)
/*     */     {
/*  48 */       ItemObsidianUpgrade.Upgrade upgrade = (ItemObsidianUpgrade.Upgrade)upgrades.get(i);
/*  49 */       switch (upgrade)
/*     */       {
/*     */       case Explode: 
/*  52 */         this.explode = Boolean.valueOf(true);
/*  53 */         break;
/*     */       case Fake: 
/*  55 */         this.fake = Boolean.valueOf(true);
/*  56 */         break;
/*     */       case TwoLife: 
/*  58 */         this.twoLife = Boolean.valueOf(true);
/*  59 */         break;
/*     */       case Camouflage: 
/*  61 */         this.camouflage = Boolean.valueOf(true);
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   public List<ItemObsidianUpgrade.Upgrade> getInformations()
/*     */   {
/*  69 */     List<ItemObsidianUpgrade.Upgrade> upgrades = new ArrayList();
/*  70 */     if (this.explode.booleanValue())
/*  71 */       upgrades.add(ItemObsidianUpgrade.Upgrade.Explode);
/*  72 */     if (this.fake.booleanValue())
/*  73 */       upgrades.add(ItemObsidianUpgrade.Upgrade.Fake);
/*  74 */     if (this.twoLife.booleanValue())
/*  75 */       upgrades.add(ItemObsidianUpgrade.Upgrade.TwoLife);
/*  76 */     if (this.camouflage.booleanValue()) {
/*  77 */       upgrades.add(ItemObsidianUpgrade.Upgrade.Camouflage);
/*     */     }
/*  79 */     return upgrades;
/*     */   }
/*     */   
/*     */   public Boolean hasUpgrade(ItemObsidianUpgrade.Upgrade upgrade)
/*     */   {
/*  84 */     switch (upgrade)
/*     */     {
/*     */     case Explode: 
/*  87 */       return this.explode;
/*     */     case Fake: 
/*  89 */       return this.fake;
/*     */     case TwoLife: 
/*  91 */       return this.twoLife;
/*     */     case Camouflage: 
/*  93 */       return this.camouflage;
/*     */     }
/*  95 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAlife()
/*     */   {
/* 101 */     if (this.life == 1)
/*     */     {
/* 103 */       this.life -= 1;
/* 104 */       return true;
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */   
/*     */   public void setBaseLife()
/*     */   {
/* 111 */     this.life = 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldRefresh(Block oldBlock, Block newBlock, int oldMeta, int newMeta, World world, int x, int y, int z)
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityUpgradedObsidian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */