/*    */ package fr.paladium.palamod.tiles;
/*    */ 
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.network.NetworkManager;
/*    */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class TileEntityOnlineDetector extends TileEntity
/*    */ {
/*    */   String player;
/*    */   boolean playerOnline;
/*    */   
/*    */   public TileEntityOnlineDetector()
/*    */   {
/* 16 */     this.player = "";
/* 17 */     this.playerOnline = false;
/*    */   }
/*    */   
/*    */   public String getPlayerName() {
/* 21 */     return this.player;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 25 */     this.player = name;
/* 26 */     markDirty();
/* 27 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*    */   }
/*    */   
/*    */   public net.minecraft.network.Packet getDescriptionPacket()
/*    */   {
/* 32 */     NBTTagCompound nbtTag = new NBTTagCompound();
/* 33 */     writeToNBT(nbtTag);
/* 34 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, 1, nbtTag);
/*    */   }
/*    */   
/*    */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet) {
/* 38 */     readFromNBT(packet.func_148857_g());
/*    */   }
/*    */   
/*    */   public void updateEntity()
/*    */   {
/* 43 */     if (this.worldObj.getTotalWorldTime() % 20L == 0L) {
/* 44 */       boolean playerCheck = fr.paladium.palamod.util.PlayerHelper.isPlayerOnline(this.player);
/* 45 */       if (playerCheck != this.playerOnline) {
/* 46 */         markDirty();
/*    */         int meta;
/* 48 */         int meta; if (playerCheck) {
/* 49 */           meta = 1;
/*    */         } else
/* 51 */           meta = 0;
/* 52 */         this.worldObj.setBlockMetadataWithNotify(this.xCoord, this.yCoord, this.zCoord, meta, 3);
/* 53 */         this.playerOnline = playerCheck;
/*    */       }
/*    */     }
/* 56 */     super.updateEntity();
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound nbt) {
/* 60 */     super.writeToNBT(nbt);
/* 61 */     nbt.setString("username", this.player);
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound nbt) {
/* 65 */     super.readFromNBT(nbt);
/* 66 */     this.player = nbt.getString("username");
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityOnlineDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */