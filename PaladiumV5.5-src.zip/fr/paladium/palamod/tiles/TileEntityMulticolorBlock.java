/*     */ package fr.paladium.palamod.tiles;
/*     */ 
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class TileEntityMulticolorBlock
/*     */   extends TileEntity
/*     */ {
/*  14 */   private int color1 = -1;
/*  15 */   private int color2 = -1;
/*  16 */   private int color3 = -1;
/*  17 */   private int color4 = -1;
/*  18 */   private int currentColor = -1;
/*  19 */   private int index = 0;
/*     */   
/*  21 */   private boolean activate2 = true;
/*  22 */   private boolean activate3 = true;
/*  23 */   private boolean activate4 = true;
/*     */   
/*  25 */   private int time = 10;
/*  26 */   private int counter = 0;
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  31 */     super.writeToNBT(compound);
/*     */     
/*  33 */     compound.setInteger("Color1", this.color1);
/*  34 */     compound.setInteger("Color2", this.color2);
/*  35 */     compound.setInteger("Color3", this.color3);
/*  36 */     compound.setInteger("Color4", this.color4);
/*  37 */     compound.setInteger("CurrentColor", this.currentColor);
/*     */     
/*  39 */     compound.setBoolean("Activate2", this.activate2);
/*  40 */     compound.setBoolean("Activate3", this.activate3);
/*  41 */     compound.setBoolean("Activate4", this.activate4);
/*     */     
/*  43 */     compound.setInteger("Time", this.time);
/*  44 */     compound.setInteger("Counter", this.counter);
/*  45 */     compound.setInteger("Index", this.index);
/*     */   }
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  51 */     super.readFromNBT(compound);
/*     */     
/*  53 */     this.color1 = compound.getInteger("Color1");
/*  54 */     this.color2 = compound.getInteger("Color2");
/*  55 */     this.color3 = compound.getInteger("Color3");
/*  56 */     this.color4 = compound.getInteger("Color4");
/*  57 */     this.currentColor = compound.getInteger("CurrentColor");
/*     */     
/*  59 */     this.activate2 = compound.getBoolean("Activate2");
/*  60 */     this.activate3 = compound.getBoolean("Activate3");
/*  61 */     this.activate4 = compound.getBoolean("Activate4");
/*     */     
/*  63 */     this.time = compound.getInteger("Time");
/*  64 */     this.counter = compound.getInteger("Counter");
/*  65 */     this.index = compound.getInteger("Index");
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateEntity()
/*     */   {
/*  71 */     if (this.counter > 0)
/*     */     {
/*  73 */       this.counter -= 1;
/*     */     }
/*  75 */     if (this.counter == 0)
/*     */     {
/*  77 */       if (this.index == 1)
/*     */       {
/*  79 */         if (this.activate2) {
/*  80 */           this.currentColor = this.color2;
/*     */         } else {
/*  82 */           this.index += 1;
/*     */         }
/*     */       }
/*  85 */       if (this.index == 2)
/*     */       {
/*  87 */         if (this.activate3) {
/*  88 */           this.currentColor = this.color3;
/*     */         } else {
/*  90 */           this.index += 1;
/*     */         }
/*     */       }
/*  93 */       if (this.index == 3)
/*     */       {
/*  95 */         if (this.activate4) {
/*  96 */           this.currentColor = this.color4;
/*     */         } else {
/*  98 */           this.index += 1;
/*     */         }
/*     */       }
/* 101 */       if (this.index > 3) {
/* 102 */         this.index = 0;
/*     */       }
/* 104 */       if (this.index == 0) {
/* 105 */         this.currentColor = this.color1;
/*     */       }
/* 107 */       this.index += 1;
/* 108 */       this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/* 109 */       this.counter = (this.time * 20);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getTime()
/*     */   {
/* 115 */     return this.time;
/*     */   }
/*     */   
/*     */   public void setTime(int time)
/*     */   {
/* 120 */     this.time = time;
/*     */   }
/*     */   
/*     */   public int getColor1()
/*     */   {
/* 125 */     return this.color1;
/*     */   }
/*     */   
/*     */   public void setColor1(int color1)
/*     */   {
/* 130 */     this.color1 = color1;
/*     */   }
/*     */   
/*     */   public int getColor2()
/*     */   {
/* 135 */     return this.color2;
/*     */   }
/*     */   
/*     */   public void setColor2(int color2)
/*     */   {
/* 140 */     this.color2 = color2;
/*     */   }
/*     */   
/*     */   public int getColor3()
/*     */   {
/* 145 */     return this.color3;
/*     */   }
/*     */   
/*     */   public void setColor3(int color3)
/*     */   {
/* 150 */     this.color3 = color3;
/*     */   }
/*     */   
/*     */   public int getColor4()
/*     */   {
/* 155 */     return this.color4;
/*     */   }
/*     */   
/*     */   public void setColor4(int color4)
/*     */   {
/* 160 */     this.color4 = color4;
/*     */   }
/*     */   
/*     */   public boolean isActivate2()
/*     */   {
/* 165 */     return this.activate2;
/*     */   }
/*     */   
/*     */   public void setActivate2(boolean activate2)
/*     */   {
/* 170 */     this.activate2 = activate2;
/*     */   }
/*     */   
/*     */   public boolean isActivate3()
/*     */   {
/* 175 */     return this.activate3;
/*     */   }
/*     */   
/*     */   public void setActivate3(boolean activate3)
/*     */   {
/* 180 */     this.activate3 = activate3;
/*     */   }
/*     */   
/*     */   public boolean isActivate4()
/*     */   {
/* 185 */     return this.activate4;
/*     */   }
/*     */   
/*     */   public void setActivate4(boolean activate4)
/*     */   {
/* 190 */     this.activate4 = activate4;
/*     */   }
/*     */   
/*     */   public int getCurrentColor()
/*     */   {
/* 195 */     return this.currentColor;
/*     */   }
/*     */   
/*     */   public void setCurrentColor(int currentColor)
/*     */   {
/* 200 */     this.currentColor = currentColor;
/*     */   }
/*     */   
/*     */   public int getCounter()
/*     */   {
/* 205 */     return this.counter;
/*     */   }
/*     */   
/*     */   public void setCounter(int counter)
/*     */   {
/* 210 */     this.counter = counter;
/*     */   }
/*     */   
/*     */   public int getIndex()
/*     */   {
/* 215 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int index)
/*     */   {
/* 220 */     this.index = index;
/*     */   }
/*     */   
/*     */ 
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 226 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 227 */     writeToNBT(nbttagcompound);
/* 228 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, getBlockMetadata(), nbttagcompound);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/* 234 */     readFromNBT(pkt.func_148857_g());
/* 235 */     this.worldObj.markBlockRangeForRenderUpdate(this.xCoord, this.yCoord, this.zCoord, this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityMulticolorBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */