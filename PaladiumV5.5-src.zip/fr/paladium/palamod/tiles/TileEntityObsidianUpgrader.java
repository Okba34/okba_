/*     */ package fr.paladium.palamod.tiles;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.items.ItemObsidianUpgrade;
/*     */ import fr.paladium.palamod.items.ItemObsidianUpgrade.Upgrade;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.recipies.IncompatibleObsidianUpgrades;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntityFurnace;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class TileEntityObsidianUpgrader
/*     */   extends TileEntityMultiblock
/*     */   implements IInventory
/*     */ {
/*     */   public static enum Id
/*     */   {
/*  29 */     input, 
/*  30 */     output, 
/*  31 */     obsi, 
/*  32 */     fuel;
/*     */     
/*     */     private Id() {} }
/*  35 */   private ItemStack[] contents = new ItemStack[6];
/*  36 */   private int obsidian = 0;
/*  37 */   private int timeMax = 150;
/*  38 */   private int timeMaxObsi = 175;
/*  39 */   private int itemBurnTime = 0;
/*     */   
/*  41 */   private int timeInput = 0;
/*  42 */   private int timeOutput = 0;
/*  43 */   private int timeObsi = 0;
/*  44 */   private int timeFuel = 0;
/*     */   
/*  46 */   private Boolean explode = Boolean.valueOf(false);
/*  47 */   private Boolean fake = Boolean.valueOf(false);
/*  48 */   private Boolean twoLife = Boolean.valueOf(false);
/*  49 */   private Boolean camouflage = Boolean.valueOf(false);
/*  50 */   private int upgradeNumber = 0;
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  55 */     super.writeToNBT(compound);
/*     */     
/*  57 */     NBTTagList nbttaglist = new NBTTagList();
/*  58 */     for (int i = 0; i < this.contents.length; i++)
/*     */     {
/*  60 */       if (this.contents[i] != null)
/*     */       {
/*  62 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/*  63 */         nbttagcompound1.setByte("Slot", (byte)i);
/*  64 */         this.contents[i].writeToNBT(nbttagcompound1);
/*  65 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/*  68 */     compound.setTag("Items", nbttaglist);
/*     */     
/*  70 */     compound.setInteger("Obsidian", this.obsidian);
/*  71 */     compound.setInteger("TimeInput", this.timeInput);
/*  72 */     compound.setInteger("TimeOutput", this.timeOutput);
/*  73 */     compound.setInteger("TimeObsi", this.timeObsi);
/*  74 */     compound.setInteger("TimeFuel", this.timeFuel);
/*  75 */     compound.setInteger("ItemBurnTime", this.itemBurnTime);
/*     */     
/*  77 */     compound.setBoolean("Explode", this.explode.booleanValue());
/*  78 */     compound.setBoolean("Fake", this.fake.booleanValue());
/*  79 */     compound.setBoolean("TwoLife", this.twoLife.booleanValue());
/*  80 */     compound.setBoolean("Camouflage", this.camouflage.booleanValue());
/*  81 */     compound.setInteger("UpgradeNumber", this.upgradeNumber);
/*     */   }
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  87 */     super.readFromNBT(compound);
/*     */     
/*  89 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/*  90 */     this.contents = new ItemStack[getSizeInventory()];
/*  91 */     for (int i = 0; i < nbttaglist.tagCount(); i++)
/*     */     {
/*  93 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/*  94 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/*  96 */       if ((j >= 0) && (j < this.contents.length))
/*     */       {
/*  98 */         this.contents[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 102 */     this.obsidian = compound.getInteger("Obsidian");
/* 103 */     this.timeInput = compound.getInteger("TimeInput");
/* 104 */     this.timeOutput = compound.getInteger("TimeOutput");
/* 105 */     this.timeObsi = compound.getInteger("TimeObsi");
/* 106 */     this.timeFuel = compound.getInteger("TimeFuel");
/* 107 */     this.itemBurnTime = compound.getInteger("ItemBurnTime");
/*     */     
/* 109 */     this.explode = Boolean.valueOf(compound.getBoolean("Explode"));
/* 110 */     this.fake = Boolean.valueOf(compound.getBoolean("Fake"));
/* 111 */     this.twoLife = Boolean.valueOf(compound.getBoolean("TwoLife"));
/* 112 */     this.camouflage = Boolean.valueOf(compound.getBoolean("Camouflage"));
/* 113 */     this.upgradeNumber = compound.getInteger("UpgradeNumber");
/*     */   }
/*     */   
/*     */   public Boolean hasObsidian()
/*     */   {
/* 118 */     return Boolean.valueOf(this.obsidian > 0);
/*     */   }
/*     */   
/*     */   private Boolean isMaxObsidian()
/*     */   {
/* 123 */     return Boolean.valueOf(this.obsidian >= 64);
/*     */   }
/*     */   
/*     */   public Boolean isBurning(Id id)
/*     */   {
/* 128 */     if (id == Id.input)
/* 129 */       return Boolean.valueOf(this.timeInput > 0);
/* 130 */     if (id == Id.output)
/* 131 */       return Boolean.valueOf(this.timeOutput > 0);
/* 132 */     if (id == Id.obsi)
/* 133 */       return Boolean.valueOf(this.timeObsi > 0);
/* 134 */     if (id == Id.fuel)
/* 135 */       return Boolean.valueOf(this.timeFuel > 0);
/* 136 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   private Boolean canSmelt(Id id)
/*     */   {
/* 141 */     if ((id == Id.input) && (this.contents[1] != null) && (this.obsidian != 0) && (this.upgradeNumber < 3))
/*     */     {
/* 143 */       if ((this.contents[1].getItem() instanceof ItemObsidianUpgrade))
/*     */       {
/* 145 */         ItemObsidianUpgrade.Upgrade upgrade = ((ItemObsidianUpgrade)this.contents[1].getItem()).type;
/* 146 */         return Boolean.valueOf((!isUpgraded(upgrade).booleanValue()) && (isCompatible(upgrade)));
/*     */       }
/*     */     } else {
/* 149 */       if ((id == Id.output) && (!isBurning(Id.input).booleanValue()))
/*     */       {
/* 151 */         if ((hasObsidian().booleanValue()) && (this.contents[2] != null) && (this.contents[3] != null))
/*     */         {
/* 153 */           if ((this.contents[2].getItem() == ModItems.paternBlock) && (this.contents[3].getItem() == ModItems.paternSocket))
/* 154 */             return Boolean.valueOf(true);
/*     */         }
/* 156 */         return Boolean.valueOf(false);
/*     */       }
/* 158 */       if ((id == Id.obsi) && (this.contents[0] != null))
/*     */       {
/* 160 */         if (isBurning(Id.fuel).booleanValue()) {
/* 161 */           return Boolean.valueOf((canAdd(this.contents[0]).booleanValue()) && (!isMaxObsidian().booleanValue()));
/*     */         }
/* 163 */       } else if ((id == Id.fuel) && (this.contents[5] != null))
/*     */       {
/* 165 */         return Boolean.valueOf(!isBurning(Id.fuel).booleanValue()); }
/*     */     }
/* 167 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public Boolean isUpgraded(ItemObsidianUpgrade.Upgrade upgrade)
/*     */   {
/* 172 */     switch (upgrade)
/*     */     {
/*     */     case Explode: 
/* 175 */       return this.explode;
/*     */     case Fake: 
/* 177 */       return this.fake;
/*     */     case TwoLife: 
/* 179 */       return this.twoLife;
/*     */     case Camouflage: 
/* 181 */       return this.camouflage;
/*     */     }
/* 183 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isCompatible(ItemObsidianUpgrade.Upgrade upgrade)
/*     */   {
/* 189 */     if ((this.explode.booleanValue()) && 
/* 190 */       (!IncompatibleObsidianUpgrades.getManager().isCompatible(ItemObsidianUpgrade.Upgrade.Explode, upgrade).booleanValue()))
/* 191 */       return false;
/* 192 */     if ((this.fake.booleanValue()) && 
/* 193 */       (!IncompatibleObsidianUpgrades.getManager().isCompatible(ItemObsidianUpgrade.Upgrade.Fake, upgrade).booleanValue()))
/* 194 */       return false;
/* 195 */     if ((this.twoLife.booleanValue()) && 
/* 196 */       (!IncompatibleObsidianUpgrades.getManager().isCompatible(ItemObsidianUpgrade.Upgrade.TwoLife, upgrade).booleanValue()))
/* 197 */       return false;
/* 198 */     if ((this.camouflage.booleanValue()) && 
/* 199 */       (!IncompatibleObsidianUpgrades.getManager().isCompatible(ItemObsidianUpgrade.Upgrade.Camouflage, upgrade).booleanValue())) {
/* 200 */       return false;
/*     */     }
/* 202 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateEntity()
/*     */   {
/* 208 */     setStructure(2, 1, 2);
/*     */     
/* 210 */     if (this.isMaster)
/*     */     {
/* 212 */       if ((isBurning(Id.input).booleanValue()) && (canSmelt(Id.input).booleanValue()))
/* 213 */         this.timeInput += 1;
/* 214 */       if ((isBurning(Id.output).booleanValue()) && (canSmelt(Id.output).booleanValue()))
/* 215 */         this.timeOutput += 1;
/* 216 */       if ((isBurning(Id.obsi).booleanValue()) && (canSmelt(Id.obsi).booleanValue()))
/* 217 */         this.timeObsi += 1;
/* 218 */       if (isBurning(Id.fuel).booleanValue()) {
/* 219 */         this.timeFuel -= 1;
/*     */       }
/* 221 */       if ((canSmelt(Id.input).booleanValue()) && (!isBurning(Id.input).booleanValue()))
/* 222 */         this.timeInput = 1;
/* 223 */       if ((canSmelt(Id.output).booleanValue()) && (!isBurning(Id.output).booleanValue()))
/* 224 */         this.timeOutput = 1;
/* 225 */       if ((canSmelt(Id.obsi).booleanValue()) && (!isBurning(Id.obsi).booleanValue()))
/* 226 */         this.timeObsi = 1;
/* 227 */       if (canSmelt(Id.fuel).booleanValue())
/*     */       {
/* 229 */         this.itemBurnTime = (this.timeFuel = TileEntityFurnace.getItemBurnTime(this.contents[5]));
/* 230 */         if (this.timeFuel > 0)
/*     */         {
/* 232 */           this.contents[5].stackSize -= 1;
/* 233 */           if (this.contents[5].stackSize == 0) {
/* 234 */             this.contents[5] = null;
/*     */           }
/*     */         }
/*     */       }
/* 238 */       if (!canSmelt(Id.input).booleanValue())
/* 239 */         this.timeInput = 0;
/* 240 */       if (!canSmelt(Id.output).booleanValue())
/* 241 */         this.timeOutput = 0;
/* 242 */       if (!canSmelt(Id.obsi).booleanValue()) {
/* 243 */         this.timeObsi = 0;
/*     */       }
/* 245 */       if ((canSmelt(Id.input).booleanValue()) && (this.timeInput == this.timeMax))
/*     */       {
/* 247 */         upgrade();
/* 248 */         this.timeInput = 0;
/*     */       }
/* 250 */       if ((canSmelt(Id.output).booleanValue()) && (this.timeOutput == this.timeMax))
/*     */       {
/* 252 */         smelt();
/* 253 */         this.timeOutput = 0;
/*     */       }
/* 255 */       if ((canSmelt(Id.obsi).booleanValue()) && (this.timeObsi == this.timeMaxObsi))
/*     */       {
/* 257 */         addObsidian();
/* 258 */         this.timeObsi = 0;
/*     */       }
/*     */     }
/*     */     
/* 262 */     markDirty();
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset()
/*     */   {
/* 268 */     super.reset();
/* 269 */     this.contents = new ItemStack[6];
/* 270 */     this.obsidian = 0;
/*     */     
/* 272 */     this.timeMax = 150;
/* 273 */     this.timeMaxObsi = 100;
/* 274 */     this.itemBurnTime = 0;
/*     */     
/* 276 */     this.timeInput = 0;
/* 277 */     this.timeOutput = 0;
/* 278 */     this.timeObsi = 0;
/* 279 */     this.timeFuel = 0;
/*     */     
/* 281 */     this.explode = Boolean.valueOf(false);
/* 282 */     this.fake = Boolean.valueOf(false);
/* 283 */     this.twoLife = Boolean.valueOf(false);
/* 284 */     this.camouflage = Boolean.valueOf(false);
/* 285 */     this.upgradeNumber = 0;
/*     */   }
/*     */   
/*     */   public void addObsidian()
/*     */   {
/* 290 */     if (this.obsidian != 0)
/*     */     {
/* 292 */       if (canAdd(this.contents[0]).booleanValue())
/*     */       {
/* 294 */         this.contents[0].stackSize -= 1;
/* 295 */         this.obsidian += 1;
/*     */         
/* 297 */         if (this.contents[0].stackSize == 0) {
/* 298 */           this.contents[0] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 303 */       ItemStack stack = this.contents[0];
/* 304 */       if (!stack.hasTagCompound())
/*     */       {
/* 306 */         NBTTagCompound compound = new NBTTagCompound();
/* 307 */         compound.setBoolean("Explode", false);
/* 308 */         compound.setBoolean("Fake", false);
/* 309 */         compound.setBoolean("TwoLife", false);
/* 310 */         stack.setTagCompound(compound);
/*     */       }
/*     */       
/* 313 */       NBTTagCompound compound = stack.getTagCompound();
/* 314 */       this.explode = Boolean.valueOf(compound.getBoolean("Explode"));
/* 315 */       this.fake = Boolean.valueOf(compound.getBoolean("Fake"));
/* 316 */       this.twoLife = Boolean.valueOf(compound.getBoolean("TwoLife"));
/* 317 */       this.camouflage = Boolean.valueOf(compound.getBoolean("Camouflage"));
/*     */       
/* 319 */       this.contents[0].stackSize -= 1;
/* 320 */       this.obsidian += 1;
/*     */       
/* 322 */       if (this.contents[0].stackSize == 0) {
/* 323 */         this.contents[0] = null;
/*     */       }
/*     */     }
/* 326 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */   
/*     */   public Boolean canAdd(ItemStack stack)
/*     */   {
/* 331 */     if (stack != null)
/*     */     {
/* 333 */       if (!stack.hasTagCompound())
/*     */       {
/* 335 */         NBTTagCompound compound = new NBTTagCompound();
/* 336 */         compound.setBoolean("Explode", false);
/* 337 */         compound.setBoolean("Fake", false);
/* 338 */         compound.setBoolean("TwoLife", false);
/* 339 */         compound.setBoolean("Camouflage", false);
/* 340 */         stack.setTagCompound(compound);
/*     */       }
/*     */       
/* 343 */       NBTTagCompound compound = stack.getTagCompound();
/* 344 */       if ((compound.getBoolean("Explode") == this.explode.booleanValue()) && (compound.getBoolean("Fake") == this.fake.booleanValue()) && (compound.getBoolean("TwoLife") == this.twoLife.booleanValue()) && (compound.getBoolean("Camouflage") == this.camouflage.booleanValue()))
/* 345 */         return Boolean.valueOf(true);
/*     */     }
/* 347 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public void upgrade()
/*     */   {
/* 352 */     if (this.contents[1] != null)
/*     */     {
/* 354 */       if ((this.contents[1].getItem() instanceof ItemObsidianUpgrade))
/*     */       {
/* 356 */         ItemObsidianUpgrade upgrade = (ItemObsidianUpgrade)this.contents[1].getItem();
/* 357 */         if (upgrade.type == ItemObsidianUpgrade.Upgrade.Explode) {
/* 358 */           this.explode = Boolean.valueOf(true);
/* 359 */         } else if (upgrade.type == ItemObsidianUpgrade.Upgrade.Fake) {
/* 360 */           this.fake = Boolean.valueOf(true);
/* 361 */         } else if (upgrade.type == ItemObsidianUpgrade.Upgrade.TwoLife) {
/* 362 */           this.twoLife = Boolean.valueOf(true);
/* 363 */         } else if (upgrade.type == ItemObsidianUpgrade.Upgrade.Camouflage) {
/* 364 */           this.camouflage = Boolean.valueOf(true);
/*     */         }
/* 366 */         this.upgradeNumber += 1;
/*     */         
/* 368 */         this.contents[1].stackSize -= 1;
/* 369 */         if (this.contents[1].stackSize == 0) {
/* 370 */           this.contents[1] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void smelt() {
/* 377 */     ItemStack stack = getUpgradedObsidian();
/* 378 */     if (this.contents[4] == null)
/*     */     {
/* 380 */       this.contents[4] = stack.copy();
/* 381 */       obsidianDown();
/*     */     }
/* 383 */     else if (((this.contents[4].getItem() == Item.getItemFromBlock(Blocks.obsidian)) || (this.contents[4].getItem() == Item.getItemFromBlock(PaladiumRegister.UPGRADED_OBSIDIAN))) && (canAdd(this.contents[4]).booleanValue()))
/*     */     {
/* 385 */       this.contents[4].stackSize += 1;
/* 386 */       obsidianDown();
/*     */     }
/*     */     
/* 389 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */   
/*     */   public void obsidianDown()
/*     */   {
/* 394 */     this.obsidian -= 1;
/* 395 */     if (this.obsidian == 0)
/*     */     {
/* 397 */       this.explode = Boolean.valueOf(false);
/* 398 */       this.fake = Boolean.valueOf(false);
/* 399 */       this.twoLife = Boolean.valueOf(false);
/* 400 */       this.camouflage = Boolean.valueOf(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack getUpgradedObsidian()
/*     */   {
/* 406 */     if ((!this.explode.booleanValue()) && (!this.fake.booleanValue()) && (!this.twoLife.booleanValue()) && (!this.camouflage.booleanValue())) {
/* 407 */       return new ItemStack(Blocks.obsidian);
/*     */     }
/*     */     
/* 410 */     ItemStack stack = new ItemStack(PaladiumRegister.UPGRADED_OBSIDIAN);
/* 411 */     if (!stack.hasTagCompound()) {
/* 412 */       stack.setTagCompound(new NBTTagCompound());
/*     */     }
/* 414 */     NBTTagCompound compound = stack.getTagCompound();
/* 415 */     compound.setBoolean("Explode", this.explode.booleanValue());
/* 416 */     compound.setBoolean("Fake", this.fake.booleanValue());
/* 417 */     compound.setBoolean("TwoLife", this.twoLife.booleanValue());
/* 418 */     compound.setBoolean("Camouflage", this.camouflage.booleanValue());
/* 419 */     stack.setTagCompound(compound);
/* 420 */     return stack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSizeInventory()
/*     */   {
/* 427 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlot(int slotIndex)
/*     */   {
/* 433 */     return this.contents[slotIndex];
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/* 439 */     if (this.contents[slotIndex] != null)
/*     */     {
/*     */ 
/*     */ 
/* 443 */       if (this.contents[slotIndex].stackSize <= amount)
/*     */       {
/* 445 */         ItemStack itemstack = this.contents[slotIndex];
/* 446 */         this.contents[slotIndex] = null;
/* 447 */         markDirty();
/* 448 */         return itemstack;
/*     */       }
/*     */       
/*     */ 
/* 452 */       ItemStack itemstack = this.contents[slotIndex].splitStack(amount);
/*     */       
/* 454 */       if (this.contents[slotIndex].stackSize == 0)
/*     */       {
/* 456 */         this.contents[slotIndex] = null;
/*     */       }
/*     */       
/* 459 */       markDirty();
/* 460 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 465 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/* 472 */     if (this.contents[slotIndex] != null)
/*     */     {
/* 474 */       ItemStack itemstack = this.contents[slotIndex];
/* 475 */       this.contents[slotIndex] = null;
/* 476 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/* 480 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/* 487 */     this.contents[slotIndex] = stack;
/*     */     
/* 489 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit()))
/*     */     {
/* 491 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 494 */     markDirty();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getInventoryName()
/*     */   {
/* 500 */     return "gui.obsidian_upgrader";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 506 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCustomName(String customName) {}
/*     */   
/*     */ 
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 515 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 521 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 535 */     return slot != 3;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getProgress(Id id, int size)
/*     */   {
/* 541 */     if (id == Id.input)
/* 542 */       return this.timeInput * size / this.timeMax;
/* 543 */     if (id == Id.output)
/* 544 */       return this.timeOutput * size / this.timeMax;
/* 545 */     if (id == Id.obsi)
/* 546 */       return this.timeObsi * size / this.timeMaxObsi;
/* 547 */     if (id == Id.fuel)
/* 548 */       return this.timeFuel * size / this.itemBurnTime;
/* 549 */     return 0;
/*     */   }
/*     */   
/*     */   public int getObsidian()
/*     */   {
/* 554 */     return this.obsidian;
/*     */   }
/*     */   
/*     */   public List<Object> getInformations()
/*     */   {
/* 559 */     List<Object> list = new ArrayList();
/* 560 */     list.add(Integer.valueOf(this.obsidian));
/* 561 */     list.add(this.explode);
/* 562 */     list.add(this.fake);
/* 563 */     list.add(this.twoLife);
/* 564 */     list.add(this.camouflage);
/* 565 */     return list;
/*     */   }
/*     */   
/*     */   public void setInformations(List<Object> list)
/*     */   {
/* 570 */     this.obsidian = ((Integer)list.get(0)).intValue();
/* 571 */     this.explode = ((Boolean)list.get(1));
/* 572 */     this.fake = ((Boolean)list.get(2));
/* 573 */     this.twoLife = ((Boolean)list.get(3));
/* 574 */     this.camouflage = ((Boolean)list.get(4));
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityObsidianUpgrader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */