/*    */ package fr.paladium.palamod.tiles;
/*    */ 
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class TileEntityCamera
/*    */   extends TileEntity
/*    */ {
/*    */   float rotation;
/*    */   
/*    */   public TileEntityCamera() {}
/*    */   
/*    */   public TileEntityCamera(float rotation)
/*    */   {
/* 14 */     this.rotation = rotation;
/*    */   }
/*    */   
/*    */   public void setRotation(float rotation) {
/* 18 */     this.rotation = rotation;
/*    */   }
/*    */   
/*    */   public float getRotation() {
/* 22 */     return this.rotation;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */