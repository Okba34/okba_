/*     */ package fr.paladium.palamod.tiles;
/*     */ 
/*     */ import com.sun.corba.se.impl.io.TypeMismatchException;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*     */ import fr.paladium.palamod.entities.projectiles.EntityTurretBullet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.boss.EntityWither;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import org.lwjgl.util.vector.Vector3f;
/*     */ 
/*     */ public class TileEntityTurret
/*     */   extends TileEntity
/*     */ {
/*     */   static final int cooldownBase = 5;
/*     */   static final int distanceTarget = 15;
/*  31 */   int timer = 0;
/*  32 */   int cooldown = 5;
/*     */   
/*     */   public float targetOffX;
/*     */   
/*     */   public float targetOffY;
/*     */   public float targetOffZ;
/*  38 */   public boolean activate = true;
/*     */   
/*  40 */   boolean checkOtherTurret = true;
/*     */   
/*     */   public void updateEntity()
/*     */   {
/*  44 */     if ((!this.worldObj.isRemote) && (this.activate)) {
/*  45 */       this.timer += 1;
/*  46 */       if (this.timer >= this.cooldown) {
/*  47 */         this.timer = 0;
/*  48 */         EntityTurretBullet grenade = new EntityTurretBullet(this.worldObj);
/*     */         
/*  50 */         grenade.setPosition(this.xCoord + 0.5F, this.yCoord + 0.5F, this.zCoord + 0.5F);
/*     */         
/*  52 */         List<Entity> withers = new ArrayList();
/*     */         
/*  54 */         withers.addAll(this.worldObj.getEntitiesWithinAABB(EntityWither.class, 
/*  55 */           AxisAlignedBB.getBoundingBox(this.xCoord - 15, this.yCoord - 15, this.zCoord - 15, this.xCoord + 15, this.yCoord + 15, this.zCoord + 15)));
/*     */         
/*     */ 
/*  58 */         withers.addAll(this.worldObj.getEntitiesWithinAABB(EntityCustomWither.class, 
/*  59 */           AxisAlignedBB.getBoundingBox(this.xCoord - 15, this.yCoord - 15, this.zCoord - 15, this.xCoord + 15, this.yCoord + 15, this.zCoord + 15)));
/*     */         
/*     */ 
/*     */ 
/*  63 */         if (withers.isEmpty()) {
/*  64 */           this.checkOtherTurret = true;
/*  65 */           return;
/*     */         }
/*     */         
/*  68 */         Entity wither = (Entity)withers.get(new Random().nextInt(withers.size()));
/*     */         
/*  70 */         double offX = wither.posX - grenade.posX;
/*  71 */         double offY = wither.posY + wither.height / 2.0F - grenade.posY;
/*  72 */         double offZ = wither.posZ - grenade.posZ;
/*     */         
/*  74 */         Vec3 off = Vec3.createVectorHelper(offX, offY, offZ);
/*  75 */         off = off.normalize();
/*     */         
/*  77 */         grenade.setVelocity(off.xCoord, off.yCoord, off.zCoord);
/*     */         
/*  79 */         Vector3f vec = new Vector3f((float)off.xCoord, (float)off.yCoord, (float)off.zCoord);
/*  80 */         vec.normalise();
/*     */         
/*  82 */         this.targetOffX = vec.x;
/*  83 */         this.targetOffY = vec.y;
/*  84 */         this.targetOffZ = vec.z;
/*     */         
/*  86 */         this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/*     */         
/*  88 */         this.worldObj.spawnEntityInWorld(grenade);
/*     */         
/*  90 */         if (this.checkOtherTurret) {
/*  91 */           int count = countTurretInChunk();
/*  92 */           this.cooldown = (5 * count);
/*  93 */           this.checkOtherTurret = false;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*  99 */   public int countTurretInChunk() { int chunkX = this.xCoord / 16;
/* 100 */     int chunkZ = this.zCoord / 16;
/* 101 */     int count = 0;
/*     */     
/* 103 */     Map tileMap = this.worldObj.getChunkFromChunkCoords(chunkX, chunkZ).chunkTileEntityMap;
/* 104 */     Iterator entries = tileMap.entrySet().iterator();
/* 105 */     while (entries.hasNext()) {
/*     */       try {
/* 107 */         Map.Entry e = (Map.Entry)entries.next();
/* 108 */         TileEntity te = (TileEntity)e.getValue();
/* 109 */         if (te != null)
/*     */         {
/* 111 */           if ((te instanceof TileEntityTurret))
/* 112 */             count++;
/*     */         }
/*     */       } catch (TypeMismatchException e) {
/* 115 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 118 */     return count;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 123 */     super.writeToNBT(compound);
/*     */     
/* 125 */     compound.setFloat("targetOffX", this.targetOffX);
/* 126 */     compound.setFloat("targetOffY", this.targetOffY);
/* 127 */     compound.setFloat("targetOffZ", this.targetOffZ);
/* 128 */     compound.setBoolean("activate", this.activate);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 133 */     super.readFromNBT(compound);
/*     */     
/* 135 */     this.targetOffX = compound.getFloat("targetOffX");
/* 136 */     this.targetOffY = compound.getFloat("targetOffY");
/* 137 */     this.targetOffZ = compound.getFloat("targetOffZ");
/* 138 */     this.activate = compound.getBoolean("activate");
/*     */   }
/*     */   
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 143 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 144 */     writeToNBT(nbttagcompound);
/* 145 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, getBlockMetadata(), nbttagcompound);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt)
/*     */   {
/* 150 */     readFromNBT(pkt.func_148857_g());
/* 151 */     this.worldObj.markBlockRangeForRenderUpdate(this.xCoord, this.yCoord, this.zCoord, this.xCoord, this.yCoord, this.zCoord);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\tiles\TileEntityTurret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */