package fr.paladium.palamod;

public class Constants
{
  public static final String MOD_ID = "palamod";
  public static final String MOD_NAME = "PalaMod";
  public static final String MOD_VERSION = "5.5";
  public static final String MOD_DEPENDENCIES = "required-after:Forge@[10.13.4.1448,)";
  public static final String MOD_MINECRAFTVERSION = "[1.7.10]";
  public static final String MOD_CLIENTSIDE = "fr.paladium.palamod.proxy.ClientProxy";
  public static final String MOD_SERVERSIDE = "fr.paladium.palamod.proxy.CommonProxy";
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */