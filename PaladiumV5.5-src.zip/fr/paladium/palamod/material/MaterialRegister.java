/*    */ package fr.paladium.palamod.material;
/*    */ 
/*    */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*    */ import fr.paladium.palamod.library.Register;
/*    */ import fr.paladium.palamod.material.item.BaseItemMaterial;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaterialRegister
/*    */   extends Register
/*    */ {
/*    */   public static BaseItemMaterial ENDIUM_INGOT;
/*    */   public static BaseItemMaterial PALADIUM_INGOT;
/*    */   public static BaseItemMaterial PALADIUM_GREEN_INGOT;
/*    */   public static BaseItemMaterial TITANE_INGOT;
/*    */   public static BaseItemMaterial AMETHYST_INGOT;
/*    */   public static BaseItemMaterial FINDIUM;
/*    */   
/*    */   public void preInit(FMLPreInitializationEvent event)
/*    */   {
/* 24 */     register();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void init(FMLInitializationEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void postInit(FMLPostInitializationEvent event) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private void register()
/*    */   {
/* 42 */     registerItem(ENDIUM_INGOT = new BaseItemMaterial("endium_ingot"));
/* 43 */     registerItem(PALADIUM_INGOT = new BaseItemMaterial("paladium_ingot"));
/* 44 */     registerItem(PALADIUM_GREEN_INGOT = new BaseItemMaterial("paladium_green_ingot"));
/* 45 */     registerItem(TITANE_INGOT = new BaseItemMaterial("titane_ingot"));
/* 46 */     registerItem(AMETHYST_INGOT = new BaseItemMaterial("amethyst_ingot"));
/*    */     
/* 48 */     registerItem(FINDIUM = new BaseItemMaterial("findium"));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\material\MaterialRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */