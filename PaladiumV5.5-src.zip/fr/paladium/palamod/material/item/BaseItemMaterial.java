/*    */ package fr.paladium.palamod.material.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import fr.paladium.palamod.util.GuardianHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class BaseItemMaterial extends BaseItem
/*    */ {
/*    */   public BaseItemMaterial(String unlocalizedName)
/*    */   {
/* 16 */     super(unlocalizedName);
/*    */     
/* 18 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 23 */     super.addInformation(stack, player, list, b);
/* 24 */     list.add(EnumChatFormatting.GRAY + StatCollector.translateToLocal("tooltip.show"));
/*    */     
/* 26 */     if (net.minecraft.client.gui.GuiScreen.isShiftKeyDown()) {
/* 27 */       list.add(EnumChatFormatting.GREEN + StatCollector.translateToLocal("tooltip.guardianXpPrefix") + " " + GuardianHelper.getXpFromItem(this) + " xp");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\material\item\BaseItemMaterial.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */