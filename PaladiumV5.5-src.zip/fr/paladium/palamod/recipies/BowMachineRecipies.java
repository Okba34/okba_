/*    */ package fr.paladium.palamod.recipies;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ 
/*    */ public class BowMachineRecipies
/*    */ {
/*    */   public static final int RANGE = 0;
/* 11 */   public static BowMachineRecipies instance = new BowMachineRecipies();
/* 12 */   private Map<Item, Integer> modifiers = new HashMap();
/*    */   
/*    */   public void addRecipie(Item stack, int type) {
/* 15 */     this.modifiers.put(stack, Integer.valueOf(type));
/*    */   }
/*    */   
/*    */   public boolean hasRecipie(Item stack) {
/* 19 */     if (this.modifiers.containsKey(stack)) {
/* 20 */       return true;
/*    */     }
/* 22 */     return false;
/*    */   }
/*    */   
/*    */   public int getModifier(Item stack) {
/* 26 */     if (this.modifiers.containsKey(stack)) {
/* 27 */       return ((Integer)this.modifiers.get(stack)).intValue();
/*    */     }
/* 29 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\BowMachineRecipies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */