/*    */ package fr.paladium.palamod.recipies;
/*    */ 
/*    */ import fr.paladium.palamod.items.ItemObsidianUpgrade.Upgrade;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncompatibleObsidianUpgrades
/*    */ {
/* 15 */   private static final IncompatibleObsidianUpgrades instance = new IncompatibleObsidianUpgrades();
/* 16 */   private Map smeltingList = new HashMap();
/*    */   
/*    */   public void add(ItemObsidianUpgrade.Upgrade upgrade1, ItemObsidianUpgrade.Upgrade upgrade2)
/*    */   {
/* 20 */     this.smeltingList.put(upgrade1, upgrade2);
/*    */   }
/*    */   
/*    */   public Boolean isCompatible(ItemObsidianUpgrade.Upgrade upgrade1, ItemObsidianUpgrade.Upgrade upgrade2)
/*    */   {
/* 25 */     Iterator iterator = this.smeltingList.entrySet().iterator();
/*    */     
/*    */ 
/* 28 */     while (iterator.hasNext())
/*    */     {
/* 30 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 31 */       if ((ItemObsidianUpgrade.Upgrade)entry.getKey() == upgrade1)
/*    */       {
/* 33 */         int value = ((ItemObsidianUpgrade.Upgrade)entry.getValue()).ordinal();
/* 34 */         int value2 = upgrade2.ordinal();
/* 35 */         if (value == value2)
/* 36 */           return Boolean.valueOf(false);
/*    */       }
/*    */     }
/* 39 */     return Boolean.valueOf(true);
/*    */   }
/*    */   
/*    */   public static IncompatibleObsidianUpgrades getManager()
/*    */   {
/* 44 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\IncompatibleObsidianUpgrades.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */