/*    */ package fr.paladium.palamod.recipies;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class PaladiumMachineRecipies
/*    */ {
/* 14 */   private static final PaladiumMachineRecipies instance = new PaladiumMachineRecipies();
/* 15 */   private Map<ItemStack[], ItemStack> smeltingList = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void add(ItemStack stack1, ItemStack stack2, ItemStack stack3, ItemStack stack4, ItemStack stack5, ItemStack stack)
/*    */   {
/* 23 */     ItemStack[] stackList = { stack1, stack2, stack3, stack4, stack5 };
/* 24 */     this.smeltingList.put(stackList, stack);
/*    */   }
/*    */   
/*    */   public void add(Item item1, Block item2, Item item3, Block item4, Item item5, ItemStack stack) {
/* 28 */     add(new ItemStack(item1), new ItemStack(item2), new ItemStack(item3), new ItemStack(item4), new ItemStack(item5), stack);
/*    */   }
/*    */   
/*    */   public void add(Item item1, Item item2, Item item3, Item item4, Item item5, ItemStack stack)
/*    */   {
/* 33 */     add(new ItemStack(item1), new ItemStack(item2), new ItemStack(item3), new ItemStack(item4), new ItemStack(item5), stack);
/*    */   }
/*    */   
/*    */   public void add(Block item1, Block item2, Item item3, Block item4, Block item5, ItemStack stack)
/*    */   {
/* 38 */     add(new ItemStack(item1), new ItemStack(item2), new ItemStack(item3), new ItemStack(item4), new ItemStack(item5), stack);
/*    */   }
/*    */   
/*    */   public void add(Item item1, Block item2, Block item3, Block item4, Block item5, ItemStack stack)
/*    */   {
/* 43 */     add(new ItemStack(item1), new ItemStack(item2), new ItemStack(item3), new ItemStack(item4), new ItemStack(item5), stack);
/*    */   }
/*    */   
/*    */   public ItemStack getSmeltingResult(ItemStack[] stack)
/*    */   {
/* 48 */     Iterator iterator = this.smeltingList.entrySet().iterator();
/*    */     Map.Entry entry;
/*    */     do
/*    */     {
/* 52 */       if (!iterator.hasNext()) {
/* 53 */         return null;
/*    */       }
/* 55 */       entry = (Map.Entry)iterator.next();
/* 56 */     } while (!isSameKey(stack, (ItemStack[])entry.getKey()));
/*    */     
/* 58 */     return (ItemStack)entry.getValue();
/*    */   }
/*    */   
/*    */   private boolean isSameKey(ItemStack[] stackList, ItemStack[] stackList2) {
/* 62 */     boolean isSame = false;
/* 63 */     for (int i = 0; i <= 4; i++) {
/* 64 */       if ((stackList[i].getItem() == stackList2[i].getItem()) && (
/* 65 */         (stackList[i].getItemDamage() == stackList2[i].getItemDamage()) || 
/* 66 */         ((stackList[0].getItem() instanceof fr.paladium.palamod.items.ItemRingBase)))) {
/* 67 */         isSame = true;
/*    */       } else {
/* 69 */         return false;
/*    */       }
/*    */     }
/* 72 */     return isSame;
/*    */   }
/*    */   
/*    */   public Map<ItemStack[], ItemStack> getSmeltingList() {
/* 76 */     return this.smeltingList;
/*    */   }
/*    */   
/*    */   public static PaladiumMachineRecipies getManager() {
/* 80 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\PaladiumMachineRecipies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */