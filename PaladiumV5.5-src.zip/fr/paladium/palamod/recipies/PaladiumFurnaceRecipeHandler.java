/*     */ package fr.paladium.palamod.recipies;
/*     */ 
/*     */ import codechicken.nei.NEIClientUtils;
/*     */ import codechicken.nei.NEIServerUtils;
/*     */ import codechicken.nei.PositionedStack;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.CachedRecipe;
/*     */ import codechicken.nei.recipe.TemplateRecipeHandler.RecipeTransferRect;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class PaladiumFurnaceRecipeHandler extends TemplateRecipeHandler
/*     */ {
/*     */   public static final String IDENTIFIER = "palamod.paladiumFurnace";
/*  27 */   private static final String BACKGROUND_TEXTURE = new ResourceLocation("palamod:textures/gui/paladium_furnace.png").toString();
/*     */   public static ArrayList<FuelPair> afuels;
/*     */   
/*  30 */   public class SmeltingPair extends TemplateRecipeHandler.CachedRecipe { public SmeltingPair(ItemStack ingred, ItemStack result) { super();
/*  31 */       ingred.stackSize = 1;
/*  32 */       this.ingred = new PositionedStack(ingred, 51, 6);
/*  33 */       this.result = new PositionedStack(result, 111, 24); }
/*     */     
/*     */     PositionedStack ingred;
/*     */     PositionedStack result;
/*  37 */     public java.util.List<PositionedStack> getIngredients() { return getCycledIngredients(PaladiumFurnaceRecipeHandler.this.cycleticks / 48, Arrays.asList(new PositionedStack[] { this.ingred })); }
/*     */     
/*     */     public PositionedStack getResult()
/*     */     {
/*  41 */       return this.result;
/*     */     }
/*     */     
/*     */     public PositionedStack getOtherStack() {
/*  45 */       return ((PaladiumFurnaceRecipeHandler.FuelPair)PaladiumFurnaceRecipeHandler.afuels.get(PaladiumFurnaceRecipeHandler.this.cycleticks / 48 % PaladiumFurnaceRecipeHandler.afuels.size())).stack;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FuelPair {
/*     */     public PositionedStack stack;
/*     */     public int burnTime;
/*     */     
/*     */     public FuelPair(ItemStack ingred, int burnTime) {
/*  54 */       this.stack = new PositionedStack(ingred, 51, 42, false);
/*  55 */       this.burnTime = burnTime;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HashSet<Block> efuels;
/*     */   
/*     */ 
/*     */   public void loadTransferRects()
/*     */   {
/*  67 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(50, 23, 18, 18), "fuel", new Object[0]));
/*  68 */     this.transferRects.add(new TemplateRecipeHandler.RecipeTransferRect(new Rectangle(74, 23, 24, 18), "smelting", new Object[0]));
/*     */   }
/*     */   
/*     */   public Class<? extends net.minecraft.client.gui.inventory.GuiContainer> getGuiClass()
/*     */   {
/*  73 */     return fr.paladium.palamod.paladium.gui.PaladiumFurnaceGui.class;
/*     */   }
/*     */   
/*     */   public String getRecipeName()
/*     */   {
/*  78 */     return NEIClientUtils.translate("recipe.furnace", new Object[0]);
/*     */   }
/*     */   
/*     */   public TemplateRecipeHandler newInstance()
/*     */   {
/*  83 */     if ((afuels == null) || (afuels.isEmpty())) {
/*  84 */       findFuels();
/*     */     }
/*  86 */     return super.newInstance();
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(String outputId, Object... results)
/*     */   {
/*  91 */     if ((outputId.equals("smelting")) && (getClass() == PaladiumFurnaceRecipeHandler.class)) {
/*  92 */       Map<ItemStack, ItemStack> recipes = FurnaceRecipes.smelting().getSmeltingList();
/*  93 */       for (Map.Entry<ItemStack, ItemStack> recipe : recipes.entrySet()) {
/*  94 */         this.arecipes.add(new SmeltingPair((ItemStack)recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */     else {
/*  98 */       super.loadCraftingRecipes(outputId, results);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadCraftingRecipes(ItemStack result)
/*     */   {
/* 104 */     Map<ItemStack, ItemStack> recipes = FurnaceRecipes.smelting().getSmeltingList();
/* 105 */     for (Map.Entry<ItemStack, ItemStack> recipe : recipes.entrySet()) {
/* 106 */       if (NEIServerUtils.areStacksSameType((ItemStack)recipe.getValue(), result)) {
/* 107 */         this.arecipes.add(new SmeltingPair((ItemStack)recipe.getKey(), (ItemStack)recipe.getValue()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(String inputId, Object... ingredients)
/*     */   {
/* 114 */     if ((inputId.equals("fuel")) && (getClass() == PaladiumFurnaceRecipeHandler.class)) {
/* 115 */       loadCraftingRecipes("smelting", new Object[0]);
/*     */     }
/*     */     else {
/* 118 */       super.loadUsageRecipes(inputId, ingredients);
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadUsageRecipes(ItemStack ingredient)
/*     */   {
/* 124 */     Map<ItemStack, ItemStack> recipes = FurnaceRecipes.smelting().getSmeltingList();
/* 125 */     for (Map.Entry<ItemStack, ItemStack> recipe : recipes.entrySet()) {
/* 126 */       if (NEIServerUtils.areStacksSameTypeCrafting((ItemStack)recipe.getKey(), ingredient)) {
/* 127 */         SmeltingPair arecipe = new SmeltingPair((ItemStack)recipe.getKey(), (ItemStack)recipe.getValue());
/* 128 */         arecipe.setIngredientPermutation(Arrays.asList(new PositionedStack[] { arecipe.ingred }), ingredient);
/* 129 */         this.arecipes.add(arecipe);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getGuiTexture() {
/* 135 */     return BACKGROUND_TEXTURE;
/*     */   }
/*     */   
/*     */   public void drawExtras(int recipe)
/*     */   {
/* 140 */     drawProgressBar(51, 25, 176, 0, 14, 14, 48, 7);
/* 141 */     drawProgressBar(74, 23, 176, 14, 24, 16, 48, 0);
/*     */   }
/*     */   
/*     */   private static Set<Item> excludedFuels() {
/* 145 */     Set<Item> efuels = new HashSet();
/* 146 */     efuels.add(Item.getItemFromBlock(Blocks.brown_mushroom));
/* 147 */     efuels.add(Item.getItemFromBlock(Blocks.red_mushroom));
/* 148 */     efuels.add(Item.getItemFromBlock(Blocks.standing_sign));
/* 149 */     efuels.add(Item.getItemFromBlock(Blocks.wall_sign));
/* 150 */     efuels.add(Item.getItemFromBlock(Blocks.trapped_chest));
/*     */     
/* 152 */     return efuels;
/*     */   }
/*     */   
/*     */   private static void findFuels() {
/* 156 */     afuels = new ArrayList();
/* 157 */     Set<Item> efuels = excludedFuels();
/* 158 */     for (ItemStack item : codechicken.nei.ItemList.items) {
/* 159 */       Block block = Block.getBlockFromItem(item.getItem());
/* 160 */       if ((!(block instanceof net.minecraft.block.BlockDoor)) && 
/*     */       
/*     */ 
/* 163 */         (!efuels.contains(item.getItem())))
/*     */       {
/*     */ 
/*     */ 
/* 167 */         int burnTime = fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic.getItemBurnTime(item);
/* 168 */         if (burnTime > 0) {
/* 169 */           afuels.add(new FuelPair(item.copy(), burnTime));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getOverlayIdentifier() {
/* 176 */     return "palamod.paladiumFurnace";
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\PaladiumFurnaceRecipeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */