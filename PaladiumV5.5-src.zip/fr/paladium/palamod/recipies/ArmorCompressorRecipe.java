/*    */ package fr.paladium.palamod.recipies;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ArmorCompressorRecipe
/*    */ {
/* 12 */   private static final ArmorCompressorRecipe instance = new ArmorCompressorRecipe();
/* 13 */   private Map smeltingList = new HashMap();
/*    */   
/*    */   public void add(ItemStack stack1, ItemStack stack)
/*    */   {
/* 17 */     ItemStack stackList = stack1;
/* 18 */     this.smeltingList.put(stackList, stack);
/*    */   }
/*    */   
/*    */   public ItemStack getSmeltingResult(ItemStack stack)
/*    */   {
/* 23 */     Iterator iterator = this.smeltingList.entrySet().iterator();
/*    */     
/*    */     Map.Entry entry;
/*    */     do
/*    */     {
/* 28 */       if (!iterator.hasNext())
/*    */       {
/* 30 */         return null;
/*    */       }
/* 32 */       entry = (Map.Entry)iterator.next();
/*    */     }
/* 34 */     while (!isSameKey(stack, (ItemStack)entry.getKey()));
/*    */     
/* 36 */     return (ItemStack)entry.getValue();
/*    */   }
/*    */   
/*    */   private boolean isSameKey(ItemStack stackList, ItemStack stackList2)
/*    */   {
/* 41 */     boolean isSame = false;
/*    */     
/* 43 */     if (stackList.getItem() == stackList2.getItem())
/*    */     {
/* 45 */       isSame = true;
/*    */     }
/*    */     else
/*    */     {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     return isSame;
/*    */   }
/*    */   
/*    */   public Map<ItemStack, ItemStack> getSmeltingList()
/*    */   {
/* 57 */     return this.smeltingList;
/*    */   }
/*    */   
/*    */   public static ArmorCompressorRecipe getManager()
/*    */   {
/* 62 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\ArmorCompressorRecipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */