/*    */ package fr.paladium.palamod.recipies;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class AlchemyCreatorPotionRecipies
/*    */ {
/* 12 */   private static final AlchemyCreatorPotionRecipies instance = new AlchemyCreatorPotionRecipies();
/* 13 */   private Map smeltingList = new HashMap();
/*    */   
/*    */   public void add(ItemStack stack1, ItemStack stack2, ItemStack stack3, ItemStack stack4, ItemStack stack)
/*    */   {
/* 17 */     ItemStack[] stackList = { stack1, stack2, stack3, stack4 };
/* 18 */     this.smeltingList.put(stackList, stack);
/*    */   }
/*    */   
/*    */   public ItemStack getSmeltingResult(ItemStack[] stack) {
/* 22 */     Iterator iterator = this.smeltingList.entrySet().iterator();
/*    */     Map.Entry entry;
/*    */     do
/*    */     {
/* 26 */       if (!iterator.hasNext()) {
/* 27 */         return null;
/*    */       }
/* 29 */       entry = (Map.Entry)iterator.next();
/* 30 */     } while (!isSameKey(stack, (ItemStack[])entry.getKey()));
/*    */     
/* 32 */     return (ItemStack)entry.getValue();
/*    */   }
/*    */   
/*    */   private boolean isSameKey(ItemStack[] stackList, ItemStack[] stackList2) {
/* 36 */     boolean isSame = false;
/* 37 */     for (int i = 0; i <= 3; i++) {
/* 38 */       if (stackList[i].getItem() == stackList2[i].getItem()) {
/* 39 */         isSame = true;
/*    */       } else {
/* 41 */         return false;
/*    */       }
/*    */     }
/* 44 */     return isSame;
/*    */   }
/*    */   
/*    */   public static AlchemyCreatorPotionRecipies getManager() {
/* 48 */     return instance;
/*    */   }
/*    */   
/*    */   public Map<ItemStack[], ItemStack> getSmeltingList()
/*    */   {
/* 53 */     return this.smeltingList;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\AlchemyCreatorPotionRecipies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */