/*     */ package fr.paladium.palamod.recipies;
/*     */ 
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.smeltery.SmelteryRegister;
/*     */ import fr.paladium.palamod.smeltery.crafting.GrinderRecipe;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ public class ModRecipies
/*     */ {
/*     */   public static void init()
/*     */   {
/*  20 */     craftingRecipies();
/*  21 */     AlchemyCreatorRecipies();
/*  22 */     BowRecipies();
/*  23 */     paladiumGrinderRecipies();
/*  24 */     ArmorCompressorRecipies();
/*     */   }
/*     */   
/*     */   private static void ArmorCompressorRecipies() {
/*  28 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.amethystBoots, 1), new ItemStack(ModItems.itemrune, 1));
/*     */     
/*  30 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.amethystChestplate, 1), new ItemStack(ModItems.itemrune, 1));
/*     */     
/*  32 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.amethystHelmet, 1), new ItemStack(ModItems.itemrune, 1));
/*     */     
/*  34 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.amethystLeggings, 1), new ItemStack(ModItems.itemrune, 1));
/*     */     
/*  36 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.itemshardrune, 4), new ItemStack(ModItems.itemrune, 1));
/*     */     
/*     */ 
/*  39 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.titaneBoots, 1), new ItemStack(ModItems.itemrune2, 1));
/*     */     
/*  41 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.titaneChestplate, 1), new ItemStack(ModItems.itemrune2, 1));
/*     */     
/*  43 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.titaneHelmet, 1), new ItemStack(ModItems.itemrune2, 1));
/*     */     
/*  45 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.titaneLeggings, 1), new ItemStack(ModItems.itemrune2, 1));
/*     */     
/*  47 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.itemshardrune2, 4), new ItemStack(ModItems.itemrune2, 1));
/*     */     
/*     */ 
/*  50 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.paladiumBoots, 1), new ItemStack(ModItems.itemrune3, 1));
/*     */     
/*  52 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.paladiumChestplate, 1), new ItemStack(ModItems.itemrune3, 1));
/*     */     
/*  54 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.paladiumHelmet, 1), new ItemStack(ModItems.itemrune3, 1));
/*     */     
/*  56 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.paladiumLeggings, 1), new ItemStack(ModItems.itemrune3, 1));
/*     */     
/*  58 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.itemshardrune3, 4), new ItemStack(ModItems.itemrune3, 1));
/*     */     
/*     */ 
/*  61 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.endiumBoots, 1), new ItemStack(ModItems.itemrune4, 1));
/*     */     
/*  63 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.endiumChestplate, 1), new ItemStack(ModItems.itemrune4, 1));
/*     */     
/*  65 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.endiumHelmet, 1), new ItemStack(ModItems.itemrune4, 1));
/*     */     
/*  67 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.endiumLeggings, 1), new ItemStack(ModItems.itemrune4, 1));
/*     */     
/*  69 */     ArmorCompressorRecipe.getManager().add(new ItemStack(ModItems.itemshardrune4, 4), new ItemStack(ModItems.itemrune4, 1));
/*     */   }
/*     */   
/*     */ 
/*     */   private static void paladiumGrinderRecipies()
/*     */   {
/*  75 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternBroadsword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.broadSwordHead), 4);
/*     */     
/*  77 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternPickaxe), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.pickaxeHead), 3);
/*     */     
/*  79 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternFastSword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.fastSwordHead), 1);
/*     */     
/*  81 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternSword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.swordHead), 2);
/*     */     
/*  83 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternHammer), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.hammerHead), 6);
/*     */     
/*  85 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternShovel), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.shovelHead), 1);
/*     */     
/*  87 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternAxe), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.axeHead), 3);
/*     */     
/*  89 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternIngot), new ItemStack(ModItems.paternSocket), new ItemStack(MaterialRegister.PALADIUM_INGOT), 1);
/*     */     
/*     */ 
/*  92 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.broadSwordHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumBroadsword), 0);
/*     */     
/*  94 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.broadSwordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumBroadsword), 1);
/*     */     
/*  96 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.pickaxeHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumPickaxe), 0);
/*     */     
/*  98 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.swordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumSword), 0);
/*     */     
/* 100 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.fastSwordHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumFastSword), 0);
/*     */     
/* 102 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.fastSwordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumFastSword), 1);
/*     */     
/* 104 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.hammerHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumHammer), 1);
/*     */     
/* 106 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.hammerHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumHammer), 0);
/*     */     
/* 108 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.axeHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumAxe), 0);
/*     */     
/* 110 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.shovelHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumShovel), 0);
/*     */     
/*     */ 
/* 113 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.smeltModifier, 0);
/*     */     
/* 115 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.speedModifier, 2);
/*     */     
/* 117 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.fortuneModifier, 1);
/*     */     
/* 119 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.obsidianUpgrade, 6);
/*     */     
/* 121 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.moreUpgrade, 7);
/*     */     
/*     */ 
/* 124 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.damageModifier, 3);
/*     */     
/* 126 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.flameModifier, 4);
/*     */     
/* 128 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.knockbackModifier, 5);
/*     */     
/* 130 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.moreUpgrade, 7);
/*     */   }
/*     */   
/*     */   private static void BowRecipies()
/*     */   {
/* 135 */     BowMachineRecipies.instance.addRecipie(ModItems.bowRangeModifier, 0);
/* 136 */     BowMachineRecipies.instance.addRecipie(ModItems.bowSpeedModifier, 1);
/*     */   }
/*     */   
/*     */   private static void AlchemyCreatorRecipies() {
/* 140 */     AlchemyCreatorPotionRecipies.getManager().add(new ItemStack(Items.fermented_spider_eye), new ItemStack(Items.nether_wart), new ItemStack(Items.poisonous_potato), new ItemStack(Items.glass_bottle, 1, 0), new ItemStack(ModItems.potionPoison));
/*     */     
/*     */ 
/*     */ 
/* 144 */     AlchemyCreatorPotionRecipies.getManager().add(new ItemStack(Items.blaze_powder), new ItemStack(Items.nether_wart), new ItemStack(Items.fire_charge), new ItemStack(Items.glass_bottle, 1, 0), new ItemStack(ModItems.potionFire));
/*     */     
/*     */ 
/*     */ 
/* 148 */     AlchemyCreatorPotionRecipies.getManager().add(new ItemStack(ModItems.witherSkullFragment), new ItemStack(Items.nether_wart), new ItemStack(Items.bone), new ItemStack(Items.glass_bottle, 1, 0), new ItemStack(ModItems.potionWither));
/*     */     
/*     */ 
/*     */ 
/* 152 */     AlchemyCreatorPotionRecipies.getManager().add(new ItemStack(Items.blaze_powder, 1, 0), new ItemStack(Items.nether_wart), new ItemStack(Items.fermented_spider_eye), new ItemStack(Items.glass_bottle, 1, 0), new ItemStack(ModItems.sicknessPotion, 1, 0));
/*     */     
/*     */ 
/*     */ 
/* 156 */     AlchemyCreatorPotionRecipies.getManager().add(new ItemStack(Items.blaze_powder), new ItemStack(Items.nether_wart), new ItemStack(Items.fermented_spider_eye), new ItemStack(Items.glass_bottle, 1, 0), new ItemStack(ModItems.sicknessPotion, 1, 1));
/*     */     
/*     */ 
/*     */ 
/* 160 */     AlchemyCreatorArrowRecipies.getManager().add(new ItemStack(Items.fermented_spider_eye), new ItemStack(Items.nether_wart), new ItemStack(Items.poisonous_potato), new ItemStack(Items.arrow, 16), new ItemStack(ModItems.arrowPoison, 16));
/*     */     
/*     */ 
/*     */ 
/* 164 */     AlchemyCreatorArrowRecipies.getManager().add(new ItemStack(ModItems.witherSkullFragment), new ItemStack(Items.nether_wart), new ItemStack(Items.bone), new ItemStack(Items.arrow, 16), new ItemStack(ModItems.arrowWither, 16));
/*     */     
/*     */ 
/*     */ 
/* 168 */     AlchemyCreatorArrowRecipies.getManager().add(new ItemStack(Items.spider_eye), new ItemStack(Items.nether_wart), new ItemStack(Items.carrot), new ItemStack(Items.arrow, 16), new ItemStack(ModItems.arrowSlowness, 16));
/*     */     
/*     */ 
/* 171 */     AlchemyCreatorArrowRecipies.getManager().add(new ItemStack(Items.ender_pearl), new ItemStack(Items.nether_wart), new ItemStack(Items.ender_pearl), new ItemStack(Items.arrow, 16), new ItemStack(ModItems.arrowSwitch, 16));
/*     */   }
/*     */   
/*     */ 
/*     */   private static void craftingRecipies()
/*     */   {
/* 177 */     GameRegistry.addRecipe(new ItemStack(ModItems.itemshardrune, 1), new Object[] { "Y", 
/* 178 */       Character.valueOf('Y'), new ItemStack(ModItems.itemrune) });
/* 179 */     GameRegistry.addRecipe(new ItemStack(ModItems.itemshardrune2, 1), new Object[] { "Y", 
/* 180 */       Character.valueOf('Y'), new ItemStack(ModItems.itemrune2) });
/* 181 */     GameRegistry.addRecipe(new ItemStack(ModItems.itemshardrune3, 1), new Object[] { "Y", 
/* 182 */       Character.valueOf('Y'), new ItemStack(ModItems.itemrune3) });
/* 183 */     GameRegistry.addRecipe(new ItemStack(ModItems.itemshardrune4, 1), new Object[] { "Y", 
/* 184 */       Character.valueOf('Y'), new ItemStack(ModItems.itemrune4) });
/* 185 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternPickaxe, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 186 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titanePickaxe), 
/* 187 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 189 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternSword, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 190 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneSword), 
/* 191 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 193 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternFastSword, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 194 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneFastSword), 
/* 195 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 197 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternBroadsword, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 198 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneBroadsword), 
/* 199 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 201 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternHammer, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 202 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneHammer), 
/* 203 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 205 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternIngot, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 206 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 207 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 209 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternShovel, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 210 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneShovel), 
/* 211 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 213 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternAxe, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 214 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.titaneAxe), 
/* 215 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 217 */     GameRegistry.addRecipe(new ItemStack(ModItems.paternSocket, 1), new Object[] { "YXY", "X X", "YXY", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 218 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/*     */ 
/*     */ 
/* 222 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumHelmet), new Object[] { "XXX", "X X", 
/* 223 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 225 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumChestplate), new Object[] { "X X", "XXX", "XXX", 
/* 226 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 228 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumLeggings), new Object[] { "XXX", "X X", "X X", 
/* 229 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 231 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumBoots), new Object[] { "X X", "X X", 
/* 232 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 234 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumHelmet), new Object[] { "XXX", "X X", 
/* 235 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT) });
/*     */     
/* 237 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumChestplate), new Object[] { "X X", "XXX", "XXX", 
/* 238 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT) });
/*     */     
/* 240 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumLeggings), new Object[] { "XXX", "X X", "X X", 
/* 241 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT) });
/*     */     
/* 243 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumBoots), new Object[] { "X X", "X X", 
/* 244 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT) });
/*     */     
/* 246 */     GameRegistry.addRecipe(new ItemStack(ModItems.compressedPaladium), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, 
/* 247 */       Character.valueOf('X'), new ItemStack(DecorativeRegister.PALADIUM_BLOCK) });
/*     */     
/* 249 */     GameRegistry.addRecipe(new ItemStack(ModItems.compressedTitane), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('Y'), MaterialRegister.TITANE_INGOT, 
/* 250 */       Character.valueOf('X'), new ItemStack(DecorativeRegister.TITANE_BLOCK) });
/*     */     
/* 252 */     GameRegistry.addRecipe(new ItemStack(ModItems.compressedAmethyst), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('Y'), MaterialRegister.AMETHYST_INGOT, 
/* 253 */       Character.valueOf('X'), new ItemStack(DecorativeRegister.AMETHYST_BLOCK) });
/*     */     
/* 255 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumStick, 4), new Object[] { "X", "X", 
/* 256 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 258 */     GameRegistry.addRecipe(new ItemStack(ModItems.travelLeggings, 1), new Object[] { "XXX", "Y Y", "Z Z", Character.valueOf('X'), new ItemStack(Items.leather), 
/* 259 */       Character.valueOf('Y'), new ItemStack(Items.feather), Character.valueOf('Z'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 261 */     GameRegistry.addRecipe(new ItemStack(ModItems.travelBoots, 1), new Object[] { "X X", "Y Y", 
/* 262 */       Character.valueOf('X'), new ItemStack(Items.feather), Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 264 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumApple, 1), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 265 */       Character.valueOf('Y'), new ItemStack(Items.apple) });
/*     */     
/* 267 */     GameRegistry.addRecipe(new ItemStack(ModItems.infernalKnocker, 1), new Object[] { "X", "Z", "Y", 
/* 268 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.knockbackOrb), 
/* 269 */       Character.valueOf('Y'), new ItemStack(ModItems.paladiumStick) });
/*     */     
/* 271 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystPickaxe, 1), new Object[] { "XXX", " Z ", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 272 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 274 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumPickaxe, 1), new Object[] { "XXX", " Z ", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT), 
/* 275 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 277 */     GameRegistry.addRecipe(new ItemStack(ModItems.titanePickaxe, 1), new Object[] { "XXX", " Y ", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 278 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 280 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneAxe, 1), new Object[] { " XX", " ZX", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 281 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 283 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneAxe, 1), new Object[] { "XX ", "XZ ", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 284 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 286 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystAxe, 1), new Object[] { " XX", " ZX", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 287 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 289 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystAxe, 1), new Object[] { "XX ", "XZ ", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 290 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 292 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumAxe, 1), new Object[] { "XX ", "XZ ", " Z ", Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT), 
/* 293 */       Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 295 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystSword, 1), new Object[] { "X", "X", "Y", 
/* 296 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 298 */     GameRegistry.addRecipe(new ItemStack(ModItems.endiumSword, 1), new Object[] { "X", "X", "Y", 
/* 299 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT), Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 301 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneSword, 1), new Object[] { "X", "X", "Y", 
/* 302 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 304 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneShovel, 1), new Object[] { "X", "Z", "Z", 
/* 305 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 307 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystShovel, 1), new Object[] { "X", "Z", "Z", 
/* 308 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), Character.valueOf('Z'), new ItemStack(Items.stick) });
/*     */     
/* 310 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneBroadsword, 1), new Object[] { "XX", "XX", "Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 311 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 313 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneStick, 1), new Object[] { "X", "X", 
/* 314 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 316 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystStick, 1), new Object[] { "X", "X", 
/* 317 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*     */     
/* 319 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystBroadsword, 1), new Object[] { "XX", "XX", "Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 320 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 322 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystFastSword, 1), new Object[] { "X", "X", "Y", Character.valueOf('X'), new ItemStack(ModItems.amethystStick), 
/* 323 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 325 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneFastSword, 1), new Object[] { "X", "X", "Y", Character.valueOf('X'), new ItemStack(ModItems.titaneStick), 
/* 326 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 328 */     GameRegistry.addRecipe(new ItemStack(ModItems.diamondString, 9), new Object[] { "XYX", "XYX", "XYX", Character.valueOf('X'), new ItemStack(Items.string), 
/* 329 */       Character.valueOf('Y'), new ItemStack(Items.diamond) });
/*     */     
/* 331 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumBow, 1), new Object[] { " XY", "X Y", " XY", Character.valueOf('X'), new ItemStack(ModItems.paladiumStick), 
/* 332 */       Character.valueOf('Y'), new ItemStack(ModItems.diamondString) });
/*     */     
/* 334 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneHelmet), new Object[] { "XXX", "X X", 
/* 335 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 337 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneChestplate), new Object[] { "X X", "XXX", "XXX", 
/* 338 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 340 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneLeggings), new Object[] { "XXX", "X X", "X X", 
/* 341 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 343 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneBoots), new Object[] { "X X", "X X", 
/* 344 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/* 346 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystHelmet), new Object[] { "XXX", "X X", 
/* 347 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*     */     
/* 349 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystChestplate), new Object[] { "X X", "XXX", "XXX", 
/* 350 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*     */     
/* 352 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystLeggings), new Object[] { "XXX", "X X", "X X", 
/* 353 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*     */     
/* 355 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystBoots), new Object[] { "X X", "X X", 
/* 356 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT) });
/*     */     
/* 358 */     GameRegistry.addRecipe(new ItemStack(ModItems.jumpChest, 1), new Object[] { "X X", "YZY", "YZY", 
/* 359 */       Character.valueOf('X'), new ItemStack(Items.feather), Character.valueOf('Z'), new ItemStack(Items.iron_ingot), 
/* 360 */       Character.valueOf('Y'), new ItemStack(Items.leather) });
/*     */     
/* 362 */     GameRegistry.addRecipe(new ItemStack(ModItems.amethystHammer, 1), new Object[] { "XXX", "XXX", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 363 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 365 */     GameRegistry.addRecipe(new ItemStack(ModItems.titaneHammer, 1), new Object[] { "XXX", "XXX", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 366 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 368 */     GameRegistry.addRecipe(new ItemStack(ModItems.slimyHelmet, 1), new Object[] { "XXX", "Y Y", 
/* 369 */       Character.valueOf('X'), new ItemStack(Items.slime_ball), Character.valueOf('Y'), new ItemStack(Items.diamond) });
/*     */     
/* 371 */     GameRegistry.addRecipe(new ItemStack(ModItems.scubaHelmet, 1), new Object[] { "XXX", "XZX", "XXX", Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 372 */       Character.valueOf('Z'), new ItemStack(Blocks.glass_pane) });
/*     */     
/* 374 */     GameRegistry.addRecipe(new ItemStack(ModItems.hoodHelmet, 1), new Object[] { "XXX", "XZX", "XXX", Character.valueOf('X'), new ItemStack(Blocks.wool), 
/* 375 */       Character.valueOf('Z'), new ItemStack(ModItems.paladiumCore) });
/*     */     
/* 377 */     GameRegistry.addRecipe(new ItemStack(ModItems.wing, 2), new Object[] { "  X", " XZ", "XZZ", Character.valueOf('X'), new ItemStack(ModItems.paladiumStick), 
/* 378 */       Character.valueOf('Z'), new ItemStack(Items.leather) });
/*     */     
/* 380 */     GameRegistry.addRecipe(new ItemStack(ModItems.hangGlider, 1), new Object[] { " Y ", "XYX", 
/* 381 */       Character.valueOf('X'), new ItemStack(ModItems.wing), Character.valueOf('Y'), new ItemStack(Items.leather) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 386 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianStone, 1), new Object[] { " X ", "XYX", " X ", Character.valueOf('X'), new ItemStack(Blocks.stone), 
/* 387 */       Character.valueOf('Y'), new ItemStack(ModItems.compressedPaladium) });
/*     */     
/* 389 */     GameRegistry.addRecipe(new ItemStack(ModItems.voidStone, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 390 */       Character.valueOf('Z'), new ItemStack(Blocks.chest) });
/*     */     
/* 392 */     GameRegistry.addRecipe(new ItemStack(ModItems.chestExplorer, 1), new Object[] { "XYX", "XZX", "XYX", 
/* 393 */       Character.valueOf('X'), new ItemStack(MaterialRegister.FINDIUM), Character.valueOf('Z'), new ItemStack(ModItems.compressedPaladium), 
/* 394 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/*     */ 
/* 397 */     GameRegistry.addRecipe(new ItemStack(ModItems.stuffSwitcher, 1), new Object[] { " X ", "YZY", " X ", 
/* 398 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.amethystChestplate), 
/* 399 */       Character.valueOf('Y'), new ItemStack(ModItems.paladiumCore) });
/*     */     
/*     */ 
/* 402 */     GameRegistry.addRecipe(new ItemStack(ModItems.backpack, 1), new Object[] { "XXX", "YZY", "YYY", 
/* 403 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumStick), Character.valueOf('Z'), new ItemStack(Blocks.chest), 
/* 404 */       Character.valueOf('Y'), new ItemStack(Items.leather) });
/*     */     
/* 406 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianWhitelist, 1), new Object[] { "XXX", "XZX", "XXX", Character.valueOf('X'), new ItemStack(Items.paper), 
/* 407 */       Character.valueOf('Z'), new ItemStack(ModItems.guardianStone) });
/*     */     
/* 409 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianXpUpgrade, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 410 */       Character.valueOf('Z'), new ItemStack(ModItems.guardianStone) });
/*     */     
/* 412 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianLifeUpgrade1, 1), new Object[] { "XYZ", "MVM", "ZYX", 
/* 413 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumApple), Character.valueOf('Y'), new ItemStack(DecorativeRegister.AMETHYST_BLOCK), 
/* 414 */       Character.valueOf('Z'), new ItemStack(DecorativeRegister.TITANE_BLOCK), Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), 
/* 415 */       Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/* 417 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianLifeUpgrade2, 1), new Object[] { "XZX", "MVM", "XZX", 
/* 418 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumApple), Character.valueOf('Z'), new ItemStack(DecorativeRegister.TITANE_BLOCK), 
/* 419 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianLifeUpgrade1) });
/*     */     
/*     */ 
/* 422 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianLifeUpgrade3, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 423 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumApple), Character.valueOf('Z'), new ItemStack(DecorativeRegister.TITANE_BLOCK), 
/* 424 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianLifeUpgrade2) });
/*     */     
/*     */ 
/* 427 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianDamageUpgrade1, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 428 */       Character.valueOf('X'), new ItemStack(ModItems.amethystSword), Character.valueOf('Y'), new ItemStack(DecorativeRegister.AMETHYST_BLOCK), 
/* 429 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 432 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianDamageUpgrade2, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 433 */       Character.valueOf('X'), new ItemStack(ModItems.titaneSword), Character.valueOf('Y'), new ItemStack(DecorativeRegister.TITANE_BLOCK), 
/* 434 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianDamageUpgrade1) });
/*     */     
/*     */ 
/* 437 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianDamageUpgrade3, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 438 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumSword), Character.valueOf('Y'), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), 
/* 439 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianDamageUpgrade2) });
/*     */     
/*     */ 
/* 442 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianPeneUpgrade1, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 443 */       Character.valueOf('X'), new ItemStack(ModItems.amethystChestplate), Character.valueOf('Y'), new ItemStack(MaterialRegister.AMETHYST_INGOT), 
/* 444 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 447 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianPeneUpgrade2, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 448 */       Character.valueOf('X'), new ItemStack(ModItems.titaneChestplate), Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 449 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianPeneUpgrade1) });
/*     */     
/*     */ 
/* 452 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianPeneUpgrade3, 1), new Object[] { "XYX", "MVM", "XYX", 
/* 453 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumChestplate), Character.valueOf('Y'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 454 */       Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), Character.valueOf('V'), new ItemStack(ModItems.guardianPeneUpgrade2) });
/*     */     
/*     */ 
/* 457 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianExplosiveUpgrade, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 458 */       Character.valueOf('X'), new ItemStack(Blocks.obsidian), Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), 
/* 459 */       Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/* 461 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianThornsUpgrade1, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 462 */       Character.valueOf('X'), new ItemStack(PaladiumRegister.AMETHYST_SPIKE_BLOCK), Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), 
/* 463 */       Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 466 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianThornsUpgrade2, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 467 */       Character.valueOf('X'), new ItemStack(PaladiumRegister.TITANE_SPIKE_BLOCK), Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), 
/* 468 */       Character.valueOf('V'), new ItemStack(ModItems.guardianThornsUpgrade1) });
/*     */     
/*     */ 
/*     */ 
/* 472 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianThornsUpgrade3, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 473 */       Character.valueOf('X'), new ItemStack(PaladiumRegister.PALADIUM_SPIKE_BLOCK), Character.valueOf('M'), new ItemStack(ModItems.paladiumCore), 
/* 474 */       Character.valueOf('V'), new ItemStack(ModItems.guardianThornsUpgrade2) });
/*     */     
/*     */ 
/*     */ 
/* 478 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianWeaponUpgrade, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 479 */       Character.valueOf('X'), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), Character.valueOf('V'), new ItemStack(ModItems.paladiumSword), 
/* 480 */       Character.valueOf('M'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 483 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianFarmUpgrade, 1), new Object[] { "XYZ", "MVM", "ZYX", 
/* 484 */       Character.valueOf('X'), new ItemStack(ModItems.paladiumHammer), Character.valueOf('Y'), new ItemStack(DecorativeRegister.TITANE_BLOCK), 
/* 485 */       Character.valueOf('Z'), new ItemStack(ModItems.paladiumPickaxe), Character.valueOf('M'), new ItemStack(DecorativeRegister.AMETHYST_BLOCK), 
/* 486 */       Character.valueOf('V'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 489 */     GameRegistry.addRecipe(new ItemStack(ModItems.guardianAutoXPUpgrade, 1), new Object[] { "XXX", "MVM", "XXX", 
/* 490 */       Character.valueOf('X'), new ItemStack(WorldRegister.XP_BERRY), Character.valueOf('V'), new ItemStack(ModItems.paladiumSword), 
/* 491 */       Character.valueOf('M'), new ItemStack(ModItems.guardianXpUpgrade) });
/*     */     
/*     */ 
/* 494 */     GameRegistry.addRecipe(new ItemStack(ModItems.healOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 495 */       Character.valueOf('Z'), new ItemStack(Items.speckled_melon) });
/*     */     
/* 497 */     GameRegistry.addRecipe(new ItemStack(ModItems.strenghtOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 498 */       Character.valueOf('Z'), new ItemStack(Items.blaze_powder) });
/*     */     
/* 500 */     GameRegistry.addRecipe(new ItemStack(ModItems.jumpOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 501 */       Character.valueOf('Z'), new ItemStack(Items.nether_wart) });
/*     */     
/* 503 */     GameRegistry.addRecipe(new ItemStack(ModItems.healOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 504 */       Character.valueOf('Z'), new ItemStack(Items.book) });
/*     */     
/* 506 */     GameRegistry.addRecipe(new ItemStack(ModItems.potionLauncher, 1), new Object[] { "XXX", "ZYY", "XXX", 
/* 507 */       Character.valueOf('X'), new ItemStack(MaterialRegister.AMETHYST_INGOT), Character.valueOf('Z'), new ItemStack(ModItems.paladiumCore), 
/* 508 */       Character.valueOf('Y'), new ItemStack(Items.glass_bottle) });
/*     */     
/* 510 */     GameRegistry.addRecipe(new ItemStack(ModItems.bowModifer, 1), new Object[] { " X ", "XYX", " X ", Character.valueOf('X'), new ItemStack(ModItems.paladiumStick), 
/* 511 */       Character.valueOf('Y'), new ItemStack(Items.paper) });
/*     */     
/* 513 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumCore, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 514 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 515 */       Character.valueOf('Z'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 517 */     GameRegistry.addRecipe(new ItemStack(ModItems.speedModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 518 */       Character.valueOf('Z'), new ItemStack(ModItems.speedOrb) });
/*     */     
/* 520 */     GameRegistry.addRecipe(new ItemStack(ModItems.smeltModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 521 */       Character.valueOf('Z'), new ItemStack(Items.blaze_rod) });
/*     */     
/* 523 */     GameRegistry.addRecipe(new ItemStack(ModItems.knockbackModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 524 */       Character.valueOf('Z'), new ItemStack(ModItems.knockbackOrb) });
/*     */     
/* 526 */     GameRegistry.addRecipe(new ItemStack(ModItems.knockbackOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 527 */       Character.valueOf('Z'), new ItemStack(Items.ghast_tear) });
/*     */     
/* 529 */     GameRegistry.addRecipe(new ItemStack(ModItems.fortuneModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 530 */       Character.valueOf('Z'), new ItemStack(Blocks.gold_block) });
/*     */     
/* 532 */     GameRegistry.addRecipe(new ItemStack(ModItems.flameModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 533 */       Character.valueOf('Z'), new ItemStack(Items.flint_and_steel) });
/*     */     
/* 535 */     GameRegistry.addRecipe(new ItemStack(ModItems.damageModifier, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 536 */       Character.valueOf('Z'), new ItemStack(Items.mushroom_stew) });
/*     */     
/* 538 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumCore, 1), new Object[] { "YXY", "XZX", "YXY", 
/* 539 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Y'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 540 */       Character.valueOf('Z'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 542 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumAxe, 1), new Object[] { " XX", " YX", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 543 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 545 */     GameRegistry.addRecipe(new ItemStack(ModItems.MagicalAnvilTop, 1), new Object[] { "XYX", "YZY", "XYX", 
/* 546 */       Character.valueOf('X'), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), Character.valueOf('Y'), new ItemStack(MaterialRegister.FINDIUM), 
/* 547 */       Character.valueOf('Z'), new ItemStack(ModItems.compressedPaladium) });
/* 548 */     GameRegistry.addRecipe(new ItemStack(ModItems.MagicalAnvilMiddle, 1), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('X'), new ItemStack(Blocks.cobblestone), 
/* 549 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.FINDIUM) });
/* 550 */     GameRegistry.addRecipe(new ItemStack(ModItems.MagicalAnvilBottom, 1), new Object[] { "   ", " X ", "XYX", Character.valueOf('X'), new ItemStack(Blocks.cobblestone), 
/* 551 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.FINDIUM) });
/*     */     
/* 553 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumAxe, 1), new Object[] { "XX ", "XY ", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 554 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 556 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumPickaxe, 1), new Object[] { "XXX", " Y ", " Y ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 557 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 559 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumShovel, 1), new Object[] { "X", "Y", "Y", 
/* 560 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 562 */     GameRegistry.addRecipe(new ItemStack(ModItems.paladiumSword, 1), new Object[] { "X", "X", "Y", 
/* 563 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/* 565 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.bucketSulfuric, 1), new Object[] { "Y", "X", 
/* 566 */       Character.valueOf('X'), new ItemStack(Items.water_bucket), Character.valueOf('Y'), new ItemStack(Items.potionitem, 1, 8268), 
/* 567 */       Character.valueOf('Y'), new ItemStack(ModItems.paladiumStick) });
/*     */     
/* 569 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.bucketAngelic, 1), new Object[] { "Y", "X", Character.valueOf('X'), new ItemStack(Items.water_bucket), 
/* 570 */       Character.valueOf('Y'), new ItemStack(Items.potionitem, 1, 8193) });
/*     */     
/* 572 */     GameRegistry.addRecipe(new ItemStack(ModItems.speedOrb, 1), new Object[] { " X ", "XZX", " X ", Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 573 */       Character.valueOf('Z'), new ItemStack(Items.sugar) });
/*     */     
/*     */ 
/*     */ 
/* 577 */     GameRegistry.addShapelessRecipe(new ItemStack(ModItems.witherSkullFragment, 9), new Object[] { new ItemStack(Items.skull, 1, 1) });
/*     */     
/*     */ 
/* 580 */     GameRegistry.addShapelessRecipe(new ItemStack(MaterialRegister.TITANE_INGOT, 9), new Object[] { new ItemStack(DecorativeRegister.TITANE_BLOCK, 1) });
/*     */     
/* 582 */     GameRegistry.addShapelessRecipe(new ItemStack(MaterialRegister.PALADIUM_INGOT, 9), new Object[] { new ItemStack(DecorativeRegister.PALADIUM_BLOCK, 1) });
/*     */     
/* 584 */     GameRegistry.addShapelessRecipe(new ItemStack(MaterialRegister.AMETHYST_INGOT, 9), new Object[] { new ItemStack(DecorativeRegister.AMETHYST_BLOCK, 1) });
/*     */     
/* 586 */     GameRegistry.addShapelessRecipe(new ItemStack(ModItems.bowSpeedModifier, 1), new Object[] { new ItemStack(ModItems.bowModifer, 1), new ItemStack(Items.potionitem, 1, 8258) });
/*     */     
/*     */ 
/* 589 */     GameRegistry.addShapelessRecipe(new ItemStack(ModItems.bowRangeModifier, 1), new Object[] { new ItemStack(ModItems.bowModifer, 1), new ItemStack(Items.potionitem, 1, 8201) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 594 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.PALADIUM_CHEST), new Object[] { "XXX", "Y Y", "XXX", Character.valueOf('Y'), ModItems.compressedPaladium, 
/* 595 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/* 597 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.BOW_MACHINE_BLOCK), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('Y'), ModItems.compressedPaladium, 
/* 598 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/*     */ 
/* 601 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.ALCHEMY_CREATOR_BLOCK), new Object[] { "YUY", "XZX", "XXX", 
/* 602 */       Character.valueOf('Y'), Items.blaze_powder, Character.valueOf('U'), new ItemStack(ModItems.compressedPaladium), 
/* 603 */       Character.valueOf('X'), MaterialRegister.TITANE_INGOT, Character.valueOf('Z'), ModItems.paladiumCore });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 612 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.ONLINE_DETECTOR_BLOCK), new Object[] { "YYY", "YXY", "ZZZ", 
/* 613 */       Character.valueOf('Y'), Items.dye, Character.valueOf('U'), new ItemStack(ModItems.witherSkullFragment), 
/* 614 */       Character.valueOf('X'), MaterialRegister.PALADIUM_INGOT, Character.valueOf('Z'), MaterialRegister.TITANE_INGOT });
/*     */     
/*     */ 
/* 617 */     GameRegistry.addRecipe(new ItemStack(SmelteryRegister.GRINDER_BLOCK), new Object[] { "YYY", "YXY", "YYY", Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, 
/* 618 */       Character.valueOf('X'), new ItemStack(PaladiumRegister.PALADIUM_FURNACE) });
/*     */     
/* 620 */     GameRegistry.addRecipe(new ItemStack(SmelteryRegister.GRINDER_CASING_BLOCK), new Object[] { "Y Y", "Y Y", "Y Y", 
/* 621 */       Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT });
/*     */     
/* 623 */     GameRegistry.addRecipe(new ItemStack(SmelteryRegister.GRINDER_FRAME_BLOCK), new Object[] { "YZY", "   ", "YZY", 
/* 624 */       Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, Character.valueOf('Z'), MaterialRegister.TITANE_INGOT });
/*     */     
/* 626 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.GUARDIAN_BLOCK), new Object[] { "YYY", "YXY", "YYY", 
/* 627 */       Character.valueOf('X'), ModItems.guardianStone, Character.valueOf('Y'), MaterialRegister.TITANE_INGOT });
/*     */     
/* 629 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.GUARDIAN_KEEPER_BLOCK), new Object[] { "YYY", "ZXZ", "YYY", Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, 
/* 630 */       Character.valueOf('Z'), new ItemStack(ModItems.compressedPaladium), Character.valueOf('X'), ModItems.guardianStone });
/*     */     
/* 632 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.IRON_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 633 */       Character.valueOf('Y'), Items.wooden_sword, Character.valueOf('X'), Items.iron_ingot });
/*     */     
/* 635 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.AMETHYST_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 636 */       Character.valueOf('Y'), Items.diamond_sword, Character.valueOf('X'), MaterialRegister.AMETHYST_INGOT });
/*     */     
/* 638 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.DIAMOND_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 639 */       Character.valueOf('Y'), Items.golden_sword, Character.valueOf('X'), Items.diamond });
/*     */     
/* 641 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.GOLD_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 642 */       Character.valueOf('Y'), Items.golden_sword, Character.valueOf('X'), Items.gold_ingot });
/*     */     
/* 644 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.PALADIUM_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 645 */       Character.valueOf('Y'), ModItems.titaneSword, Character.valueOf('X'), MaterialRegister.PALADIUM_INGOT });
/*     */     
/* 647 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.TITANE_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 648 */       Character.valueOf('Y'), ModItems.amethystSword, Character.valueOf('X'), MaterialRegister.TITANE_INGOT });
/*     */     
/* 650 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.WOOD_SPIKE_BLOCK), new Object[] { " Y ", "YXY", "XXX", 
/* 651 */       Character.valueOf('Y'), Items.wooden_sword, Character.valueOf('X'), Blocks.planks });
/*     */     
/* 653 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.SLIMEPAD_BLOCK), new Object[] { "XXX", "XXX", Character.valueOf('X'), Items.slime_ball });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 658 */     GameRegistry.addRecipe(new ItemStack(PaladiumRegister.CAVE_BLOCK), new Object[] { "XXX", "XYX", "XXX", Character.valueOf('X'), new ItemStack(Blocks.glass), 
/* 659 */       Character.valueOf('Y'), new ItemStack(MaterialRegister.FINDIUM) });
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\recipies\ModRecipies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */