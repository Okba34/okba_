/*    */ package fr.paladium.palamod.blocks.fluids;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fluids.BlockFluidClassic;
/*    */ 
/*    */ public class BlockAngelicWater extends BlockFluidClassic
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected IIcon stillIcon;
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected IIcon flowingIcon;
/*    */   
/*    */   public BlockAngelicWater(net.minecraftforge.fluids.Fluid fluid, Material material)
/*    */   {
/* 24 */     super(fluid, material);
/* 25 */     setHardness(100.0F);
/* 26 */     setBlockName("angelicwater");
/*    */   }
/*    */   
/*    */   public IIcon getIcon(int side, int meta)
/*    */   {
/* 31 */     return (side == 0) || (side == 1) ? this.stillIcon : this.flowingIcon;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerBlockIcons(IIconRegister register)
/*    */   {
/* 37 */     this.stillIcon = register.registerIcon(PalaMod.MODID + ":AngelicWaterStill");
/* 38 */     this.flowingIcon = register.registerIcon(PalaMod.MODID + ":AngelicWaterFlowing");
/*    */   }
/*    */   
/*    */   public boolean canDisplace(IBlockAccess world, int x, int y, int z)
/*    */   {
/* 43 */     if ((world.getBlock(x, y, z).getMaterial().isLiquid()) && ((world.getBlock(x, y, z) instanceof BlockSlufuricWater))) {
/* 44 */       return true;
/*    */     }
/* 46 */     return super.canDisplace(world, x, y, z);
/*    */   }
/*    */   
/*    */   public boolean displaceIfPossible(World world, int x, int y, int z)
/*    */   {
/* 51 */     if ((world.getBlock(x, y, z).getMaterial().isLiquid()) && ((world.getBlock(x, y, z) instanceof BlockSlufuricWater))) {
/* 52 */       return true;
/*    */     }
/* 54 */     return super.displaceIfPossible(world, x, y, z);
/*    */   }
/*    */   
/* 57 */   int i = 0;
/*    */   
/*    */   public void onEntityCollidedWithBlock(World wolrd, int x, int y, int z, net.minecraft.entity.Entity entity) {
/* 60 */     super.onEntityCollidedWithBlock(wolrd, x, y, z, entity);
/*    */     
/* 62 */     if (!(entity instanceof net.minecraft.entity.player.EntityPlayer)) {
/* 63 */       return;
/*    */     }
/*    */     
/* 66 */     EntityLivingBase livingBase = (EntityLivingBase)entity;
/*    */     
/* 68 */     this.i += 1;
/* 69 */     if ((livingBase.getHealth() < livingBase.getMaxHealth()) && (this.i >= 120)) {
/* 70 */       this.i = 0;
/* 71 */       livingBase.heal(1.0F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\blocks\fluids\BlockAngelicWater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */