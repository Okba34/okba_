/*    */ package fr.paladium.palamod.blocks.fluids;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fluids.BlockFluidClassic;
/*    */ 
/*    */ public class BlockSlufuricWater extends BlockFluidClassic
/*    */ {
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected IIcon stillIcon;
/*    */   @SideOnly(Side.CLIENT)
/*    */   protected IIcon flowingIcon;
/*    */   
/*    */   public BlockSlufuricWater(net.minecraftforge.fluids.Fluid fluid, Material material)
/*    */   {
/* 26 */     super(fluid, material);
/* 27 */     setHardness(100.0F);
/* 28 */     setBlockName("sulfuricwater");
/*    */   }
/*    */   
/*    */   public IIcon getIcon(int side, int meta)
/*    */   {
/* 33 */     return (side == 0) || (side == 1) ? this.stillIcon : this.flowingIcon;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void registerBlockIcons(IIconRegister register)
/*    */   {
/* 39 */     this.stillIcon = register.registerIcon(PalaMod.MODID + ":SulfuricWaterStill");
/* 40 */     this.flowingIcon = register.registerIcon(PalaMod.MODID + ":SulfuricWaterFlowing");
/*    */   }
/*    */   
/*    */   public boolean canDisplace(IBlockAccess world, int x, int y, int z)
/*    */   {
/* 45 */     if (world.getBlock(x, y, z).getMaterial().isLiquid()) {
/* 46 */       return false;
/*    */     }
/* 48 */     return super.canDisplace(world, x, y, z);
/*    */   }
/*    */   
/*    */   public boolean displaceIfPossible(World world, int x, int y, int z)
/*    */   {
/* 53 */     if (world.getBlock(x, y, z).getMaterial().isLiquid()) {
/* 54 */       return false;
/*    */     }
/* 56 */     return super.displaceIfPossible(world, x, y, z);
/*    */   }
/*    */   
/*    */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity)
/*    */   {
/* 61 */     super.onEntityCollidedWithBlock(world, x, y, z, entity);
/*    */     
/* 63 */     if (((entity instanceof net.minecraft.entity.boss.EntityWither)) || ((entity instanceof EntityLivingBase))) {
/* 64 */       if (((entity instanceof EntityCustomWither)) && (((EntityCustomWither)entity).getWitherData().nofakewater)) {
/* 65 */         return;
/*    */       }
/* 67 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 68 */       livingBase.attackEntityFrom(net.minecraft.util.DamageSource.magic, 2.0F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\blocks\fluids\BlockSlufuricWater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */