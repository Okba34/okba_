/*    */ package fr.paladium.palamod.blocks.fluids;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ModFluids
/*    */ {
/*    */   public static void init()
/*    */   {
/* 11 */     net.minecraftforge.fluids.FluidContainerRegistry.registerFluidContainer(PaladiumRegister.sulfuricWaterFluid, new ItemStack(PaladiumRegister.bucketSulfuric), new ItemStack(Items.bucket));
/*    */     
/* 13 */     fr.paladium.palamod.common.EventHandler.buckets.put(PaladiumRegister.sulfuricWater, PaladiumRegister.bucketSulfuric);
/* 14 */     net.minecraftforge.fluids.FluidContainerRegistry.registerFluidContainer(PaladiumRegister.angelicWaterFluid, new ItemStack(PaladiumRegister.bucketAngelic), new ItemStack(Items.bucket));
/*    */     
/* 16 */     fr.paladium.palamod.common.EventHandler.buckets.put(PaladiumRegister.angelicWater, PaladiumRegister.bucketAngelic);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\blocks\fluids\ModFluids.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */