/*    */ package fr.paladium.palamod.job;
/*    */ 
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ public class Job
/*    */ {
/*    */   int id;
/*    */   String name;
/*    */   String displayName;
/*    */   ResourceLocation location;
/*    */   int[] coords;
/*    */   
/*    */   public Job(int id, String name, String displayName, String logoLocation, int[] coords)
/*    */   {
/* 16 */     this.id = id;
/* 17 */     this.name = name;
/* 18 */     this.displayName = displayName;
/* 19 */     this.location = new ResourceLocation(logoLocation);
/* 20 */     this.coords = coords;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 24 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 28 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getDisplayName() {
/* 36 */     return this.displayName;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 40 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getSubLevel(int xp) {
/* 44 */     if (getXPForLevel(getLevel(xp) + 1) == 0)
/* 45 */       return 0;
/* 46 */     return xp / getLevel(xp);
/*    */   }
/*    */   
/*    */   public int getLevel(int xp) {
/* 50 */     int level = (int)Math.pow(xp / 20, 0.3333333333333333D);
/* 51 */     if (level == 0)
/* 52 */       level = 1;
/* 53 */     if (level >= 20)
/* 54 */       level = 20;
/* 55 */     return level;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getXPForLevel(int level)
/*    */   {
/* 61 */     return (int)(Math.pow(level, 3.0D) * 20.0D);
/*    */   }
/*    */   
/*    */   public int getSubXPFromXP(int xp) {
/* 65 */     return getXPForLevel(getLevel(xp) - 1);
/*    */   }
/*    */   
/*    */   public int getSubXPFromLevel(int level) {
/* 69 */     return getXPForLevel(level - 1);
/*    */   }
/*    */   
/*    */   public int getTotalXPLevel(int level) {
/* 73 */     return getXPForLevel(level + 1) - getXPForLevel(level);
/*    */   }
/*    */   
/*    */   public ResourceLocation getLogo() {
/* 77 */     return this.location;
/*    */   }
/*    */   
/*    */   public int[] getCoords() {
/* 81 */     return this.coords;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\Job.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */