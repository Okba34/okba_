/*     */ package fr.paladium.palamod.job.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.job.Job;
/*     */ import fr.paladium.palamod.job.JobsXPManager;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.job.logic.TileCobbleBreaker;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockCobbleBreaker
/*     */   extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   private IIcon front;
/*     */   private IIcon top;
/*     */   
/*     */   public BlockCobbleBreaker(String unlocalizedName)
/*     */   {
/*  36 */     super(Material.iron);
/*     */     
/*  38 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  40 */     setBlockName(this.unlocalizedName);
/*     */     
/*  42 */     setHardness(12.0F);
/*  43 */     setResistance(8.0F);
/*     */     
/*  45 */     setHarvestLevel("pickaxe", 1);
/*  46 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  51 */     return new TileCobbleBreaker();
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  56 */     if (!world.isRemote) {
/*  57 */       JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString());
/*  58 */       if (((Job)ModJobs.jobs.get(Integer.valueOf(3))).getLevel(jobs.getXP(3)) >= 10) {
/*  59 */         player.openGui(PalaMod.instance, 29, world, x, y, z);
/*     */       }
/*     */     }
/*  62 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iiconRegister)
/*     */   {
/*  68 */     this.blockIcon = iiconRegister.registerIcon("palamod:machines/cobbleBreaker_side");
/*  69 */     this.front = iiconRegister.registerIcon("palamod:machines/cobbleBreaker_front");
/*  70 */     this.top = iiconRegister.registerIcon("palamod:machines/cobbleBreaker_top");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata) {
/*  75 */     return side != metadata ? this.blockIcon : side == 0 ? this.top : side == 1 ? this.top : this.front;
/*     */   }
/*     */   
/*     */   public Item getItemDropped(int p_149650_1_, Random p_149650_2_, int p_149650_3_)
/*     */   {
/*  80 */     return Item.getItemFromBlock(this);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void onBlockAdded(World world, int x, int y, int z)
/*     */   {
/*  87 */     super.onBlockAdded(world, x, y, z);
/*  88 */     direction(world, x, y, z);
/*     */   }
/*     */   
/*     */   private void direction(World world, int x, int y, int z) {
/*  92 */     if (!world.isRemote) {
/*  93 */       byte byte0 = 3;
/*     */       
/*     */ 
/*  96 */       Block direction = world.getBlock(x, y, z - 1);
/*  97 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/*  98 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 102 */       Block direction = world.getBlock(x, y, z + 1);
/* 103 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 104 */         byte0 = 2;
/*     */       }
/*     */       
/*     */ 
/* 108 */       Block direction = world.getBlock(x - 1, y, z);
/* 109 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 110 */         byte0 = 5;
/*     */       }
/*     */       
/*     */ 
/* 114 */       Block direction = world.getBlock(x + 1, y, z);
/* 115 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 116 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 120 */       world.setBlockMetadataWithNotify(x, y, z, byte0, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemStack)
/*     */   {
/* 126 */     int direction = MathHelper.floor_double(entity.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3;
/*     */     
/* 128 */     if (direction == 0) {
/* 129 */       world.setBlockMetadataWithNotify(x, y, z, 2, 2);
/*     */     }
/* 131 */     else if (direction == 1) {
/* 132 */       world.setBlockMetadataWithNotify(x, y, z, 5, 2);
/*     */     }
/* 134 */     else if (direction == 2) {
/* 135 */       world.setBlockMetadataWithNotify(x, y, z, 3, 2);
/*     */     }
/* 137 */     else if (direction == 3) {
/* 138 */       world.setBlockMetadataWithNotify(x, y, z, 4, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item getItem(World p_149694_1_, int p_149694_2_, int p_149694_3_, int p_149694_4_)
/*     */   {
/* 145 */     return Item.getItemFromBlock(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\block\BlockCobbleBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */