/*     */ package fr.paladium.palamod.job.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.job.JobRegister;
/*     */ import fr.paladium.palamod.job.logic.ForgeLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class BlockForge
/*     */   extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   private IIcon front;
/*     */   private IIcon top;
/*     */   private final boolean isActive;
/*     */   private static boolean isBurning;
/*     */   
/*     */   public BlockForge(String unlocalizedName, boolean isActive)
/*     */   {
/*  35 */     super(Material.iron);
/*     */     
/*  37 */     this.unlocalizedName = unlocalizedName;
/*  38 */     this.isActive = isActive;
/*     */     
/*  40 */     setBlockName(this.unlocalizedName);
/*     */     
/*  42 */     setHardness(12.0F);
/*  43 */     setResistance(8.0F);
/*     */     
/*  45 */     setHarvestLevel("pickaxe", 1);
/*     */     
/*  47 */     if (!this.isActive) {
/*  48 */       setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */     }
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  54 */     return new ForgeLogic();
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  59 */     if (!world.isRemote) {
/*  60 */       player.openGui(PalaMod.instance, 28, world, x, y, z);
/*     */     }
/*  62 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iiconRegister)
/*     */   {
/*  68 */     this.blockIcon = iiconRegister.registerIcon("palamod:machines/forge_side");
/*  69 */     this.front = iiconRegister.registerIcon(this.isActive ? "palamod:machines/forge_front_on" : "palamod:machines/forge_front_off");
/*  70 */     this.top = iiconRegister.registerIcon("palamod:machines/forge_top");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata) {
/*  75 */     return side != metadata ? this.blockIcon : side == 0 ? this.top : side == 1 ? this.top : this.front;
/*     */   }
/*     */   
/*     */   public Item getItemDropped(int p_149650_1_, Random p_149650_2_, int p_149650_3_)
/*     */   {
/*  80 */     return Item.getItemFromBlock(JobRegister.FORGE);
/*     */   }
/*     */   
/*     */   public static void updateBlockState(boolean burning, World world, int x, int y, int z) {
/*  84 */     int direction = world.getBlockMetadata(x, y, z);
/*     */     
/*  86 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*  87 */     isBurning = true;
/*     */     
/*  89 */     if (burning) {
/*  90 */       world.setBlock(x, y, z, JobRegister.LIT_FORGE);
/*     */     }
/*     */     else {
/*  93 */       world.setBlock(x, y, z, JobRegister.FORGE);
/*     */     }
/*     */     
/*  96 */     isBurning = false;
/*     */     
/*  98 */     world.setBlockMetadataWithNotify(x, y, z, direction, 2);
/*     */     
/* 100 */     if (tileentity != null) {
/* 101 */       tileentity.validate();
/* 102 */       world.setTileEntity(x, y, z, tileentity);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void onBlockAdded(World world, int x, int y, int z)
/*     */   {
/* 109 */     super.onBlockAdded(world, x, y, z);
/* 110 */     direction(world, x, y, z);
/*     */   }
/*     */   
/*     */   private void direction(World world, int x, int y, int z) {
/* 114 */     if (!world.isRemote) {
/* 115 */       byte byte0 = 3;
/*     */       
/*     */ 
/* 118 */       Block direction = world.getBlock(x, y, z - 1);
/* 119 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 120 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 124 */       Block direction = world.getBlock(x, y, z + 1);
/* 125 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 126 */         byte0 = 2;
/*     */       }
/*     */       
/*     */ 
/* 130 */       Block direction = world.getBlock(x - 1, y, z);
/* 131 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 132 */         byte0 = 5;
/*     */       }
/*     */       
/*     */ 
/* 136 */       Block direction = world.getBlock(x + 1, y, z);
/* 137 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 138 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 142 */       world.setBlockMetadataWithNotify(x, y, z, byte0, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemStack)
/*     */   {
/* 148 */     int direction = MathHelper.floor_double(entity.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3;
/*     */     
/* 150 */     if (direction == 0) {
/* 151 */       world.setBlockMetadataWithNotify(x, y, z, 2, 2);
/*     */     }
/* 153 */     else if (direction == 1) {
/* 154 */       world.setBlockMetadataWithNotify(x, y, z, 5, 2);
/*     */     }
/* 156 */     else if (direction == 2) {
/* 157 */       world.setBlockMetadataWithNotify(x, y, z, 3, 2);
/*     */     }
/* 159 */     else if (direction == 3) {
/* 160 */       world.setBlockMetadataWithNotify(x, y, z, 4, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World p_149734_1_, int p_149734_2_, int p_149734_3_, int p_149734_4_, Random p_149734_5_) {
/* 166 */     if (this.isActive) {
/* 167 */       int l = p_149734_1_.getBlockMetadata(p_149734_2_, p_149734_3_, p_149734_4_);
/*     */       
/* 169 */       float f = p_149734_2_ + 0.5F;
/* 170 */       float f1 = p_149734_3_ + 0.0F + p_149734_5_.nextFloat() * 6.0F / 16.0F;
/* 171 */       float f2 = p_149734_4_ + 0.5F;
/* 172 */       float f3 = 0.52F;
/* 173 */       float f4 = p_149734_5_.nextFloat() * 0.6F - 0.3F;
/*     */       
/* 175 */       if (l == 4) {
/* 176 */         p_149734_1_.spawnParticle("smoke", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 177 */         p_149734_1_.spawnParticle("flame", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 179 */       else if (l == 5) {
/* 180 */         p_149734_1_.spawnParticle("smoke", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 181 */         p_149734_1_.spawnParticle("flame", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 183 */       else if (l == 2) {
/* 184 */         p_149734_1_.spawnParticle("smoke", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/* 185 */         p_149734_1_.spawnParticle("flame", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 187 */       else if (l == 3) {
/* 188 */         p_149734_1_.spawnParticle("smoke", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/* 189 */         p_149734_1_.spawnParticle("flame", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item getItem(World p_149694_1_, int p_149694_2_, int p_149694_3_, int p_149694_4_) {
/* 196 */     return Item.getItemFromBlock(JobRegister.FORGE);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\block\BlockForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */