/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import com.github.abrarsyed.secretroomsmod.common.SecretRooms;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.HashMap;
/*     */ import jds.bibliocraft.blocks.BlockLoader;
/*     */ import lumien.randomthings.Blocks.ModBlocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LvlItemManager
/*     */ {
/*  21 */   public static HashMap<String, LvlItem.CraftEvent> craftEvents = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init()
/*     */   {
/*  30 */     LvlItem.CraftEvent serpe = new LvlItem.CraftEvent(4, 5);
/*  31 */     LvlItem.CraftEvent woodMachine = new LvlItem.CraftEvent(4, 15);
/*  32 */     LvlItem.CraftEvent specialAxe = new LvlItem.CraftEvent(4, 15);
/*  33 */     LvlItem.CraftEvent endiumAxe = new LvlItem.CraftEvent(4, 20);
/*     */     
/*  35 */     LvlItem.CraftEvent lumberjackLvl5 = new LvlItem.CraftEvent(4, 5);
/*  36 */     LvlItem.CraftEvent lumberjackLvl10 = new LvlItem.CraftEvent(4, 15);
/*  37 */     LvlItem.CraftEvent lumberjackLvl15 = new LvlItem.CraftEvent(4, 15);
/*  38 */     LvlItem.CraftEvent lumberjackLvl20 = new LvlItem.CraftEvent(4, 20);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  43 */     craftEvents.put(new ItemStack(ModItems.endiumAxe).getUnlocalizedName(), endiumAxe);
/*     */     
/*  45 */     craftEvents.put(new ItemStack(BlockLoader.fancyclock).getUnlocalizedName(), lumberjackLvl10);
/*  46 */     craftEvents.put(new ItemStack(BlockLoader.fancySign).getUnlocalizedName(), lumberjackLvl5);
/*     */     
/*  48 */     craftEvents.put(new ItemStack(BlockLoader.bookcase).getUnlocalizedName(), lumberjackLvl5);
/*  49 */     craftEvents.put(new ItemStack(BlockLoader.potionShelf).getUnlocalizedName(), lumberjackLvl5);
/*  50 */     craftEvents.put(new ItemStack(BlockLoader.genericShelf).getUnlocalizedName(), lumberjackLvl5);
/*  51 */     craftEvents.put(new ItemStack(BlockLoader.table).getUnlocalizedName(), lumberjackLvl5);
/*  52 */     craftEvents.put(new ItemStack(BlockLoader.mapFrame).getUnlocalizedName(), lumberjackLvl5);
/*  53 */     craftEvents.put(new ItemStack(BlockLoader.seat).getUnlocalizedName(), lumberjackLvl5);
/*     */     
/*  55 */     craftEvents.put(new ItemStack(BlockLoader.toolRack).getUnlocalizedName(), lumberjackLvl10);
/*  56 */     craftEvents.put(new ItemStack(BlockLoader.weaponCase).getUnlocalizedName(), lumberjackLvl10);
/*  57 */     craftEvents.put(new ItemStack(BlockLoader.woodLabel).getUnlocalizedName(), lumberjackLvl10);
/*     */     
/*  59 */     craftEvents.put(new ItemStack(BlockLoader.writingDesk).getUnlocalizedName(), lumberjackLvl15);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     LvlItem.CraftEvent glove = new LvlItem.CraftEvent(1, 5);
/*  67 */     LvlItem.CraftEvent mintCake = new LvlItem.CraftEvent(1, 10);
/*     */     
/*  69 */     craftEvents.put(new ItemStack(JobRegister.GLOVE).getUnlocalizedName(), glove);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */     LvlItem.CraftEvent forge = new LvlItem.CraftEvent(3, 5);
/*  76 */     LvlItem.CraftEvent cobbleBreaker = new LvlItem.CraftEvent(3, 10);
/*  77 */     LvlItem.CraftEvent autoSmeltPickAxe = new LvlItem.CraftEvent(3, 15);
/*  78 */     LvlItem.CraftEvent endiumPickAxe = new LvlItem.CraftEvent(3, 20);
/*     */     
/*     */ 
/*  81 */     LvlItem.CraftEvent minerLvl5 = new LvlItem.CraftEvent(3, 5);
/*  82 */     LvlItem.CraftEvent minerLvl10 = new LvlItem.CraftEvent(3, 15);
/*  83 */     LvlItem.CraftEvent minerLvl15 = new LvlItem.CraftEvent(3, 15);
/*  84 */     LvlItem.CraftEvent minerLvl20 = new LvlItem.CraftEvent(3, 20);
/*     */     
/*  86 */     craftEvents.put(new ItemStack(JobRegister.FORGE).getUnlocalizedName(), forge);
/*  87 */     craftEvents.put(new ItemStack(JobRegister.COBBLEBREAKER).getUnlocalizedName(), cobbleBreaker);
/*     */     
/*  89 */     craftEvents.put(new ItemStack(ModItems.endiumPickaxe).getUnlocalizedName(), endiumPickAxe);
/*     */     
/*  91 */     craftEvents.put(new ItemStack(BlockLoader.swordPedestal).getUnlocalizedName(), minerLvl5);
/*     */     
/*  93 */     craftEvents.put(new ItemStack(BlockLoader.lantern).getUnlocalizedName(), minerLvl10);
/*  94 */     craftEvents.put(new ItemStack(BlockLoader.lamp).getUnlocalizedName(), minerLvl10);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     LvlItem.CraftEvent hunterSauce = new LvlItem.CraftEvent(5, 5);
/* 101 */     LvlItem.CraftEvent barbecue = new LvlItem.CraftEvent(5, 10);
/* 102 */     LvlItem.CraftEvent endiumBow = new LvlItem.CraftEvent(5, 20);
/*     */     
/* 104 */     LvlItem.CraftEvent explodeObisidian = new LvlItem.CraftEvent(5, 15);
/* 105 */     LvlItem.CraftEvent fakeObisidian = new LvlItem.CraftEvent(5, 5);
/* 106 */     LvlItem.CraftEvent twoLifeObisidian = new LvlItem.CraftEvent(5, 10);
/*     */     
/* 108 */     craftEvents.put(new ItemStack(PaladiumRegister.EXPLODE_OBSIDIAN_BLOCK).getUnlocalizedName(), explodeObisidian);
/* 109 */     craftEvents.put(new ItemStack(PaladiumRegister.FAKE_OBSIDIAN_BLOCK).getUnlocalizedName(), fakeObisidian);
/* 110 */     craftEvents.put(new ItemStack(PaladiumRegister.TWOLIFE_OBSIDIAN_BLOCK).getUnlocalizedName(), twoLifeObisidian);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     LvlItem.CraftEvent hunterLvl5 = new LvlItem.CraftEvent(5, 5);
/* 119 */     LvlItem.CraftEvent hunterLvl10 = new LvlItem.CraftEvent(5, 15);
/* 120 */     LvlItem.CraftEvent hunterLvl15 = new LvlItem.CraftEvent(5, 15);
/* 121 */     LvlItem.CraftEvent hunterLvl20 = new LvlItem.CraftEvent(5, 20);
/*     */     
/*     */ 
/* 124 */     craftEvents.put(new ItemStack(SecretRooms.torchLever).getUnlocalizedName(), hunterLvl5);
/* 125 */     craftEvents.put(new ItemStack(SecretRooms.camoGate).getUnlocalizedName(), hunterLvl5);
/* 126 */     craftEvents.put(new ItemStack(SecretRooms.camoGateExt).getUnlocalizedName(), hunterLvl5);
/* 127 */     craftEvents.put(new ItemStack(SecretRooms.camoTrapDoor).getUnlocalizedName(), hunterLvl5);
/* 128 */     craftEvents.put(new ItemStack(SecretRooms.camoPlateAll).getUnlocalizedName(), hunterLvl5);
/* 129 */     craftEvents.put(new ItemStack(SecretRooms.camoStairs).getUnlocalizedName(), hunterLvl5);
/* 130 */     craftEvents.put(new ItemStack(SecretRooms.solidAir).getUnlocalizedName(), hunterLvl5);
/* 131 */     craftEvents.put(new ItemStack(SecretRooms.camoDoorWood).getUnlocalizedName(), hunterLvl5);
/*     */     
/*     */ 
/*     */ 
/* 135 */     craftEvents.put(new ItemStack(SecretRooms.oneWay).getUnlocalizedName(), hunterLvl10);
/* 136 */     craftEvents.put(new ItemStack(SecretRooms.camoLever).getUnlocalizedName(), hunterLvl10);
/* 137 */     craftEvents.put(new ItemStack(SecretRooms.camoButton).getUnlocalizedName(), hunterLvl10);
/* 138 */     craftEvents.put(new ItemStack(SecretRooms.camoPlateHeavy).getUnlocalizedName(), hunterLvl10);
/* 139 */     craftEvents.put(new ItemStack(SecretRooms.camoPlateLight).getUnlocalizedName(), hunterLvl10);
/* 140 */     craftEvents.put(new ItemStack(SecretRooms.camoDoorIron).getUnlocalizedName(), hunterLvl10);
/*     */     
/*     */ 
/* 143 */     craftEvents.put(new ItemStack(SecretRooms.camoGhost).getUnlocalizedName(), hunterLvl15);
/* 144 */     craftEvents.put(new ItemStack(SecretRooms.camoPlatePlayer).getUnlocalizedName(), hunterLvl15);
/* 145 */     craftEvents.put(new ItemStack(SecretRooms.camoChest).getUnlocalizedName(), hunterLvl15);
/* 146 */     craftEvents.put(new ItemStack(SecretRooms.camoTrappedChest).getUnlocalizedName(), hunterLvl15);
/* 147 */     craftEvents.put(new ItemStack(SecretRooms.camoLightDetector).getUnlocalizedName(), hunterLvl15);
/* 148 */     craftEvents.put(new ItemStack(SecretRooms.camoPaste).getUnlocalizedName(), hunterLvl15);
/*     */     
/*     */ 
/*     */ 
/* 152 */     LvlItem.CraftEvent eggplantSeed = new LvlItem.CraftEvent(2, 5);
/* 153 */     LvlItem.CraftEvent chervilSeed = new LvlItem.CraftEvent(2, 10);
/* 154 */     LvlItem.CraftEvent kiwanoSeed = new LvlItem.CraftEvent(2, 15);
/* 155 */     LvlItem.CraftEvent orangeblueSeed = new LvlItem.CraftEvent(2, 20);
/*     */     
/* 157 */     craftEvents.put(new ItemStack(WorldRegister.EGGPLANT_SEED).getUnlocalizedName(), eggplantSeed);
/* 158 */     craftEvents.put(new ItemStack(WorldRegister.EGGPLANT).getUnlocalizedName(), eggplantSeed);
/* 159 */     craftEvents.put(new ItemStack(Item.getItemFromBlock(WorldRegister.EGGPLANT_CROP)).getUnlocalizedName(), eggplantSeed);
/*     */     
/* 161 */     craftEvents.put(new ItemStack(WorldRegister.CHERVIL_SEED).getUnlocalizedName(), chervilSeed);
/* 162 */     craftEvents.put(new ItemStack(Item.getItemFromBlock(WorldRegister.CHERVIL_CROP)).getUnlocalizedName(), chervilSeed);
/*     */     
/* 164 */     craftEvents.put(new ItemStack(WorldRegister.KIWANO_SEED).getUnlocalizedName(), kiwanoSeed);
/* 165 */     craftEvents.put(new ItemStack(WorldRegister.KIWANO).getUnlocalizedName(), kiwanoSeed);
/* 166 */     craftEvents.put(new ItemStack(Item.getItemFromBlock(WorldRegister.KIWANO_CROP)).getUnlocalizedName(), kiwanoSeed);
/*     */     
/* 168 */     craftEvents.put(new ItemStack(WorldRegister.ORANGEBLUE_SEED).getUnlocalizedName(), orangeblueSeed);
/* 169 */     craftEvents.put(new ItemStack(WorldRegister.ORANGEBLUE).getUnlocalizedName(), orangeblueSeed);
/* 170 */     craftEvents.put(new ItemStack(Item.getItemFromBlock(WorldRegister.ORANGEBLUE_CROP)).getUnlocalizedName(), orangeblueSeed);
/*     */     
/* 172 */     LvlItem.CraftEvent farmerLvl5 = new LvlItem.CraftEvent(2, 5);
/* 173 */     LvlItem.CraftEvent farmerLvl10 = new LvlItem.CraftEvent(2, 5);
/* 174 */     LvlItem.CraftEvent farmerLvl15 = new LvlItem.CraftEvent(2, 5);
/* 175 */     LvlItem.CraftEvent famerLvl20 = new LvlItem.CraftEvent(2, 5);
/* 176 */     craftEvents.put(new ItemStack(ModBlocks.fertilizedDirt).getUnlocalizedName(), farmerLvl5);
/* 177 */     craftEvents.put(new ItemStack(ModBlocks.dyeingMachine).getUnlocalizedName(), farmerLvl10);
/* 178 */     craftEvents.put(new ItemStack(ModBlocks.imbuingStation).getUnlocalizedName(), farmerLvl10);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\LvlItemManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */