/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.Event;
/*     */ import cpw.mods.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
/*     */ import cpw.mods.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.player.AnvilRepairEvent;
/*     */ import net.minecraftforge.event.world.BlockEvent.BreakEvent;
/*     */ 
/*     */ public abstract class LvlItem
/*     */ {
/*     */   int job;
/*     */   int minLvl;
/*     */   
/*     */   public LvlItem(int job, int minLvl)
/*     */   {
/*  20 */     this.minLvl = minLvl;
/*  21 */     this.job = job;
/*     */   }
/*     */   
/*     */   public Boolean onEvent(Event event)
/*     */   {
/*  26 */     EntityPlayer player = isEventValid(event);
/*  27 */     boolean flag = (player != null) && (!event.isCanceled());
/*  28 */     if (flag) {
/*  29 */       return Boolean.valueOf(true);
/*     */     }
/*  31 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public abstract EntityPlayer isEventValid(Event paramEvent);
/*     */   
/*     */   public static class BreakEvent extends LvlItem
/*     */   {
/*     */     IBlockState blockState;
/*     */     
/*     */     public BreakEvent(int job, int minLvl) {
/*  41 */       super(minLvl);
/*     */     }
/*     */     
/*     */ 
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/*  47 */       if (!(event instanceof BlockEvent.BreakEvent))
/*  48 */         return null;
/*  49 */       BlockEvent.BreakEvent breakEvent = (BlockEvent.BreakEvent)event;
/*  50 */       IBlockState blockstateBreak = new IBlockState(((BlockEvent.BreakEvent)event).block, ((BlockEvent.BreakEvent)event).blockMetadata);
/*  51 */       if (blockstateBreak.equals(this.blockState))
/*  52 */         return breakEvent.getPlayer();
/*  53 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CraftEvent
/*     */     extends LvlItem
/*     */   {
/*     */     ItemStack stack;
/*     */     
/*     */     public CraftEvent(int job, int minLvl)
/*     */     {
/*  64 */       super(minLvl);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/*  71 */       if ((event instanceof PlayerEvent.ItemCraftedEvent)) {
/*  72 */         JobsXPManager jobsXPManager = (JobsXPManager)ModJobs.allJobsXpManager.get(((PlayerEvent.ItemCraftedEvent)event).player.getUniqueID().toString());
/*  73 */         if (jobsXPManager == null) return null;
/*  74 */         if (jobsXPManager.getXP(this.job) >= ((Job)ModJobs.jobs.get(Integer.valueOf(this.job))).getXPForLevel(this.minLvl)) {
/*  75 */           return ((PlayerEvent.ItemCraftedEvent)event).player;
/*     */         }
/*     */       }
/*  78 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class SmeltingEvent
/*     */     extends LvlItem
/*     */   {
/*     */     ItemStack stack;
/*     */     
/*     */     public SmeltingEvent(int job, int minLvl, ItemStack stack)
/*     */     {
/*  90 */       super(minLvl);
/*  91 */       this.stack = stack;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/*  98 */       if (((event instanceof PlayerEvent.ItemSmeltedEvent)) && 
/*  99 */         (((PlayerEvent.ItemSmeltedEvent)event).smelting.isItemEqual(this.stack))) {
/* 100 */         return ((PlayerEvent.ItemSmeltedEvent)event).player;
/*     */       }
/*     */       
/* 103 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AnvilEvent extends LvlItem
/*     */   {
/*     */     net.minecraft.item.Item item;
/*     */     
/*     */     public AnvilEvent(int job, int minLvl, net.minecraft.item.Item item)
/*     */     {
/* 113 */       super(minLvl);
/* 114 */       this.item = item;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 121 */       if (((event instanceof AnvilRepairEvent)) && (
/* 122 */         (((AnvilRepairEvent)event).left.getItem().equals(this.item)) || (((AnvilRepairEvent)event).right.getItem().equals(this.item)))) {
/* 123 */         return ((AnvilRepairEvent)event).entityPlayer;
/*     */       }
/*     */       
/* 126 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class KillEvent extends LvlItem
/*     */   {
/*     */     EntityLivingBase entity;
/*     */     
/*     */     public KillEvent(int job, int minLvl, EntityLivingBase entity)
/*     */     {
/* 136 */       super(minLvl);
/* 137 */       this.entity = entity;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 144 */       if (((event instanceof LivingDeathEvent)) && 
/* 145 */         ((((LivingDeathEvent)event).source.getSourceOfDamage() instanceof EntityPlayer))) {
/* 146 */         EntityPlayer player = (EntityPlayer)((LivingDeathEvent)event).source.getSourceOfDamage();
/* 147 */         if (this.entity.getEntityId() == ((LivingDeathEvent)event).entityLiving.getEntityId()) {
/* 148 */           return player;
/*     */         }
/*     */       }
/*     */       
/* 152 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\LvlItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */