/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.Event;
/*     */ import cpw.mods.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.player.AnvilRepairEvent;
/*     */ 
/*     */ public abstract class XPItem
/*     */ {
/*     */   int job;
/*     */   int[] xpGained;
/*     */   int[] xpLevels;
/*     */   
/*     */   public XPItem(int job, int[] xpGained, int[] xpLevels)
/*     */   {
/*  18 */     this.job = job;
/*  19 */     this.xpGained = xpGained;
/*  20 */     this.xpLevels = xpLevels;
/*     */   }
/*     */   
/*     */   public XPItem(int job, int[] xpGained) {
/*  24 */     this(job, xpGained, new int[] { 5, 10, 15, 20 });
/*     */   }
/*     */   
/*     */   public void onEvent(Event event) {
/*  28 */     EntityPlayer player = isEventValid(event);
/*  29 */     boolean flag = (player != null) && (!event.isCanceled());
/*  30 */     if (flag) {
/*  31 */       JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString());
/*  32 */       if (jobs == null) return;
/*  33 */       int ammount = getAmmountFromLevel(((Job)ModJobs.jobs.get(Integer.valueOf(this.job))).getLevel(jobs.getXP(this.job)));
/*  34 */       jobs.addXP(this.job, ammount, player);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getAmmountFromLevel(int level) {
/*  39 */     int index = 0;
/*  40 */     for (int i = 0; i < this.xpLevels.length; i++) {
/*  41 */       if ((level <= this.xpLevels[i]) && (this.xpLevels[i] > level))
/*  42 */         index = i;
/*     */     }
/*  44 */     return this.xpGained[index];
/*     */   }
/*     */   
/*     */   public abstract EntityPlayer isEventValid(Event paramEvent);
/*     */   
/*     */   public static class BreakEvent extends XPItem
/*     */   {
/*     */     public BreakEvent(int job, int[] xpGained) {
/*  52 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public BreakEvent(int job, int[] xpGained, int[] xpLevels) {
/*  56 */       super(xpGained, xpLevels);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/*  61 */       if (!(event instanceof net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent)) {
/*  62 */         return null;
/*     */       }
/*  64 */       net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent breakEvent = (net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent)event;
/*  65 */       return breakEvent.harvester;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class FishEvent
/*     */     extends XPItem
/*     */   {
/*     */     public FishEvent(int job, int[] xpGained)
/*     */     {
/*  74 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public FishEvent(int job, int[] xpGained, int[] xpLevels) {
/*  78 */       super(xpGained, xpLevels);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/*  83 */       return null;
/*     */     }
/*     */     
/*     */     public void onEvent(net.minecraft.item.ItemStack itemStack, EntityPlayer player) {
/*  87 */       boolean flag = player != null;
/*  88 */       if (flag) {
/*  89 */         JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString());
/*  90 */         if (jobs == null) return;
/*  91 */         int ammount = 0;
/*  92 */         for (int i = itemStack.stackSize; i >= 1; i--) {
/*  93 */           ammount += getAmmountFromLevel(((Job)ModJobs.jobs.get(Integer.valueOf(this.job))).getLevel(jobs.getXP(this.job)));
/*     */         }
/*  95 */         jobs.addXP(this.job, ammount, player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class CraftEvent
/*     */     extends XPItem
/*     */   {
/*     */     public CraftEvent(int job, int[] xpGained)
/*     */     {
/* 106 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public CraftEvent(int job, int[] xpGained, int[] levelXP) {
/* 110 */       super(xpGained, levelXP);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 115 */       if ((event instanceof cpw.mods.fml.common.gameevent.PlayerEvent.ItemCraftedEvent)) {
/* 116 */         return ((cpw.mods.fml.common.gameevent.PlayerEvent.ItemCraftedEvent)event).player;
/*     */       }
/* 118 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SmeltingEvent
/*     */     extends XPItem
/*     */   {
/*     */     public SmeltingEvent(int job, int[] xpGained)
/*     */     {
/* 127 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public SmeltingEvent(int job, int[] xpGained, int[] levelXP) {
/* 131 */       super(xpGained, levelXP);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 136 */       if ((event instanceof PlayerEvent.ItemSmeltedEvent)) {
/* 137 */         for (int i = ((PlayerEvent.ItemSmeltedEvent)event).smelting.stackSize; i >= 0; i--) {
/* 138 */           JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(((PlayerEvent.ItemSmeltedEvent)event).player.getUniqueID().toString());
/* 139 */           if (jobs == null) return null;
/* 140 */           int ammount = getAmmountFromLevel(((Job)ModJobs.jobs.get(Integer.valueOf(this.job))).getLevel(jobs.getXP(this.job)));
/* 141 */           jobs.addXP(this.job, ammount, ((PlayerEvent.ItemSmeltedEvent)event).player);
/*     */         }
/* 143 */         return null;
/*     */       }
/* 145 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AnvilEvent
/*     */     extends XPItem
/*     */   {
/*     */     public AnvilEvent(int job, int[] xpGained)
/*     */     {
/* 154 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public AnvilEvent(int job, int[] xpGained, int[] levelXP) {
/* 158 */       super(xpGained, levelXP);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 163 */       if (((event instanceof AnvilRepairEvent)) && 
/* 164 */         (((AnvilRepairEvent)event).left != null) && (((AnvilRepairEvent)event).right != null))
/*     */       {
/* 166 */         return ((AnvilRepairEvent)event).entityPlayer;
/*     */       }
/*     */       
/* 169 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class KillEvent
/*     */     extends XPItem
/*     */   {
/*     */     public KillEvent(int job, int[] xpGained)
/*     */     {
/* 178 */       super(xpGained);
/*     */     }
/*     */     
/*     */     public KillEvent(int job, int[] xpGained, int[] levelXP) {
/* 182 */       super(xpGained, levelXP);
/*     */     }
/*     */     
/*     */     public EntityPlayer isEventValid(Event event)
/*     */     {
/* 187 */       if (((event instanceof LivingDeathEvent)) && 
/* 188 */         ((((LivingDeathEvent)event).source.getSourceOfDamage() instanceof EntityPlayer))) {
/* 189 */         EntityPlayer player = (EntityPlayer)((LivingDeathEvent)event).source.getSourceOfDamage();
/* 190 */         if ((((LivingDeathEvent)event).source != null) && (((LivingDeathEvent)event).source.getSourceOfDamage() != null)) {
/* 191 */           return player;
/*     */         }
/*     */       }
/*     */       
/* 195 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\XPItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */