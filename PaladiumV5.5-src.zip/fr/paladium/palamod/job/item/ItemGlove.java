/*    */ package fr.paladium.palamod.job.item;
/*    */ 
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import fr.paladium.palamod.world.block.flower.BaseBlockFlower;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentHelper;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemGlove extends BaseItem
/*    */ {
/*    */   public ItemGlove(String unlocalizedName)
/*    */   {
/* 19 */     super(unlocalizedName);
/*    */     
/* 21 */     setTextureName("palamod:jobs/" + this.unlocalizedName);
/*    */     
/* 23 */     setMaxStackSize(1);
/* 24 */     setMaxDamage(238);
/*    */   }
/*    */   
/*    */   public boolean onBlockStartBreak(ItemStack itemstack, int x, int y, int z, EntityPlayer player)
/*    */   {
/* 29 */     if (player.worldObj.isRemote) {
/* 30 */       return false;
/*    */     }
/*    */     
/* 33 */     Block block = player.worldObj.getBlock(x, y, z);
/* 34 */     if ((block instanceof BaseBlockFlower)) {
/* 35 */       BaseBlockFlower target = (BaseBlockFlower)block;
/* 36 */       if (target.isShearable(itemstack, player.worldObj, x, y, z)) {
/* 37 */         ArrayList<ItemStack> drops = target.onSheared(itemstack, player.worldObj, x, y, z, EnchantmentHelper.getEnchantmentLevel(Enchantment.fortune.effectId, itemstack));
/* 38 */         Random rand = new Random();
/*    */         
/* 40 */         for (ItemStack stack : drops) {
/* 41 */           float f = 0.7F;
/* 42 */           double d = rand.nextFloat() * f + (1.0F - f) * 0.5D;
/* 43 */           double d1 = rand.nextFloat() * f + (1.0F - f) * 0.5D;
/* 44 */           double d2 = rand.nextFloat() * f + (1.0F - f) * 0.5D;
/* 45 */           EntityItem entityitem = new EntityItem(player.worldObj, x + d, y + d1, z + d2, stack);
/* 46 */           entityitem.delayBeforeCanPickup = 10;
/* 47 */           player.worldObj.spawnEntityInWorld(entityitem);
/*    */         }
/*    */         
/* 50 */         itemstack.damageItem(1, player);
/* 51 */         player.addStat(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(block)], 1);
/*    */       }
/*    */     }
/* 54 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\ItemGlove.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */