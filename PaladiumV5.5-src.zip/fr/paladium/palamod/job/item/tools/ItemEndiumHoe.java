/*     */ package fr.paladium.palamod.job.item.tools;
/*     */ 
/*     */ import cpw.mods.fml.common.FMLCommonHandler;
/*     */ import fr.paladium.palamod.common.ToolMaterialPaladium;
/*     */ import fr.paladium.palamod.job.Job;
/*     */ import fr.paladium.palamod.job.JobsXPManager;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.util.BlockLocation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.Block.SoundType;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ItemEndiumHoe extends ItemHoeMod
/*     */ {
/*     */   public ArrayList<String> addInformation;
/*     */   
/*     */   public ItemEndiumHoe(ArrayList<String> information)
/*     */   {
/*  31 */     super(ToolMaterialPaladium.toolTypeEndium, "endiumHoe");
/*  32 */     this.addInformation = information;
/*     */   }
/*     */   
/*     */   public boolean onItemUse(ItemStack p_77648_1_, EntityPlayer p_77648_2_, World p_77648_3_, int p_77648_4_, int p_77648_5_, int p_77648_6_, int p_77648_7_, float p_77648_8_, float p_77648_9_, float p_77648_10_)
/*     */   {
/*  37 */     if (!p_77648_3_.isRemote) {
/*  38 */       Job famer = (Job)ModJobs.jobs.get(Integer.valueOf(2));
/*  39 */       if (famer.getLevel(((JobsXPManager)ModJobs.allJobsXpManager.get(p_77648_2_.getUniqueID().toString())).getXP(2)) < 20) {
/*  40 */         p_77648_2_.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Il faut etre niveau 20 pour utiliser cet item.", new Object[0]));
/*  41 */         return false;
/*     */       }
/*  43 */       List<BlockLocation> blockPosList = getBlocks(new BlockLocation(p_77648_4_, p_77648_5_, p_77648_6_), 1);
/*  44 */       for (BlockLocation blockPos : blockPosList) {
/*  45 */         if ((p_77648_3_.isAirBlock(blockPos.getX(), blockPos.getY() + 1, blockPos.getZ())) && 
/*  46 */           (p_77648_3_.getBlock(blockPos.getX(), blockPos.getY(), blockPos.getZ()) != null) && ((p_77648_3_.getBlock(blockPos.getX(), blockPos.getY(), blockPos.getZ()).equals(Blocks.grass)) || (p_77648_3_.getBlock(blockPos.getX(), blockPos.getY(), blockPos.getZ()).equals(Blocks.dirt)))) {
/*  47 */           p_77648_3_.setBlock(blockPos.getX(), blockPos.getY(), blockPos.getZ(), Blocks.farmland);
/*  48 */           if (!p_77648_3_.isRemote) {
/*  49 */             int random = (int)(Math.random() * 1000.0D);
/*  50 */             if (random == 1) {
/*  51 */               p_77648_3_.spawnEntityInWorld(new EntityItem(p_77648_3_, p_77648_4_, p_77648_5_, p_77648_6_, new ItemStack(fr.paladium.palamod.job.JobRegister.PARTICLE_PALADIUM, 1)));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  57 */       p_77648_3_.playSoundEffect(p_77648_4_ + 0.5F, p_77648_5_ + 0.5F, p_77648_6_ + 0.5F, Blocks.farmland.stepSound.getStepResourcePath(), (Blocks.farmland.stepSound.getVolume() + 1.0F) / 2.0F, Blocks.farmland.stepSound.getPitch() * 0.8F);
/*     */     }
/*  59 */     return super.onItemUse(p_77648_1_, p_77648_2_, p_77648_3_, p_77648_4_, p_77648_5_, p_77648_6_, p_77648_7_, p_77648_8_, p_77648_9_, p_77648_10_);
/*     */   }
/*     */   
/*     */   public List<BlockLocation> getBlocks(BlockLocation start, int radius)
/*     */   {
/*  64 */     if (radius < 0) {
/*  65 */       return new ArrayList(0);
/*     */     }
/*  67 */     int iterations = radius * 2 + 1;
/*  68 */     List<BlockLocation> blockPos = new ArrayList(iterations * iterations * iterations);
/*  69 */     for (int x = -radius; x <= radius; x++) {
/*  70 */       for (int y = -radius; y <= radius; y++) {
/*  71 */         for (int z = -radius; z <= radius; z++) {
/*  72 */           blockPos.add(start.add(x, y, z));
/*     */         }
/*     */       }
/*     */     }
/*  76 */     return blockPos;
/*     */   }
/*     */   
/*     */   public void onUpdate(ItemStack stack, World worldIn, Entity entityIn, int itemSlot, boolean isSelected)
/*     */   {
/*  81 */     if (worldIn.isRemote) {
/*  82 */       return;
/*     */     }
/*  84 */     if ((entityIn instanceof EntityPlayer)) {
/*  85 */       EntityPlayer entityPlayer = (EntityPlayer)entityIn;
/*  86 */       if ((stack.getTagCompound() == null) || ((stack.getTagCompound() != null) && (!stack.getTagCompound().hasKey("firstPlayer")))) { NBTTagCompound nbtTagCompound;
/*     */         NBTTagCompound nbtTagCompound;
/*  88 */         if (stack.getTagCompound() == null) {
/*  89 */           nbtTagCompound = new NBTTagCompound();
/*     */         } else {
/*  91 */           nbtTagCompound = stack.getTagCompound();
/*     */         }
/*     */         
/*  94 */         nbtTagCompound.setString("firstPlayer", entityPlayer.getUniqueID().toString());
/*  95 */         stack.setTagCompound(nbtTagCompound);
/*     */         
/*  97 */         FMLCommonHandler.instance().getMinecraftServerInstance().addChatMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium] " + EnumChatFormatting.GOLD + entityPlayer.getDisplayName() + " A generer un item en Endium (" + stack.getUnlocalizedName() + ").", new Object[0]));
/*     */       }
/*     */       
/* 100 */       if ((stack.getTagCompound() == null) || ((stack.getTagCompound() != null) && (!stack.getTagCompound().hasKey("timestamp")))) { NBTTagCompound nbtTagCompound;
/*     */         NBTTagCompound nbtTagCompound;
/* 102 */         if (stack.getTagCompound() == null) {
/* 103 */           nbtTagCompound = new NBTTagCompound();
/*     */         } else {
/* 105 */           nbtTagCompound = stack.getTagCompound();
/*     */         }
/*     */         
/* 108 */         nbtTagCompound.setString("timestamp", System.currentTimeMillis() + "");
/* 109 */         stack.setTagCompound(nbtTagCompound);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*     */   {
/* 116 */     super.addInformation(stack, player, list, b);
/* 117 */     list.add(EnumChatFormatting.GRAY + net.minecraft.util.StatCollector.translateToLocal("tooltip.show"));
/*     */     
/* 119 */     if (net.minecraft.client.gui.GuiScreen.isShiftKeyDown()) {
/* 120 */       for (String value : this.addInformation) {
/* 121 */         list.add(value);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\tools\ItemEndiumHoe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */