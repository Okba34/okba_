/*    */ package fr.paladium.palamod.job.item.tools;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.item.Item.ToolMaterial;
/*    */ import net.minecraft.item.ItemHoe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ItemHoeMod
/*    */   extends ItemHoe
/*    */ {
/*    */   public ItemHoeMod(Item.ToolMaterial toolMaterial, String name)
/*    */   {
/* 14 */     super(toolMaterial);
/* 15 */     setUnlocalizedName(name);
/* 16 */     setTextureName("palamod:" + name);
/* 17 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean getIsRepairable(ItemStack input, ItemStack repair) {
/* 21 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\tools\ItemHoeMod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */