/*    */ package fr.paladium.palamod.job.item;
/*    */ 
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ 
/*    */ public class BaseJobParticle extends BaseItem
/*    */ {
/*    */   public BaseJobParticle(String unlocalizedName)
/*    */   {
/*  9 */     super(unlocalizedName);
/*    */     
/* 11 */     setTextureName("palamod:jobs/" + this.unlocalizedName);
/*    */     
/* 13 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\BaseJobParticle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */