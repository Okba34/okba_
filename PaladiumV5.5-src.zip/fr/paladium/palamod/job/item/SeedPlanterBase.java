/*    */ package fr.paladium.palamod.job.item;
/*    */ 
/*    */ import fr.paladium.palamod.job.Job;
/*    */ import fr.paladium.palamod.job.JobsXPManager;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import fr.paladium.palamod.world.item.seed.BaseItemSeed;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemSeeds;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class SeedPlanterBase extends BaseItem
/*    */ {
/* 25 */   public int r = 0;
/* 26 */   public int lvlmin = 0;
/*    */   public ArrayList<String> addInformation;
/*    */   
/*    */   public SeedPlanterBase(String unlocalizedName, int radius, int lvlmin, ArrayList<String> information) {
/* 30 */     super(unlocalizedName);
/* 31 */     this.r = radius;
/* 32 */     this.lvlmin = lvlmin;
/* 33 */     this.addInformation = information;
/*    */   }
/*    */   
/*    */ 
/*    */   public ItemStack onItemRightClick(ItemStack p_77659_1_, World p_77659_2_, EntityPlayer p_77659_3_)
/*    */   {
/* 39 */     if (!p_77659_2_.isRemote) {
/* 40 */       Job famer = (Job)ModJobs.jobs.get(Integer.valueOf(2));
/* 41 */       if (famer.getLevel(((JobsXPManager)ModJobs.allJobsXpManager.get(p_77659_3_.getUniqueID().toString())).getXP(2)) < this.lvlmin) {
/* 42 */         p_77659_3_.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Il faut etre niveau " + this.lvlmin + " en farmer pour utiliser cet item.", new Object[0]));
/* 43 */         return super.onItemRightClick(p_77659_1_, p_77659_2_, p_77659_3_);
/*    */       }
/* 45 */       ItemStack itemStack = p_77659_3_.inventory.mainInventory[(p_77659_3_.inventory.currentItem + 1)];
/* 46 */       Block crops = net.minecraft.init.Blocks.wheat;
/* 47 */       if (itemStack.getItem() != null) {
/* 48 */         if ((itemStack.getItem() instanceof ItemSeeds)) {
/* 49 */           ItemSeeds itemSeeds = (ItemSeeds)itemStack.getItem();
/* 50 */           crops = itemSeeds.getPlant(null, 0, 0, 0);
/* 51 */         } else if ((itemStack.getItem() instanceof BaseItemSeed)) {
/* 52 */           BaseItemSeed itemSeeds = (BaseItemSeed)itemStack.getItem();
/* 53 */           if (famer.getLevel(((JobsXPManager)ModJobs.allJobsXpManager.get(p_77659_3_.getUniqueID().toString())).getXP(2)) >= itemSeeds.getLvlmin()) {
/* 54 */             crops = itemSeeds.getPlant(null, 0, 0, 0);
/*    */           } else {
/* 56 */             return super.onItemRightClick(p_77659_1_, p_77659_2_, p_77659_3_);
/*    */           }
/*    */         } else {
/* 59 */           return super.onItemRightClick(p_77659_1_, p_77659_2_, p_77659_3_);
/*    */         }
/* 61 */       } else { return super.onItemRightClick(p_77659_1_, p_77659_2_, p_77659_3_);
/*    */       }
/*    */       
/* 64 */       ItemStack itemStack1 = p_77659_3_.inventory.mainInventory[(p_77659_3_.inventory.currentItem + 1)];
/* 65 */       for (int x = 0; x < this.r; x++) {
/* 66 */         for (int z = 0; z < this.r; z++) {
/* 67 */           int posX = (int)p_77659_3_.posX + x;
/* 68 */           int posY = (int)p_77659_3_.posY;
/* 69 */           int posZ = (int)p_77659_3_.posZ + z;
/*    */           
/* 71 */           if ((p_77659_2_.isAirBlock(posX, posY, posZ)) && (p_77659_2_.getBlock(posX, posY - 1, posZ) != null) && ((p_77659_2_.getBlock(posX, posY - 1, posZ) instanceof net.minecraft.block.BlockFarmland)) && (itemStack1.stackSize > 0)) {
/* 72 */             p_77659_2_.setBlock(posX, posY, posZ, crops);
/* 73 */             itemStack1.stackSize -= 1;
/*    */           }
/*    */         }
/*    */       }
/* 77 */       p_77659_3_.inventory.setInventorySlotContents(p_77659_3_.inventory.currentItem + 1, itemStack1);
/*    */     }
/* 79 */     return super.onItemRightClick(p_77659_1_, p_77659_2_, p_77659_3_);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 84 */     super.addInformation(stack, player, list, b);
/* 85 */     list.add(EnumChatFormatting.GRAY + StatCollector.translateToLocal("tooltip.show"));
/*    */     
/* 87 */     if (GuiScreen.isShiftKeyDown()) {
/* 88 */       for (String value : this.addInformation) {
/* 89 */         list.add(value);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\SeedPlanterBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */