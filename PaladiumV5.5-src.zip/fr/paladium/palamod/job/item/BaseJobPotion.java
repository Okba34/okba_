/*    */ package fr.paladium.palamod.job.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class BaseJobPotion
/*    */   extends BaseItem
/*    */ {
/*    */   private List<String> addInformation;
/*    */   private int job_id;
/*    */   private int job_xp;
/*    */   
/*    */   public BaseJobPotion(String unlocalizedName, List<String> addInformation, int job_id, int job_xp)
/*    */   {
/* 21 */     super(unlocalizedName);
/*    */     
/* 23 */     this.addInformation = addInformation;
/*    */     
/* 25 */     this.job_id = job_id;
/* 26 */     this.job_xp = job_xp;
/*    */     
/* 28 */     setTextureName("palamod:jobs/" + this.unlocalizedName);
/*    */     
/* 30 */     setMaxStackSize(1);
/* 31 */     setMaxDamage(16);
/*    */     
/* 33 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 38 */     super.addInformation(stack, player, list, b);
/* 39 */     list.add(EnumChatFormatting.GRAY + StatCollector.translateToLocal("tooltip.show"));
/*    */     
/* 41 */     if (GuiScreen.isShiftKeyDown()) {
/* 42 */       for (String value : this.addInformation) {
/* 43 */         list.add(value);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\BaseJobPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */