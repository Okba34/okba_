/*    */ package fr.paladium.palamod.job.item;
/*    */ 
/*    */ import net.minecraft.item.ItemFood;
/*    */ 
/*    */ public class BaseJobFood extends ItemFood
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   
/*    */   public BaseJobFood(String unlocalizedName, int amount, float saturation, boolean isWolfFood)
/*    */   {
/* 11 */     super(amount, saturation, isWolfFood);
/*    */     
/* 13 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 15 */     setUnlocalizedName(this.unlocalizedName);
/* 16 */     setTextureName("palamod:jobs/" + this.unlocalizedName);
/*    */     
/* 18 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\item\BaseJobFood.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */