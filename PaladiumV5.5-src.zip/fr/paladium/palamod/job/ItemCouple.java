/*    */ package fr.paladium.palamod.job;
/*    */ 
/*    */ import net.minecraft.item.Item;
/*    */ 
/*    */ public class ItemCouple
/*    */ {
/*    */   private Item item;
/*    */   private int meta;
/*    */   
/*    */   public ItemCouple(net.minecraft.block.Block block)
/*    */   {
/* 12 */     this(block, 0);
/*    */   }
/*    */   
/*    */   public ItemCouple(net.minecraft.block.Block block, int meta) {
/* 16 */     this.item = Item.getItemFromBlock(block);
/* 17 */     this.meta = meta;
/*    */   }
/*    */   
/*    */   public ItemCouple(Item item) {
/* 21 */     this(item, 0);
/*    */   }
/*    */   
/*    */   public ItemCouple(Item item, int meta) {
/* 25 */     this.item = item;
/* 26 */     this.meta = meta;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 31 */     return this.item.hashCode() + this.meta;
/*    */   }
/*    */   
/*    */   public String getAll() {
/* 35 */     return "item:" + this.item.getUnlocalizedName() + "+meta:" + this.meta;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\ItemCouple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */