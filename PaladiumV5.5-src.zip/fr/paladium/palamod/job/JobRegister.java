/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.job.block.BlockCobbleBreaker;
/*     */ import fr.paladium.palamod.job.block.BlockForge;
/*     */ import fr.paladium.palamod.job.item.BaseJobFood;
/*     */ import fr.paladium.palamod.job.item.BaseJobParticle;
/*     */ import fr.paladium.palamod.job.item.BaseJobPotion;
/*     */ import fr.paladium.palamod.job.item.ItemGlove;
/*     */ import fr.paladium.palamod.job.item.SeedPlanterBase;
/*     */ import fr.paladium.palamod.job.item.tools.ItemEndiumHoe;
/*     */ import fr.paladium.palamod.job.logic.ForgeLogic;
/*     */ import fr.paladium.palamod.job.logic.TileCobbleBreaker;
/*     */ import fr.paladium.palamod.library.Register;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.StatCollector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobRegister
/*     */   extends Register
/*     */ {
/*     */   public static BaseJobPotion POTION_FOGGY;
/*     */   public static BaseJobPotion POTION_FOGGY_SPLASH;
/*     */   public static BaseJobPotion POTION_SINNER;
/*     */   public static BaseJobPotion POTION_SINNER_SPLASH;
/*     */   public static BaseJobPotion POTION_OCEAN;
/*     */   public static BaseJobPotion POTION_OCEAN_SPLASH;
/*     */   public static BaseJobPotion POTION_RAPPER;
/*     */   public static BaseJobPotion POTION_RAPPER_SPLASH;
/*     */   public static BaseJobPotion POTION_LUMBERJACK;
/*     */   public static BaseJobPotion POTION_LUMBERJACK_SPLASH;
/*     */   public static BaseJobPotion POTION_TREECUTTER;
/*     */   public static BaseJobPotion POTION_TREECUTTER_SPLASH;
/*     */   public static ItemGlove GLOVE;
/*     */   public static BaseJobPotion POTION_PLANTING;
/*     */   public static BaseJobPotion POTION_PLANTING_SPLASH;
/*     */   public static BaseJobPotion POTION_FARMER;
/*     */   public static BaseJobPotion POTION_FARMER_SPLASH;
/*     */   public static BaseJobPotion POTION_CRAZYFARMER;
/*     */   public static BaseJobPotion POTION_CRAZYFARMER_SPLASH;
/*     */   public static BaseJobFood FOOD_HAM;
/*     */   public static BaseJobFood FOOD_MARINATED_PORKCHOP;
/*     */   public static BaseJobFood FOOD_MARINATED_CHICKEN;
/*     */   public static BaseJobFood FOOD_MARINATED_STEAK;
/*     */   public static BaseJobFood FOOD_MARINATED_ROTTENFLESH;
/*     */   public static BaseJobFood FOOD_MARINATED_MUTTON;
/*     */   public static BaseJobPotion POTION_BLOOD;
/*     */   public static BaseJobPotion POTION_BLOOD_SPLASH;
/*     */   public static BaseJobPotion POTION_HUNTER;
/*     */   public static BaseJobPotion POTION_HUNTER_SPLASH;
/*     */   public static BaseJobPotion POTION_BUTCHERY;
/*     */   public static BaseJobPotion POTION_BUTCHERY_SPLASH;
/*     */   public static BaseJobPotion POTION_LIMESTONE;
/*     */   public static BaseJobPotion POTION_LIMESTONE_SPLASH;
/*     */   public static BaseJobPotion POTION_MINER;
/*     */   public static BaseJobPotion POTION_MINER_SPLASH;
/*     */   public static BaseJobPotion POTION_TUNNELING;
/*     */   public static BaseJobPotion POTION_TUNNELING_SPLASH;
/*     */   public static BaseJobParticle PARTICLE_IRON;
/*     */   public static BaseJobParticle PARTICLE_GOLD;
/*     */   public static BaseJobParticle PARTICLE_DIAMOND;
/*     */   public static BaseJobParticle PARTICLE_AMETHYST;
/*     */   public static BaseJobParticle PARTICLE_TITANE;
/*     */   public static BaseJobParticle PARTICLE_PALADIUM;
/*     */   public static BlockForge FORGE;
/*     */   public static BlockForge LIT_FORGE;
/*     */   public static BlockCobbleBreaker COBBLEBREAKER;
/*     */   public static BaseJobPotion POTION_MAGIC;
/*     */   public static BaseJobPotion POTION_MAGIC_SPLASH;
/*     */   public static BaseJobPotion POTION_ENCHANTING;
/*     */   public static BaseJobPotion POTION_ENCHANTING_SPLASH;
/*     */   public static BaseJobPotion POTION_MERLIN;
/*     */   public static BaseJobPotion POTION_MERLIN_SPLASH;
/*     */   public static SeedPlanterBase SEEDPLANTER_LVL1;
/*     */   public static SeedPlanterBase SEEDPLANTER_LVL2;
/*     */   public static SeedPlanterBase SEEDPLANTER_LVL3;
/*     */   public static SeedPlanterBase SEEDPLANTER_LVL4;
/*     */   public static ItemEndiumHoe ENDIUM_HOE;
/*     */   public static BaseJobParticle NUGGET_ENDIUM;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/*  96 */     register();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init(FMLInitializationEvent event)
/*     */   {
/* 103 */     registerRecipes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postInit(FMLPostInitializationEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void register()
/*     */   {
/* 116 */     String jobXpPrefix = EnumChatFormatting.GREEN + StatCollector.translateToLocal("tooltip.jobXpPrefix");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     ArrayList<String> tooltip = new ArrayList();
/* 125 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 126 */     registerItem(POTION_FOGGY = new BaseJobPotion("foggy_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 129 */     ArrayList<String> tooltip = new ArrayList();
/* 130 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 131 */     registerItem(POTION_FOGGY_SPLASH = new BaseJobPotion("foggy_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 134 */     ArrayList<String> tooltip = new ArrayList();
/* 135 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 136 */     registerItem(POTION_SINNER = new BaseJobPotion("sinner_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 139 */     ArrayList<String> tooltip = new ArrayList();
/* 140 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 141 */     registerItem(POTION_SINNER_SPLASH = new BaseJobPotion("sinner_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 144 */     ArrayList<String> tooltip = new ArrayList();
/* 145 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 146 */     registerItem(POTION_OCEAN = new BaseJobPotion("ocean_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 149 */     ArrayList<String> tooltip = new ArrayList();
/* 150 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 151 */     registerItem(POTION_OCEAN_SPLASH = new BaseJobPotion("ocean_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */     ArrayList<String> tooltip = new ArrayList();
/* 161 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 162 */     registerItem(POTION_RAPPER = new BaseJobPotion("rapper_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 165 */     ArrayList<String> tooltip = new ArrayList();
/* 166 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 167 */     registerItem(POTION_RAPPER_SPLASH = new BaseJobPotion("rapper_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 170 */     ArrayList<String> tooltip = new ArrayList();
/* 171 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 172 */     registerItem(POTION_RAPPER = new BaseJobPotion("lumberjack_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 175 */     ArrayList<String> tooltip = new ArrayList();
/* 176 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 177 */     registerItem(POTION_RAPPER_SPLASH = new BaseJobPotion("lumberjack_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 180 */     ArrayList<String> tooltip = new ArrayList();
/* 181 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 182 */     registerItem(POTION_RAPPER = new BaseJobPotion("treecutter_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 185 */     ArrayList<String> tooltip = new ArrayList();
/* 186 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 187 */     registerItem(POTION_RAPPER_SPLASH = new BaseJobPotion("treecutter_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/*     */ 
/* 191 */     registerItem(GLOVE = new ItemGlove("glove"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 199 */     ArrayList<String> tooltip = new ArrayList();
/* 200 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 201 */     registerItem(POTION_PLANTING = new BaseJobPotion("planting_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 204 */     ArrayList<String> tooltip = new ArrayList();
/* 205 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 206 */     registerItem(POTION_PLANTING_SPLASH = new BaseJobPotion("planting_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 209 */     ArrayList<String> tooltip = new ArrayList();
/* 210 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 211 */     registerItem(POTION_FARMER = new BaseJobPotion("farmer_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 214 */     ArrayList<String> tooltip = new ArrayList();
/* 215 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 216 */     registerItem(POTION_FARMER_SPLASH = new BaseJobPotion("farmer_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 219 */     ArrayList<String> tooltip = new ArrayList();
/* 220 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 221 */     registerItem(POTION_CRAZYFARMER = new BaseJobPotion("crazyfarmer_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 224 */     ArrayList<String> tooltip = new ArrayList();
/* 225 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 226 */     registerItem(POTION_CRAZYFARMER = new BaseJobPotion("crazyfarmer_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 229 */     ArrayList<String> tooltip = new ArrayList();
/* 230 */     tooltip.add(jobXpPrefix + " Lvl 5 Farmer Min");
/* 231 */     registerItem(SEEDPLANTER_LVL1 = new SeedPlanterBase("seedPlanterLvl1", 2, 5, tooltip));
/*     */     
/*     */ 
/* 234 */     ArrayList<String> tooltip = new ArrayList();
/* 235 */     tooltip.add(jobXpPrefix + " Lvl 10 Farmer Min");
/* 236 */     registerItem(SEEDPLANTER_LVL2 = new SeedPlanterBase("seedPlanterLvl2", 3, 10, tooltip));
/*     */     
/*     */ 
/* 239 */     ArrayList<String> tooltip = new ArrayList();
/* 240 */     tooltip.add(jobXpPrefix + " Lvl 15 Farmer Min");
/* 241 */     registerItem(SEEDPLANTER_LVL3 = new SeedPlanterBase("seedPlanterLvl3", 4, 15, tooltip));
/*     */     
/*     */ 
/* 244 */     ArrayList<String> tooltip = new ArrayList();
/* 245 */     tooltip.add(jobXpPrefix + " Lvl 20 Farmer Min");
/* 246 */     registerItem(SEEDPLANTER_LVL4 = new SeedPlanterBase("seedPlanterLvl4", 5, 20, tooltip));
/*     */     
/*     */ 
/* 249 */     ArrayList<String> tooltip = new ArrayList();
/* 250 */     tooltip.add(jobXpPrefix + " Lvl 20 Farmer Min");
/* 251 */     registerItem(ENDIUM_HOE = new ItemEndiumHoe(tooltip));
/*     */     
/*     */ 
/* 254 */     registerItem(NUGGET_ENDIUM = new BaseJobParticle("nuggetEndium"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     ArrayList<String> tooltip = new ArrayList();
/* 264 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 265 */     registerItem(POTION_BLOOD = new BaseJobPotion("blood_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 268 */     ArrayList<String> tooltip = new ArrayList();
/* 269 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 270 */     registerItem(POTION_BLOOD = new BaseJobPotion("blood_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 273 */     ArrayList<String> tooltip = new ArrayList();
/* 274 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 275 */     registerItem(POTION_HUNTER = new BaseJobPotion("hunter_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 278 */     ArrayList<String> tooltip = new ArrayList();
/* 279 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 280 */     registerItem(POTION_HUNTER_SPLASH = new BaseJobPotion("hunter_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 283 */     ArrayList<String> tooltip = new ArrayList();
/* 284 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 285 */     registerItem(POTION_BUTCHERY = new BaseJobPotion("butchery_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 288 */     ArrayList<String> tooltip = new ArrayList();
/* 289 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 290 */     registerItem(POTION_BUTCHERY = new BaseJobPotion("butchery_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/*     */ 
/* 294 */     registerItem(FOOD_HAM = new BaseJobFood("ham_food", 8, 8.0F, true));
/* 295 */     registerItem(FOOD_MARINATED_PORKCHOP = new BaseJobFood("marinated_porkchop_food", 8, 8.0F, false));
/* 296 */     registerItem(FOOD_MARINATED_CHICKEN = new BaseJobFood("marinated_chicken_food", 8, 8.0F, false));
/* 297 */     registerItem(FOOD_MARINATED_STEAK = new BaseJobFood("marinated_steak_food", 8, 8.0F, false));
/* 298 */     registerItem(FOOD_MARINATED_ROTTENFLESH = new BaseJobFood("marinated_rottenflesh_food", 8, 8.0F, false));
/* 299 */     registerItem(FOOD_MARINATED_MUTTON = new BaseJobFood("marinated_mutton_food", 8, 8.0F, false));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */     ArrayList<String> tooltip = new ArrayList();
/* 308 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 309 */     registerItem(POTION_LIMESTONE = new BaseJobPotion("limestone_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 312 */     ArrayList<String> tooltip = new ArrayList();
/* 313 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 314 */     registerItem(POTION_LIMESTONE_SPLASH = new BaseJobPotion("limestone_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 317 */     ArrayList<String> tooltip = new ArrayList();
/* 318 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 319 */     registerItem(POTION_MINER = new BaseJobPotion("miner_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 322 */     ArrayList<String> tooltip = new ArrayList();
/* 323 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 324 */     registerItem(POTION_MINER_SPLASH = new BaseJobPotion("miner_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 327 */     ArrayList<String> tooltip = new ArrayList();
/* 328 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 329 */     registerItem(POTION_TUNNELING = new BaseJobPotion("tunneling_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 332 */     ArrayList<String> tooltip = new ArrayList();
/* 333 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 334 */     registerItem(POTION_TUNNELING_SPLASH = new BaseJobPotion("tunneling_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/*     */ 
/* 338 */     registerItem(PARTICLE_IRON = new BaseJobParticle("iron_particle"));
/* 339 */     registerItem(PARTICLE_GOLD = new BaseJobParticle("gold_particle"));
/* 340 */     registerItem(PARTICLE_DIAMOND = new BaseJobParticle("diamond_particle"));
/* 341 */     registerItem(PARTICLE_AMETHYST = new BaseJobParticle("amethyst_particle"));
/* 342 */     registerItem(PARTICLE_TITANE = new BaseJobParticle("titane_particle"));
/* 343 */     registerItem(PARTICLE_PALADIUM = new BaseJobParticle("paladium_particle"));
/*     */     
/*     */ 
/* 346 */     registerBlock(FORGE = new BlockForge("forge", false));
/* 347 */     registerBlock(LIT_FORGE = new BlockForge("lit_forge", true));
/*     */     
/*     */ 
/* 350 */     registerBlock(COBBLEBREAKER = new BlockCobbleBreaker("cobbleBreaker"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 358 */     ArrayList<String> tooltip = new ArrayList();
/* 359 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 360 */     registerItem(POTION_MAGIC = new BaseJobPotion("magic_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 363 */     ArrayList<String> tooltip = new ArrayList();
/* 364 */     tooltip.add(jobXpPrefix + " 50 xp");
/* 365 */     registerItem(POTION_MAGIC_SPLASH = new BaseJobPotion("magic_splash_potion", tooltip, 0, 50));
/*     */     
/*     */ 
/* 368 */     ArrayList<String> tooltip = new ArrayList();
/* 369 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 370 */     registerItem(POTION_ENCHANTING = new BaseJobPotion("enchanting_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 373 */     ArrayList<String> tooltip = new ArrayList();
/* 374 */     tooltip.add(jobXpPrefix + " 100 xp");
/* 375 */     registerItem(POTION_ENCHANTING_SPLASH = new BaseJobPotion("enchanting_splash_potion", tooltip, 0, 100));
/*     */     
/*     */ 
/* 378 */     ArrayList<String> tooltip = new ArrayList();
/* 379 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 380 */     registerItem(POTION_MERLIN = new BaseJobPotion("merlin_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/* 383 */     ArrayList<String> tooltip = new ArrayList();
/* 384 */     tooltip.add(jobXpPrefix + " 250 xp");
/* 385 */     registerItem(POTION_MERLIN_SPLASH = new BaseJobPotion("merlin_splash_potion", tooltip, 0, 250));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 397 */     registerTileEntity(ForgeLogic.class, "forge");
/* 398 */     registerTileEntity(TileCobbleBreaker.class, "cobbleBreaker");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void registerRecipes()
/*     */   {
/* 405 */     GameRegistry.addRecipe(new ItemStack(GLOVE), new Object[] { "X", "Y", 
/*     */     
/*     */ 
/* 408 */       Character.valueOf('X'), new ItemStack(Items.leather), 
/* 409 */       Character.valueOf('Y'), new ItemStack(Items.string) });
/*     */     
/*     */ 
/* 412 */     GameRegistry.addRecipe(new ItemStack(MaterialRegister.PALADIUM_INGOT), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 416 */       Character.valueOf('X'), new ItemStack(PARTICLE_PALADIUM) });
/*     */     
/*     */ 
/* 419 */     GameRegistry.addRecipe(new ItemStack(MaterialRegister.TITANE_INGOT), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 423 */       Character.valueOf('X'), new ItemStack(PARTICLE_TITANE) });
/*     */     
/*     */ 
/* 426 */     GameRegistry.addRecipe(new ItemStack(MaterialRegister.AMETHYST_INGOT), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 430 */       Character.valueOf('X'), new ItemStack(PARTICLE_AMETHYST) });
/*     */     
/*     */ 
/* 433 */     GameRegistry.addRecipe(new ItemStack(MaterialRegister.ENDIUM_INGOT), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 437 */       Character.valueOf('X'), new ItemStack(NUGGET_ENDIUM) });
/*     */     
/*     */ 
/* 440 */     GameRegistry.addRecipe(new ItemStack(Items.diamond), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 444 */       Character.valueOf('X'), new ItemStack(PARTICLE_DIAMOND) });
/*     */     
/*     */ 
/* 447 */     GameRegistry.addRecipe(new ItemStack(Items.gold_ingot), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 451 */       Character.valueOf('X'), new ItemStack(PARTICLE_GOLD) });
/*     */     
/*     */ 
/* 454 */     GameRegistry.addRecipe(new ItemStack(Items.iron_ingot), new Object[] { "XXX", "XXX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 458 */       Character.valueOf('X'), new ItemStack(PARTICLE_IRON) });
/*     */     
/*     */ 
/* 461 */     GameRegistry.addRecipe(new ItemStack(ENDIUM_HOE), new Object[] { "XX", "Y", "Y", 
/*     */     
/*     */ 
/*     */ 
/* 465 */       Character.valueOf('X'), new ItemStack(MaterialRegister.ENDIUM_INGOT), 
/* 466 */       Character.valueOf('Y'), new ItemStack(Items.stick) });
/*     */     
/*     */ 
/* 469 */     GameRegistry.addRecipe(new ItemStack(SEEDPLANTER_LVL1), new Object[] { " XX", "XY ", "ZZZ", 
/*     */     
/*     */ 
/*     */ 
/* 473 */       Character.valueOf('X'), new ItemStack(Items.iron_ingot), 
/* 474 */       Character.valueOf('Y'), new ItemStack(Blocks.hopper), 
/* 475 */       Character.valueOf('Z'), new ItemStack(ModItems.compressedAmethyst) });
/*     */     
/*     */ 
/* 478 */     GameRegistry.addRecipe(new ItemStack(SEEDPLANTER_LVL2), new Object[] { " XX", "XY ", "ZZZ", 
/*     */     
/*     */ 
/*     */ 
/* 482 */       Character.valueOf('X'), new ItemStack(Items.iron_ingot), 
/* 483 */       Character.valueOf('Y'), new ItemStack(Blocks.hopper), 
/* 484 */       Character.valueOf('Z'), new ItemStack(ModItems.compressedTitane) });
/*     */     
/*     */ 
/* 487 */     GameRegistry.addRecipe(new ItemStack(SEEDPLANTER_LVL3), new Object[] { " XX", "XY ", "ZZZ", 
/*     */     
/*     */ 
/*     */ 
/* 491 */       Character.valueOf('X'), new ItemStack(Items.iron_ingot), 
/* 492 */       Character.valueOf('Y'), new ItemStack(Blocks.hopper), 
/* 493 */       Character.valueOf('Z'), new ItemStack(ModItems.compressedPaladium) });
/*     */     
/*     */ 
/* 496 */     GameRegistry.addRecipe(new ItemStack(SEEDPLANTER_LVL4), new Object[] { " XX", "XY ", "ZZZ", 
/*     */     
/*     */ 
/*     */ 
/* 500 */       Character.valueOf('X'), new ItemStack(Items.iron_ingot), 
/* 501 */       Character.valueOf('Y'), new ItemStack(Blocks.hopper), 
/* 502 */       Character.valueOf('Z'), new ItemStack(MaterialRegister.ENDIUM_INGOT) });
/*     */     
/*     */ 
/* 505 */     GameRegistry.addRecipe(new ItemStack(FORGE), new Object[] { "XXX", "YZY", "YYY", 
/*     */     
/*     */ 
/*     */ 
/* 509 */       Character.valueOf('X'), new ItemStack(Blocks.obsidian), 
/* 510 */       Character.valueOf('Y'), new ItemStack(ModItems.compressedTitane), 
/* 511 */       Character.valueOf('Z'), new ItemStack(Items.lava_bucket) });
/*     */     
/*     */ 
/* 514 */     GameRegistry.addRecipe(new ItemStack(COBBLEBREAKER), new Object[] { "XXX", "ABC", "YYY", 
/*     */     
/*     */ 
/*     */ 
/* 518 */       Character.valueOf('X'), new ItemStack(Blocks.hopper), 
/* 519 */       Character.valueOf('Y'), new ItemStack(Blocks.obsidian), 
/* 520 */       Character.valueOf('A'), new ItemStack(ModItems.amethystHammer), 
/* 521 */       Character.valueOf('B'), new ItemStack(ModItems.paladiumHammer), 
/* 522 */       Character.valueOf('C'), new ItemStack(ModItems.titaneHammer) });
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\JobRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */