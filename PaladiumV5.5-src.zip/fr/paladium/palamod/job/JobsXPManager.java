/*    */ package fr.paladium.palamod.job;
/*    */ 
/*    */ import fr.paladium.palamod.util.NotificationHelper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobsXPManager
/*    */ {
/*    */   private HashMap<Integer, Integer> jobXP;
/*    */   private EntityPlayer player;
/*    */   
/*    */   public JobsXPManager(EntityPlayer player)
/*    */   {
/* 19 */     this.jobXP = new HashMap();
/* 20 */     this.player = player;
/* 21 */     NBTTagCompound nbtPlayer = player.getEntityData().getTagList("Jobs", 10).getCompoundTagAt(0);
/*    */     
/* 23 */     if (nbtPlayer != null) {
/* 24 */       for (Map.Entry<Integer, Job> entry : ModJobs.jobs.entrySet()) {
/* 25 */         Integer jobId = (Integer)entry.getKey();
/*    */         
/* 27 */         if (nbtPlayer.hasKey(jobId + "")) {
/* 28 */           this.jobXP.put(jobId, Integer.valueOf(nbtPlayer.getInteger(jobId + "")));
/*    */         } else {
/* 30 */           this.jobXP.put(jobId, Integer.valueOf(0));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public int getXP(int job) {
/* 37 */     if (this.jobXP.containsKey(Integer.valueOf(job))) {
/* 38 */       return ((Integer)this.jobXP.get(Integer.valueOf(job))).intValue();
/*    */     }
/* 40 */     return 0;
/*    */   }
/*    */   
/*    */   public void setXP(int job, int ammount)
/*    */   {
/* 45 */     this.jobXP.put(Integer.valueOf(job), Integer.valueOf(ammount));
/*    */     NBTTagList nbtTagList;
/* 47 */     NBTTagList nbtTagList; if (this.player.getEntityData().getTagList("Jobs", 10).getCompoundTagAt(0) != null) {
/* 48 */       nbtTagList = this.player.getEntityData().getTagList("Jobs", 10);
/*    */     } else {
/* 50 */       nbtTagList = new NBTTagList();
/*    */     }
/* 52 */     NBTTagCompound nbtTagCompound = nbtTagList.getCompoundTagAt(0);
/* 53 */     nbtTagCompound.setInteger(job + "", getXP(job));
/*    */     
/* 55 */     NBTTagList newNbt = new NBTTagList();
/* 56 */     newNbt.appendTag(nbtTagCompound);
/*    */     
/* 58 */     this.player.getEntityData().setTag("Jobs", newNbt);
/*    */   }
/*    */   
/*    */   public void addXP(int job, int ammount, EntityPlayer player)
/*    */   {
/* 63 */     if (((Job)ModJobs.jobs.get(Integer.valueOf(job))).getLevel(getXP(job)) >= 20)
/* 64 */       return;
/* 65 */     setXP(job, getXP(job) + ammount);
/* 66 */     if (ammount != 0) {
/* 67 */       NotificationHelper.sendNotification(player, ammount + " /%jobs.earnedxp%/ /%" + ((Job)ModJobs.jobs.get(Integer.valueOf(job))).getDisplayName() + "%/");
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeXP(int job, int ammount)
/*    */   {
/* 73 */     setXP(job, getXP(job) - ammount);
/*    */   }
/*    */   
/*    */   public HashMap<Integer, Integer> getAllJobs()
/*    */   {
/* 78 */     return this.jobXP;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\JobsXPManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */