/*    */ package fr.paladium.palamod.job.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.job.logic.ForgeLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ForgeContainer extends net.minecraft.inventory.Container
/*    */ {
/*    */   private ForgeLogic tile;
/*    */   
/*    */   public ForgeContainer(ForgeLogic tile, InventoryPlayer inventory, EntityPlayer player)
/*    */   {
/* 16 */     this.tile = tile;
/*    */     
/* 18 */     addSlotToContainer(new Slot(tile, 0, 58, 15)
/*    */     {
/*    */       public boolean isItemValid(ItemStack p_75214_1_) {
/* 21 */         if (fr.paladium.palamod.util.EnumAllowItemsForge.containItem(p_75214_1_.getItem()).booleanValue()) {
/* 22 */           return true;
/*    */         }
/* 24 */         return false;
/*    */       }
/* 26 */     });
/* 27 */     addSlotToContainer(new Slot(tile, 1, 58, 58)
/*    */     {
/*    */       public boolean isItemValid(ItemStack p_75214_1_) {
/* 30 */         return false;
/*    */       }
/*    */       
/* 33 */     });
/* 34 */     addSlotToContainer(new Slot(tile, 2, 115, 45)
/*    */     {
/*    */       public boolean isItemValid(ItemStack p_75214_1_) {
/* 37 */         if (net.minecraft.tileentity.TileEntityFurnace.isItemFuel(p_75214_1_)) {
/* 38 */           return true;
/*    */         }
/* 40 */         return false;
/*    */       }
/*    */       
/* 43 */     });
/* 44 */     int l1 = 7;
/* 45 */     for (int l = 9; l <= 17; l++) {
/* 46 */       addSlotToContainer(new Slot(inventory, l, l1, 93));
/* 47 */       l1 += 20;
/*    */     }
/*    */     
/* 50 */     int a1 = 7;
/* 51 */     for (int a = 18; a <= 26; a++) {
/* 52 */       addSlotToContainer(new Slot(inventory, a, a1, 115));
/* 53 */       a1 += 20;
/*    */     }
/*    */     
/* 56 */     int b1 = 7;
/* 57 */     for (int b = 27; b <= 35; b++) {
/* 58 */       addSlotToContainer(new Slot(inventory, b, b1, 137));
/* 59 */       b1 += 20;
/*    */     }
/*    */     
/* 62 */     int c1 = 7;
/* 63 */     for (int c = 0; c <= 8; c++) {
/* 64 */       addSlotToContainer(new Slot(inventory, c, c1, 160));
/* 65 */       c1 += 20;
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer p_75145_1_) {
/* 70 */     return this.tile.isUseableByPlayer(p_75145_1_);
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer p_82846_1_, int p_82846_2_) {
/* 74 */     ItemStack itemstack = null;
/* 75 */     Slot slot = (Slot)this.inventorySlots.get(p_82846_2_);
/* 76 */     return itemstack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\inventory\ForgeContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */