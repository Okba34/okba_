/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import fr.paladium.palamod.util.BlockLocation;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.player.AnvilRepairEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
/*     */ import net.minecraftforge.event.world.BlockEvent.PlaceEvent;
/*     */ 
/*     */ public class EventHandlerJobs
/*     */ {
/*     */   @SubscribeEvent
/*     */   public void onBlockPlace(BlockEvent.PlaceEvent e)
/*     */   {
/*  21 */     if (!e.world.isRemote) {
/*  22 */       IBlockState iBlockState = new IBlockState(e.block, e.blockMetadata);
/*  23 */       if (XPManager.breakEvents.containsKey(iBlockState)) {
/*  24 */         BlockLocation blockLocation = new BlockLocation(e.x, e.y, e.z);
/*  25 */         ModJobs.allBlockPosed.put(blockLocation, Long.valueOf(System.currentTimeMillis()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onInteractEventRight(PlayerInteractEvent e)
/*     */   {
/*  33 */     if ((e.entityPlayer != null) && (e.entityPlayer.getHeldItem() == null)) {
/*  34 */       return;
/*     */     }
/*  36 */     ItemStack itemStack = e.entityPlayer.getHeldItem().copy();
/*  37 */     itemStack.stackSize = 1;
/*  38 */     if (LvlItemManager.craftEvents.containsKey(itemStack.getUnlocalizedName())) {
/*  39 */       LvlItem.CraftEvent craftEvent = (LvlItem.CraftEvent)LvlItemManager.craftEvents.get(itemStack.getUnlocalizedName());
/*  40 */       JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(e.entityPlayer.getUniqueID().toString());
/*  41 */       if (jobs == null)
/*  42 */         return;
/*  43 */       if (craftEvent.minLvl > ((Job)ModJobs.jobs.get(Integer.valueOf(craftEvent.job))).getLevel(jobs.getXP(craftEvent.job))) {
/*  44 */         e.entityPlayer.inventory.setInventorySlotContents(e.entityPlayer.inventory.currentItem, null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBreakBlock(BlockEvent.HarvestDropsEvent e)
/*     */   {
/*  52 */     if (!e.world.isRemote) {
/*  53 */       BlockLocation blockLocation = new BlockLocation(e.x, e.y, e.z);
/*  54 */       if (ModJobs.allBlockPosed.containsKey(blockLocation)) {
/*  55 */         ModJobs.allBlockPosed.remove(blockLocation);
/*  56 */         return;
/*     */       }
/*     */     }
/*  59 */     if (e.harvester == null) return;
/*  60 */     if (e.isCanceled())
/*  61 */       return;
/*  62 */     if ((e.world.isRemote) || (XPManager.breakEvents.get(new IBlockState(e.block, e.blockMetadata)) == null)) {
/*  63 */       return;
/*     */     }
/*     */     
/*     */ 
/*  67 */     if (!e.isSilkTouching) {
/*  68 */       XPItem.BreakEvent item = (XPItem.BreakEvent)XPManager.breakEvents.get(new IBlockState(e.block, e.blockMetadata));
/*  69 */       if (item != null) {
/*  70 */         item.onEvent(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onKill(LivingDeathEvent e)
/*     */   {
/*  80 */     if (e.source == null) {
/*  81 */       return;
/*     */     }
/*  83 */     if (e.source.getEntity() == null) {
/*  84 */       return;
/*     */     }
/*  86 */     if (e.source.getEntity().worldObj == null) {
/*  87 */       return;
/*     */     }
/*  89 */     if (e.source.getEntity().worldObj.isRemote) {
/*  90 */       return;
/*     */     }
/*  92 */     if ((e.source.getSourceOfDamage() instanceof EntityPlayer)) {
/*  93 */       EntityPlayer entityPlayer = (EntityPlayer)e.source.getSourceOfDamage();
/*  94 */       XPItem.KillEvent killEvent = (XPItem.KillEvent)XPManager.killEvents.get(e.entity);
/*  95 */       if (killEvent != null) {
/*  96 */         killEvent.onEvent(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onAnvil(AnvilRepairEvent e)
/*     */   {
/* 119 */     if ((e.entityPlayer.getEntityWorld().isRemote) || (e.left == null) || (e.right == null) || (e.left.getItem() == null) || (e.right.getItem() == null) || 
/* 120 */       (XPManager.anvilEvents.get(e.left.getItem()) == null)) {
/* 121 */       return;
/*     */     }
/* 123 */     XPItem.AnvilEvent item = (XPItem.AnvilEvent)XPManager.anvilEvents.get(e.left.getItem());
/* 124 */     if (item != null) {
/* 125 */       item.onEvent(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void onFish(ItemStack itemStack, EntityPlayer entityPlayer)
/*     */   {
/* 132 */     if ((entityPlayer.getEntityWorld().isRemote) || (XPManager.fishEvents.get(new ItemCouple(itemStack.getItem(), itemStack.getItemDamage()).getAll()) == null)) {
/* 133 */       return;
/*     */     }
/* 135 */     XPItem.FishEvent item = (XPItem.FishEvent)XPManager.fishEvents.get(new ItemCouple(itemStack.getItem(), itemStack.getItemDamage()).getAll());
/* 136 */     if (item != null) {
/* 137 */       item.onEvent(itemStack, entityPlayer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\EventHandlerJobs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */