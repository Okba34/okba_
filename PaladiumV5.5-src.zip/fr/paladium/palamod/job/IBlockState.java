/*    */ package fr.paladium.palamod.job;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ public class IBlockState
/*    */ {
/*    */   private Block block;
/*    */   private int meta;
/*    */   
/*    */   public IBlockState(Block block, int meta) {
/* 11 */     this.block = block;
/* 12 */     this.meta = meta;
/*    */   }
/*    */   
/*    */   public Block getBlock()
/*    */   {
/* 17 */     return this.block;
/*    */   }
/*    */   
/*    */   public int getMeta() {
/* 21 */     return this.meta;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 26 */     if ((obj instanceof IBlockState)) {
/* 27 */       IBlockState iBlockState = (IBlockState)obj;
/* 28 */       if ((iBlockState.getBlock().equals(this.block)) && (iBlockState.getMeta() == this.meta)) {
/* 29 */         return true;
/*    */       }
/*    */     }
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 37 */     String compare = "block:" + this.block.toString() + ";/;Meta:" + this.meta;
/* 38 */     return compare.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\IBlockState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */