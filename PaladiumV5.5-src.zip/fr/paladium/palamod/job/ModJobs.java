/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import fr.paladium.palamod.util.BlockLocation;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModJobs
/*     */ {
/*  22 */   public static HashMap<Integer, Job> jobs = new HashMap();
/*  23 */   public static HashMap<String, JobsXPManager> allJobsXpManager = new HashMap();
/*  24 */   public static HashMap<BlockLocation, Long> allBlockPosed = new HashMap();
/*  25 */   public static File folder = new File("config");
/*  26 */   public static File savedFile = new File(folder.getPath() + "/paladiumJobsBlockSaved");
/*     */   
/*     */   public static void init()
/*     */   {
/*  30 */     if (!folder.exists()) {
/*  31 */       folder.mkdir();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  37 */     Job farmer = new Job(2, "farmer", "jobs.farmer", LibRessources.FARMER_LOGO, LibRessources.FARMER_LOGO_COORDS);
/*     */     
/*  39 */     Job hunter = new Job(5, "hunter", "jobs.hunter", LibRessources.HUNTER_LOGO, LibRessources.HUNTER_LOGO_COORDS);
/*     */     
/*  41 */     Job miner = new Job(3, "miner", "jobs.miner", LibRessources.MINER_LOGO, LibRessources.MINER_LOGO_COORDS);
/*     */     
/*     */ 
/*     */ 
/*  45 */     Job alchimiste = new Job(1, "alchimiste", "jobs.alchimiste", LibRessources.ALCHIMISTE_LOGO, LibRessources.ALCHIMISTE_LOGO_COORDS);
/*     */     
/*  47 */     Job lumberjack = new Job(4, "lumberjack", "jobs.lumberjack", LibRessources.LUMBERJACK_LOGO, LibRessources.LUMBERJACK_LOGO_COORDS);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */     addJob(4, lumberjack);
/*     */     
/*  55 */     addJob(2, farmer);
/*  56 */     addJob(5, hunter);
/*  57 */     addJob(3, miner);
/*     */     
/*  59 */     addJob(1, alchimiste);
/*  60 */     addJob(4, lumberjack);
/*     */     
/*     */ 
/*  63 */     XPManager.init();
/*  64 */     LvlItemManager.init();
/*     */   }
/*     */   
/*     */   public static void addJob(int jobInt, Job job) {
/*  68 */     jobs.put(Integer.valueOf(jobInt), job);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void autoSave()
/*     */   {
/* 105 */     ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
/*     */     
/* 107 */     ses.scheduleAtFixedRate(new Runnable()
/*     */     {
/*     */       public void run() {
/* 110 */         for (Map.Entry<BlockLocation, Long> entryset : ModJobs.allBlockPosed.entrySet()) {
/* 111 */           BlockLocation location = (BlockLocation)entryset.getKey();
/* 112 */           Long Time = (Long)entryset.getValue();
/*     */           
/* 114 */           Long TimeAfter = Long.valueOf(System.currentTimeMillis() - Time.longValue());
/* 115 */           if (TimeAfter.longValue() > TimeUnit.MILLISECONDS.convert(1L, TimeUnit.HOURS))
/* 116 */             ModJobs.allBlockPosed.remove(location); } } }, 2L, 2L, TimeUnit.HOURS);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\ModJobs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */