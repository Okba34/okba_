/*     */ package fr.paladium.palamod.job.logic;
/*     */ 
/*     */ import fr.paladium.palamod.job.block.BlockForge;
/*     */ import fr.paladium.palamod.util.EnumAllowItemsForge;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityFurnace;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ForgeLogic extends TileEntity implements net.minecraft.inventory.IInventory, ISidedInventory
/*     */ {
/*     */   private ItemStack[] contents;
/*  20 */   private int work = 0;
/*  21 */   private int burn = 0;
/*  22 */   private int burnMax = 100;
/*     */   
/*     */   public ForgeLogic() {
/*  25 */     this.contents = new ItemStack[3];
/*     */   }
/*     */   
/*     */   public int getWork() {
/*  29 */     return this.work;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  34 */     return this.contents.length;
/*     */   }
/*     */   
/*     */   public void setWork(int work) {
/*  38 */     this.work = work;
/*     */   }
/*     */   
/*     */   public int getBurn() {
/*  42 */     return this.burn;
/*     */   }
/*     */   
/*     */   public void setBurn(int burn) {
/*  46 */     this.burn = burn;
/*     */   }
/*     */   
/*     */   public int getBurnMax() {
/*  50 */     return this.burnMax;
/*     */   }
/*     */   
/*     */   public void setBurnMax(int burnMax) {
/*  54 */     this.burnMax = burnMax;
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  59 */     if (this.contents[slotIndex] != null)
/*     */     {
/*     */ 
/*  62 */       if (this.contents[slotIndex].stackSize <= amount) {
/*  63 */         ItemStack itemstack = this.contents[slotIndex];
/*     */         
/*  65 */         this.contents[slotIndex] = null;
/*  66 */         markDirty();
/*     */         
/*  68 */         return itemstack;
/*     */       }
/*     */       
/*  71 */       ItemStack itemstack = this.contents[slotIndex].splitStack(amount);
/*     */       
/*  73 */       if (this.contents[slotIndex].stackSize == 0) {
/*  74 */         this.contents[slotIndex] = null;
/*     */       }
/*     */       
/*  77 */       markDirty();
/*  78 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  88 */     if (this.contents[slotIndex] != null) {
/*  89 */       ItemStack itemstack = this.contents[slotIndex];
/*  90 */       this.contents[slotIndex] = null;
/*     */       
/*  92 */       return itemstack;
/*     */     }
/*     */     
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/* 101 */     this.contents[slotIndex] = stack;
/*     */     
/* 103 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/* 104 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 107 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/* 112 */     return "tile.Forge";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 117 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 122 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 127 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 138 */     return slot != 5;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 143 */     super.writeToNBT(compound);
/*     */     
/* 145 */     NBTTagList nbttaglist = new NBTTagList();
/* 146 */     compound.setInteger("work", this.work);
/* 147 */     compound.setInteger("burn", this.burn);
/* 148 */     compound.setInteger("burnMax", this.burnMax);
/*     */     
/* 150 */     for (int i = 0; i < this.contents.length; i++) {
/* 151 */       if (this.contents[i] != null) {
/* 152 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 153 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 154 */         this.contents[i].writeToNBT(nbttagcompound1);
/* 155 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 159 */     compound.setTag("Items", nbttaglist);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 164 */     super.readFromNBT(compound);
/*     */     
/* 166 */     this.work = compound.getInteger("work");
/* 167 */     this.burn = compound.getInteger("burn");
/* 168 */     this.burnMax = compound.getInteger("burnMax");
/*     */     
/* 170 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/*     */     
/* 172 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 173 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 174 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 176 */       if ((j >= 0) && (j < this.contents.length)) {
/* 177 */         this.contents[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/* 184 */     return this.contents[slot];
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/* 189 */     boolean flag = this.work > 0;
/*     */     
/* 191 */     if (this.burn <= 0) {
/* 192 */       if (((getStackInSlot(0) != null) && (EnumAllowItemsForge.containItem(getStackInSlot(0).getItem()).booleanValue())) || (this.work != 0)) {
/* 193 */         if (TileEntityFurnace.isItemFuel(getStackInSlot(2))) {
/* 194 */           this.burnMax = TileEntityFurnace.getItemBurnTime(getStackInSlot(2));
/* 195 */           this.burn = TileEntityFurnace.getItemBurnTime(getStackInSlot(2));
/* 196 */           decrStackSize(2, 1);
/* 197 */           if (!this.worldObj.isRemote) {
/* 198 */             if (flag != this.work > 0) {
/* 199 */               BlockForge.updateBlockState(this.work > 0, this.worldObj, this.xCoord, this.yCoord, this.zCoord);
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 204 */           this.work = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 209 */       if ((getStackInSlot(0) != null) && (EnumAllowItemsForge.containItem(getStackInSlot(0).getItem()).booleanValue()) && (
/* 210 */         (getStackInSlot(1) == null) || ((EnumAllowItemsForge.valuesOf(getStackInSlot(0).getItem()).getItemDrop().equals(getStackInSlot(1).getItem())) && 
/* 211 */         (EnumAllowItemsForge.valuesOf(getStackInSlot(0).getItem()).getMaxDrop() + getStackInSlot(1).stackSize <= getStackInSlot(1).getMaxStackSize())))) {
/* 212 */         if (this.work == 100) {
/* 213 */           int i = getStackInSlot(0).getMaxDamage() - getStackInSlot(0).getItemDamage();
/* 214 */           double pDamageC = i * 100;
/* 215 */           double pDamageC1 = pDamageC / getStackInSlot(0).getMaxDamage();
/* 216 */           int pDamage = (int)pDamageC1;
/*     */           
/* 218 */           EnumAllowItemsForge enumAllowItemsForge = EnumAllowItemsForge.valuesOf(getStackInSlot(0).getItem());
/* 219 */           double dropD = enumAllowItemsForge.getMaxDrop() * pDamage / 100;
/* 220 */           int drop = (int)dropD;
/*     */           
/* 222 */           decrStackSize(0, 1);
/* 223 */           if (getStackInSlot(1) == null) {
/* 224 */             ItemStack itemStack = new ItemStack(enumAllowItemsForge.getItemDrop(), drop);
/* 225 */             setInventorySlotContents(1, itemStack);
/*     */           }
/*     */           else {
/* 228 */             ItemStack itemStack = new ItemStack(getStackInSlot(1).getItem(), getStackInSlot(1).stackSize + drop, getStackInSlot(1).getItemDamage());
/* 229 */             setInventorySlotContents(1, itemStack);
/*     */           }
/* 231 */           this.work = 0;
/*     */         }
/*     */         else {
/* 234 */           this.work += 1;
/*     */         }
/*     */       }
/*     */       else {
/* 238 */         this.work = 0;
/*     */       }
/* 240 */       this.burn -= 1;
/*     */       
/* 242 */       if ((this.burn <= 0) && 
/* 243 */         (!this.worldObj.isRemote)) {
/* 244 */         if (flag != this.work > 0) {
/* 245 */           BlockForge.updateBlockState(this.work > 0, this.worldObj, this.xCoord, this.yCoord, this.zCoord);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 254 */     return new int[0];
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 259 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 264 */     return false;
/*     */   }
/*     */   
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 269 */     NBTTagCompound nbtTag = new NBTTagCompound();
/* 270 */     writeToNBT(nbtTag);
/*     */     
/* 272 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, 1, nbtTag);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet)
/*     */   {
/* 277 */     readFromNBT(packet.func_148857_g());
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\logic\ForgeLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */