/*     */ package fr.paladium.palamod.job.logic;
/*     */ 
/*     */ import fr.paladium.palamod.job.JobRegister;
/*     */ import fr.paladium.palamod.util.ItemStackHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileCobbleBreaker
/*     */   extends TileEntity
/*     */   implements IInventory, ISidedInventory
/*     */ {
/*  29 */   private int work = 0;
/*     */   
/*  31 */   private ItemStack[] contents = new ItemStack[7];
/*     */   
/*     */   public int getWork() {
/*  34 */     return this.work;
/*     */   }
/*     */   
/*     */   public void setWork(int work) {
/*  38 */     this.work = work;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/*  45 */     super.writeToNBT(compound);
/*     */     
/*  47 */     NBTTagList nbttaglist = new NBTTagList();
/*  48 */     compound.setInteger("work", this.work);
/*     */     
/*     */ 
/*  51 */     for (int i = 0; i < this.contents.length; i++) {
/*  52 */       if (this.contents[i] != null) {
/*  53 */         NBTTagCompound nbttagcompound = new NBTTagCompound();
/*  54 */         nbttagcompound.setByte("Slot", (byte)i);
/*  55 */         this.contents[i].writeToNBT(nbttagcompound);
/*  56 */         nbttaglist.appendTag(nbttagcompound);
/*     */       }
/*     */     }
/*     */     
/*  60 */     compound.setTag("Items", nbttaglist);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/*  68 */     super.readFromNBT(compound);
/*     */     
/*  70 */     this.work = compound.getInteger("work");
/*     */     
/*  72 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/*  73 */     this.contents = new ItemStack[getSizeInventory()];
/*     */     
/*  75 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/*  76 */       NBTTagCompound nbttagcompound = nbttaglist.getCompoundTagAt(i);
/*  77 */       int j = nbttagcompound.getByte("Slot") & 0xFF;
/*     */       
/*  79 */       if ((j >= 0) && (j < this.contents.length)) {
/*  80 */         this.contents[j] = ItemStack.loadItemStackFromNBT(nbttagcompound);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty()
/*     */   {
/*  88 */     super.markDirty();
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/*  93 */     if ((getStackInSlot(0) != null) && (getStackInSlot(0).getItem().equals(Item.getItemFromBlock(Blocks.cobblestone))) && (
/*  94 */       (getStackInSlot(1) == null) || (getStackInSlot(1).stackSize < 64) || (getStackInSlot(2) == null) || (getStackInSlot(2).stackSize < 64) || (getStackInSlot(3) == null) || (getStackInSlot(3).stackSize < 64) || 
/*  95 */       (getStackInSlot(4) == null) || (getStackInSlot(4).stackSize < 64) || (getStackInSlot(5) == null) || (getStackInSlot(5).stackSize < 64) || (getStackInSlot(6) == null) || (getStackInSlot(6).stackSize < 64))) {
/*  96 */       if (this.work >= 400) {
/*  97 */         if (!this.worldObj.isRemote) {
/*  98 */           int random = (int)(Math.random() * 125.0D);
/*  99 */           if (random <= 2) {
/* 100 */             if (getStackInSlot(6) != null) {
/* 101 */               if (getStackInSlot(6).stackSize < 64) {
/* 102 */                 ItemStack paladium = new ItemStack(getStackInSlot(6).getItem(), getStackInSlot(6).stackSize + 1, getStackInSlot(6).getItemDamage());
/* 103 */                 setInventorySlotContents(6, paladium);
/*     */               }
/*     */             } else {
/* 106 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_PALADIUM, 1, 0);
/* 107 */               setInventorySlotContents(6, paladium);
/*     */             }
/*     */           }
/* 110 */           if ((random > 2) && (random <= 7)) {
/* 111 */             if (getStackInSlot(5) != null) {
/* 112 */               if (getStackInSlot(5).stackSize < 64) {
/* 113 */                 ItemStack paladium = new ItemStack(getStackInSlot(5).getItem(), getStackInSlot(5).stackSize + 1, getStackInSlot(5).getItemDamage());
/* 114 */                 setInventorySlotContents(5, paladium);
/*     */               }
/*     */             } else {
/* 117 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_TITANE, 1, 0);
/* 118 */               setInventorySlotContents(5, paladium);
/*     */             }
/*     */           }
/* 121 */           if ((random > 7) && (random <= 15)) {
/* 122 */             if (getStackInSlot(4) != null) {
/* 123 */               if (getStackInSlot(4).stackSize < 64) {
/* 124 */                 ItemStack paladium = new ItemStack(getStackInSlot(4).getItem(), getStackInSlot(4).stackSize + 1, getStackInSlot(4).getItemDamage());
/* 125 */                 setInventorySlotContents(4, paladium);
/*     */               }
/*     */             } else {
/* 128 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_AMETHYST, 1, 0);
/* 129 */               setInventorySlotContents(4, paladium);
/*     */             }
/*     */           }
/* 132 */           if ((random > 15) && (random <= 25)) {
/* 133 */             if (getStackInSlot(3) != null) {
/* 134 */               if (getStackInSlot(3).stackSize < 64) {
/* 135 */                 ItemStack paladium = new ItemStack(getStackInSlot(3).getItem(), getStackInSlot(3).stackSize + 1, getStackInSlot(3).getItemDamage());
/* 136 */                 setInventorySlotContents(3, paladium);
/*     */               }
/*     */             } else {
/* 139 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_DIAMOND, 1, 0);
/* 140 */               setInventorySlotContents(3, paladium);
/*     */             }
/*     */           }
/* 143 */           if ((random > 25) && (random <= 40)) {
/* 144 */             if (getStackInSlot(2) != null) {
/* 145 */               if (getStackInSlot(2).stackSize < 64) {
/* 146 */                 ItemStack paladium = new ItemStack(getStackInSlot(2).getItem(), getStackInSlot(2).stackSize + 1, getStackInSlot(2).getItemDamage());
/* 147 */                 setInventorySlotContents(2, paladium);
/*     */               }
/*     */             } else {
/* 150 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_GOLD, 1, 0);
/* 151 */               setInventorySlotContents(2, paladium);
/*     */             }
/*     */           }
/* 154 */           if ((random > 40) && (random <= 55)) {
/* 155 */             if (getStackInSlot(1) != null) {
/* 156 */               if (getStackInSlot(1).stackSize < 64) {
/* 157 */                 ItemStack paladium = new ItemStack(getStackInSlot(1).getItem(), getStackInSlot(1).stackSize + 1, getStackInSlot(1).getItemDamage());
/* 158 */                 setInventorySlotContents(1, paladium);
/*     */               }
/*     */             } else {
/* 161 */               ItemStack paladium = new ItemStack(JobRegister.PARTICLE_IRON, 1, 0);
/* 162 */               setInventorySlotContents(1, paladium);
/*     */             }
/*     */           }
/*     */         }
/* 166 */         decrStackSize(0, 1);
/* 167 */         this.work = 0;
/*     */       } else {
/* 169 */         this.work += 1;
/*     */       }
/*     */     } else {
/* 172 */       this.work = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int p_94128_1_)
/*     */   {
/* 178 */     return new int[0];
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int p_102007_1_, ItemStack p_102007_2_, int p_102007_3_)
/*     */   {
/* 183 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int p_102008_1_, ItemStack p_102008_2_, int p_102008_3_)
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/* 193 */     return this.contents.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int p_70301_1_)
/*     */   {
/* 198 */     return this.contents[p_70301_1_];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int p_70298_1_, int p_70298_2_)
/*     */   {
/* 203 */     ItemStack itemstack = ItemStackHelper.getAndSplit(this.contents, p_70298_1_, p_70298_2_);
/*     */     
/* 205 */     if (itemstack != null)
/*     */     {
/* 207 */       markDirty();
/*     */     }
/*     */     
/* 210 */     return itemstack;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlotOnClosing(int p_70304_1_)
/*     */   {
/* 215 */     return this.contents[p_70304_1_];
/*     */   }
/*     */   
/*     */   public void setInventorySlotContents(int p_70299_1_, ItemStack p_70299_2_)
/*     */   {
/* 220 */     this.contents[p_70299_1_] = p_70299_2_;
/*     */     
/* 222 */     if ((p_70299_2_ != null) && (p_70299_2_.stackSize > getInventoryStackLimit()))
/*     */     {
/* 224 */       p_70299_2_.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 227 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/* 232 */     return "tile.CobbleBreaker";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 237 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 242 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer p_70300_1_)
/*     */   {
/* 247 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isItemValidForSlot(int p_94041_1_, ItemStack p_94041_2_)
/*     */   {
/* 262 */     return true;
/*     */   }
/*     */   
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 267 */     NBTTagCompound nbtTag = new NBTTagCompound();
/* 268 */     writeToNBT(nbtTag);
/*     */     
/* 270 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, 1, nbtTag);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet)
/*     */   {
/* 275 */     readFromNBT(packet.func_148857_g());
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\logic\TileCobbleBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */