/*     */ package fr.paladium.palamod.job;
/*     */ 
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntityWitch;
/*     */ import net.minecraft.entity.passive.EntityChicken;
/*     */ import net.minecraft.entity.passive.EntityCow;
/*     */ import net.minecraft.entity.passive.EntityPig;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ 
/*     */ public class XPManager
/*     */ {
/*  19 */   public static HashMap<IBlockState, XPItem.BreakEvent> breakEvents = new HashMap();
/*  20 */   public static HashMap<String, XPItem.CraftEvent> craftEvents = new HashMap();
/*  21 */   public static HashMap<Entity, XPItem.KillEvent> killEvents = new HashMap();
/*  22 */   public static HashMap<String, XPItem.FishEvent> fishEvents = new HashMap();
/*  23 */   public static HashMap<String, XPItem.SmeltingEvent> smeltEvents = new HashMap();
/*  24 */   public static HashMap<Item, XPItem.AnvilEvent> anvilEvents = new HashMap();
/*     */   
/*     */   public static void init()
/*     */   {
/*  28 */     XPItem.BreakEvent logLumberjack = new XPItem.BreakEvent(4, new int[] { 5, 3, 2, 1 });
/*  29 */     XPItem.BreakEvent log2Lumberjack = new XPItem.BreakEvent(4, new int[] { 5, 3, 2, 1 });
/*  30 */     XPItem.BreakEvent logSpecial1Lumberjack = new XPItem.BreakEvent(4, new int[] { 5, 3, 2, 1 });
/*  31 */     XPItem.BreakEvent logSpecial2Lumberjack = new XPItem.BreakEvent(4, new int[] { 0, 5, 3, 2 });
/*  32 */     XPItem.BreakEvent logSpecial3Lumberjack = new XPItem.BreakEvent(4, new int[] { 0, 0, 5, 3 });
/*  33 */     XPItem.BreakEvent logSpecial4Lumberjack = new XPItem.BreakEvent(4, new int[] { 0, 0, 0, 5 });
/*     */     
/*  35 */     breakEvents.put(new IBlockState(Blocks.log, 0), logLumberjack);
/*  36 */     breakEvents.put(new IBlockState(Blocks.log, 1), logLumberjack);
/*  37 */     breakEvents.put(new IBlockState(Blocks.log, 2), logLumberjack);
/*  38 */     breakEvents.put(new IBlockState(Blocks.log, 3), logLumberjack);
/*  39 */     breakEvents.put(new IBlockState(Blocks.log2, 0), log2Lumberjack);
/*  40 */     breakEvents.put(new IBlockState(Blocks.log2, 1), log2Lumberjack);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     XPItem.CraftEvent oakPlanksLumberjack = new XPItem.CraftEvent(4, new int[] { 1, 1, 1, 1 });
/*     */     
/*  50 */     XPItem.CraftEvent special1PlanksLumberjack = new XPItem.CraftEvent(4, new int[] { 1, 0, 0, 0 });
/*     */     
/*  52 */     XPItem.CraftEvent special2PlanksLumberjack = new XPItem.CraftEvent(4, new int[] { 0, 1, 0, 0 });
/*     */     
/*  54 */     XPItem.CraftEvent special3PlanksLumberjack = new XPItem.CraftEvent(4, new int[] { 0, 0, 1, 0 });
/*     */     
/*  56 */     craftEvents.put(new ItemCouple(Blocks.planks).getAll(), oakPlanksLumberjack);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     XPItem.BreakEvent netherWart = new XPItem.BreakEvent(1, new int[] { 2, 1, 1, 1 });
/*  64 */     XPItem.CraftEvent yellowFlower = new XPItem.CraftEvent(1, new int[] { 5, 3, 1, 1 });
/*  65 */     XPItem.CraftEvent redFlower = new XPItem.CraftEvent(1, new int[] { 5, 3, 1, 1 });
/*  66 */     XPItem.CraftEvent blueFlower = new XPItem.CraftEvent(1, new int[] { 0, 5, 3, 2 });
/*  67 */     XPItem.CraftEvent alliumFlower = new XPItem.CraftEvent(1, new int[] { 0, 0, 5, 3 });
/*  68 */     XPItem.CraftEvent tulip1Flower = new XPItem.CraftEvent(1, new int[] { 0, 0, 0, 5 });
/*  69 */     XPItem.CraftEvent tulip2Flower = new XPItem.CraftEvent(1, new int[] { 0, 0, 0, 5 });
/*  70 */     XPItem.CraftEvent tulip3Flower = new XPItem.CraftEvent(1, new int[] { 0, 0, 0, 5 });
/*  71 */     XPItem.CraftEvent tulip4Flower = new XPItem.CraftEvent(1, new int[] { 0, 0, 0, 5 });
/*  72 */     XPItem.BreakEvent glowstone = new XPItem.BreakEvent(1, new int[] { 2, 2, 2, 2 });
/*  73 */     XPItem.BreakEvent clathrus = new XPItem.BreakEvent(1, new int[] { 5, 3, 2, 1 });
/*  74 */     XPItem.BreakEvent mint = new XPItem.BreakEvent(1, new int[] { 5, 3, 2, 1 });
/*  75 */     XPItem.BreakEvent sauge = new XPItem.BreakEvent(1, new int[] { 5, 3, 2, 1 });
/*  76 */     XPItem.BreakEvent trefle = new XPItem.BreakEvent(1, new int[] { 0, 5, 3, 2 });
/*  77 */     XPItem.BreakEvent actaeaPachypoda = new XPItem.BreakEvent(1, new int[] { 0, 5, 3, 2 });
/*  78 */     XPItem.BreakEvent ortie = new XPItem.BreakEvent(1, new int[] { 0, 0, 5, 3 });
/*  79 */     XPItem.BreakEvent absinthe = new XPItem.BreakEvent(1, new int[] { 0, 0, 5, 3 });
/*  80 */     XPItem.BreakEvent fleurPaladium = new XPItem.BreakEvent(1, new int[] { 0, 0, 5, 3 });
/*  81 */     XPItem.BreakEvent harpagophytum = new XPItem.BreakEvent(1, new int[] { 0, 0, 0, 5 });
/*  82 */     XPItem.BreakEvent fleurEndium = new XPItem.BreakEvent(1, new int[] { 0, 0, 0, 5 });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  87 */     craftEvents.put(new ItemCouple(Items.dye, 11).getAll(), yellowFlower);
/*  88 */     craftEvents.put(new ItemCouple(Items.dye, 1).getAll(), redFlower);
/*  89 */     craftEvents.put(new ItemCouple(Items.dye, 12).getAll(), blueFlower);
/*  90 */     craftEvents.put(new ItemCouple(Items.dye, 13).getAll(), alliumFlower);
/*  91 */     craftEvents.put(new ItemCouple(Items.dye, 14).getAll(), tulip1Flower);
/*  92 */     craftEvents.put(new ItemCouple(Items.dye, 7).getAll(), tulip2Flower);
/*  93 */     craftEvents.put(new ItemCouple(Items.dye, 9).getAll(), tulip3Flower);
/*     */     
/*     */ 
/*  96 */     breakEvents.put(new IBlockState(Blocks.glowstone, 0), glowstone);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */     XPItem.CraftEvent red = new XPItem.CraftEvent(1, new int[] { 1, 1, 1, 1 });
/* 110 */     XPItem.CraftEvent yellow = new XPItem.CraftEvent(1, new int[] { 1, 1, 1, 1 });
/* 111 */     XPItem.CraftEvent lightBlue = new XPItem.CraftEvent(1, new int[] { 0, 1, 1, 1 });
/*     */     
/* 113 */     craftEvents.put(new ItemCouple(Items.dye, 1).getAll(), red);
/* 114 */     craftEvents.put(new ItemCouple(Items.dye, 11).getAll(), yellow);
/* 115 */     craftEvents.put(new ItemCouple(Items.dye, 12).getAll(), lightBlue);
/*     */     
/*     */ 
/*     */ 
/* 119 */     XPItem.BreakEvent stoneBlockMiner = new XPItem.BreakEvent(3, new int[] { 1, 1, 0, 0 });
/* 120 */     XPItem.BreakEvent obsidianBlockMiner = new XPItem.BreakEvent(3, new int[] { 2, 2, 2, 2 });
/* 121 */     XPItem.SmeltingEvent ironoreBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 5, 3, 2, 1 });
/* 122 */     XPItem.SmeltingEvent goldoreBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 5, 3, 2, 1 });
/* 123 */     XPItem.BreakEvent diamondoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 0, 5, 3, 2 });
/* 124 */     XPItem.BreakEvent emeraldoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 0, 5, 3, 2 });
/* 125 */     XPItem.SmeltingEvent amethysteoreBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 0, 0, 5, 3 });
/* 126 */     XPItem.SmeltingEvent titaneoreBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 0, 0, 5, 3 });
/* 127 */     XPItem.BreakEvent netherquartzoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 0, 0, 5, 3 });
/* 128 */     XPItem.SmeltingEvent mossstoneBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 0, 0, 10, 10 });
/* 129 */     XPItem.BreakEvent coaloreBlockMiner = new XPItem.BreakEvent(3, new int[] { 3, 2, 1, 1 });
/* 130 */     XPItem.BreakEvent lapisoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 3, 2, 1, 1 });
/* 131 */     XPItem.BreakEvent redstoneoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 3, 2, 1, 1 });
/* 132 */     XPItem.SmeltingEvent paladiumoreBlockMiner = new XPItem.SmeltingEvent(3, new int[] { 0, 0, 0, 5 });
/* 133 */     XPItem.BreakEvent findiumoreBlockMiner = new XPItem.BreakEvent(3, new int[] { 0, 0, 0, 5 });
/* 134 */     XPItem.BreakEvent mobspawnerBlockMiner = new XPItem.BreakEvent(3, new int[] { 0, 0, 50, 50 });
/*     */     
/* 136 */     breakEvents.put(new IBlockState(Blocks.stone, 0), stoneBlockMiner);
/* 137 */     breakEvents.put(new IBlockState(Blocks.obsidian, 0), obsidianBlockMiner);
/* 138 */     breakEvents.put(new IBlockState(Blocks.diamond_ore, 0), diamondoreBlockMiner);
/* 139 */     breakEvents.put(new IBlockState(Blocks.emerald_ore, 0), emeraldoreBlockMiner);
/* 140 */     breakEvents.put(new IBlockState(Blocks.quartz_block, 0), netherquartzoreBlockMiner);
/* 141 */     breakEvents.put(new IBlockState(Blocks.coal_ore, 0), coaloreBlockMiner);
/* 142 */     breakEvents.put(new IBlockState(Blocks.lapis_ore, 0), lapisoreBlockMiner);
/* 143 */     breakEvents.put(new IBlockState(Blocks.redstone_ore, 0), redstoneoreBlockMiner);
/* 144 */     breakEvents.put(new IBlockState(WorldRegister.FINDIUM_ORE, 0), findiumoreBlockMiner);
/* 145 */     breakEvents.put(new IBlockState(Blocks.mob_spawner, 0), mobspawnerBlockMiner);
/*     */     
/* 147 */     smeltEvents.put(new ItemCouple(Items.iron_ingot).getAll(), ironoreBlockMiner);
/* 148 */     smeltEvents.put(new ItemCouple(Items.gold_ingot).getAll(), goldoreBlockMiner);
/* 149 */     smeltEvents.put(new ItemCouple(MaterialRegister.AMETHYST_INGOT).getAll(), amethysteoreBlockMiner);
/* 150 */     smeltEvents.put(new ItemCouple(MaterialRegister.TITANE_INGOT).getAll(), titaneoreBlockMiner);
/* 151 */     smeltEvents.put(new ItemCouple(MaterialRegister.PALADIUM_INGOT).getAll(), paladiumoreBlockMiner);
/*     */     
/*     */ 
/*     */ 
/* 155 */     XPItem.KillEvent sheep = new XPItem.KillEvent(5, new int[] { 2, 2, 2, 1 });
/* 156 */     XPItem.KillEvent cow = new XPItem.KillEvent(5, new int[] { 5, 3, 2, 1 });
/* 157 */     XPItem.KillEvent chicken = new XPItem.KillEvent(5, new int[] { 0, 0, 3, 2 });
/* 158 */     XPItem.KillEvent pig = new XPItem.KillEvent(5, new int[] { 0, 0, 0, 5 });
/*     */     
/*     */ 
/* 161 */     XPItem.KillEvent spider = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 162 */     XPItem.KillEvent skeleton = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 163 */     XPItem.KillEvent creeper = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 164 */     XPItem.KillEvent enderman = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 165 */     XPItem.KillEvent cavespider = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 166 */     XPItem.KillEvent blaze = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/* 167 */     XPItem.KillEvent witch = new XPItem.KillEvent(5, new int[] { 0, 0, 5, 5 });
/*     */     
/*     */ 
/* 170 */     killEvents.put(new net.minecraft.entity.passive.EntitySheep(null), sheep);
/* 171 */     killEvents.put(new EntityCow(null), cow);
/* 172 */     killEvents.put(new EntityChicken(null), chicken);
/* 173 */     killEvents.put(new EntityPig(null), pig);
/* 174 */     killEvents.put(new net.minecraft.entity.monster.EntitySpider(null), spider);
/* 175 */     killEvents.put(new net.minecraft.entity.monster.EntitySkeleton(null), skeleton);
/* 176 */     killEvents.put(new EntityCreeper(null), creeper);
/* 177 */     killEvents.put(new EntityEnderman(null), enderman);
/* 178 */     killEvents.put(new net.minecraft.entity.monster.EntityCaveSpider(null), cavespider);
/* 179 */     killEvents.put(new net.minecraft.entity.monster.EntityBlaze(null), blaze);
/* 180 */     killEvents.put(new EntityWitch(null), witch);
/*     */     
/*     */ 
/* 183 */     XPItem.BreakEvent brunMushroom = new XPItem.BreakEvent(5, new int[] { 3, 2, 1, 1 });
/* 184 */     XPItem.BreakEvent redMushroom = new XPItem.BreakEvent(5, new int[] { 3, 2, 1, 1 });
/* 185 */     XPItem.BreakEvent pumpkin = new XPItem.BreakEvent(5, new int[] { 0, 5, 3, 2 });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     XPItem.CraftEvent mushroom = new XPItem.CraftEvent(5, new int[] { 0, 0, 3, 0 });
/*     */     
/* 194 */     craftEvents.put(new ItemCouple(Items.mushroom_stew).getAll(), mushroom);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 199 */     XPItem.BreakEvent wheat = new XPItem.BreakEvent(2, new int[] { 5, 3, 2, 1 });
/* 200 */     XPItem.BreakEvent carrot = new XPItem.BreakEvent(2, new int[] { 5, 3, 2, 1 });
/* 201 */     XPItem.BreakEvent potatoes = new XPItem.BreakEvent(2, new int[] { 0, 5, 3, 2 });
/* 202 */     XPItem.BreakEvent melon = new XPItem.BreakEvent(2, new int[] { 0, 0, 5, 3 });
/* 203 */     XPItem.BreakEvent cactus = new XPItem.BreakEvent(2, new int[] { 0, 0, 5, 3 });
/*     */     
/* 205 */     breakEvents.put(new IBlockState(Blocks.wheat, 7), wheat);
/* 206 */     breakEvents.put(new IBlockState(Blocks.carrots, 7), carrot);
/* 207 */     breakEvents.put(new IBlockState(Blocks.potatoes, 7), potatoes);
/* 208 */     breakEvents.put(new IBlockState(Blocks.melon_block, 0), melon);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */     XPItem.CraftEvent bread = new XPItem.CraftEvent(2, new int[] { 2, 1, 1, 1 });
/* 215 */     XPItem.CraftEvent cookie = new XPItem.CraftEvent(2, new int[] { 2, 2, 2, 1 });
/* 216 */     XPItem.CraftEvent cake = new XPItem.CraftEvent(2, new int[] { 0, 5, 3, 2 });
/*     */     
/*     */ 
/* 219 */     craftEvents.put(new ItemCouple(Items.bread).getAll(), bread);
/* 220 */     craftEvents.put(new ItemCouple(Items.cookie).getAll(), cookie);
/* 221 */     craftEvents.put(new ItemCouple(Items.cake).getAll(), cake);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\XPManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */