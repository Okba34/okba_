/*    */ package fr.paladium.palamod.job.gui;
/*    */ 
/*    */ import fr.paladium.palamod.job.inventory.ForgeContainer;
/*    */ import fr.paladium.palamod.job.logic.ForgeLogic;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ForgeGui extends GuiContainer
/*    */ {
/* 14 */   public static final ResourceLocation background = new ResourceLocation("palamod", "textures/gui/forge.png");
/*    */   private ForgeLogic tile;
/*    */   
/*    */   public ForgeGui(ForgeLogic tile, InventoryPlayer inventory, EntityPlayer player) {
/* 18 */     super(new ForgeContainer(tile, inventory, player));
/*    */     
/* 20 */     this.xSize = 188;
/* 21 */     this.ySize = 190;
/*    */     
/* 23 */     this.allowUserInput = false;
/*    */     
/* 25 */     this.tile = tile;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 30 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 31 */     this.mc.getTextureManager().bindTexture(background);
/* 32 */     int k = (this.width - this.xSize) / 2;
/* 33 */     int l = (this.height - this.ySize) / 2;
/* 34 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 36 */     double d = 16 * this.tile.getWork() / 100;
/* 37 */     int i = (int)d;
/* 38 */     drawTexturedModalRect(k + 61, l + 36, 1, 228, 11, i);
/*    */     
/*    */ 
/* 41 */     double d1 = 21 * this.tile.getBurn() / this.tile.getBurnMax();
/* 42 */     int i1 = (int)d1;
/* 43 */     drawTexturedModalRect(k + 114, l + 25 + 17 - i1, 14, 251 - i1, 17, i1);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\gui\ForgeGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */