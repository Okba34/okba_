/*    */ package fr.paladium.palamod.job;
/*    */ 
/*    */ import cpw.mods.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
/*    */ import cpw.mods.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class EventHandlerJobsNetwork
/*    */ {
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onPlayerJoin(cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent event)
/*    */   {
/* 14 */     String uuid = event.player.getUniqueID().toString();
/* 15 */     if (ModJobs.allJobsXpManager.containsKey(uuid)) {
/* 16 */       ModJobs.allJobsXpManager.remove(uuid);
/*    */     }
/* 18 */     ModJobs.allJobsXpManager.put(uuid, new JobsXPManager(event.player));
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onPlayerLeave(cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent event) {
/* 23 */     String uuid = event.player.getUniqueID().toString();
/* 24 */     if (ModJobs.allJobsXpManager.containsKey(uuid)) {
/* 25 */       ModJobs.allJobsXpManager.remove(uuid);
/*    */     }
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onCraftItem(PlayerEvent.ItemCraftedEvent e)
/*    */   {
/* 32 */     ItemStack itemStack = e.crafting.copy();
/* 33 */     itemStack.stackSize = 1;
/* 34 */     if (LvlItemManager.craftEvents.containsKey(itemStack.getUnlocalizedName())) {
/* 35 */       LvlItem.CraftEvent craftEvent = (LvlItem.CraftEvent)LvlItemManager.craftEvents.get(itemStack.getUnlocalizedName());
/* 36 */       JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(e.player.getUniqueID().toString());
/* 37 */       if (jobs == null) {
/* 38 */         return;
/*    */       }
/* 40 */       if (craftEvent.minLvl > ((Job)ModJobs.jobs.get(Integer.valueOf(craftEvent.job))).getLevel(jobs.getXP(craftEvent.job))) {
/* 41 */         e.craftMatrix.closeInventory();
/* 42 */         e.player.closeScreen();
/* 43 */         e.player.addChatComponentMessage(new net.minecraft.util.ChatComponentText(net.minecraft.util.EnumChatFormatting.DARK_RED + "[PalaMod-Jobs] " + net.minecraft.util.EnumChatFormatting.RED + "Il faut un lvl min dans un jobs pour l'item."));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onFurnace(PlayerEvent.ItemSmeltedEvent e)
/*    */   {
/* 51 */     if ((e.player.getEntityWorld().isRemote) || (XPManager.smeltEvents.get(new ItemCouple(e.smelting.getItem(), e.smelting.getItemDamage()).getAll()) == null)) {
/* 52 */       return;
/*    */     }
/*    */     
/* 55 */     XPItem.SmeltingEvent smeltingEvent = (XPItem.SmeltingEvent)XPManager.smeltEvents.get(new ItemCouple(e.smelting.getItem(), e.smelting.getItemDamage()).getAll());
/* 56 */     if (smeltingEvent != null) {
/* 57 */       smeltingEvent.isEventValid(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onCraftitem(PlayerEvent.ItemCraftedEvent e)
/*    */   {
/* 65 */     if ((e.player.getEntityWorld().isRemote) || 
/* 66 */       (!XPManager.craftEvents.containsKey(new ItemCouple(e.crafting.getItem(), e.crafting.getItemDamage()).getAll()))) {
/* 67 */       return;
/*    */     }
/* 69 */     Boolean regionBool = Boolean.valueOf(false);
/* 70 */     Boolean regionEmpty = Boolean.valueOf(false);
/*    */     
/*    */ 
/* 73 */     if ((regionEmpty.booleanValue()) || (!regionBool.booleanValue())) {
/* 74 */       XPItem.CraftEvent item = (XPItem.CraftEvent)XPManager.craftEvents.get(new ItemCouple(e.crafting.getItem(), e.crafting.getItemDamage()).getAll());
/* 75 */       if (item != null) {
/* 76 */         item.onEvent(e);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.common.eventhandler.SubscribeEvent
/*    */   public void onPickUpItem(cpw.mods.fml.common.gameevent.PlayerEvent.ItemPickupEvent e) {
/* 83 */     ItemStack itemStack = e.pickedUp.getEntityItem().copy();
/* 84 */     itemStack.stackSize = 1;
/* 85 */     if (LvlItemManager.craftEvents.containsKey(itemStack.getUnlocalizedName())) {
/* 86 */       LvlItem.CraftEvent craftEvent = (LvlItem.CraftEvent)LvlItemManager.craftEvents.get(itemStack.getUnlocalizedName());
/* 87 */       JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(e.player.getUniqueID().toString());
/* 88 */       if (jobs == null) {
/* 89 */         return;
/*    */       }
/* 91 */       if (craftEvent.minLvl > ((Job)ModJobs.jobs.get(Integer.valueOf(craftEvent.job))).getLevel(jobs.getXP(craftEvent.job))) {
/* 92 */         e.setCanceled(true);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\job\EventHandlerJobsNetwork.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */