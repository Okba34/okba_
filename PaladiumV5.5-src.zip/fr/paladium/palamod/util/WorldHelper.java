/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class WorldHelper
/*    */ {
/*    */   public static void dropItemStack(World world, ItemStack stack, int x, int y, int z)
/*    */   {
/* 12 */     if (stack != null)
/*    */     {
/* 14 */       float f = world.rand.nextFloat() * 0.8F + 0.1F;
/* 15 */       float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*    */       
/*    */       EntityItem entityitem;
/* 18 */       for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; stack.stackSize > 0; world.spawnEntityInWorld(entityitem))
/*    */       {
/* 20 */         int k1 = world.rand.nextInt(21) + 10;
/* 21 */         if (k1 > stack.stackSize)
/* 22 */           k1 = stack.stackSize;
/* 23 */         stack.stackSize -= k1;
/*    */         
/* 25 */         entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(stack.getItem(), k1, stack.getItemDamage()));
/* 26 */         float f3 = 0.05F;
/* 27 */         entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/* 28 */         entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/* 29 */         entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/* 30 */         if (stack.hasTagCompound()) {
/* 31 */           entityitem.getEntityItem().setTagCompound((net.minecraft.nbt.NBTTagCompound)stack.getTagCompound().copy());
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\WorldHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */