/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockRedstoneOre;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.item.EntityXPOrb;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class ToolHandler
/*     */ {
/*  26 */   protected static ThreadLocal<Boolean> captureDrops = new ThreadLocal()
/*     */   {
/*     */     protected Boolean initialValue() {
/*  29 */       return Boolean.valueOf(false);
/*     */     }
/*     */   };
/*     */   
/*  33 */   protected static ThreadLocal<List<ItemStack>> capturedDrops = new ThreadLocal()
/*     */   {
/*     */     protected List<ItemStack> initialValue() {
/*  36 */       return new ArrayList();
/*     */     }
/*     */   };
/*     */   
/*  40 */   public static Block[] minerals = { WorldRegister.FINDIUM_ORE, Blocks.coal_ore, Blocks.redstone_ore, Blocks.diamond_ore, Blocks.emerald_ore, Blocks.quartz_ore, Blocks.iron_ore, Blocks.lapis_ore, WorldRegister.PALADIUM_ORE, WorldRegister.TITANE_ORE, WorldRegister.AMETHYST_ORE, Blocks.gold_ore, Blocks.lit_redstone_ore };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void removeBlocksInIteration(EntityPlayer player, ItemStack stack, World world, int x, int y, int z, int xs, int ys, int zs, int xe, int ye, int ze, Block block, Material[] materialsListing, boolean smelt, int fortune, boolean dispose, boolean obsidian)
/*     */   {
/*  47 */     float blockHardness = block == null ? 1.0F : block.getBlockHardness(world, x, y, z);
/*     */     
/*  49 */     for (int x1 = xs; x1 < xe; x1++) {
/*  50 */       for (int y1 = ys; y1 < ye; y1++) {
/*  51 */         for (int z1 = zs; z1 < ze; z1++) {
/*  52 */           if ((world.getBlock(x1 + x, y1 + y, z1 + z).isToolEffective("pickaxe", 3)) || ((world.getBlock(x1 + x, y1 + y, z1 + z) instanceof BlockRedstoneOre)) || ((obsidian) && ((world.getBlock(x1 + x, y1 + y, z1 + z) instanceof BlockObsidian)))) {
/*  53 */             removeBlockWithDrops(player, stack, world, x1 + x, y1 + y, z1 + z, x, y, z, world.getBlock(x1 + x, y1 + y, z1 + z), materialsListing, smelt, fortune, blockHardness, dispose, obsidian);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void removeBlockWithDrops(EntityPlayer player, ItemStack stack, World world, int x, int y, int z, int bx, int by, int bz, Block block, Material[] materialsListing, boolean smelt, int fortune, float blockHardness, boolean dispose, boolean obsidian)
/*     */   {
/*  64 */     removeBlockWithDrops(player, stack, world, x, y, z, bx, by, bz, block, materialsListing, smelt, fortune, blockHardness, dispose, true, obsidian);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void removeBlockWithDrops(EntityPlayer player, ItemStack stack, World world, int x, int y, int z, int bx, int by, int bz, Block block, Material[] materialsListing, boolean smelt, int fortune, float blockHardness, boolean dispose, boolean particles, boolean obsidian)
/*     */   {
/*  71 */     if (!world.blockExists(x, y, z)) {
/*  72 */       return;
/*     */     }
/*  74 */     Block blk = world.getBlock(x, y, z);
/*  75 */     int meta = world.getBlockMetadata(x, y, z);
/*     */     
/*  77 */     if ((block != null) && (blk != block)) {
/*  78 */       return;
/*     */     }
/*     */     
/*  81 */     boolean flag = false;
/*  82 */     if ((!world.isRemote) && (blk != null) && (!blk.isAir(world, x, y, z)) && 
/*  83 */       (blk.getPlayerRelativeBlockHardness(player, world, x, y, z) > 0.0F)) {
/*  84 */       if ((!blk.canHarvestBlock(player, meta)) || (!isRightMaterial(blk, materialsListing)) || ((blk == Blocks.obsidian) && (!obsidian))) {
/*  85 */         return;
/*     */       }
/*  87 */       if (!player.capabilities.isCreativeMode) {
/*  88 */         int localMeta = world.getBlockMetadata(x, y, z);
/*  89 */         blk.onBlockHarvested(world, x, y, z, localMeta, player);
/*  90 */         if (blk.removedByPlayer(world, player, x, y, z, true)) {
/*  91 */           blk.onBlockDestroyedByPlayer(world, x, y, z, localMeta);
/*     */         }
/*  93 */         if (smelt) {
/*  94 */           ItemStack result = FurnaceRecipes.smelting().getSmeltingResult(
/*  95 */             (ItemStack)blk.getDrops(world, x, y, z, blk.getDamageValue(world, x, y, z), fortune).get(0));
/*  96 */           if (result == null) {
/*  97 */             blk.dropBlockAsItem(world, x, y, z, localMeta, fortune);
/*     */           } else {
/*  99 */             flag = true;
/* 100 */             ItemStack resultCopy = result.copy();
/* 101 */             float count = 1.0F;
/* 102 */             if ((fortune > 0) && (isMineral(block))) {
/* 103 */               count = 1 + (fortune - world.rand.nextInt(fortune)) / 2;
/*     */             }
/* 105 */             if (count <= 0.0F)
/* 106 */               count = 1.0F;
/* 107 */             resultCopy.stackSize = ((int)count);
/* 108 */             EntityItem entityItem = new EntityItem(world, x, y, z, resultCopy);
/* 109 */             world.spawnEntityInWorld(entityItem);
/*     */           }
/*     */         } else {
/* 112 */           blk.dropBlockAsItem(world, x, y, z, localMeta, fortune);
/*     */         }
/*     */       } else {
/* 115 */         int localMeta = world.getBlockMetadata(x, y, z);
/* 116 */         blk.dropBlockAsItem(world, x, y, z, localMeta, fortune);
/*     */       }
/* 118 */       int xpDrop = blk.getExpDrop(world, blk.getDamageValue(world, x, y, z), fortune);
/* 119 */       EntityXPOrb xp = new EntityXPOrb(world, x, y, z, xpDrop);
/* 120 */       if (xpDrop > 0)
/* 121 */         world.spawnEntityInWorld(xp);
/*     */     } else {
/* 123 */       world.setBlockToAir(x, y, z); }
/* 124 */     world.playAuxSFX(2001, x, y, z, Block.getIdFromBlock(blk) + (meta << 12));
/* 125 */     world.setBlockToAir(x, y, z);
/* 126 */     if (flag) {
/* 127 */       world.spawnParticle("flame", x + 0.5D + 0.5D * world.rand.nextDouble(), y - 0.1D, z + 0.5D * world.rand
/* 128 */         .nextDouble(), 0.0D, 0.0D, 0.0D);
/* 129 */       world.spawnParticle("flame", x + 0.5D + 0.5D * world.rand.nextDouble(), y - 0.1D, z + 0.5D * world.rand
/* 130 */         .nextDouble(), 0.0D, 0.0D, 0.0D);
/* 131 */       world.spawnParticle("smoke", x + 0.5D + 0.5D * world.rand.nextDouble(), y - 0.1D, z + 0.5D * world.rand
/* 132 */         .nextDouble(), 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isMineral(Block block) {
/* 137 */     for (Block b : minerals) {
/* 138 */       if (b == block)
/* 139 */         return true;
/*     */     }
/* 141 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isRightMaterial(Block block, Material[] materialsListing) {
/* 145 */     Material material = block.getMaterial();
/* 146 */     for (Material mat : materialsListing) {
/* 147 */       if (material == mat)
/* 148 */         return true;
/*     */     }
/* 150 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isRightBlock(Block block, Block[] list) {
/* 154 */     for (Block blk : list) {
/* 155 */       if (block == blk)
/* 156 */         return false;
/*     */     }
/* 158 */     return true;
/*     */   }
/*     */   
/*     */   public static MovingObjectPosition raytraceFromEntity(World world, Entity player, boolean par3, double range) {
/* 162 */     float f = 1.0F;
/* 163 */     float f1 = player.prevRotationPitch + (player.rotationPitch - player.prevRotationPitch) * f;
/* 164 */     float f2 = player.prevRotationYaw + (player.rotationYaw - player.prevRotationYaw) * f;
/* 165 */     double d0 = player.prevPosX + (player.posX - player.prevPosX) * f;
/* 166 */     double d1 = player.prevPosY + (player.posY - player.prevPosY) * f;
/* 167 */     if ((!world.isRemote) && ((player instanceof EntityPlayer)))
/* 168 */       d1 += ((EntityPlayer)player).eyeHeight;
/* 169 */     double d2 = player.prevPosZ + (player.posZ - player.prevPosZ) * f;
/* 170 */     Vec3 vec3 = Vec3.createVectorHelper(d0, d1, d2);
/* 171 */     float f3 = MathHelper.cos(-f2 * 0.017453292F - 3.1415927F);
/* 172 */     float f4 = MathHelper.sin(-f2 * 0.017453292F - 3.1415927F);
/* 173 */     float f5 = -MathHelper.cos(-f1 * 0.017453292F);
/* 174 */     float f6 = MathHelper.sin(-f1 * 0.017453292F);
/* 175 */     float f7 = f4 * f5;
/* 176 */     float f8 = f3 * f5;
/* 177 */     double d3 = range;
/* 178 */     Vec3 vec31 = vec3.addVector(f7 * d3, f6 * d3, f8 * d3);
/* 179 */     return world.rayTraceBlocks(vec3, vec31, par3);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\ToolHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */