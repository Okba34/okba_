/*   */ package fr.paladium.palamod.util;
/*   */ 
/*   */ import net.minecraft.util.AxisAlignedBB;
/*   */ 
/*   */ public class AABB extends AxisAlignedBB
/*   */ {
/*   */   public AABB(double minX, double minY, double minZ, double maxX, double maxY, double maxZ)
/*   */   {
/* 9 */     super(minX, minY, minZ, maxX, maxY, maxZ);
/*   */   }
/*   */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\AABB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */