/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ItemStackHelper
/*    */ {
/*    */   @Nullable
/*    */   public static ItemStack getAndSplit(ItemStack[] stacks, int index, int amount)
/*    */   {
/* 12 */     if ((index >= 0) && (index < stacks.length) && (stacks[index] != null) && (amount > 0))
/*    */     {
/* 14 */       ItemStack itemstack = stacks[index].splitStack(amount);
/*    */       
/* 16 */       if (stacks[index].stackSize == 0)
/*    */       {
/* 18 */         stacks[index] = null;
/*    */       }
/*    */       
/* 21 */       return itemstack;
/*    */     }
/*    */     
/*    */ 
/* 25 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public static ItemStack getAndRemove(ItemStack[] stacks, int index)
/*    */   {
/* 32 */     if ((index >= 0) && (index < stacks.length))
/*    */     {
/* 34 */       ItemStack itemstack = stacks[index];
/* 35 */       stacks[index] = null;
/* 36 */       return itemstack;
/*    */     }
/*    */     
/*    */ 
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\ItemStackHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */