/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiPlayerInfo;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.management.ServerConfigurationManager;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PlayerHelper
/*    */ {
/*    */   public static boolean isPlayerOnline(String username)
/*    */   {
/* 21 */     if (FMLCommonHandler.instance().getEffectiveSide().isServer()) {
/* 22 */       return MinecraftServer.getServer().getConfigurationManager().func_152612_a(username) != null;
/*    */     }
/* 24 */     net.minecraft.client.network.NetHandlerPlayClient netclienthandler = Minecraft.getMinecraft().thePlayer.sendQueue;
/* 25 */     List list = netclienthandler.playerInfoList;
/* 26 */     for (int i = 0; i < list.size(); i++) {
/* 27 */       GuiPlayerInfo guiplayerinfo = (GuiPlayerInfo)list.get(i);
/* 28 */       if (guiplayerinfo.name.toLowerCase().equals(username.toLowerCase())) {
/* 29 */         return true;
/*    */       }
/*    */     }
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public static void spawnItemAtPlayer(EntityPlayer player, ItemStack stack) {
/* 36 */     if (!player.worldObj.isRemote) {
/* 37 */       EntityItem entityitem = new EntityItem(player.worldObj, player.posX + 0.5D, player.posY + 0.5D, player.posZ + 0.5D, stack);
/*    */       
/* 39 */       player.worldObj.spawnEntityInWorld(entityitem);
/* 40 */       if (!(player instanceof net.minecraftforge.common.util.FakePlayer)) {
/* 41 */         entityitem.onCollideWithPlayer(player);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static void spawnItemArray(int x, int y, int z, ArrayList<ItemStack> stack, World world) {
/* 47 */     for (int i = 0; i < stack.size(); i++)
/*    */     {
/* 49 */       EntityItem entityitem = new EntityItem(world, x + 0.5D, y + 0.5D, z + 0.5D, (ItemStack)stack.get(i));
/* 50 */       world.spawnEntityInWorld(entityitem);
/*    */     }
/*    */   }
/*    */   
/*    */   public static EntityPlayer getPlayerByName(String name) {
/* 55 */     List<EntityPlayer> players = MinecraftServer.getServer().getConfigurationManager().playerEntityList;
/* 56 */     for (EntityPlayer p : players)
/* 57 */       if (p.getDisplayName().equalsIgnoreCase(name))
/* 58 */         return p;
/* 59 */     return null;
/*    */   }
/*    */   
/*    */   public static boolean hasItem(Item item, EntityPlayer player) {
/* 63 */     for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
/* 64 */       if ((player.inventory.getStackInSlot(i) != null) && (player.inventory.getStackInSlot(i).getItem() == item))
/* 65 */         return true;
/*    */     }
/* 67 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\PlayerHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */