/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ 
/*    */ public class LibObfuscation
/*    */ {
/*  6 */   public static final String[] PARTICLE_TEXTURES = { "particleTextures", "field_110737_b", "b" };
/*    */   
/*    */ 
/*  9 */   public static final String[] TARGET_CLASS = { "targetClass", "field_75307_b", "a" };
/* 10 */   public static final String[] TARGET_ENTITY = { "targetEntity", "field_75309_a", "g" };
/*    */   
/*    */ 
/* 13 */   public static final String[] CLASS_TARGET = { "classTarget", "field_75444_h", "g" };
/*    */   
/*    */ 
/* 16 */   public static final String[] TARGET_ENTITY_CLASS = { "targetEntityClass", "field_75381_h", "i" };
/*    */   
/*    */ 
/* 19 */   public static final String[] TIME_SINCE_IGNITED = { "timeSinceIgnited", "field_70833_d", "bq" };
/*    */   
/*    */ 
/* 22 */   public static final String[] TEXTURE_UPLOADED = { "textureUploaded", "field_110559_g", "i" };
/* 23 */   public static final String[] BUFFERED_IMAGE = { "bufferedImage", "field_110560_d", "g" };
/*    */   
/*    */ 
/* 26 */   public static final String[] IS_IMMUNE_TO_FIRE = { "isImmuneToFire", "field_70178_ae", "ag" };
/*    */   
/*    */ 
/* 29 */   public static final String[] REED_ITEM = { "field_150935_a", "a" };
/*    */   
/*    */ 
/* 32 */   public static final String[] IN_LOVE = { "inLove", "field_70881_d", "bp" };
/*    */   
/*    */ 
/* 35 */   public static final String[] ITEM_IN_USE = { "itemInUse", "field_71074_e", "f" };
/* 36 */   public static final String[] ITEM_IN_USE_COUNT = { "itemInUseCount", "field_71072_f", "g" };
/*    */   
/*    */ 
/* 39 */   public static final String[] IS_BAD_EFFECT = { "isBadEffect", "field_76418_K", "J" };
/*    */   
/*    */ 
/* 42 */   public static final String[] HORSE_JUMP_STRENGTH = { "horseJumpStrength", "field_110271_bv", "bv" };
/* 43 */   public static final String[] HORSE_CHEST = { "horseChest", "field_110296_bG", "bG" };
/*    */   
/*    */ 
/* 46 */   public static final String[] NET_CLIENT_HANDLER = { "netClientHandler", "field_78774_b", "b" };
/* 47 */   public static final String[] CURRENT_GAME_TYPE = { "currentGameType", "field_78779_k", "k" };
/*    */   
/*    */ 
/* 50 */   public static final String[] SPAWN_RANGE = { "spawnRange", "field_98290_m", "m" };
/* 51 */   public static final String[] SPAWN_COUNT = { "spawnCount", "field_98294_i", "i" };
/* 52 */   public static final String[] MAX_NEARBY_ENTITIES = { "maxNearbyEntities", "field_98292_k", "k" };
/* 53 */   public static final String[] MAX_SPAWN_DELAY = { "maxSpawnDelay", "field_98293_h", "h" };
/* 54 */   public static final String[] MIN_SPAWN_DELAY = { "minSpawnDelay", "field_98283_g", "g" };
/* 55 */   public static final String[] POTENTIAL_ENTITY_SPAWNS = { "potentialEntitySpawns", "field_98285_e", "e" };
/*    */   
/*    */ 
/*    */ 
/* 59 */   public static final String[] REMAINING_HIGHLIGHT_TICKS = { "remainingHighlightTicks", "field_92017_k", "r" };
/*    */   
/*    */ 
/*    */ 
/* 63 */   public static final String[] GUI_OPTION_PARENT = { "field_146441_g", "f" };
/*    */   
/*    */ 
/* 66 */   public static final String[] THROWER = { "thrower", "field_70192_c", "g" };
/*    */   
/*    */ 
/* 69 */   public static final String[] THE_SLOT = { "theSlot", "field_147006_u", "u" };
/*    */   
/*    */ 
/* 72 */   public static final String[] INPUT_FIELD = { "inputField", "field_146415_a", "a" };
/* 73 */   public static final String[] COMPLETE_FLAG = { "field_146414_r", "r" };
/*    */   
/*    */ 
/* 76 */   public static final String[] GET_LIVING_SOUND = { "getLivingSound", "func_70639_aQ", "t" };
/*    */   
/*    */ 
/* 79 */   public static final String[] ANIMATION_METADATA = { "animationMetadata", "field_110982_k", "j" };
/*    */   
/*    */ 
/* 82 */   public static final String[] STAR_GL_CALL_LIST = { "starGLCallList", "field_72772_v", "F" };
/* 83 */   public static final String[] GL_SKY_LIST = { "glSkyList", "field_72771_w", "G" };
/* 84 */   public static final String[] GL_SKY_LIST2 = { "glSkyList2", "field_72781_x", "H" };
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\LibObfuscation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */