/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayHelper
/*     */ {
/*  15 */   static Minecraft mc = ;
/*     */   
/*     */   public static void drawTexturedModalRect(int par1, int par2, float z, int par3, int par4, int par5, int par6) {
/*  18 */     drawTexturedModalRect(par1, par2, z, par3, par4, par5, par6, 0.00390625F, 0.00390625F);
/*     */   }
/*     */   
/*     */   public static void drawTexturedModalRect(int par1, int par2, float z, int par3, int par4, int par5, int par6, float f, float f1)
/*     */   {
/*  23 */     Tessellator tessellator = Tessellator.instance;
/*  24 */     tessellator.startDrawingQuads();
/*  25 */     tessellator.addVertexWithUV(par1 + 0, par2 + par6, z, (par3 + 0) * f, (par4 + par6) * f1);
/*  26 */     tessellator.addVertexWithUV(par1 + par5, par2 + par6, z, (par3 + par5) * f, (par4 + par6) * f1);
/*  27 */     tessellator.addVertexWithUV(par1 + par5, par2 + 0, z, (par3 + par5) * f, (par4 + 0) * f1);
/*  28 */     tessellator.addVertexWithUV(par1 + 0, par2 + 0, z, (par3 + 0) * f, (par4 + 0) * f1);
/*  29 */     tessellator.draw();
/*     */   }
/*     */   
/*     */ 
/*     */   public static void renderEntity(int x, int y, int scale, float rotX, float rotY, EntityLivingBase entity, boolean nametag)
/*     */   {
/*  35 */     GL11.glEnable(2903);
/*  36 */     GL11.glPushMatrix();
/*  37 */     GL11.glTranslatef(x, y, 50.0F);
/*  38 */     GL11.glScalef(-scale, scale, scale);
/*  39 */     GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*  40 */     float f2 = entity.renderYawOffset;
/*  41 */     float f3 = entity.rotationYaw;
/*  42 */     float f4 = entity.rotationPitch;
/*  43 */     float f5 = entity.prevRotationYawHead;
/*  44 */     float f6 = entity.rotationYawHead;
/*  45 */     GL11.glRotatef(135.0F, 0.0F, 1.0F, 0.0F);
/*  46 */     GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
/*  47 */     GL11.glRotatef(-(float)Math.atan(rotY / 40.0F) * 20.0F, 1.0F, 0.0F, 0.0F);
/*  48 */     entity.renderYawOffset = ((float)Math.atan(rotX / 40.0F) * 20.0F);
/*  49 */     entity.rotationYaw = ((float)Math.atan(rotX / 40.0F) * 40.0F);
/*  50 */     entity.rotationPitch = (-(float)Math.atan(rotY / 40.0F) * 20.0F);
/*  51 */     entity.rotationYawHead = entity.rotationYaw;
/*  52 */     entity.prevRotationYawHead = entity.rotationYaw;
/*  53 */     GL11.glTranslatef(0.0F, entity.yOffset, 0.0F);
/*  54 */     RenderManager.instance.playerViewY = 180.0F;
/*  55 */     RenderManager.instance.renderEntityWithPosYaw(entity, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
/*  56 */     entity.renderYawOffset = f2;
/*  57 */     entity.rotationYaw = f3;
/*  58 */     entity.rotationPitch = f4;
/*  59 */     entity.prevRotationYawHead = f5;
/*  60 */     entity.rotationYawHead = f6;
/*  61 */     GL11.glPopMatrix();
/*  62 */     GL11.glDisable(32826);
/*  63 */     OpenGlHelper.setActiveTexture(OpenGlHelper.lightmapTexUnit);
/*  64 */     GL11.glDisable(3553);
/*  65 */     OpenGlHelper.setActiveTexture(OpenGlHelper.defaultTexUnit);
/*     */   }
/*     */   
/*     */   public static void drawTexturedQuadFit(double x, double y, double width, double height, double zLevel) {
/*  69 */     Tessellator tessellator = Tessellator.instance;
/*  70 */     tessellator.startDrawingQuads();
/*  71 */     tessellator.addVertexWithUV(x + 0.0D, y + height, zLevel, 0.0D, 1.0D);
/*  72 */     tessellator.addVertexWithUV(x + width, y + height, zLevel, 1.0D, 1.0D);
/*  73 */     tessellator.addVertexWithUV(x + width, y + 0.0D, zLevel, 1.0D, 0.0D);
/*  74 */     tessellator.addVertexWithUV(x + 0.0D, y + 0.0D, zLevel, 0.0D, 0.0D);
/*  75 */     tessellator.draw();
/*     */   }
/*     */   
/*     */   public static void renderFloatingText(String text, float x, float y, float z, int color) {
/*  79 */     RenderManager renderManager = RenderManager.instance;
/*  80 */     FontRenderer fontRenderer = mc.fontRenderer;
/*  81 */     float scale = 0.027F;
/*  82 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
/*  83 */     GL11.glPushMatrix();
/*  84 */     GL11.glTranslatef(x + 0.0F, y + 2.3F, z);
/*  85 */     GL11.glNormal3f(0.0F, 1.0F, 0.0F);
/*  86 */     GL11.glRotatef(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
/*  87 */     GL11.glRotatef(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
/*  88 */     GL11.glScalef(-scale, -scale, scale);
/*  89 */     GL11.glDisable(2896);
/*  90 */     GL11.glDepthMask(false);
/*  91 */     GL11.glDisable(2929);
/*  92 */     GL11.glEnable(3042);
/*  93 */     GL11.glBlendFunc(770, 771);
/*  94 */     Tessellator tessellator = Tessellator.instance;
/*  95 */     int yOffset = 0;
/*     */     
/*  97 */     GL11.glDisable(3553);
/*  98 */     tessellator.startDrawingQuads();
/*  99 */     int stringMiddle = fontRenderer.getStringWidth(text) / 2;
/* 100 */     tessellator.setColorRGBA_F(0.0F, 0.0F, 0.0F, 0.5F);
/* 101 */     tessellator.addVertex(-stringMiddle - 1, -1 + yOffset, 0.0D);
/* 102 */     tessellator.addVertex(-stringMiddle - 1, 8 + yOffset, 0.0D);
/* 103 */     tessellator.addVertex(stringMiddle + 1, 8 + yOffset, 0.0D);
/* 104 */     tessellator.addVertex(stringMiddle + 1, -1 + yOffset, 0.0D);
/* 105 */     tessellator.draw();
/* 106 */     GL11.glEnable(3553);
/* 107 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
/* 108 */     fontRenderer.drawString(text, -fontRenderer.getStringWidth(text) / 2, yOffset, color);
/* 109 */     GL11.glEnable(2929);
/* 110 */     GL11.glDepthMask(true);
/* 111 */     fontRenderer.drawString(text, -fontRenderer.getStringWidth(text) / 2, yOffset, color);
/* 112 */     GL11.glEnable(2896);
/* 113 */     GL11.glDisable(3042);
/* 114 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 115 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\DisplayHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */