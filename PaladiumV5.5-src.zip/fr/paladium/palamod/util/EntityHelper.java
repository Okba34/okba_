/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class EntityHelper
/*    */ {
/*    */   public static void customKnockBack(EntityPlayer player, EntityPlayer attacker, double par3, double par4)
/*    */   {
/* 10 */     double motionY = player.motionY;
/* 11 */     double motionX = player.motionY;
/* 12 */     double motionZ = player.motionY;
/* 13 */     player.isAirBorne = true;
/* 14 */     float f1 = net.minecraft.util.MathHelper.sqrt_double(par3 * par3 + par4 * par4);
/* 15 */     float f2 = 0.4F;
/* 16 */     motionX /= 2.0D;
/* 17 */     motionY /= 2.0D;
/* 18 */     motionZ /= 2.0D;
/* 19 */     motionX -= par3 / f1 * f2;
/* 20 */     motionY += f2;
/* 21 */     player.motionZ -= par4 / f1 * f2;
/* 22 */     if (motionY > 0.4000000059604645D)
/*    */     {
/* 24 */       motionY = 0.4000000059604645D;
/*    */     }
/* 26 */     player.moveEntity(motionX, motionY, motionZ);
/*    */   }
/*    */   
/*    */   public static void knockbackEntity(EntityLivingBase living, double boost)
/*    */   {
/* 31 */     living.motionX *= boost;
/*    */     
/* 33 */     living.motionZ *= boost;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\EntityHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */