/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ 
/*    */ public class GuiDrawer
/*    */ {
/*    */   public static void drawTexturedQuadFit(double x, double y, double width, double height, double zLevel)
/*    */   {
/*  9 */     Tessellator tessellator = Tessellator.instance;
/* 10 */     tessellator.startDrawingQuads();
/* 11 */     tessellator.addVertexWithUV(x + 0.0D, y + height, zLevel, 0.0D, 1.0D);
/* 12 */     tessellator.addVertexWithUV(x + width, y + height, zLevel, 1.0D, 1.0D);
/* 13 */     tessellator.addVertexWithUV(x + width, y + 0.0D, zLevel, 1.0D, 0.0D);
/* 14 */     tessellator.addVertexWithUV(x + 0.0D, y + 0.0D, zLevel, 0.0D, 0.0D);
/* 15 */     tessellator.draw();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\GuiDrawer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */