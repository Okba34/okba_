/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import fr.paladium.palamod.items.weapons.ItemBroadsword;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemSword;
/*    */ 
/*    */ public class SingleItemSlot extends Slot
/*    */ {
/*    */   public SingleItemSlot(IInventory inventory, int index, int xPosition, int yPosition)
/*    */   {
/* 14 */     super(inventory, index, xPosition, yPosition);
/*    */   }
/*    */   
/*    */   public int getSlotStackLimit()
/*    */   {
/* 19 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack itemstack)
/*    */   {
/* 25 */     return ((itemstack.getItem() instanceof ItemSword)) || ((itemstack.getItem() instanceof ItemArmor)) || ((itemstack.getItem() instanceof ItemBroadsword)) || ((itemstack.getItem() instanceof fr.paladium.palamod.items.weapons.ItemFastsword));
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\SingleItemSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */