/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryGuardianMore;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemGuardianUpgrade;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class GuardianHelper
/*    */ {
/* 13 */   public static HashMap<Item, Integer> xpTools = new HashMap();
/*    */   
/*    */   public static boolean checkXPStuff(Item item) {
/* 16 */     if (item == MaterialRegister.PALADIUM_INGOT) {
/* 17 */       return true;
/*    */     }
/* 19 */     if (item == MaterialRegister.FINDIUM) {
/* 20 */       return true;
/*    */     }
/* 22 */     if (item == MaterialRegister.TITANE_INGOT) {
/* 23 */       return true;
/*    */     }
/* 25 */     if (item == MaterialRegister.AMETHYST_INGOT) {
/* 26 */       return true;
/*    */     }
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   public static int getXpFromItem(Item item) {
/* 32 */     if (item == MaterialRegister.PALADIUM_INGOT) {
/* 33 */       return 5;
/*    */     }
/* 35 */     if (item == MaterialRegister.FINDIUM) {
/* 36 */       return 10;
/*    */     }
/* 38 */     if (item == MaterialRegister.TITANE_INGOT) {
/* 39 */       return 2;
/*    */     }
/* 41 */     if (item == MaterialRegister.AMETHYST_INGOT) {
/* 42 */       return 1;
/*    */     }
/* 44 */     return 0;
/*    */   }
/*    */   
/*    */   public static boolean hasUpgrade(EntityGuardianGolem golem, int type) {
/* 48 */     for (int i = 0; i < 3; i++) {
/* 49 */       if (golem.content[i] != null) {
/* 50 */         int typeLoop = ((ItemGuardianUpgrade)golem.content[i].getItem()).getType();
/* 51 */         if (typeLoop == type)
/* 52 */           return true;
/*    */       }
/*    */     }
/* 55 */     InventoryGuardianMore guardianMore = new InventoryGuardianMore(golem);
/* 56 */     for (int i = 0; i < guardianMore.getSizeInventory(); i++) {
/* 57 */       ItemStack stack = guardianMore.getStackInSlot(i);
/* 58 */       if ((stack != null) && (((ItemGuardianUpgrade)stack.getItem()).getType() == type))
/* 59 */         return true;
/*    */     }
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public static ItemStack getWeaponFromUpgrade(ItemStack stack) {
/* 65 */     if (stack == null)
/* 66 */       return null;
/* 67 */     if (!(stack.getItem() instanceof ItemGuardianUpgrade))
/* 68 */       return null;
/* 69 */     if (((ItemGuardianUpgrade)stack.getItem()).getType() != 20) {
/* 70 */       return null;
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\GuardianHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */