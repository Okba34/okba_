/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ 
/*     */ public enum EnumAllowItemsForge
/*     */ {
/*  10 */   IRON_HELMET(Items.iron_helmet, Items.iron_ingot, 5), 
/*  11 */   IRON_CHEST(Items.iron_chestplate, Items.iron_ingot, 8), 
/*  12 */   IRON_LEGGINGS(Items.iron_leggings, Items.iron_ingot, 7), 
/*  13 */   IRON_BOOTS(Items.iron_boots, Items.iron_ingot, 4), 
/*  14 */   IRON_SWORD(Items.iron_sword, Items.iron_ingot, 2), 
/*  15 */   IRON_AXE(Items.iron_axe, Items.iron_ingot, 3), 
/*  16 */   IRON_PICKAXE(Items.iron_pickaxe, Items.iron_ingot, 3), 
/*  17 */   IRON_SHOVEL(Items.iron_shovel, Items.iron_ingot, 1), 
/*     */   
/*  19 */   GOLDEN_HELMET(Items.golden_helmet, Items.gold_ingot, 5), 
/*  20 */   GOLDEN_CHEST(Items.golden_chestplate, Items.gold_ingot, 8), 
/*  21 */   GOLDEN_LEGGINGS(Items.golden_leggings, Items.gold_ingot, 7), 
/*  22 */   GOLDEN_BOOTS(Items.golden_boots, Items.gold_ingot, 4), 
/*  23 */   GOLDEN_SWORD(Items.golden_sword, Items.gold_ingot, 2), 
/*  24 */   GOLDEN_AXE(Items.golden_axe, Items.gold_ingot, 3), 
/*  25 */   GOLDEN_PICKAXE(Items.golden_pickaxe, Items.gold_ingot, 3), 
/*  26 */   GOLDEN_SHOVEL(Items.golden_shovel, Items.gold_ingot, 1), 
/*     */   
/*  28 */   TITANE_HELMET(ModItems.titaneHelmet, MaterialRegister.TITANE_INGOT, 5), 
/*  29 */   TITANE_CHEST(ModItems.titaneChestplate, MaterialRegister.TITANE_INGOT, 8), 
/*  30 */   TITANE_LEGGINGS(ModItems.titaneLeggings, MaterialRegister.TITANE_INGOT, 7), 
/*  31 */   TITANE_BOOTS(ModItems.titaneBoots, MaterialRegister.TITANE_INGOT, 4), 
/*  32 */   TITANE_AXE(ModItems.titaneAxe, MaterialRegister.TITANE_INGOT, 3), 
/*  33 */   TITANE_BROADSWORD(ModItems.titaneBroadsword, MaterialRegister.TITANE_INGOT, 2), 
/*  34 */   TITANE_SHOVEL(ModItems.titaneShovel, MaterialRegister.TITANE_INGOT, 1), 
/*  35 */   TITANE_FASTSWORD(ModItems.titaneFastSword, MaterialRegister.TITANE_INGOT, 2), 
/*  36 */   TITANE_HAMMER(ModItems.titaneHammer, MaterialRegister.TITANE_INGOT, 5), 
/*  37 */   TITANE_PICKAXE(ModItems.titanePickaxe, MaterialRegister.TITANE_INGOT, 3), 
/*  38 */   TITANE_STICK(ModItems.titaneStick, MaterialRegister.TITANE_INGOT, 2), 
/*  39 */   TITANE_SWORD(ModItems.titaneSword, MaterialRegister.TITANE_INGOT, 2), 
/*  40 */   TITANE_COMPRESS(ModItems.compressedTitane, Item.getItemFromBlock(fr.paladium.palamod.decorative.DecorativeRegister.TITANE_BLOCK), 8), 
/*     */   
/*  42 */   AMETHYST_HELMET(ModItems.amethystHelmet, MaterialRegister.AMETHYST_INGOT, 5), 
/*  43 */   AMETHYST_CHEST(ModItems.amethystChestplate, MaterialRegister.AMETHYST_INGOT, 8), 
/*  44 */   AMETHYST_LEGGINGS(ModItems.amethystLeggings, MaterialRegister.AMETHYST_INGOT, 7), 
/*  45 */   AMETHYST_BOOTS(ModItems.amethystBoots, MaterialRegister.AMETHYST_INGOT, 4), 
/*  46 */   AMETHYST_AXE(ModItems.amethystAxe, MaterialRegister.AMETHYST_INGOT, 3), 
/*  47 */   AMETHYST_BROADSWORD(ModItems.amethystBroadsword, MaterialRegister.AMETHYST_INGOT, 2), 
/*  48 */   AMETHYST_SHOVEL(ModItems.amethystShovel, MaterialRegister.AMETHYST_INGOT, 1), 
/*  49 */   AMETHYST_FASTSWORD(ModItems.amethystFastSword, MaterialRegister.AMETHYST_INGOT, 2), 
/*  50 */   AMETHYST_HAMMER(ModItems.amethystHammer, MaterialRegister.AMETHYST_INGOT, 5), 
/*  51 */   AMETHYST_PICKAXE(ModItems.amethystPickaxe, MaterialRegister.AMETHYST_INGOT, 3), 
/*  52 */   AMETHYST_STICK(ModItems.amethystStick, ModItems.amethystStick, 2), 
/*  53 */   AMETHYST_SWORD(ModItems.amethystSword, MaterialRegister.AMETHYST_INGOT, 2), 
/*  54 */   AMETHYST_COMPRESS(ModItems.compressedTitane, Item.getItemFromBlock(fr.paladium.palamod.decorative.DecorativeRegister.AMETHYST_BLOCK), 8), 
/*     */   
/*  56 */   ENDIUM_HELMET(ModItems.endiumHelmet, MaterialRegister.ENDIUM_INGOT, 5), 
/*  57 */   ENDIUM_CHEST(ModItems.endiumChestplate, MaterialRegister.ENDIUM_INGOT, 8), 
/*  58 */   ENDIUM_LEGGINGS(ModItems.endiumLeggings, MaterialRegister.ENDIUM_INGOT, 7), 
/*  59 */   ENDIUM_BOOTS(ModItems.endiumBoots, MaterialRegister.ENDIUM_INGOT, 4), 
/*  60 */   ENDIUM_AXE(ModItems.endiumAxe, MaterialRegister.ENDIUM_INGOT, 3), 
/*     */   
/*  62 */   ENDIUM_PICKAXE(ModItems.endiumPickaxe, MaterialRegister.ENDIUM_INGOT, 3), 
/*  63 */   ENDIUM_SWORD(ModItems.endiumSword, MaterialRegister.ENDIUM_INGOT, 2);
/*     */   
/*  65 */   private Item itemAllowed = null;
/*  66 */   private Item itemDrop = null;
/*  67 */   private int maxDrop = 0;
/*     */   
/*     */   private EnumAllowItemsForge(Item itemAllowed, Item itemDrop, int maxDrop) {
/*  70 */     this.itemAllowed = itemAllowed;
/*  71 */     this.itemDrop = itemDrop;
/*  72 */     this.maxDrop = maxDrop;
/*     */   }
/*     */   
/*     */   public Item getItemAllowed() {
/*  76 */     return this.itemAllowed;
/*     */   }
/*     */   
/*     */   public Item getItemDrop() {
/*  80 */     return this.itemDrop;
/*     */   }
/*     */   
/*     */   public int getMaxDrop() {
/*  84 */     return this.maxDrop;
/*     */   }
/*     */   
/*     */   public static Boolean containItem(Item item) {
/*  88 */     for (EnumAllowItemsForge enumAllowItemsForge : ) {
/*  89 */       if (enumAllowItemsForge.getItemAllowed().equals(item)) {
/*  90 */         return Boolean.valueOf(true);
/*     */       }
/*     */     }
/*  93 */     return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public static EnumAllowItemsForge valuesOf(Item itemAllowed) {
/*  97 */     for (EnumAllowItemsForge enumAllowItemsForge : ) {
/*  98 */       if (enumAllowItemsForge.getItemAllowed().equals(itemAllowed)) {
/*  99 */         return enumAllowItemsForge;
/*     */       }
/*     */     }
/* 102 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\EnumAllowItemsForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */