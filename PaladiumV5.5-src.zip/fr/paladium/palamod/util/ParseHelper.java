/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import fr.paladium.servertools.market.MarketOffer;
/*    */ import java.util.HashMap;
/*    */ import java.util.UUID;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.parser.JSONParser;
/*    */ import org.json.simple.parser.ParseException;
/*    */ 
/*    */ public class ParseHelper
/*    */ {
/*    */   public static HashMap<UUID, MarketOffer> getMarketOfferFromJson(String json) throws ClassCastException
/*    */   {
/* 15 */     JSONParser parser = new JSONParser();
/*    */     
/*    */ 
/*    */ 
/*    */     try
/*    */     {
/* 21 */       jsonEntries = (JSONObject)parser.parse(json);
/*    */     } catch (ParseException e) { JSONObject jsonEntries;
/* 23 */       return new HashMap();
/*    */     }
/*    */     JSONObject jsonEntries;
/* 26 */     HashMap<UUID, MarketOffer> result = new HashMap();
/*    */     
/* 28 */     JSONArray array = (JSONArray)jsonEntries.get("marketOffers");
/* 29 */     for (int i = 0; i < array.size(); i++) {
/* 30 */       JSONObject e = (JSONObject)array.get(i);
/* 31 */       UUID uuid = UUID.fromString((String)e.get("UUID"));
/* 32 */       int type = ((Long)e.get("type")).intValue();
/* 33 */       String player = (String)e.get("player");
/* 34 */       int bid = ((Long)e.get("bid")).intValue();
/* 35 */       int ammount = ((Long)e.get("ammount")).intValue();
/* 36 */       MarketOffer offer = new MarketOffer(uuid, player, type, ammount, bid);
/* 37 */       result.put(uuid, offer);
/*    */     }
/* 39 */     return result;
/*    */   }
/*    */   
/*    */   public static String offerToJson(MarketOffer offer) {
/* 43 */     JSONObject marketObj = new JSONObject();
/* 44 */     marketObj.put("UUID", offer.getIdOffer().toString());
/* 45 */     marketObj.put("type", Integer.valueOf(offer.getType()));
/* 46 */     marketObj.put("player", offer.getPlayerName());
/* 47 */     marketObj.put("bid", Integer.valueOf(offer.getBid()));
/* 48 */     marketObj.put("ammount", Integer.valueOf(offer.getAmmount()));
/* 49 */     return marketObj.toJSONString();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\ParseHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */