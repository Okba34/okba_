/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class ParticlesHandler
/*    */ {
/*    */   public static final int EXPLOSION = 0;
/*    */   
/*    */   public static void generateCustomExplosion(Entity theEntity, int color)
/*    */   {
/* 13 */     EntityFX explosion = new fr.paladium.palamod.client.particles.ExplosionParticles(Minecraft.getMinecraft().getTextureManager(), theEntity.worldObj, theEntity.posX, theEntity.posY, theEntity.posZ, color, color, color);
/* 14 */     Minecraft.getMinecraft().effectRenderer.addEffect(explosion);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\ParticlesHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */