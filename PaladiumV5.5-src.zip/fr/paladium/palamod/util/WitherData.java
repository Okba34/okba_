/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ public class WitherData {
/*   6 */   public boolean nofakewater = false; public boolean nosound = false; public boolean nofly = false; public boolean remote = false;
/*   7 */   public int maxlife = 300;
/*   8 */   public float impactDamage = 1.0F;
/*   9 */   public short angrylevel = 0; public short explosion = 0; public short anvil = 0;
/*     */   
/*     */   public void readNBT(NBTTagCompound tagCompound)
/*     */   {
/*  13 */     this.maxlife = tagCompound.getInteger("maxlife");
/*     */     
/*  15 */     this.nofly = tagCompound.getBoolean("nofly");
/*  16 */     this.nofakewater = tagCompound.getBoolean("nofakewater");
/*  17 */     this.nosound = tagCompound.getBoolean("nosound");
/*  18 */     this.impactDamage = tagCompound.getFloat("impactDamage");
/*  19 */     this.angrylevel = tagCompound.getShort("angrylevel");
/*  20 */     this.explosion = tagCompound.getShort("explosion");
/*  21 */     this.anvil = tagCompound.getShort("anvil");
/*  22 */     this.remote = tagCompound.getBoolean("remote");
/*     */   }
/*     */   
/*     */   public void writeNBT(NBTTagCompound tagCompound)
/*     */   {
/*  27 */     tagCompound.setInteger("maxlife", 100);
/*     */     
/*  29 */     tagCompound.setBoolean("nofly", this.nofly);
/*  30 */     tagCompound.setBoolean("nofakewater", this.nofakewater);
/*  31 */     tagCompound.setBoolean("nosound", this.nosound);
/*  32 */     tagCompound.setFloat("impactDamage", this.impactDamage);
/*  33 */     tagCompound.setShort("angrylevel", this.angrylevel);
/*  34 */     tagCompound.setShort("explosion", this.explosion);
/*  35 */     tagCompound.setShort("anvil", this.anvil);
/*  36 */     tagCompound.setBoolean("remote", this.remote);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract enum WitherUpgrade
/*     */   {
/*  53 */     LIFE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     DAMAGE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */     NOFLY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     NOSOUND, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     NOFAKE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     ANGRY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     EXPLOSION, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     ANVIL, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     REMOTE;
/*     */     
/*     */     private WitherUpgrade() {}
/*     */     
/*     */     public abstract boolean proccesUpgrade(WitherData paramWitherData);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\WitherData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */