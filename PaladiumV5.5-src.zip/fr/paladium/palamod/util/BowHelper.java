/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumBow;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ public class BowHelper
/*     */ {
/*     */   public static final int RANGE = 0;
/*     */   public static final int SPEED = 1;
/*     */   
/*     */   public static int[] getModifiers(ItemStack stack)
/*     */   {
/*  16 */     if ((stack == null) || (!(stack.getItem() instanceof ItemPaladiumBow))) {
/*  17 */       return null;
/*     */     }
/*  19 */     if (!stack.hasTagCompound()) {
/*  20 */       stack.setTagCompound(new NBTTagCompound());
/*  21 */       stack.getTagCompound().setInteger("modifiersammount", 0);
/*     */     }
/*     */     
/*  24 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/*  26 */     if (!tag.hasKey("modifiersarray")) {
/*  27 */       tag.setIntArray("modifiersarray", new int[0]);
/*  28 */       return null;
/*     */     }
/*  30 */     return tag.getIntArray("modifiersarray");
/*     */   }
/*     */   
/*     */   public static void applyModifiers(ItemStack stack, int modifier) {
/*  34 */     if ((stack == null) || (!(stack.getItem() instanceof ItemPaladiumBow))) {
/*  35 */       return;
/*     */     }
/*  37 */     if (!stack.hasTagCompound()) {
/*  38 */       stack.setTagCompound(new NBTTagCompound());
/*  39 */       stack.getTagCompound().setInteger("modifiersammount", 1);
/*     */     }
/*     */     
/*  42 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/*  44 */     if (!tag.hasKey("modifiersarray")) {
/*  45 */       tag.setIntArray("modifiersarray", new int[0]);
/*     */     }
/*     */     
/*  48 */     int[] modifiersArray = tag.getIntArray("modifiersarray");
/*  49 */     int modifiersSzize = modifiersArray.length;
/*  50 */     int[] finalModifiers = new int[modifiersSzize + 1];
/*     */     
/*  52 */     for (int i = 0; i < modifiersSzize; i++) {
/*  53 */       finalModifiers[i] = modifiersArray[i];
/*     */     }
/*     */     
/*  56 */     finalModifiers[modifiersSzize] = modifier;
/*     */     
/*  58 */     tag.setIntArray("modifiersarray", finalModifiers);
/*     */   }
/*     */   
/*     */   public static boolean canApply(ItemStack stack, int type) {
/*  62 */     int[] result = getModifiers(stack);
/*  63 */     if (result == null)
/*  64 */       return true;
/*  65 */     for (int i = 0; i < result.length; i++) {
/*  66 */       if (result[i] == type)
/*  67 */         return false;
/*     */     }
/*  69 */     return true;
/*     */   }
/*     */   
/*     */   public static String getModifierName(int type) {
/*  73 */     switch (type) {
/*     */     case 0: 
/*  75 */       return "§a Range+";
/*     */     case 1: 
/*  77 */       return "§6 Speed+";
/*     */     }
/*  79 */     return ""; }
/*     */   
/*     */   public static Item getItem(int type) { Item arrow;
/*     */     Item arrow;
/*     */     Item arrow;
/*     */     Item arrow;
/*  85 */     Item arrow; switch (type) {
/*     */     case 0: 
/*  87 */       arrow = ModItems.arrowPoison;
/*  88 */       break;
/*     */     case 2: 
/*  90 */       arrow = ModItems.arrowSlowness;
/*  91 */       break;
/*     */     case 3: 
/*  93 */       arrow = ModItems.arrowSwitch;
/*  94 */       break;
/*     */     case 1: 
/*  96 */       arrow = ModItems.arrowWither;
/*  97 */       break;
/*     */     default: 
/*  99 */       arrow = null;
/*     */     }
/*     */     
/* 102 */     return arrow;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\BowHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */