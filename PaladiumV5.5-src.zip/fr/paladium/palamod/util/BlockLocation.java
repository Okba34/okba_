/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ public class BlockLocation
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int z;
/*    */   
/*    */   public BlockLocation(int x, int y, int z) {
/* 10 */     this.x = x;
/* 11 */     this.y = y;
/* 12 */     this.z = z;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 16 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 20 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getZ() {
/* 24 */     return this.z;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 29 */     return "LOCATION BLOCK: (X: " + this.x + ", Y: " + this.y + ", Z: " + this.z + " )";
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 34 */     return ("LOCATION BLOCK: (X: " + this.x + ", Y: " + this.y + ", Z: " + this.z + " )").hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 39 */     if (((obj instanceof BlockLocation)) && 
/* 40 */       (toString().equalsIgnoreCase(obj.toString()))) {
/* 41 */       return true;
/*    */     }
/*    */     
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   public BlockLocation add(int x, int y, int z) {
/* 48 */     return new BlockLocation(this.x + x, this.y + y, this.z + z);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\BlockLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */