/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import fr.paladium.palamod.network.packets.PacketNotification;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class NotificationHelper
/*    */ {
/*    */   public static void sendNotification(EntityPlayer p, String notif)
/*    */   {
/* 10 */     if (!p.worldObj.isRemote) {
/* 11 */       PacketNotification packet = new PacketNotification(notif);
/* 12 */       fr.paladium.palamod.proxy.CommonProxy.packetPipeline.sendTo(packet, p);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\NotificationHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */