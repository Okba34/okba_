/*    */ package fr.paladium.palamod.util;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class RuneItemSlot extends Slot
/*    */ {
/*    */   public RuneItemSlot(IInventory inventory, int index, int xPosition, int yPosition)
/*    */   {
/* 11 */     super(inventory, index, xPosition, yPosition);
/*    */   }
/*    */   
/*    */   public int getSlotStackLimit()
/*    */   {
/* 16 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack itemstack)
/*    */   {
/* 22 */     return itemstack.getItem() instanceof fr.paladium.palamod.items.ItemRune;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\RuneItemSlot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */