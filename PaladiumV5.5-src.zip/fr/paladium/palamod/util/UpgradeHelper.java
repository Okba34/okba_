/*     */ package fr.paladium.palamod.util;
/*     */ 
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumHammer;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumBroadsword;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumFastsword;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpgradeHelper
/*     */ {
/*     */   public static HashMap<Integer, Integer> upgrades;
/*     */   public static HashMap<Integer, Integer> upgradeType;
/*     */   public static final int PHAMMER = 0;
/*     */   public static final int PSWORD = 1;
/*     */   public static final int SMELT = 0;
/*     */   public static final int FORTUNE = 1;
/*     */   public static final int SPEED = 2;
/*     */   public static final int OBSIDIAN = 6;
/*     */   public static final int DAMAGE = 3;
/*     */   public static final int FLAME = 4;
/*     */   public static final int KNOCKBACK = 5;
/*     */   public static final int MORE = 7;
/*     */   
/*     */   public static void init()
/*     */   {
/*  30 */     upgrades = new HashMap();
/*  31 */     upgradeType = new HashMap();
/*     */     
/*  33 */     upgrades.put(Integer.valueOf(1), Integer.valueOf(3));
/*  34 */     upgradeType.put(Integer.valueOf(1), Integer.valueOf(0));
/*     */     
/*  36 */     upgrades.put(Integer.valueOf(0), Integer.valueOf(1));
/*  37 */     upgradeType.put(Integer.valueOf(0), Integer.valueOf(0));
/*     */     
/*  39 */     upgrades.put(Integer.valueOf(2), Integer.valueOf(3));
/*  40 */     upgradeType.put(Integer.valueOf(2), Integer.valueOf(0));
/*     */     
/*  42 */     upgrades.put(Integer.valueOf(6), Integer.valueOf(1));
/*  43 */     upgradeType.put(Integer.valueOf(6), Integer.valueOf(0));
/*     */     
/*  45 */     upgrades.put(Integer.valueOf(3), Integer.valueOf(3));
/*  46 */     upgradeType.put(Integer.valueOf(3), Integer.valueOf(1));
/*     */     
/*  48 */     upgrades.put(Integer.valueOf(4), Integer.valueOf(1));
/*  49 */     upgradeType.put(Integer.valueOf(4), Integer.valueOf(1));
/*     */     
/*  51 */     upgrades.put(Integer.valueOf(5), Integer.valueOf(2));
/*  52 */     upgradeType.put(Integer.valueOf(5), Integer.valueOf(1));
/*     */     
/*  54 */     upgrades.put(Integer.valueOf(7), Integer.valueOf(2));
/*     */   }
/*     */   
/*     */   public static boolean canApplyUpgrade(ItemStack stack, int type, ItemStack tool) {
/*  58 */     if ((getMaxEnchants(tool) <= getEnchants(tool)) && (type != 7)) {
/*  59 */       return false;
/*     */     }
/*     */     
/*  62 */     int toolType = -1;
/*     */     
/*  64 */     if ((tool.getItem() instanceof ItemPaladiumHammer)) {
/*  65 */       toolType = 0;
/*     */     }
/*     */     
/*  68 */     if (((tool.getItem() instanceof ItemPaladiumBroadsword)) || ((tool.getItem() instanceof ItemPaladiumFastsword))) {
/*  69 */       toolType = 1;
/*     */     }
/*     */     
/*  72 */     if (getModifier(tool, type) >= ((Integer)upgrades.get(Integer.valueOf(type))).intValue()) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     if ((upgradeType.containsKey(Integer.valueOf(type))) && (toolType != ((Integer)upgradeType.get(Integer.valueOf(type))).intValue())) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   private static int getEnchants(ItemStack stack) {
/*  84 */     createDefaultNBT(stack);
/*  85 */     NBTTagCompound tag = stack.getTagCompound();
/*  86 */     return tag.getInteger("modifiersammount");
/*     */   }
/*     */   
/*     */   public static int getMaxEnchants(ItemStack stack) {
/*  90 */     createDefaultNBT(stack);
/*  91 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/*  93 */     return tag.getInteger("modifiersmax") + getModifier(stack, 7) * 2;
/*     */   }
/*     */   
/*     */   public static int getModifier(ItemStack stack, int type) {
/*  97 */     createDefaultNBT(stack);
/*  98 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/* 100 */     if (!tag.hasKey("upgradearray")) {
/* 101 */       tag.setIntArray("upgradearray", new int[0]);
/* 102 */       return 0;
/*     */     }
/*     */     
/* 105 */     int[] upgrades = tag.getIntArray("upgradearray");
/* 106 */     for (int i = 0; i < upgrades.length; i += 2) {
/* 107 */       if (upgrades[i] == type) {
/* 108 */         return upgrades[(i + 1)];
/*     */       }
/*     */     }
/*     */     
/* 112 */     return 0;
/*     */   }
/*     */   
/*     */   public static void createDefaultNBT(ItemStack stack) {
/* 116 */     if (!stack.hasTagCompound()) {
/* 117 */       int modifiers = 3;
/* 118 */       if ((stack.getItem() instanceof ItemPaladiumBroadsword)) {
/* 119 */         modifiers = 6;
/*     */       }
/* 121 */       stack.setTagCompound(new NBTTagCompound());
/* 122 */       stack.getTagCompound().setInteger("modifiersammount", 0);
/* 123 */       stack.getTagCompound().setInteger("modifiersmax", modifiers);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void applyUpgrade(ItemStack stack, int type) {
/* 128 */     createDefaultNBT(stack);
/* 129 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/* 131 */     if (!tag.hasKey("upgradearray")) {
/* 132 */       tag.setIntArray("upgradearray", new int[2]);
/* 133 */       return;
/*     */     }
/*     */     
/* 136 */     int[] upgrades = tag.getIntArray("upgradearray");
/* 137 */     for (int i = 0; i < upgrades.length; i += 2) {
/* 138 */       if (upgrades[i] == type) {
/* 139 */         upgrades[(i + 1)] += 1;
/* 140 */         tag.setIntArray("upgradearray", upgrades);
/* 141 */         tag.setInteger("modifiersammount", tag.getInteger("modifiersammount") + 1);
/* 142 */         return;
/*     */       }
/*     */     }
/*     */     
/* 146 */     int[] array = new int[upgrades.length + 2];
/* 147 */     for (int i = 0; i < upgrades.length; i++) {
/* 148 */       array[i] = upgrades[i];
/*     */     }
/*     */     
/* 151 */     array[(array.length - 2)] = type;
/* 152 */     array[(array.length - 1)] = 1;
/* 153 */     tag.setIntArray("upgradearray", array);
/* 154 */     tag.setInteger("modifiersammount", tag.getInteger("modifiersammount") + 1);
/*     */   }
/*     */   
/*     */   public static String getUpgradeName(int type)
/*     */   {
/* 159 */     if (type == 0) {
/* 160 */       return "§3 Smelt";
/*     */     }
/* 162 */     if (type == 1) {
/* 163 */       return "§6 Fortune";
/*     */     }
/* 165 */     if (type == 2) {
/* 166 */       return "§c Speed";
/*     */     }
/* 168 */     if (type == 3) {
/* 169 */       return "§9 Damage";
/*     */     }
/* 171 */     if (type == 4) {
/* 172 */       return "§7 Flame";
/*     */     }
/* 174 */     if (type == 5) {
/* 175 */       return "§2 Knockback";
/*     */     }
/* 177 */     if (type == 6) {
/* 178 */       return "§0 Obsidian";
/*     */     }
/*     */     
/* 181 */     return "";
/*     */   }
/*     */   
/*     */   public static int[] getUpgradeAmmount(ItemStack stack) {
/* 185 */     createDefaultNBT(stack);
/* 186 */     NBTTagCompound tag = stack.getTagCompound();
/*     */     
/* 188 */     if (!tag.hasKey("upgradearray")) {
/* 189 */       tag.setIntArray("upgradearray", new int[0]);
/* 190 */       return null;
/*     */     }
/*     */     
/* 193 */     return tag.getIntArray("upgradearray");
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\util\UpgradeHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */