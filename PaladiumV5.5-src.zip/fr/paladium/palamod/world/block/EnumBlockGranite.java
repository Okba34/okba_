/*    */ package fr.paladium.palamod.world.block;
/*    */ 
/*    */ public enum EnumBlockGranite {
/*  4 */   GRANITE(0, "granite"), 
/*  5 */   GRANITE_SMOOTH(1, "granite_smooth"), 
/*  6 */   DIORITE(2, "diorite"), 
/*  7 */   DIORITE_SMOOTH(3, "diorite_smooth"), 
/*  8 */   ANDESITE(4, "andesite"), 
/*  9 */   ANDESITE_SMOOTH(5, "andesite_smooth");
/*    */   
/*    */   private final int meta;
/*    */   private final String name;
/*    */   
/*    */   private EnumBlockGranite(int meta, String name) {
/* 15 */     this.meta = meta;
/* 16 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getMeta() {
/* 20 */     return this.meta;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 24 */     return this.name;
/*    */   }
/*    */   
/*    */   public static int count() {
/* 28 */     return values().length;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\EnumBlockGranite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */