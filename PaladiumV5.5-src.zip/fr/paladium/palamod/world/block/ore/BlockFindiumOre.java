/*    */ package fr.paladium.palamod.world.block.ore;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.render.effects.FindiumOreFX;
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockFindiumOre extends BaseBlockOre
/*    */ {
/*    */   public BlockFindiumOre(String unlocalizedName)
/*    */   {
/* 14 */     super(unlocalizedName);
/*    */     
/* 16 */     setTickRandomly(true);
/*    */   }
/*    */   
/*    */   public int tickRate(World worldIn)
/*    */   {
/* 21 */     return 30;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void randomDisplayTick(World worldIn, int x, int y, int z, Random r)
/*    */   {
/* 27 */     spawnParticles(worldIn, x, y, z);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   private void spawnParticles(World worldIn, int x, int y, int z) {
/* 32 */     Random random = worldIn.rand;
/*    */     
/* 34 */     double xOff = random.nextFloat();
/* 35 */     double yOff = random.nextFloat();
/* 36 */     double zOff = random.nextFloat();
/*    */     
/* 38 */     switch (random.nextInt(6)) {
/*    */     case 0: 
/* 40 */       xOff = -0.01D;
/* 41 */       break;
/*    */     case 1: 
/* 43 */       yOff = -0.01D;
/* 44 */       break;
/*    */     case 2: 
/* 46 */       xOff = -0.01D;
/* 47 */       break;
/*    */     case 3: 
/* 49 */       zOff = -0.01D;
/* 50 */       break;
/*    */     case 4: 
/* 52 */       xOff = 1.01D;
/* 53 */       break;
/*    */     case 5: 
/* 55 */       yOff = 1.01D;
/* 56 */       break;
/*    */     case 6: 
/* 58 */       zOff = 1.01D;
/*    */     }
/*    */     
/*    */     
/* 62 */     if (fr.paladium.palamod.PalaMod.proxy.shouldAddParticles(random)) {
/* 63 */       FindiumOreFX fx = new FindiumOreFX(worldIn, x + xOff, y + yOff, z + zOff, 0.0F, 0.0F, 0.0F);
/* 64 */       Minecraft.getMinecraft().effectRenderer.addEffect(fx);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\ore\BlockFindiumOre.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */