/*    */ package fr.paladium.palamod.world.block.ore;
/*    */ 
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import fr.paladium.palamod.world.WorldRegister;
/*    */ import java.util.Random;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BaseBlockOre extends BaseBlock
/*    */ {
/*    */   public BaseBlockOre(String unlocalizedName)
/*    */   {
/* 16 */     super(unlocalizedName, net.minecraft.block.material.Material.rock);
/*    */     
/* 18 */     setHarvestLevel("pickaxe", 2);
/*    */   }
/*    */   
/*    */   public Item getItemDropped(int p_149650_1_, Random random, int p_149650_3_)
/*    */   {
/* 23 */     return this == WorldRegister.FINDIUM_ORE ? MaterialRegister.FINDIUM : Item.getItemFromBlock(this);
/*    */   }
/*    */   
/*    */   public int quantityDropped(Random random)
/*    */   {
/* 28 */     return this == WorldRegister.FINDIUM_ORE ? 1 + random.nextInt(2) : 1;
/*    */   }
/*    */   
/*    */   public int quantityDroppedWithBonus(int fortune, Random random)
/*    */   {
/* 33 */     if ((fortune > 0) && (Item.getItemFromBlock(this) != getItemDropped(0, random, fortune))) {
/* 34 */       int j = random.nextInt(fortune + 2) - 1;
/*    */       
/* 36 */       if (j < 0) {
/* 37 */         j = 0;
/*    */       }
/*    */       
/* 40 */       return quantityDropped(random) * (j + 1);
/*    */     }
/*    */     
/* 43 */     return quantityDropped(random);
/*    */   }
/*    */   
/*    */ 
/*    */   public void dropBlockAsItemWithChance(World p_149690_1_, int p_149690_2_, int p_149690_3_, int p_149690_4_, int p_149690_5_, float p_149690_6_, int p_149690_7_)
/*    */   {
/* 49 */     super.dropBlockAsItemWithChance(p_149690_1_, p_149690_2_, p_149690_3_, p_149690_4_, p_149690_5_, p_149690_6_, p_149690_7_);
/*    */   }
/*    */   
/* 52 */   private Random rand = new Random();
/*    */   
/*    */   public int getExpDrop(IBlockAccess p_149690_1_, int p_149690_5_, int p_149690_7_) {
/* 55 */     if (getItemDropped(p_149690_5_, this.rand, p_149690_7_) != Item.getItemFromBlock(this)) {
/* 56 */       int j1 = 0;
/*    */       
/* 58 */       if (this == WorldRegister.FINDIUM_ORE) {
/* 59 */         j1 = MathHelper.getRandomIntegerInRange(this.rand, 2, 5);
/*    */       }
/*    */       
/* 62 */       return j1;
/*    */     }
/* 64 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\ore\BaseBlockOre.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */