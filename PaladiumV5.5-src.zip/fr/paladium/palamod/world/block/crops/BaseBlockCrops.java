/*     */ package fr.paladium.palamod.world.block.crops;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.job.Job;
/*     */ import fr.paladium.palamod.job.JobRegister;
/*     */ import fr.paladium.palamod.job.JobsXPManager;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockBush;
/*     */ import net.minecraft.block.IGrowable;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.GameRules;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.common.util.ForgeDirection;
/*     */ 
/*     */ public class BaseBlockCrops extends BlockBush implements IGrowable
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon[] icons;
/*     */   private String[] textureNames;
/*  40 */   private int lvlmin = 0;
/*     */   
/*     */   public BaseBlockCrops(String unlocalizedName, String[] textureNames, int lvlmin) {
/*  43 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  45 */     setBlockName(this.unlocalizedName);
/*  46 */     setBlockTextureName("palamod:crops/" + textureNames[0]);
/*     */     
/*  48 */     this.textureNames = textureNames;
/*     */     
/*  50 */     setTickRandomly(true);
/*     */     
/*  52 */     float f = 0.5F;
/*  53 */     setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
/*     */     
/*  55 */     setHardness(0.0F);
/*     */     
/*  57 */     setStepSound(Block.soundTypeGrass);
/*     */     
/*  59 */     setCreativeTab((CreativeTabs)null);
/*  60 */     disableStats();
/*  61 */     this.lvlmin = lvlmin;
/*     */   }
/*     */   
/*     */   protected boolean canPlaceBlockOn(Block parBlock)
/*     */   {
/*  66 */     return parBlock == Blocks.farmland;
/*     */   }
/*     */   
/*     */   public boolean removedByPlayer(World world, EntityPlayer player, int x, int y, int z, boolean willHarvest)
/*     */   {
/*  71 */     Job famer = (Job)ModJobs.jobs.get(Integer.valueOf(2));
/*  72 */     if (famer.getLevel(((JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString())).getXP(2)) < this.lvlmin) {
/*  73 */       player.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Il faut etre niveau " + this.lvlmin + " pour utiliser cet item.", new Object[0]));
/*  74 */       return false;
/*     */     }
/*  76 */     return true;
/*     */   }
/*     */   
/*     */   private void incrementGrowStage(World parWorld, Random parRand, int parX, int parY, int parZ) {
/*  80 */     int growStage = parWorld.getBlockMetadata(parX, parY, parZ) + MathHelper.getRandomIntegerInRange(parRand, 2, 5);
/*     */     
/*  82 */     if (growStage > this.icons.length - 1) {
/*  83 */       growStage = this.icons.length - 1;
/*     */     }
/*     */     
/*  86 */     parWorld.setBlockMetadataWithNotify(parX, parY, parZ, growStage, 2);
/*     */   }
/*     */   
/*     */   public int quantityDropped(Random p_149745_1_)
/*     */   {
/*  91 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune)
/*     */   {
/*  98 */     ArrayList<ItemStack> ret = super.getDrops(world, x, y, z, metadata, fortune);
/*  99 */     if (metadata == this.icons.length - 1) {
/* 100 */       if (this == WorldRegister.EGGPLANT_CROP) {
/* 101 */         int random = (int)(Math.random() * 10000.0D);
/* 102 */         if (random <= 400) {
/* 103 */           ret.add(new ItemStack(MaterialRegister.AMETHYST_INGOT));
/*     */         }
/*     */         else {
/* 106 */           ret.add(new ItemStack(WorldRegister.EGGPLANT));
/*     */         }
/* 108 */         ret.add(new ItemStack(WorldRegister.EGGPLANT_SEED));
/*     */       }
/* 110 */       else if (this == WorldRegister.CHERVIL_CROP) {
/* 111 */         int random = (int)(Math.random() * 10000.0D);
/* 112 */         if (random <= 300) {
/* 113 */           ret.add(new ItemStack(MaterialRegister.TITANE_INGOT));
/*     */         }
/* 115 */         ret.add(new ItemStack(WorldRegister.CHERVIL_SEED));
/*     */       }
/* 117 */       else if (this == WorldRegister.KIWANO_CROP) {
/* 118 */         int random = (int)(Math.random() * 10000.0D);
/* 119 */         if (random <= 75) {
/* 120 */           ret.add(new ItemStack(MaterialRegister.PALADIUM_INGOT));
/*     */         }
/*     */         else {
/* 123 */           ret.add(new ItemStack(WorldRegister.KIWANO));
/*     */         }
/* 125 */         ret.add(new ItemStack(WorldRegister.KIWANO_SEED));
/*     */       }
/* 127 */       else if (this == WorldRegister.ORANGEBLUE_CROP) {
/* 128 */         int random = (int)(Math.random() * 10000.0D);
/* 129 */         if (random <= 50) {
/* 130 */           ret.add(new ItemStack(JobRegister.NUGGET_ENDIUM));
/*     */         }
/*     */         else {
/* 133 */           ret.add(new ItemStack(WorldRegister.ORANGEBLUE));
/*     */         }
/* 135 */         int r = (int)(Math.random() * 10.0D);
/* 136 */         if (r <= 1) {
/* 137 */           ret.add(new ItemStack(WorldRegister.ORANGEBLUE_SEED));
/*     */         }
/*     */       }
/*     */     }
/* 141 */     return ret;
/*     */   }
/*     */   
/*     */   public int getRenderType()
/*     */   {
/* 146 */     return 1;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iconRegister)
/*     */   {
/* 152 */     this.icons = new IIcon[this.textureNames.length - 1];
/* 153 */     for (int i = 0; i < this.icons.length; i++) {
/* 154 */       this.icons[i] = iconRegister.registerIcon("palamod:crops/" + this.textureNames[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/* 161 */     return this.icons[metadata];
/*     */   }
/*     */   
/*     */   public void updateTick(World p_149674_1_, int p_149674_2_, int p_149674_3_, int p_149674_4_, Random p_149674_5_)
/*     */   {
/* 166 */     super.updateTick(p_149674_1_, p_149674_2_, p_149674_3_, p_149674_4_, p_149674_5_);
/*     */     
/* 168 */     if (p_149674_1_.getBlockLightValue(p_149674_2_, p_149674_3_ + 1, p_149674_4_) >= 9) {
/* 169 */       int l = p_149674_1_.getBlockMetadata(p_149674_2_, p_149674_3_, p_149674_4_);
/*     */       
/* 171 */       if (l < this.icons.length - 1) {
/* 172 */         float f = func_149864_n(p_149674_1_, p_149674_2_, p_149674_3_, p_149674_4_);
/*     */         
/* 174 */         if (p_149674_5_.nextInt((int)(25.0F / f) + 1) == 0) {
/* 175 */           l++;
/* 176 */           p_149674_1_.setBlockMetadataWithNotify(p_149674_2_, p_149674_3_, p_149674_4_, l, 2);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private float func_149864_n(World p_149864_1_, int p_149864_2_, int p_149864_3_, int p_149864_4_) {
/* 183 */     float f = 1.0F;
/* 184 */     Block block = p_149864_1_.getBlock(p_149864_2_, p_149864_3_, p_149864_4_ - 1);
/* 185 */     Block block1 = p_149864_1_.getBlock(p_149864_2_, p_149864_3_, p_149864_4_ + 1);
/* 186 */     Block block2 = p_149864_1_.getBlock(p_149864_2_ - 1, p_149864_3_, p_149864_4_);
/* 187 */     Block block3 = p_149864_1_.getBlock(p_149864_2_ + 1, p_149864_3_, p_149864_4_);
/* 188 */     Block block4 = p_149864_1_.getBlock(p_149864_2_ - 1, p_149864_3_, p_149864_4_ - 1);
/* 189 */     Block block5 = p_149864_1_.getBlock(p_149864_2_ + 1, p_149864_3_, p_149864_4_ - 1);
/* 190 */     Block block6 = p_149864_1_.getBlock(p_149864_2_ + 1, p_149864_3_, p_149864_4_ + 1);
/* 191 */     Block block7 = p_149864_1_.getBlock(p_149864_2_ - 1, p_149864_3_, p_149864_4_ + 1);
/* 192 */     boolean flag = (block2 == this) || (block3 == this);
/* 193 */     boolean flag1 = (block == this) || (block1 == this);
/* 194 */     boolean flag2 = (block4 == this) || (block5 == this) || (block6 == this) || (block7 == this);
/*     */     
/* 196 */     for (int l = p_149864_2_ - 1; l <= p_149864_2_ + 1; l++) {
/* 197 */       for (int i1 = p_149864_4_ - 1; i1 <= p_149864_4_ + 1; i1++) {
/* 198 */         float f1 = 0.0F;
/*     */         
/* 200 */         if (p_149864_1_.getBlock(l, p_149864_3_ - 1, i1).canSustainPlant(p_149864_1_, l, p_149864_3_ - 1, i1, ForgeDirection.UP, this)) {
/* 201 */           f1 = 1.0F;
/*     */           
/* 203 */           if (p_149864_1_.getBlock(l, p_149864_3_ - 1, i1).isFertile(p_149864_1_, l, p_149864_3_ - 1, i1)) {
/* 204 */             f1 = 3.0F;
/*     */           }
/*     */         }
/*     */         
/* 208 */         if ((l != p_149864_2_) || (i1 != p_149864_4_)) {
/* 209 */           f1 /= 4.0F;
/*     */         }
/*     */         
/* 212 */         f += f1;
/*     */       }
/*     */     }
/*     */     
/* 216 */     if ((flag2) || ((flag) && (flag1))) {
/* 217 */       f /= 2.0F;
/*     */     }
/*     */     
/* 220 */     return f;
/*     */   }
/*     */   
/*     */   public void onFallenUpon(World p_149746_1_, int p_149746_2_, int p_149746_3_, int p_149746_4_, Entity p_149746_5_, float p_149746_6_)
/*     */   {
/* 225 */     if ((!p_149746_1_.isRemote) && (p_149746_1_.rand.nextFloat() < p_149746_6_ - 0.5F)) {
/* 226 */       if ((!(p_149746_5_ instanceof EntityPlayer)) && (!p_149746_1_.getGameRules().getGameRuleBooleanValue("mobGriefing"))) {
/* 227 */         return;
/*     */       }
/* 229 */       p_149746_1_.setBlock(p_149746_2_, p_149746_3_, p_149746_4_, Blocks.dirt);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean func_149851_a(World parWorld, int parX, int parY, int parZ, boolean p_149851_5_)
/*     */   {
/* 235 */     return parWorld.getBlockMetadata(parX, parY, parZ) != this.icons.length - 1;
/*     */   }
/*     */   
/*     */   public boolean func_149852_a(World p_149852_1_, Random p_149852_2_, int p_149852_3_, int p_149852_4_, int p_149852_5_)
/*     */   {
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   public void func_149853_b(World parWorld, Random parRand, int parX, int parY, int parZ)
/*     */   {
/* 245 */     incrementGrowStage(parWorld, parRand, parX, parY, parZ);
/*     */   }
/*     */   
/*     */   public EnumPlantType getPlantType(IBlockAccess world, int x, int y, int z)
/*     */   {
/* 250 */     return EnumPlantType.Crop;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\crops\BaseBlockCrops.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */