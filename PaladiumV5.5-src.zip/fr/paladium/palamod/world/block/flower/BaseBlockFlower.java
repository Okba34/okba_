/*    */ package fr.paladium.palamod.world.block.flower;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockBush;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ 
/*    */ public class BaseBlockFlower extends BlockBush
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   
/*    */   public BaseBlockFlower(String unlocalizedName)
/*    */   {
/* 19 */     super(Material.plants);
/*    */     
/* 21 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 23 */     setBlockName(this.unlocalizedName);
/* 24 */     setBlockTextureName("palamod:flowers/" + this.unlocalizedName);
/*    */     
/* 26 */     setBlockBounds(0.3F, 0.0F, 0.3F, 0.8F, 1.0F, 0.8F);
/*    */     
/* 28 */     setHardness(0.0F);
/*    */     
/* 30 */     setStepSound(Block.soundTypeGrass);
/*    */     
/* 32 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean isShearable(ItemStack item, IBlockAccess world, int x, int y, int z) {
/* 36 */     return true;
/*    */   }
/*    */   
/*    */   public ArrayList<ItemStack> onSheared(ItemStack item, IBlockAccess world, int x, int y, int z, int fortune) {
/* 40 */     ArrayList<ItemStack> ret = new ArrayList();
/* 41 */     ret.add(new ItemStack(this, 1));
/*    */     
/* 43 */     return ret;
/*    */   }
/*    */   
/*    */   public Item getItemDropped(int p_149650_1_, Random p_149650_2_, int p_149650_3_)
/*    */   {
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public int quantityDropped(Random p_149745_1_)
/*    */   {
/* 53 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\flower\BaseBlockFlower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */