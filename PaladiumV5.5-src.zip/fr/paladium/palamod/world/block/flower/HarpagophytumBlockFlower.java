/*    */ package fr.paladium.palamod.world.block.flower;
/*    */ 
/*    */ import fr.paladium.palamod.tiles.TileHarpagophytumFlower;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class HarpagophytumBlockFlower extends BaseBlockFlower implements net.minecraft.block.ITileEntityProvider
/*    */ {
/*    */   public HarpagophytumBlockFlower(String unlocalizedName)
/*    */   {
/* 10 */     super(unlocalizedName);
/*    */   }
/*    */   
/*    */   public net.minecraft.tileentity.TileEntity createNewTileEntity(World world, int metadata)
/*    */   {
/* 15 */     return new TileHarpagophytumFlower();
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity()
/*    */   {
/* 20 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\flower\HarpagophytumBlockFlower.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */