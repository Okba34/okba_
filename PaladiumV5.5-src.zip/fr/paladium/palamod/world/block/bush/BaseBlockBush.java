/*     */ package fr.paladium.palamod.world.block.bush;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.world.model.BlockBushRender;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockLeavesBase;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.common.util.FakePlayer;
/*     */ 
/*     */ public class BaseBlockBush extends BlockLeavesBase implements net.minecraftforge.common.IPlantable
/*     */ {
/*     */   private String unlocalizedName;
/*     */   private IIcon[] fastIcons;
/*     */   private IIcon[] fancyIcons;
/*     */   private String[] textureNames;
/*     */   
/*     */   public BaseBlockBush(String unlocalizedName, String[] textureNames)
/*     */   {
/*  37 */     super(Material.leaves, false);
/*     */     
/*  39 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  41 */     setBlockName(this.unlocalizedName);
/*  42 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*     */     
/*  44 */     this.textureNames = textureNames;
/*     */     
/*  46 */     setTickRandomly(true);
/*     */     
/*  48 */     setHardness(0.3F);
/*  49 */     setStepSound(Block.soundTypeGrass);
/*     */     
/*  51 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iconRegister)
/*     */   {
/*  57 */     this.fastIcons = new IIcon[this.textureNames.length];
/*  58 */     this.fancyIcons = new IIcon[this.textureNames.length];
/*     */     
/*  60 */     for (int i = 0; i < this.fastIcons.length; i++) {
/*  61 */       if (this.textureNames[i] != "") {
/*  62 */         this.fastIcons[i] = iconRegister.registerIcon("palamod:crops/" + this.textureNames[i] + "_fast");
/*  63 */         this.fancyIcons[i] = iconRegister.registerIcon("palamod:crops/" + this.textureNames[i] + "_fancy");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/*  70 */     setGraphicsLevel(Minecraft.getMinecraft().gameSettings.fancyGraphics);
/*     */     
/*  72 */     if (this.field_150121_P) {
/*  73 */       if (metadata < 12) {
/*  74 */         return this.fancyIcons[(metadata % 4)];
/*     */       }
/*     */       
/*  77 */       return this.fancyIcons[(metadata % 4 + 4)];
/*     */     }
/*     */     
/*     */ 
/*  81 */     if (metadata < 12) {
/*  82 */       return this.fastIcons[(metadata % 4)];
/*     */     }
/*     */     
/*  85 */     return this.fastIcons[(metadata % 4 + 4)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int damageDropped(int metadata)
/*     */   {
/*  92 */     return metadata % 4;
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z)
/*     */   {
/*  97 */     int l = world.getBlockMetadata(x, y, z);
/*  98 */     if (l < 4) {
/*  99 */       return AxisAlignedBB.getBoundingBox(x + 0.25D, y, z + 0.25D, x + 0.75D, y + 0.5D, z + 0.75D);
/*     */     }
/* 101 */     if (l < 8) {
/* 102 */       return AxisAlignedBB.getBoundingBox(x + 0.125D, y, z + 0.125D, x + 0.875D, y + 0.75D, z + 0.875D);
/*     */     }
/*     */     
/* 105 */     return AxisAlignedBB.getBoundingBox(x + 0.0625D, y, z + 0.0625D, x + 0.9375D, y + 0.9375D, z + 0.9375D);
/*     */   }
/*     */   
/*     */ 
/*     */   public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int x, int y, int z)
/*     */   {
/* 111 */     int l = world.getBlockMetadata(x, y, z);
/* 112 */     if (l < 4) {
/* 113 */       return AxisAlignedBB.getBoundingBox(x + 0.25D, y, z + 0.25D, x + 0.75D, y + 0.5D, z + 0.75D);
/*     */     }
/* 115 */     if (l < 8) {
/* 116 */       return AxisAlignedBB.getBoundingBox(x + 0.125D, y, z + 0.125D, x + 0.875D, y + 0.75D, z + 0.875D);
/*     */     }
/*     */     
/* 119 */     return AxisAlignedBB.getBoundingBox(x, y, z, x + 1.0D, y + 1.0D, z + 1.0D);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBlockBoundsBasedOnState(IBlockAccess iblockaccess, int x, int y, int z)
/*     */   {
/* 125 */     int md = iblockaccess.getBlockMetadata(x, y, z);
/*     */     
/*     */ 
/* 128 */     float minY = 0.0F;
/*     */     float maxY;
/*     */     float minZ;
/*     */     float minX;
/*     */     float maxZ;
/*     */     float maxX;
/* 134 */     float maxY; if (md < 4) { float minZ;
/* 135 */       float minX = minZ = 0.25F;
/* 136 */       float maxZ; float maxX = maxZ = 0.75F;
/* 137 */       maxY = 0.5F;
/*     */     } else {
/*     */       float maxY;
/* 140 */       if (md < 8) { float minZ;
/* 141 */         float minX = minZ = 0.125F;
/* 142 */         float maxZ; float maxX = maxZ = 0.875F;
/* 143 */         maxY = 0.75F;
/*     */       }
/*     */       else
/*     */       {
/* 147 */         minX = minZ = 0.0F;
/* 148 */         maxX = maxZ = 1.0F;
/* 149 */         maxY = 1.0F;
/*     */       }
/*     */     }
/*     */     
/* 153 */     setBlockBounds(minX, minY, minZ, maxX, maxY, maxZ);
/*     */   }
/*     */   
/*     */   public void onBlockClicked(World world, int x, int y, int z, EntityPlayer player)
/*     */   {
/* 158 */     harvest(world, x, y, z, player);
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int par6, float par7, float par8, float par9)
/*     */   {
/* 163 */     return harvest(world, x, y, z, player);
/*     */   }
/*     */   
/*     */   protected boolean harvest(World world, int x, int y, int z, EntityPlayer player) {
/* 167 */     return false;
/*     */   }
/*     */   
/*     */   protected void spawnItemAtPlayer(EntityPlayer player, ItemStack stack) {
/* 171 */     if (!player.worldObj.isRemote) {
/* 172 */       if (((player instanceof FakePlayer)) || (!player.inventory.addItemStackToInventory(stack))) {
/* 173 */         EntityItem entityitem = new EntityItem(player.worldObj, player.posX + 0.5D, player.posY + 0.5D, player.posZ + 0.5D, stack);
/* 174 */         player.worldObj.spawnEntityInWorld(entityitem);
/*     */         
/* 176 */         if (!(player instanceof FakePlayer)) {
/* 177 */           entityitem.onCollideWithPlayer(player);
/*     */         }
/*     */         
/*     */       }
/* 181 */       else if ((player instanceof net.minecraft.entity.player.EntityPlayerMP)) {
/* 182 */         player.inventoryContainer.detectAndSendChanges();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOpaqueCube()
/*     */   {
/* 190 */     return false;
/*     */   }
/*     */   
/*     */   private void setGraphicsLevel(boolean flag) {
/* 194 */     this.field_150121_P = flag;
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock()
/*     */   {
/* 199 */     return false;
/*     */   }
/*     */   
/*     */   public int getRenderType()
/*     */   {
/* 204 */     return BlockBushRender.model;
/*     */   }
/*     */   
/*     */   public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int x, int y, int z, int meta)
/*     */   {
/* 209 */     if ((meta > 7) || (this.field_150121_P)) {
/* 210 */       return super.shouldSideBeRendered(iblockaccess, x, y, z, meta);
/*     */     }
/*     */     
/* 213 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateTick(World world, int x, int y, int z, Random r)
/*     */   {
/* 219 */     if (world.isRemote) {
/* 220 */       return;
/*     */     }
/*     */     
/* 223 */     if (r.nextInt(20) == 0) {
/* 224 */       int meta = world.getBlockMetadata(x, y, z);
/* 225 */       if ((meta % 4 == 1) && 
/* 226 */         (meta < 12)) {
/* 227 */         world.setBlock(x, y, z, this, meta + 4, 3);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canPlaceBlockAt(World p_149742_1_, int p_149742_2_, int p_149742_3_, int p_149742_4_)
/*     */   {
/* 235 */     return (super.canPlaceBlockAt(p_149742_1_, p_149742_2_, p_149742_3_, p_149742_4_)) && (World.doesBlockHaveSolidTopSurface(p_149742_1_, p_149742_2_, p_149742_3_ - 1, p_149742_4_));
/*     */   }
/*     */   
/*     */   public void onNeighborBlockChange(World p_149695_1_, int p_149695_2_, int p_149695_3_, int p_149695_4_, Block p_149695_5_)
/*     */   {
/* 240 */     func_150090_e(p_149695_1_, p_149695_2_, p_149695_3_, p_149695_4_);
/*     */   }
/*     */   
/*     */   private boolean func_150090_e(World p_150090_1_, int p_150090_2_, int p_150090_3_, int p_150090_4_) {
/* 244 */     if (!canBlockStay(p_150090_1_, p_150090_2_, p_150090_3_, p_150090_4_)) {
/* 245 */       dropBlockAsItem(p_150090_1_, p_150090_2_, p_150090_3_, p_150090_4_, p_150090_1_.getBlockMetadata(p_150090_2_, p_150090_3_, p_150090_4_), 0);
/* 246 */       p_150090_1_.setBlockToAir(p_150090_2_, p_150090_3_, p_150090_4_);
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canBlockStay(World p_149718_1_, int p_149718_2_, int p_149718_3_, int p_149718_4_)
/*     */   {
/* 256 */     return !p_149718_1_.isAirBlock(p_149718_2_, p_149718_3_ - 1, p_149718_4_);
/*     */   }
/*     */   
/*     */   public EnumPlantType getPlantType(IBlockAccess world, int x, int y, int z)
/*     */   {
/* 261 */     return EnumPlantType.Cave;
/*     */   }
/*     */   
/*     */   public Block getPlant(IBlockAccess world, int x, int y, int z)
/*     */   {
/* 266 */     return this;
/*     */   }
/*     */   
/*     */   public int getPlantMetadata(IBlockAccess world, int x, int y, int z)
/*     */   {
/* 271 */     return world.getBlockMetadata(x, y, z) - 4;
/*     */   }
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity)
/*     */   {
/* 276 */     if (!(entity instanceof EntityItem)) {
/* 277 */       entity.attackEntityFrom(DamageSource.cactus, 1.0F);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\bush\BaseBlockBush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */