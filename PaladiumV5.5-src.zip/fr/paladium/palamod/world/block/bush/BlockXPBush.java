/*    */ package fr.paladium.palamod.world.block.bush;
/*    */ 
/*    */ import fr.paladium.palamod.world.WorldRegister;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockXPBush extends BaseBlockBush
/*    */ {
/*    */   private Random random;
/*    */   
/*    */   public BlockXPBush(String unlocalizedName, String[] textureNames)
/*    */   {
/* 14 */     super(unlocalizedName, textureNames);
/*    */     
/* 16 */     this.random = new Random();
/*    */   }
/*    */   
/*    */   protected boolean harvest(World world, int x, int y, int z, EntityPlayer player)
/*    */   {
/* 21 */     int meta = world.getBlockMetadata(x, y, z);
/*    */     
/* 23 */     if (meta >= 12) {
/* 24 */       if (world.isRemote) {
/* 25 */         return true;
/*    */       }
/*    */       
/* 28 */       world.setBlock(x, y, z, this, meta - 4, 3);
/* 29 */       spawnItemAtPlayer(player, new net.minecraft.item.ItemStack(WorldRegister.XP_BERRY, this.random.nextInt(3) + 1));
/*    */     }
/*    */     
/* 32 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\bush\BlockXPBush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */