/*    */ package fr.paladium.palamod.world.block;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.IIcon;
/*    */ 
/*    */ public class BlockGranite extends BaseBlock
/*    */ {
/*    */   public IIcon[] icons;
/*    */   
/*    */   public BlockGranite(String unlocalizedName)
/*    */   {
/* 20 */     super(unlocalizedName, Material.rock);
/*    */     
/* 22 */     setHardness(1.5F);
/* 23 */     setResistance(10.0F);
/*    */     
/* 25 */     setHarvestLevel("pickaxe", 1);
/*    */   }
/*    */   
/*    */   public void registerBlockIcons(IIconRegister iconRegister)
/*    */   {
/* 30 */     this.icons = new IIcon[EnumBlockGranite.count()];
/*    */     
/* 32 */     for (EnumBlockGranite block : EnumBlockGranite.values()) {
/* 33 */       this.icons[block.getMeta()] = iconRegister.registerIcon("palamod:stone_" + block.getName() + "_block");
/*    */     }
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public IIcon getIcon(int side, int meta)
/*    */   {
/* 40 */     if ((meta >= 0) && (meta < EnumBlockGranite.count())) {
/* 41 */       return this.icons[meta];
/*    */     }
/* 43 */     return this.icons[0];
/*    */   }
/*    */   
/*    */   public int damageDropped(int meta)
/*    */   {
/* 48 */     return meta;
/*    */   }
/*    */   
/*    */   public void getSubBlocks(Item item, CreativeTabs tab, List list)
/*    */   {
/* 53 */     for (EnumBlockGranite block : ) {
/* 54 */       list.add(new ItemStack(item, 1, block.getMeta()));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\block\BlockGranite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */