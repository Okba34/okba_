/*     */ package fr.paladium.palamod.world;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.RenderingRegistry;
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fr.paladium.palamod.library.Register;
/*     */ import fr.paladium.palamod.library.item.BaseItemFood;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.world.block.BlockGranite;
/*     */ import fr.paladium.palamod.world.block.EnumBlockGranite;
/*     */ import fr.paladium.palamod.world.block.bush.BlockXPBush;
/*     */ import fr.paladium.palamod.world.block.crops.BaseBlockCrops;
/*     */ import fr.paladium.palamod.world.block.flower.BaseBlockFlower;
/*     */ import fr.paladium.palamod.world.block.flower.HarpagophytumBlockFlower;
/*     */ import fr.paladium.palamod.world.block.ore.BaseBlockOre;
/*     */ import fr.paladium.palamod.world.block.ore.BlockFindiumOre;
/*     */ import fr.paladium.palamod.world.item.BaseItemBerry;
/*     */ import fr.paladium.palamod.world.item.ItemBlockGranite;
/*     */ import fr.paladium.palamod.world.item.seed.BaseItemSeed;
/*     */ import fr.paladium.palamod.world.model.BlockBushRender;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldRegister
/*     */   extends Register
/*     */ {
/*     */   public static BaseBlockOre PALADIUM_ORE;
/*     */   public static BaseBlockOre PALADIUM_GREEN_ORE;
/*     */   public static BaseBlockOre TITANE_ORE;
/*     */   public static BaseBlockOre AMETHYST_ORE;
/*     */   public static BlockFindiumOre FINDIUM_ORE;
/*     */   public static BlockGranite GRANITE_BLOCK;
/*     */   public static BaseItemBerry XP_BERRY;
/*     */   public static BlockXPBush XP_BERRY_BUSH;
/*     */   public static BaseBlockFlower ABSINTHE_FLOWER;
/*     */   public static BaseBlockFlower ACTAEAPACHYPODA_FLOWER;
/*     */   public static BaseBlockFlower CLATHRUSARCHERI_FLOWER;
/*     */   public static BaseBlockFlower ENDIUM_FLOWER;
/*     */   public static BaseBlockFlower PALADIUM_FLOWER;
/*     */   public static BaseBlockFlower HARPAGOPHYTUM_FLOWER;
/*     */   public static BaseBlockFlower MINT_FLOWER;
/*     */   public static BaseBlockFlower ORTIE_FLOWER;
/*     */   public static BaseBlockFlower SAUGE_FLOWER;
/*     */   public static BaseBlockFlower TREFLE_FLOWER;
/*     */   public static BaseBlockCrops EGGPLANT_CROP;
/*     */   public static BaseItemSeed EGGPLANT_SEED;
/*     */   public static BaseItemFood EGGPLANT;
/*     */   public static BaseBlockCrops CHERVIL_CROP;
/*     */   public static BaseItemSeed CHERVIL_SEED;
/*     */   public static BaseBlockCrops KIWANO_CROP;
/*     */   public static BaseItemSeed KIWANO_SEED;
/*     */   public static BaseItemFood KIWANO;
/*     */   public static BaseBlockCrops ORANGEBLUE_CROP;
/*     */   public static BaseItemSeed ORANGEBLUE_SEED;
/*     */   public static BaseItemFood ORANGEBLUE;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/*  68 */     register();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init(FMLInitializationEvent event)
/*     */   {
/*  75 */     if (event.getSide().isClient()) {
/*  76 */       registerRenderer();
/*     */     }
/*  78 */     registerRecipes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postInit(FMLPostInitializationEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerRenderer()
/*     */   {
/*  91 */     RenderingRegistry.registerBlockHandler(new BlockBushRender());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void register()
/*     */   {
/*  99 */     registerBlock((PALADIUM_ORE = new BaseBlockOre("paladium_ore")).setHardness(3.0F).setResistance(5.0F));
/* 100 */     registerBlock((PALADIUM_GREEN_ORE = new BaseBlockOre("paladium_green_ore")).setHardness(3.0F).setResistance(5.0F));
/* 101 */     registerBlock((TITANE_ORE = new BaseBlockOre("titane_ore")).setHardness(3.0F).setResistance(5.0F));
/* 102 */     registerBlock((AMETHYST_ORE = new BaseBlockOre("amethyst_ore")).setHardness(3.0F).setResistance(5.0F));
/* 103 */     registerBlock((FINDIUM_ORE = new BlockFindiumOre("findium_ore")).setHardness(3.0F).setResistance(5.0F));
/*     */     
/*     */ 
/* 106 */     registerBlock(GRANITE_BLOCK = new BlockGranite("granite"), ItemBlockGranite.class);
/*     */     
/*     */ 
/* 109 */     registerItem(XP_BERRY = new BaseItemBerry("berry_xp"));
/* 110 */     registerBlock(XP_BERRY_BUSH = new BlockXPBush("berry_xp_bush", new String[] { "berry_xp_bush", "", "", "", "berry_xp_bush_ripe", "", "", "" }));
/*     */     
/*     */ 
/* 113 */     registerBlock(ABSINTHE_FLOWER = new BaseBlockFlower("absinthe_flower"));
/* 114 */     registerBlock(ACTAEAPACHYPODA_FLOWER = new BaseBlockFlower("actaeaPachypoda_flower"));
/* 115 */     registerBlock(CLATHRUSARCHERI_FLOWER = new BaseBlockFlower("clathrusArcheri_flower"));
/* 116 */     registerBlock(ENDIUM_FLOWER = new BaseBlockFlower("endium_flower"));
/* 117 */     registerBlock(PALADIUM_FLOWER = new BaseBlockFlower("paladium_flower"));
/* 118 */     registerBlock(HARPAGOPHYTUM_FLOWER = new HarpagophytumBlockFlower("harpagophytum_flower"));
/* 119 */     registerBlock(MINT_FLOWER = new BaseBlockFlower("mint_flower"));
/* 120 */     registerBlock(ORTIE_FLOWER = new BaseBlockFlower("ortie_flower"));
/* 121 */     registerBlock(SAUGE_FLOWER = new BaseBlockFlower("sauge_flower"));
/* 122 */     registerBlock(TREFLE_FLOWER = new BaseBlockFlower("trefle_flower"));
/*     */     
/*     */ 
/* 125 */     registerBlock(EGGPLANT_CROP = new BaseBlockCrops("eggplant_crops", new String[] { "eggplant_stage_0", "eggplant_stage_0", "eggplant_stage_1", "eggplant_stage_1", "eggplant_stage_2", "eggplant_stage_2", "eggplant_stage_3", "eggplant_stage_3" }, 5));
/* 126 */     registerItem(EGGPLANT_SEED = new BaseItemSeed("eggplant_seed", EGGPLANT_CROP, 5));
/* 127 */     registerItem(EGGPLANT = new BaseItemFood("eggplant", 3, 3.0F, false));
/*     */     
/* 129 */     registerBlock(CHERVIL_CROP = new BaseBlockCrops("chervil_crops", new String[] { "chervil_stage_0", "chervil_stage_0", "chervil_stage_1", "chervil_stage_1", "chervil_stage_2", "chervil_stage_2", "chervil_stage_3", "chervil_stage_3" }, 10));
/* 130 */     registerItem(CHERVIL_SEED = new BaseItemSeed("chervil_seed", CHERVIL_CROP, 10));
/*     */     
/* 132 */     registerBlock(KIWANO_CROP = new BaseBlockCrops("kiwano_crops", new String[] { "kiwano_stage_0", "kiwano_stage_0", "kiwano_stage_1", "kiwano_stage_1", "kiwano_stage_2", "kiwano_stage_2", "kiwano_stage_3", "kiwano_stage_3", "kiwano_stage_4", "kiwano_stage_4" }, 15));
/* 133 */     registerItem(KIWANO_SEED = new BaseItemSeed("kiwano_seed", KIWANO_CROP, 15));
/* 134 */     registerItem(KIWANO = new BaseItemFood("kiwano", 3, 3.0F, false));
/*     */     
/* 136 */     registerBlock(ORANGEBLUE_CROP = new BaseBlockCrops("orangeblue_crops", new String[] { "orangeblue_stage_0", "orangeblue_stage_0", "orangeblue_stage_1", "orangeblue_stage_1", "orangeblue_stage_2", "orangeblue_stage_2", "orangeblue_stage_3", "orangeblue_stage_3", "orangeblue_stage_4", "orangeblue_stage_4" }, 20));
/* 137 */     registerItem(ORANGEBLUE_SEED = new BaseItemSeed("orangeblue_seed", ORANGEBLUE_CROP, 20));
/* 138 */     registerItem(ORANGEBLUE = new BaseItemFood("orangeblue", 3, 3.0F, false));
/*     */     
/* 140 */     oreRegistry();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void oreRegistry()
/*     */   {
/* 147 */     OreDictionary.registerOre("paladium_ore", new ItemStack(PALADIUM_ORE, 1));
/* 148 */     OreDictionary.registerOre("paladium_green_ore", new ItemStack(PALADIUM_GREEN_ORE, 1));
/* 149 */     OreDictionary.registerOre("titane_ore", new ItemStack(TITANE_ORE, 1));
/* 150 */     OreDictionary.registerOre("amethyst_ore", new ItemStack(AMETHYST_ORE, 1));
/* 151 */     OreDictionary.registerOre("findium_ore", new ItemStack(FINDIUM_ORE, 1));
/*     */     
/* 153 */     for (EnumBlockGranite block : EnumBlockGranite.values()) {
/* 154 */       OreDictionary.registerOre("stone_" + block.getName() + "_block", new ItemStack(GRANITE_BLOCK, 1, block.getMeta()));
/*     */     }
/*     */     
/* 157 */     OreDictionary.registerOre("absinthe_flower", new ItemStack(ABSINTHE_FLOWER, 1));
/* 158 */     OreDictionary.registerOre("actaeaPachypoda_flower", new ItemStack(ACTAEAPACHYPODA_FLOWER, 1));
/* 159 */     OreDictionary.registerOre("clathrusArcheri_flower", new ItemStack(CLATHRUSARCHERI_FLOWER, 1));
/* 160 */     OreDictionary.registerOre("endium_flower", new ItemStack(ENDIUM_FLOWER, 1));
/* 161 */     OreDictionary.registerOre("paladium_flower", new ItemStack(PALADIUM_FLOWER, 1));
/* 162 */     OreDictionary.registerOre("harpagophytum_flower", new ItemStack(HARPAGOPHYTUM_FLOWER, 1));
/* 163 */     OreDictionary.registerOre("mint_flower", new ItemStack(MINT_FLOWER, 1));
/* 164 */     OreDictionary.registerOre("ortie_flower", new ItemStack(ORTIE_FLOWER, 1));
/* 165 */     OreDictionary.registerOre("sauge_flower", new ItemStack(SAUGE_FLOWER, 1));
/* 166 */     OreDictionary.registerOre("trefle_flower", new ItemStack(TREFLE_FLOWER, 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void registerRecipes()
/*     */   {
/* 173 */     registerFurnaceRecipes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerFurnaceRecipes()
/*     */   {
/* 181 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(PALADIUM_ORE), new ItemStack(MaterialRegister.PALADIUM_INGOT), 0.2F);
/* 182 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(PALADIUM_GREEN_ORE), new ItemStack(MaterialRegister.PALADIUM_GREEN_INGOT), 0.2F);
/* 183 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(TITANE_ORE), new ItemStack(MaterialRegister.TITANE_INGOT), 0.2F);
/* 184 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(AMETHYST_ORE), new ItemStack(MaterialRegister.AMETHYST_INGOT), 0.2F);
/* 185 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(FINDIUM_ORE), new ItemStack(MaterialRegister.FINDIUM), 0.2F);
/*     */     
/*     */ 
/* 188 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(GRANITE_BLOCK, 1, 0), new ItemStack(GRANITE_BLOCK, 1, 1), 0.2F);
/* 189 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(GRANITE_BLOCK, 1, 2), new ItemStack(GRANITE_BLOCK, 1, 3), 0.2F);
/* 190 */     FurnaceRecipes.smelting().func_151394_a(new ItemStack(GRANITE_BLOCK, 1, 4), new ItemStack(GRANITE_BLOCK, 1, 5), 0.2F);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\WorldRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */