/*    */ package fr.paladium.palamod.world.item;
/*    */ 
/*    */ import fr.paladium.palamod.world.block.EnumBlockGranite;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ 
/*    */ public class ItemBlockGranite extends ItemBlock
/*    */ {
/*    */   public ItemBlockGranite(net.minecraft.block.Block block)
/*    */   {
/* 10 */     super(block);
/*    */     
/* 12 */     setHasSubtypes(true);
/* 13 */     setMaxDamage(0);
/*    */   }
/*    */   
/*    */   public int getMetadata(int meta)
/*    */   {
/* 18 */     return meta;
/*    */   }
/*    */   
/*    */   public String getUnlocalizedName(net.minecraft.item.ItemStack itemstack)
/*    */   {
/* 23 */     EnumBlockGranite block = EnumBlockGranite.values()[itemstack.getItemDamage()];
/* 24 */     return "tile.stone_" + block.getName() + "_block";
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\item\ItemBlockGranite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */