/*    */ package fr.paladium.palamod.world.item;
/*    */ 
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BaseItemBerry extends BaseItem
/*    */ {
/*    */   public BaseItemBerry(String unlocalizedName)
/*    */   {
/* 13 */     super(unlocalizedName);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player)
/*    */   {
/* 18 */     if (this == fr.paladium.palamod.world.WorldRegister.XP_BERRY) {
/* 19 */       net.minecraft.entity.item.EntityXPOrb entity = new net.minecraft.entity.item.EntityXPOrb(world, player.posX, player.posY + 1.0D, player.posZ, itemRand.nextInt(14) + 6);
/* 20 */       spawnEntity(player.posX, player.posY + 1.0D, player.posZ, entity, world, player);
/*    */       
/* 22 */       if (!player.capabilities.isCreativeMode) {
/* 23 */         stack.stackSize -= 1;
/*    */       }
/*    */     }
/* 26 */     return stack;
/*    */   }
/*    */   
/*    */   private static void spawnEntity(double x, double y, double z, Entity entity, World world, EntityPlayer player) {
/* 30 */     if (!world.isRemote) {
/* 31 */       world.spawnEntityInWorld(entity);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\item\BaseItemBerry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */