/*    */ package fr.paladium.palamod.world.item.seed;
/*    */ 
/*    */ import fr.paladium.palamod.job.Job;
/*    */ import fr.paladium.palamod.job.JobsXPManager;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.library.item.BaseItem;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.common.EnumPlantType;
/*    */ 
/*    */ public class BaseItemSeed extends BaseItem implements net.minecraftforge.common.IPlantable
/*    */ {
/*    */   private Block crops;
/*    */   private int lvlmin;
/*    */   
/*    */   public BaseItemSeed(String unlocalizedName, Block crops, int lvlmin)
/*    */   {
/* 24 */     super(unlocalizedName);
/*    */     
/* 26 */     this.crops = crops;
/*    */     
/* 28 */     setTextureName("palamod:seeds/" + this.unlocalizedName);
/*    */     
/* 30 */     this.lvlmin = lvlmin;
/*    */   }
/*    */   
/*    */   public boolean onItemUse(ItemStack parItemStack, EntityPlayer parPlayer, World parWorld, int parX, int parY, int parZ, int par7, float par8, float par9, float par10)
/*    */   {
/* 35 */     if (!parWorld.isRemote) {
/* 36 */       Job famer = (Job)ModJobs.jobs.get(Integer.valueOf(2));
/* 37 */       if (famer.getLevel(((JobsXPManager)ModJobs.allJobsXpManager.get(parPlayer.getUniqueID().toString())).getXP(2)) < this.lvlmin) {
/* 38 */         parPlayer.addChatComponentMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Il faut etre niveau " + this.lvlmin + " pour utiliser cet item.", new Object[0]));
/* 39 */         return false;
/*    */       }
/* 41 */       if (par7 != 1)
/* 42 */         return false;
/* 43 */       if (parPlayer.canPlayerEdit(parX, parY + 1, parZ, par7, parItemStack)) {
/* 44 */         if ((parWorld.getBlock(parX, parY, parZ).canSustainPlant(parWorld, parX, parY, parZ, net.minecraftforge.common.util.ForgeDirection.UP, this)) && (parWorld.isAirBlock(parX, parY + 1, parZ))) {
/* 45 */           parWorld.setBlock(parX, parY + 1, parZ, this.crops);
/* 46 */           parItemStack.stackSize -= 1;
/*    */           
/* 48 */           return true;
/*    */         }
/* 50 */         return false;
/*    */       }
/*    */     }
/*    */     
/* 54 */     return false;
/*    */   }
/*    */   
/*    */   public EnumPlantType getPlantType(IBlockAccess world, int x, int y, int z)
/*    */   {
/* 59 */     return EnumPlantType.Crop;
/*    */   }
/*    */   
/*    */   public Block getPlant(IBlockAccess world, int x, int y, int z)
/*    */   {
/* 64 */     return this.crops;
/*    */   }
/*    */   
/*    */   public int getPlantMetadata(IBlockAccess world, int x, int y, int z)
/*    */   {
/* 69 */     return 0;
/*    */   }
/*    */   
/*    */   public int getLvlmin() {
/* 73 */     return this.lvlmin;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\item\seed\BaseItemSeed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */