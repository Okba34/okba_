/*     */ package fr.paladium.palamod.world.gen;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class OreberryBushGen extends net.minecraft.world.gen.feature.WorldGenerator
/*     */ {
/*     */   private Block blockB;
/*     */   private int metadata;
/*     */   int chance;
/*     */   private Block[] replaceBlocks;
/*     */   
/*     */   public OreberryBushGen(Block block, int meta, int chance)
/*     */   {
/*  16 */     this(block, meta, chance, new Block[] { net.minecraft.init.Blocks.stone, net.minecraft.init.Blocks.grass, net.minecraft.init.Blocks.dirt, net.minecraft.init.Blocks.water, net.minecraft.init.Blocks.sand, net.minecraft.init.Blocks.gravel, net.minecraft.init.Blocks.snow });
/*  17 */     this.blockB = block;
/*     */   }
/*     */   
/*     */   public OreberryBushGen(Block block, int meta, int chance, Block... target) {
/*  21 */     this.blockB = block;
/*  22 */     this.metadata = meta;
/*  23 */     this.chance = chance;
/*  24 */     this.replaceBlocks = target;
/*     */   }
/*     */   
/*     */   public boolean generate(World world, Random random, int x, int y, int z)
/*     */   {
/*  29 */     int type = random.nextInt(this.chance);
/*  30 */     if (type == 11) {
/*  31 */       generateMediumNode(world, random, x, y, z);
/*     */     }
/*  33 */     else if (type >= 5) {
/*  34 */       generateSmallNode(world, random, x, y, z);
/*     */     }
/*     */     else {
/*  37 */       generateTinyNode(world, random, x, y, z);
/*     */     }
/*  39 */     return true;
/*     */   }
/*     */   
/*     */   public void generateMediumNode(World world, Random random, int x, int y, int z) {
/*  43 */     for (int xPos = -1; xPos <= 1; xPos++) {
/*  44 */       for (int yPos = -1; yPos <= 1; yPos++) {
/*  45 */         for (int zPos = -1; zPos <= 1; zPos++) {
/*  46 */           if (random.nextInt(4) == 0) {
/*  47 */             generateBerryBlock(world, x + xPos, y + yPos, z + zPos, random);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  52 */     generateSmallNode(world, random, x, y, z);
/*     */   }
/*     */   
/*     */   public void generateSmallNode(World world, Random random, int x, int y, int z) {
/*  56 */     generateBerryBlock(world, x, y, z, random);
/*  57 */     if (random.nextBoolean()) {
/*  58 */       generateBerryBlock(world, x + 1, y, z, random);
/*     */     }
/*  60 */     if (random.nextBoolean()) {
/*  61 */       generateBerryBlock(world, x - 1, y, z, random);
/*     */     }
/*  63 */     if (random.nextBoolean()) {
/*  64 */       generateBerryBlock(world, x, y, z + 1, random);
/*     */     }
/*  66 */     if (random.nextBoolean()) {
/*  67 */       generateBerryBlock(world, x, y, z - 1, random);
/*     */     }
/*  69 */     if (random.nextBoolean()) {
/*  70 */       generateBerryBlock(world, x, y + 1, z, random);
/*     */     }
/*  72 */     if (random.nextBoolean()) {
/*  73 */       generateBerryBlock(world, x, y + 1, z, random);
/*     */     }
/*     */   }
/*     */   
/*     */   public void generateTinyNode(World world, Random random, int x, int y, int z) {
/*  78 */     generateBerryBlock(world, x, y, z, random);
/*     */     
/*  80 */     if (random.nextInt(4) == 0) {
/*  81 */       generateBerryBlock(world, x + 1, y, z, random);
/*     */     }
/*  83 */     if (random.nextInt(4) == 0) {
/*  84 */       generateBerryBlock(world, x - 1, y, z, random);
/*     */     }
/*  86 */     if (random.nextInt(4) == 0) {
/*  87 */       generateBerryBlock(world, x, y, z + 1, random);
/*     */     }
/*  89 */     if (random.nextInt(4) == 0) {
/*  90 */       generateBerryBlock(world, x, y, z - 1, random);
/*     */     }
/*  92 */     if (random.nextInt(4) == 0) {
/*  93 */       generateBerryBlock(world, x, y + 1, z, random);
/*     */     }
/*  95 */     if (random.nextInt(4) == 0) {
/*  96 */       generateBerryBlock(world, x, y + 1, z, random);
/*     */     }
/*     */   }
/*     */   
/*     */   private void generateBerryBlock(World world, int x, int y, int z, Random random) {
/* 101 */     Block block = world.getBlock(x, y, z);
/* 102 */     if ((block == null) || ((block != net.minecraft.init.Blocks.end_portal_frame) && (!world.getBlock(x, y, z).func_149730_j()))) {
/* 103 */       world.setBlock(x, y, z, this.blockB, this.metadata, 2);
/*     */     }
/*     */     else {
/* 106 */       for (int iter = 0; iter < this.replaceBlocks.length; iter++) {
/* 107 */         if (world.getBlock(x, y, z).isReplaceableOreGen(world, x, y, z, this.replaceBlocks[iter])) {
/* 108 */           world.setBlock(x, y, z, this.blockB, this.metadata, 2);
/* 109 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\gen\OreberryBushGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */