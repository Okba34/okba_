/*     */ package fr.paladium.palamod.world.gen;
/*     */ 
/*     */ import cpw.mods.fml.common.IWorldGenerator;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.util.Random;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraft.world.WorldType;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraft.world.gen.feature.WorldGenMinable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseWorldGenerator
/*     */   implements IWorldGenerator
/*     */ {
/*     */   private WorldGenMinable paladium;
/*     */   private WorldGenMinable titane;
/*     */   private WorldGenMinable amethyst;
/*     */   private WorldGenMinable findium;
/*     */   private WorldGenMinable paladium_green;
/*     */   private OreberryBushGen xpBush;
/*     */   
/*     */   public BaseWorldGenerator()
/*     */   {
/*  27 */     this.paladium = new WorldGenMinable(WorldRegister.PALADIUM_ORE, 0, 3, Blocks.stone);
/*  28 */     this.titane = new WorldGenMinable(WorldRegister.TITANE_ORE, 0, 8, Blocks.stone);
/*  29 */     this.amethyst = new WorldGenMinable(WorldRegister.AMETHYST_ORE, 0, 8, Blocks.stone);
/*     */     
/*  31 */     this.findium = new WorldGenMinable(WorldRegister.FINDIUM_ORE, 0, 3, Blocks.stone);
/*     */     
/*     */ 
/*  34 */     this.paladium_green = new WorldGenMinable(WorldRegister.PALADIUM_GREEN_ORE, 0, 1, Blocks.stone);
/*     */     
/*     */ 
/*  37 */     this.xpBush = new OreberryBushGen(WorldRegister.XP_BERRY_BUSH, 0, 6);
/*     */   }
/*     */   
/*     */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider)
/*     */   {
/*  42 */     if (world.provider.terrainType != WorldType.FLAT) {
/*  43 */       generateSurface(random, chunkX * 16, chunkZ * 16, world);
/*  44 */       if (world.provider.dimensionId == 0) {
/*  45 */         generateOreBushes(random, chunkX * 16, chunkZ * 16, world);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void generateSurface(Random random, int xChunk, int zChunk, World world)
/*     */   {
/*  53 */     for (int q = 0; q <= 2; q++) {
/*  54 */       int xPos = xChunk + random.nextInt(16);
/*  55 */       int yPos = 0 + random.nextInt(11);
/*  56 */       int zPos = zChunk + random.nextInt(16);
/*  57 */       this.paladium.generate(world, random, xPos, yPos, zPos);
/*     */     }
/*     */     
/*  60 */     for (int q = 0; q <= 2; q++) {
/*  61 */       int xPos = xChunk + random.nextInt(16);
/*  62 */       int yPos = 0 + random.nextInt(24);
/*  63 */       int zPos = zChunk + random.nextInt(16);
/*  64 */       this.titane.generate(world, random, xPos, yPos, zPos);
/*     */     }
/*     */     
/*  67 */     for (int q = 0; q <= 2; q++) {
/*  68 */       int xPos = xChunk + random.nextInt(16);
/*  69 */       int yPos = 0 + random.nextInt(24);
/*  70 */       int zPos = zChunk + random.nextInt(16);
/*  71 */       this.amethyst.generate(world, random, xPos, yPos, zPos);
/*     */     }
/*     */     
/*  74 */     for (int q = 0; q <= 2; q++) {
/*  75 */       int xPos = xChunk + random.nextInt(16);
/*  76 */       int yPos = 0 + random.nextInt(11);
/*  77 */       int zPos = zChunk + random.nextInt(16);
/*  78 */       this.findium.generate(world, random, xPos, yPos, zPos);
/*     */     }
/*     */     
/*  81 */     for (int q = 0; q <= 1; q++) {
/*  82 */       int xPos = xChunk + random.nextInt(16);
/*  83 */       int yPos = 0 + random.nextInt(40);
/*  84 */       int zPos = zChunk + random.nextInt(16);
/*     */       
/*  86 */       int gen = random.nextInt(200);
/*  87 */       if (gen <= 10) {
/*  88 */         this.paladium_green.generate(world, random, xPos, yPos, zPos);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  93 */     int flowerType = random.nextInt(1000);
/*     */     
/*  95 */     int xPos = xChunk + random.nextInt(16) + 8;
/*  96 */     int zPos = zChunk + random.nextInt(16) + 8;
/*  97 */     int yPos = world.getHeightValue(xPos, zPos);
/*     */     
/*  99 */     if (flowerType <= 40) {
/* 100 */       new FlowerGen(WorldRegister.MINT_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 102 */     else if ((flowerType > 40) && (flowerType <= 25)) {
/* 103 */       new FlowerGen(WorldRegister.SAUGE_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 105 */     else if ((flowerType > 65) && (flowerType <= 95)) {
/* 106 */       new FlowerGen(WorldRegister.CLATHRUSARCHERI_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 108 */     else if ((flowerType > 95) && (flowerType <= 120)) {
/* 109 */       new FlowerGen(WorldRegister.TREFLE_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 111 */     else if ((flowerType > 120) && (flowerType <= 126)) {
/* 112 */       new FlowerGen(WorldRegister.ACTAEAPACHYPODA_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 114 */     else if ((flowerType > 126) && (flowerType <= 146)) {
/* 115 */       new FlowerGen(WorldRegister.ORTIE_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 117 */     else if ((flowerType > 146) && (flowerType <= 164)) {
/* 118 */       new FlowerGen(WorldRegister.ABSINTHE_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/* 120 */     else if ((flowerType > 164) && (flowerType <= 166)) {
/* 121 */       new FlowerGen(WorldRegister.HARPAGOPHYTUM_FLOWER).generate(world, random, xPos, yPos, zPos);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void generateOreBushes(Random random, int xChunk, int zChunk, World world)
/*     */   {
/* 129 */     if (random.nextInt(6) == 0) {
/* 130 */       for (int i = 0; i < 1; i++) {
/* 131 */         int xPos = xChunk + random.nextInt(16);
/* 132 */         int yPos = 48;
/* 133 */         int zPos = zChunk + random.nextInt(16);
/* 134 */         yPos = findAdequateLocation(world, xPos, yPos, zPos, 32, 0);
/* 135 */         if (yPos != -1) {
/* 136 */           this.xpBush.generate(world, random, xPos, yPos, zPos);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   int findAdequateLocation(World world, int x, int y, int z, int heightLimit, int depthLimit) {
/* 143 */     int height = y;
/*     */     do {
/* 145 */       if ((world.getBlock(x, height, z) == Blocks.air) && (world.getBlock(x, height + 1, z) != Blocks.air)) {
/* 146 */         return height + 1;
/*     */       }
/* 148 */       height++;
/* 149 */     } while (height < heightLimit);
/*     */     
/* 151 */     height = y;
/*     */     do {
/* 153 */       if ((world.getBlock(x, height, z) == Blocks.air) && (world.getBlock(x, height - 1, z) != Blocks.air)) {
/* 154 */         return height - 1;
/*     */       }
/* 156 */       height--;
/* 157 */     } while (height > depthLimit);
/*     */     
/* 159 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\gen\BaseWorldGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */