/*    */ package fr.paladium.palamod.world.gen;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.feature.WorldGenerator;
/*    */ 
/*    */ public class GraniteGen
/*    */   extends WorldGenerator
/*    */ {
/*    */   public boolean generate(World world, Random random, int x, int y, int z)
/*    */   {
/* 12 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\gen\GraniteGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */