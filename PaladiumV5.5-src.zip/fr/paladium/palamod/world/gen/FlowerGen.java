/*    */ package fr.paladium.palamod.world.gen;
/*    */ 
/*    */ import fr.paladium.palamod.world.block.flower.BaseBlockFlower;
/*    */ import java.util.Random;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.gen.feature.WorldGenerator;
/*    */ 
/*    */ public class FlowerGen extends WorldGenerator
/*    */ {
/*    */   private BaseBlockFlower flower;
/*    */   
/*    */   public FlowerGen(BaseBlockFlower flower)
/*    */   {
/* 14 */     this.flower = flower;
/*    */   }
/*    */   
/*    */   public boolean generate(World worldIn, Random random, int x, int y, int z)
/*    */   {
/* 19 */     if ((worldIn.isAirBlock(x, y, z)) && (worldIn.getBlock(x, y - 1, z).getMaterial().equals(net.minecraft.block.material.Material.grass))) {
/* 20 */       worldIn.setBlock(x, y, z, this.flower);
/*    */     }
/* 22 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\gen\FlowerGen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */