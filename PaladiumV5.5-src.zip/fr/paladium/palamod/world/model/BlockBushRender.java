/*    */ package fr.paladium.palamod.world.model;
/*    */ 
/*    */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.RenderBlocks;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ 
/*    */ public class BlockBushRender implements ISimpleBlockRenderingHandler
/*    */ {
/* 10 */   public static int model = ;
/*    */   
/*    */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer)
/*    */   {
/* 14 */     if (modelId == model) {
/* 15 */       int md = world.getBlockMetadata(x, y, z);
/* 16 */       if (md < 4) {
/* 17 */         renderer.setRenderBounds(0.25D, 0.0D, 0.25D, 0.75D, 0.5D, 0.75D);
/* 18 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       }
/* 20 */       else if (md < 8) {
/* 21 */         renderer.setRenderBounds(0.125D, 0.0D, 0.125D, 0.875D, 0.75D, 0.875D);
/* 22 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       }
/*    */       else {
/* 25 */         renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/* 26 */         renderer.renderStandardBlock(block, x, y, z);
/*    */       }
/* 28 */       return true;
/*    */     }
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer)
/*    */   {
/* 35 */     if (modelID == model) {
/* 36 */       renderer.setRenderBounds(0.125D, 0.0D, 0.125D, 0.875D, 0.75D, 0.875D);
/* 37 */       fr.paladium.palamod.library.item.ItemHelper.renderStandardInvBlock(renderer, block, metadata);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean shouldRender3DInInventory(int modelID)
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */   
/*    */   public int getRenderId()
/*    */   {
/* 48 */     return model;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\world\model\BlockBushRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */