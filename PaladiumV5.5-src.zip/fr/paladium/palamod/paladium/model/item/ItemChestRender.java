/*    */ package fr.paladium.palamod.paladium.model.item;
/*    */ 
/*    */ import net.minecraft.client.model.ModelChest;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ItemChestRender implements net.minecraftforge.client.IItemRenderer
/*    */ {
/*    */   private ModelChest chestModel;
/*    */   
/*    */   public ItemChestRender()
/*    */   {
/* 15 */     this.chestModel = new ModelChest();
/*    */   }
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
/*    */   {
/* 20 */     return true;
/*    */   }
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, net.minecraftforge.client.IItemRenderer.ItemRendererHelper helper)
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data)
/*    */   {
/* 30 */     GL11.glPushMatrix();
/* 31 */     GL11.glRotated(90.0D, 0.0D, 1.0D, 0.0D);
/*    */     
/* 33 */     if (type != IItemRenderer.ItemRenderType.ENTITY) {
/* 34 */       GL11.glTranslatef(-1.0F, -0.1F, 0.0F);
/*    */     }
/*    */     else {
/* 37 */       GL11.glTranslatef(-0.5F, -0.45F, -0.5F);
/*    */     }
/*    */     
/* 40 */     TileEntityRendererDispatcher.instance.renderTileEntityAt(new fr.paladium.palamod.paladium.logic.PaladiumChestLogic(), 0.0D, 0.0D, 0.0D, 0.0F);
/* 41 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\model\item\ItemChestRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */