/*    */ package fr.paladium.palamod.paladium.model.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelAlchemyCreator;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ItemAlchemyCreatorRender implements net.minecraftforge.client.IItemRenderer
/*    */ {
/*    */   private ModelAlchemyCreator model;
/*    */   private TileEntitySpecialRenderer render;
/*    */   private TileEntity entity;
/*    */   
/*    */   public ItemAlchemyCreatorRender(TileEntitySpecialRenderer render, TileEntity entity)
/*    */   {
/* 18 */     this.render = render;
/* 19 */     this.entity = entity;
/*    */     
/* 21 */     this.model = new ModelAlchemyCreator();
/*    */   }
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
/*    */   {
/* 26 */     return true;
/*    */   }
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, net.minecraftforge.client.IItemRenderer.ItemRendererHelper helper)
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data)
/*    */   {
/* 36 */     if (type == IItemRenderer.ItemRenderType.ENTITY) {
/* 37 */       GL11.glTranslatef(-0.5F, 0.0F, -0.5F);
/*    */     }
/* 39 */     if (type == IItemRenderer.ItemRenderType.INVENTORY) {
/* 40 */       GL11.glTranslated(0.0D, -0.8D, 0.0D);
/*    */     }
/* 42 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/* 43 */       GL11.glScaled(1.5D, 1.5D, 1.5D);
/* 44 */       GL11.glTranslated(0.6D, 0.0D, 0.8D);
/*    */     }
/*    */     
/* 47 */     GL11.glRotated(180.0D, 0.0D, 1.0D, 0.0D);
/* 48 */     this.render.renderTileEntityAt(this.entity, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\model\item\ItemAlchemyCreatorRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */