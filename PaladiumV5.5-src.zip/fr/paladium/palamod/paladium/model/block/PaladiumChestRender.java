/*    */ package fr.paladium.palamod.paladium.model.block;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*    */ import net.minecraft.client.model.ModelChest;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class PaladiumChestRender
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/*    */   public float field_145972_a;
/*    */   public float field_145975_i;
/*    */   public int field_145973_j;
/* 21 */   private static final ResourceLocation TEXTURE = new ResourceLocation("palamod:textures/models/PaladiumChest.png");
/* 22 */   private ModelChest model = new ModelChest();
/*    */   
/*    */   public void renderTileEntityAt(PaladiumChestLogic tile, double p_147500_2_, double p_147500_4_, double p_147500_6_, float p_147500_8_) {
/* 25 */     int i = 0;
/* 26 */     if (tile.hasWorldObj()) {
/* 27 */       i = tile.getBlockMetadata();
/*    */     }
/*    */     
/* 30 */     bindTexture(TEXTURE);
/* 31 */     GL11.glPushMatrix();
/* 32 */     GL11.glEnable(32826);
/* 33 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 34 */     GL11.glTranslatef((float)p_147500_2_, (float)p_147500_4_ + 1.0F, (float)p_147500_6_ + 1.0F);
/* 35 */     GL11.glScalef(1.0F, -1.0F, -1.0F);
/* 36 */     GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/* 37 */     short short1 = 0;
/*    */     
/* 39 */     if (i == 2) {
/* 40 */       short1 = 180;
/*    */     }
/*    */     
/* 43 */     if (i == 3) {
/* 44 */       short1 = 0;
/*    */     }
/*    */     
/* 47 */     if (i == 4) {
/* 48 */       short1 = 90;
/*    */     }
/*    */     
/* 51 */     if (i == 5) {
/* 52 */       short1 = -90;
/*    */     }
/*    */     
/* 55 */     GL11.glRotatef(short1, 0.0F, 1.0F, 0.0F);
/* 56 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*    */     
/* 58 */     if (tile.openning) {
/* 59 */       if ((tile.lid >= 1.0F) || (tile.closing == true)) {
/* 60 */         tile.openning = false;
/*    */       }
/*    */       else {
/* 63 */         tile.lid += 0.05F;
/*    */       }
/*    */     }
/*    */     
/* 67 */     if (tile.closing) {
/* 68 */       if ((tile.lid <= 0.0F) || (tile.openning == true)) {
/* 69 */         tile.closing = false;
/*    */       }
/*    */       else {
/* 72 */         tile.lid -= 0.05F;
/*    */       }
/*    */     }
/*    */     
/* 76 */     float f1 = tile.lid;
/*    */     
/* 78 */     f1 = 1.0F - f1;
/* 79 */     f1 = 1.0F - f1 * f1 * f1;
/* 80 */     if (f1 < 0.0F) {
/* 81 */       f1 = 0.0F;
/*    */     }
/* 83 */     this.model.chestLid.rotateAngleX = (-(f1 * 3.1415927F / 2.0F));
/*    */     
/* 85 */     this.model.renderAll();
/* 86 */     GL11.glPopMatrix();
/* 87 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */   
/*    */   public void renderTileEntityAt(TileEntity p_147500_1_, double p_147500_2_, double p_147500_4_, double p_147500_6_, float p_147500_8_) {
/* 91 */     renderTileEntityAt((PaladiumChestLogic)p_147500_1_, p_147500_2_, p_147500_4_, p_147500_6_, p_147500_8_);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\model\block\PaladiumChestRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */