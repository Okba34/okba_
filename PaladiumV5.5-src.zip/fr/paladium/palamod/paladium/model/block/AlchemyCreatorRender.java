/*    */ package fr.paladium.palamod.paladium.model.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelAlchemyCreator;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class AlchemyCreatorRender extends net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer
/*    */ {
/*    */   private final ModelAlchemyCreator model;
/*    */   private final ResourceLocation textures;
/*    */   
/*    */   public AlchemyCreatorRender()
/*    */   {
/* 18 */     this.model = new ModelAlchemyCreator();
/* 19 */     this.textures = new ResourceLocation("palamod:textures/blocks/machines/alchemy_creator_block.png");
/*    */   }
/*    */   
/*    */   public void renderTileEntityAt(TileEntity tile, double x, double y, double z, float f)
/*    */   {
/* 24 */     GL11.glPushMatrix();
/* 25 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/*    */     
/* 27 */     Minecraft.getMinecraft().renderEngine.bindTexture(this.textures);
/*    */     
/* 29 */     GL11.glPushMatrix();
/* 30 */     int meta = Minecraft.getMinecraft().theWorld.getBlockMetadata(tile.xCoord, tile.yCoord, tile.zCoord);
/* 31 */     int id = 0;
/* 32 */     switch (meta) {
/*    */     case 0: 
/* 34 */       id = 0;
/* 35 */       break;
/*    */     case 4: 
/* 37 */       id = 3;
/* 38 */       break;
/*    */     case 3: 
/* 40 */       id = 2;
/* 41 */       break;
/*    */     case 5: 
/* 43 */       id = 1;
/*    */     }
/*    */     
/*    */     
/* 47 */     GL11.glRotatef(id * -90, 0.0F, 1.0F, 0.0F);
/* 48 */     GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/* 49 */     this.model.render((Entity)null, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
/*    */     
/* 51 */     GL11.glPopMatrix();
/* 52 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\model\block\AlchemyCreatorRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */