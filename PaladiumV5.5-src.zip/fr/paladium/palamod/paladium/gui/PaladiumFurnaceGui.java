/*    */ package fr.paladium.palamod.paladium.gui;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.inventory.PaladiumFurnaceContainer;
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class PaladiumFurnaceGui extends GuiContainer
/*    */ {
/* 14 */   public static final ResourceLocation background = new ResourceLocation("palamod", "textures/gui/paladium_furnace.png");
/*    */   private PaladiumFurnaceLogic tile;
/*    */   
/*    */   public PaladiumFurnaceGui(InventoryPlayer inventory, PaladiumFurnaceLogic tile) {
/* 18 */     super(new PaladiumFurnaceContainer(inventory, tile));
/* 19 */     this.tile = tile;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_)
/*    */   {
/* 24 */     String s = this.tile.hasCustomInventoryName() ? this.tile.getInventoryName() : I18n.format(this.tile.getInventoryName(), new Object[0]);
/*    */     
/* 26 */     this.fontRendererObj.drawString(s, this.xSize / 2 - this.fontRendererObj.getStringWidth(s) / 2, 6, 4210752);
/* 27 */     this.fontRendererObj.drawString(I18n.format("container.inventory", new Object[0]), 8, this.ySize - 96 + 2, 4210752);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 32 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 33 */     this.mc.getTextureManager().bindTexture(background);
/*    */     
/* 35 */     int k = (this.width - this.xSize) / 2;
/* 36 */     int l = (this.height - this.ySize) / 2;
/* 37 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 39 */     if (this.tile.isBurning()) {
/* 40 */       int i1 = this.tile.getBurnTimeRemainingScaled(13);
/* 41 */       drawTexturedModalRect(k + 56, l + 36 + 12 - i1, 176, 12 - i1, 14, i1 + 1);
/*    */       
/* 43 */       i1 = this.tile.getCookProgressScaled(24);
/* 44 */       drawTexturedModalRect(k + 79, l + 34, 176, 14, i1 + 1, 16);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\gui\PaladiumFurnaceGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */