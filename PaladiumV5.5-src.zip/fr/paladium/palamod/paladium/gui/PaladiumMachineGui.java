/*    */ package fr.paladium.palamod.paladium.gui;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.inventory.PaladiumMachineContainer;
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumMachineLogic;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class PaladiumMachineGui extends GuiContainer
/*    */ {
/*    */   private PaladiumMachineLogic tile;
/* 15 */   public static final ResourceLocation background = new ResourceLocation("palamod:textures/gui/paladium_machine.png");
/*    */   
/*    */   public PaladiumMachineGui(PaladiumMachineLogic tile, InventoryPlayer inventory) {
/* 18 */     super(new PaladiumMachineContainer(tile, inventory));
/*    */     
/* 20 */     this.tile = tile;
/* 21 */     this.ySize = 340;
/* 22 */     this.xSize = 200;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float f, int mouseX, int mouseY)
/*    */   {
/* 27 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 28 */     this.mc.getTextureManager().bindTexture(background);
/*    */     
/* 30 */     int k = (this.width - this.xSize) / 2;
/* 31 */     int l = (this.height - this.ySize) / 2;
/* 32 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 34 */     if (this.tile.isBurning()) {
/* 35 */       int i = this.tile.getCookProgress();
/* 36 */       drawTexturedModalRect(k + 90, l + 122, 201, 105, 20, i);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\gui\PaladiumMachineGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */