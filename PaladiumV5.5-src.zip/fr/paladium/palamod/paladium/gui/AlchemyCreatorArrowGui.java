/*    */ package fr.paladium.palamod.paladium.gui;
/*    */ 
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*    */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class AlchemyCreatorArrowGui extends GuiContainer
/*    */ {
/*    */   private AlchemyCreatorLogic tile;
/* 19 */   public static ResourceLocation background = new ResourceLocation("palamod", "textures/gui/alchemyCreator_arrow.png");
/* 20 */   public static ResourceLocation widgets = new ResourceLocation("palamod", "textures/gui/alchemyCreator_widget.png");
/*    */   
/*    */   public AlchemyCreatorArrowGui(AlchemyCreatorLogic tile, EntityPlayer player) {
/* 23 */     super(new fr.paladium.palamod.paladium.inventory.AlchemyCreatorArrowContainer(tile, player));
/*    */     
/* 25 */     this.tile = tile;
/* 26 */     this.ySize = 166;
/* 27 */     this.xSize = 200;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_)
/*    */   {
/* 32 */     String s = StatCollector.translateToLocal("crafters.AlchemyCreator");
/* 33 */     this.fontRendererObj.drawString(s, this.xSize / 2 - this.fontRendererObj.getStringWidth(s) / 2 - 10, 4, 4210752);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 38 */     int k = (this.width - this.xSize) / 2;
/* 39 */     int l = (this.height - this.ySize) / 2;
/*    */     
/* 41 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 42 */     this.mc.getTextureManager().bindTexture(background);
/*    */     
/* 44 */     drawTexturedModalRect(k, l, 0, 1, this.xSize, this.ySize);
/* 45 */     this.mc.getTextureManager().bindTexture(widgets);
/*    */     
/* 47 */     if (this.tile.isBurningArrow()) {
/* 48 */       this.mc.getTextureManager().bindTexture(widgets);
/* 49 */       double i = this.tile.getCookProgressArrow() * 1.5D;
/* 50 */       drawTexturedModalRect(k + 96, l + 48, 0, 89, 10, (int)i);
/* 51 */       drawTexturedModalRect(k + 63, l + 48, 10, 89, 14, 27 - (int)i);
/*    */     }
/*    */     else {
/* 54 */       drawTexturedModalRect(k + 63, l + 48, 10, 89, 14, 29);
/*    */     }
/*    */     
/* 57 */     drawTab(k, l);
/*    */   }
/*    */   
/*    */   private void drawTab(int k, int l) {
/* 61 */     drawTexturedModalRect(k + 176, l + 5, 33, 0, 28, 28);
/* 62 */     drawTexturedModalRect(k + 173, l + 35, 0, 28, 30, 28);
/*    */   }
/*    */   
/*    */   protected void mouseClicked(int i, int j, int k)
/*    */   {
/* 67 */     super.mouseClicked(i, j, k);
/* 68 */     int u = (this.width - this.xSize) / 2;
/* 69 */     int v = (this.height - this.ySize) / 2;
/*    */     
/* 71 */     if ((i > u + 175) && (j > v + 5) && (i < u + 205) && (j < v + 33)) {
/* 72 */       PacketOpenGui packet = new PacketOpenGui();
/* 73 */       packet.setInformations((byte)1);
/* 74 */       CommonProxy.packetPipeline.sendToServer(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\gui\AlchemyCreatorArrowGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */