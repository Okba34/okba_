/*    */ package fr.paladium.palamod.paladium.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerPaladiumChest;
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class PaladiumChestGui extends GuiContainer
/*    */ {
/* 13 */   private static final ResourceLocation BACKGROUND = new ResourceLocation("palamod", "textures/gui/paladium_chest.png");
/*    */   
/*    */   public PaladiumChestGui(PaladiumChestLogic tile, InventoryPlayer inventory) {
/* 16 */     super(new ContainerPaladiumChest(tile, inventory));
/*    */     
/* 18 */     this.xSize = 250;
/* 19 */     this.ySize = 256;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 24 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 25 */     this.mc.getTextureManager().bindTexture(BACKGROUND);
/* 26 */     int k = (this.width - this.xSize) / 2;
/* 27 */     int l = (this.height - this.ySize) / 2;
/* 28 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\gui\PaladiumChestGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */