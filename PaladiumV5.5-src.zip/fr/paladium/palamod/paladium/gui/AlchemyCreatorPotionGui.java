/*    */ package fr.paladium.palamod.paladium.gui;
/*    */ 
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*    */ import fr.paladium.palamod.paladium.inventory.AlchemyCreatorPotionContainer;
/*    */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class AlchemyCreatorPotionGui extends GuiContainer
/*    */ {
/*    */   private AlchemyCreatorLogic tile;
/* 19 */   public static final ResourceLocation background = new ResourceLocation("palamod", "textures/gui/alchemyCreator_potion.png");
/* 20 */   public static final ResourceLocation widgets = new ResourceLocation("palamod", "textures/gui/alchemyCreator_widget.png");
/*    */   
/*    */   public AlchemyCreatorPotionGui(AlchemyCreatorLogic tile, EntityPlayer player) {
/* 23 */     super(new AlchemyCreatorPotionContainer(tile, player));
/*    */     
/* 25 */     this.tile = tile;
/* 26 */     this.ySize = 166;
/* 27 */     this.xSize = 200;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int p_146979_1_, int p_146979_2_)
/*    */   {
/* 32 */     String s = net.minecraft.util.StatCollector.translateToLocal("crafters.AlchemyCreator");
/* 33 */     this.fontRendererObj.drawString(s, this.xSize / 2 - this.fontRendererObj.getStringWidth(s) / 2 - 10, 4, 4210752);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 38 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 39 */     this.mc.getTextureManager().bindTexture(background);
/*    */     
/* 41 */     int k = (this.width - this.xSize) / 2;
/* 42 */     int l = (this.height - this.ySize) / 2;
/* 43 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 45 */     this.mc.getTextureManager().bindTexture(widgets);
/* 46 */     if (this.tile.isBurningPotion()) {
/* 47 */       this.mc.getTextureManager().bindTexture(widgets);
/* 48 */       double i = this.tile.getCookProgressPotion() * 0.15D;
/*    */       
/* 50 */       drawTexturedModalRect(k + 124, l + 38, 0, 89, 10, (int)i);
/* 51 */       drawTexturedModalRect(k + 35, l + 35, 10, 89, 14, 27 - (int)i);
/*    */     }
/*    */     else {
/* 54 */       drawTexturedModalRect(k + 35, l + 35, 10, 89, 14, 29);
/*    */     }
/*    */     
/* 57 */     drawTab(k, l);
/*    */   }
/*    */   
/*    */   private void drawTab(int k, int l) {
/* 61 */     drawTexturedModalRect(k + 173, l + 5, 0, 0, 30, 28);
/* 62 */     drawTexturedModalRect(k + 176, l + 35, 33, 28, 27, 28);
/*    */   }
/*    */   
/*    */   protected void mouseClicked(int i, int j, int k)
/*    */   {
/* 67 */     super.mouseClicked(i, j, k);
/*    */     
/* 69 */     int u = (this.width - this.xSize) / 2;
/* 70 */     int v = (this.height - this.ySize) / 2;
/*    */     
/* 72 */     if ((i > u + 175) && (j > v + 35) && (i < u + 205) && (j < v + 63)) {
/* 73 */       PacketOpenGui packet = new PacketOpenGui();
/* 74 */       packet.setInformations((byte)2);
/* 75 */       CommonProxy.packetPipeline.sendToServer(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\gui\AlchemyCreatorPotionGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */