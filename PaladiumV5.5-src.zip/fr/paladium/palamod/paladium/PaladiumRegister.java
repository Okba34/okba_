/*     */ package fr.paladium.palamod.paladium;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ClientRegistry;
/*     */ import cpw.mods.fml.client.registry.RenderingRegistry;
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.blocks.fluids.BlockAngelicWater;
/*     */ import fr.paladium.palamod.blocks.fluids.BlockSlufuricWater;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.client.render.entity.RenderDynamite;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.items.ItemBucketBase;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.library.Register;
/*     */ import fr.paladium.palamod.library.item.BaseItem;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.paladium.block.BlockAlchemyCreator;
/*     */ import fr.paladium.palamod.paladium.block.BlockBowMachine;
/*     */ import fr.paladium.palamod.paladium.block.BlockCamera;
/*     */ import fr.paladium.palamod.paladium.block.BlockCave;
/*     */ import fr.paladium.palamod.paladium.block.BlockCustomWeb;
/*     */ import fr.paladium.palamod.paladium.block.BlockGuardian;
/*     */ import fr.paladium.palamod.paladium.block.BlockGuardianKeeper;
/*     */ import fr.paladium.palamod.paladium.block.BlockObsidianUpgrader;
/*     */ import fr.paladium.palamod.paladium.block.BlockOnlineDetector;
/*     */ import fr.paladium.palamod.paladium.block.BlockPaladiumChest;
/*     */ import fr.paladium.palamod.paladium.block.BlockPaladiumFurnace;
/*     */ import fr.paladium.palamod.paladium.block.BlockPaladiumMachine;
/*     */ import fr.paladium.palamod.paladium.block.BlockSlimePad;
/*     */ import fr.paladium.palamod.paladium.block.BlockSpike;
/*     */ import fr.paladium.palamod.paladium.block.BlockUpgradedObsidian;
/*     */ import fr.paladium.palamod.paladium.block.obsidian.BlockObsidianExplode;
/*     */ import fr.paladium.palamod.paladium.block.obsidian.BlockObsidianFake;
/*     */ import fr.paladium.palamod.paladium.block.obsidian.BlockObsidianTwoLife;
/*     */ import fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity;
/*     */ import fr.paladium.palamod.paladium.item.BaseItemDynamite;
/*     */ import fr.paladium.palamod.paladium.item.ItemBlockObsidian;
/*     */ import fr.paladium.palamod.paladium.item.ItemDynamiteBig;
/*     */ import fr.paladium.palamod.paladium.item.ItemDynamiteNinja;
/*     */ import fr.paladium.palamod.paladium.item.ItemExtrapolatedBucket;
/*     */ import fr.paladium.palamod.paladium.item.ItemUnclaimFinder;
/*     */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*     */ import fr.paladium.palamod.paladium.logic.BowMachineLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumMachineLogic;
/*     */ import fr.paladium.palamod.paladium.model.block.AlchemyCreatorRender;
/*     */ import fr.paladium.palamod.paladium.model.block.PaladiumChestRender;
/*     */ import fr.paladium.palamod.paladium.model.item.ItemAlchemyCreatorRender;
/*     */ import fr.paladium.palamod.paladium.model.item.ItemChestRender;
/*     */ import fr.paladium.palamod.recipies.PaladiumMachineRecipies;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.client.MinecraftForgeClient;
/*     */ import net.minecraftforge.fluids.Fluid;
/*     */ import net.minecraftforge.fluids.FluidRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PaladiumRegister
/*     */   extends Register
/*     */ {
/*     */   public static BlockPaladiumMachine PALADIUM_MACHINE_BLOCK;
/*     */   public static BlockAlchemyCreator ALCHEMY_CREATOR_BLOCK;
/*     */   public static BlockBowMachine BOW_MACHINE_BLOCK;
/*     */   public static BlockObsidianUpgrader OBSIDIAN_UPGRADER;
/*     */   public static BlockUpgradedObsidian UPGRADED_OBSIDIAN;
/*     */   public static BlockOnlineDetector ONLINE_DETECTOR_BLOCK;
/*     */   public static BlockCamera CAMERA_BLOCK;
/*     */   public static BlockPaladiumFurnace PALADIUM_FURNACE;
/*     */   public static BlockPaladiumFurnace LIT_PALADIUM_FURNACE;
/*     */   public static BaseItem FURNACE_UPGRADE;
/*     */   public static BlockPaladiumChest PALADIUM_CHEST;
/*     */   public static BlockSpike WOOD_SPIKE_BLOCK;
/*     */   public static BlockSpike IRON_SPIKE_BLOCK;
/*     */   public static BlockSpike GOLD_SPIKE_BLOCK;
/*     */   public static BlockSpike DIAMOND_SPIKE_BLOCK;
/*     */   public static BlockSpike AMETHYST_SPIKE_BLOCK;
/*     */   public static BlockSpike TITANE_SPIKE_BLOCK;
/*     */   public static BlockSpike PALADIUM_SPIKE_BLOCK;
/*     */   public static BlockGuardian GUARDIAN_BLOCK;
/*     */   public static BlockGuardianKeeper GUARDIAN_KEEPER_BLOCK;
/*     */   public static BlockCave CAVE_BLOCK;
/*     */   public static BlockSlimePad SLIMEPAD_BLOCK;
/*     */   public static BlockObsidianFake FAKE_OBSIDIAN_BLOCK;
/*     */   public static BlockObsidianExplode EXPLODE_OBSIDIAN_BLOCK;
/*     */   public static BlockObsidianTwoLife TWOLIFE_OBSIDIAN_BLOCK;
/*     */   public static BlockSlufuricWater sulfuricWater;
/*     */   public static Fluid sulfuricWaterFluid;
/*     */   public static BlockAngelicWater angelicWater;
/*     */   public static Fluid angelicWaterFluid;
/*     */   public static ItemBucketBase bucketSulfuric;
/*     */   public static ItemBucketBase bucketAngelic;
/*     */   public static BlockCustomWeb customWeb;
/*     */   public static ItemUnclaimFinder UNCLAIMFINDER;
/*     */   public static BaseItemDynamite DYNAMITE;
/*     */   public static ItemDynamiteNinja NINJA_DYNAMITE;
/*     */   public static ItemDynamiteBig BIG_DYNAMITE;
/*     */   public static ItemExtrapolatedBucket EXTRAPOLATED_BUCKET;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/* 129 */     register();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init(FMLInitializationEvent event)
/*     */   {
/* 136 */     if (event.getSide().isClient()) {
/* 137 */       registerRenderer();
/*     */     }
/* 139 */     registerRecipes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postInit(FMLPostInitializationEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   private void registerRenderer()
/*     */   {
/* 153 */     MinecraftForgeClient.registerItemRenderer(Item.getItemFromBlock(ALCHEMY_CREATOR_BLOCK), new ItemAlchemyCreatorRender(new AlchemyCreatorRender(), new AlchemyCreatorLogic()));
/* 154 */     MinecraftForgeClient.registerItemRenderer(Item.getItemFromBlock(PALADIUM_CHEST), new ItemChestRender());
/*     */     
/*     */ 
/* 157 */     ClientRegistry.bindTileEntitySpecialRenderer(AlchemyCreatorLogic.class, new AlchemyCreatorRender());
/* 158 */     ClientRegistry.bindTileEntitySpecialRenderer(PaladiumChestLogic.class, new PaladiumChestRender());
/*     */     
/*     */ 
/* 161 */     RenderingRegistry.registerEntityRenderingHandler(DynamiteEntity.class, new RenderDynamite(0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void register()
/*     */   {
/* 171 */     registerEntity(DynamiteEntity.class, 6, "dynamite", 80, 3, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 176 */     registerBlock(PALADIUM_MACHINE_BLOCK = new BlockPaladiumMachine("paladium_machine_block"));
/* 177 */     registerBlock(ALCHEMY_CREATOR_BLOCK = new BlockAlchemyCreator("alchemy_creator_block"));
/* 178 */     registerBlock(BOW_MACHINE_BLOCK = new BlockBowMachine("bow_machine_block"));
/*     */     
/* 180 */     registerBlock((OBSIDIAN_UPGRADER = new BlockObsidianUpgrader()).setBlockName("obsidian_upgrader").setHardness(2.5F).setResistance(10.0F).setStepSound(Block.soundTypeWood).setCreativeTab(CreativeTabRegister.PALADIUM));
/* 181 */     registerBlock((UPGRADED_OBSIDIAN = new BlockUpgradedObsidian()).setHardness(50.0F).setResistance(2000.0F).setStepSound(Block.soundTypePiston).setBlockName("upgraded_obsidian").setBlockTextureName("obsidian").setCreativeTab(CreativeTabRegister.PALADIUM));
/*     */     
/* 183 */     registerBlock(ONLINE_DETECTOR_BLOCK = new BlockOnlineDetector("online_detector_block"));
/* 184 */     registerBlock((CAMERA_BLOCK = new BlockCamera()).setBlockName("camera").setHardness(2.5F).setResistance(10.0F).setStepSound(Block.soundTypeWood).setCreativeTab(CreativeTabRegister.PALADIUM));
/*     */     
/* 186 */     registerBlock(GUARDIAN_BLOCK = new BlockGuardian("guardian_block"));
/* 187 */     registerBlock(GUARDIAN_KEEPER_BLOCK = new BlockGuardianKeeper("guardian_keeper_block"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 192 */     registerBlock(PALADIUM_FURNACE = new BlockPaladiumFurnace("paladium_furnace_block", false));
/* 193 */     registerBlock(LIT_PALADIUM_FURNACE = new BlockPaladiumFurnace("lit_paladium_furnace_block", true));
/*     */     
/*     */ 
/* 196 */     registerItem((FURNACE_UPGRADE = new BaseItem("furnace_upgrade")).setMaxStackSize(16));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 201 */     registerBlock(PALADIUM_CHEST = new BlockPaladiumChest("paladium_chest"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 206 */     registerBlock(WOOD_SPIKE_BLOCK = new BlockSpike("wood_spike_block", "spikewood", "SpikeWood_2", "SpikeWood_1", 2.0F, false));
/* 207 */     registerBlock(IRON_SPIKE_BLOCK = new BlockSpike("iron_spike_block", "spikeiron", "SpikeIron_1", "SpikeIron_2", 5.0F, false));
/* 208 */     registerBlock(GOLD_SPIKE_BLOCK = new BlockSpike("gold_spike_block", "spikegold", "SpikeGold_2", "SpikeGold_1", 7.0F, false));
/* 209 */     registerBlock(DIAMOND_SPIKE_BLOCK = new BlockSpike("diamond_spike_block", "spikediamond", "SpikeDiamond_2", "SpikeDiamond_1", 10.0F, false));
/* 210 */     registerBlock(AMETHYST_SPIKE_BLOCK = new BlockSpike("amethyst_spike_block", "spikeamethyst", "SpikeAmethyst_1", "SpikeAmethyst_2", 10.0F, false));
/* 211 */     registerBlock(TITANE_SPIKE_BLOCK = new BlockSpike("titane_spike_block", "spiketitane", "SpikeTitane_1", "SpikeTitane_2", 12.0F, false));
/* 212 */     registerBlock(PALADIUM_SPIKE_BLOCK = new BlockSpike("paladium_spike_block", "spikepaladium", "SpikePaladium_1", "SpikePaladium_2", 15.0F, true));
/*     */     
/* 214 */     registerBlock(CAVE_BLOCK = new BlockCave("cave_block"));
/*     */     
/* 216 */     registerBlock(SLIMEPAD_BLOCK = new BlockSlimePad("slimepad_block"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 221 */     registerBlock(EXPLODE_OBSIDIAN_BLOCK = new BlockObsidianExplode("explodeObsidian_block"), ItemBlockObsidian.class);
/* 222 */     registerBlock(FAKE_OBSIDIAN_BLOCK = new BlockObsidianFake("fakeObsidian_block"), ItemBlockObsidian.class);
/* 223 */     registerBlock(TWOLIFE_OBSIDIAN_BLOCK = new BlockObsidianTwoLife("twoLifeObsidian_block"), ItemBlockObsidian.class);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 228 */     sulfuricWaterFluid = new Fluid("sulfuricWater").setDensity(200).setViscosity(1);
/* 229 */     angelicWaterFluid = new Fluid("angelicWater").setDensity(200);
/*     */     
/* 231 */     FluidRegistry.registerFluid(angelicWaterFluid);
/* 232 */     FluidRegistry.registerFluid(sulfuricWaterFluid);
/*     */     
/* 234 */     registerBlock(sulfuricWater = new BlockSlufuricWater(sulfuricWaterFluid, Material.water));
/* 235 */     registerBlock(angelicWater = new BlockAngelicWater(angelicWaterFluid, Material.water));
/*     */     
/* 237 */     registerItem(bucketSulfuric = new ItemBucketBase(sulfuricWater, "sulfuricwater", "BucketSulfuric"));
/* 238 */     registerItem(bucketAngelic = new ItemBucketBase(angelicWater, "angelicwater", "BucketAngelic"));
/*     */     
/* 240 */     registerBlock(customWeb = new BlockCustomWeb());
/*     */     
/*     */ 
/* 243 */     registerItem(UNCLAIMFINDER = new ItemUnclaimFinder("unclaimFinder"));
/*     */     
/*     */ 
/* 246 */     registerItem(DYNAMITE = new BaseItemDynamite("dynamite"));
/* 247 */     registerItem(NINJA_DYNAMITE = new ItemDynamiteNinja("dynamite_ninja"));
/* 248 */     registerItem(BIG_DYNAMITE = new ItemDynamiteBig("dynamite_big"));
/*     */     
/* 250 */     registerItem(EXTRAPOLATED_BUCKET = new ItemExtrapolatedBucket("extrapolated_bucket"));
/*     */     
/*     */ 
/* 253 */     registerTileEntity(PaladiumMachineLogic.class, "paladiumMachine");
/* 254 */     registerTileEntity(AlchemyCreatorLogic.class, "alchemyCreator");
/* 255 */     registerTileEntity(BowMachineLogic.class, "bowMachine");
/* 256 */     registerTileEntity(PaladiumFurnaceLogic.class, "paladiumFurnace");
/* 257 */     registerTileEntity(PaladiumChestLogic.class, "paladiumChest");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerRecipes()
/*     */   {
/* 265 */     registerPaladiumMachineRecipies();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 270 */     GameRegistry.addRecipe(new ItemStack(PALADIUM_MACHINE_BLOCK), new Object[] { "XXX", "XYX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 274 */       Character.valueOf('Y'), ModItems.compressedPaladium, 
/* 275 */       Character.valueOf('X'), new ItemStack(Blocks.stone) });
/*     */     
/* 277 */     GameRegistry.addRecipe(new ItemStack(ALCHEMY_CREATOR_BLOCK), new Object[] { "YUY", "XZX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 281 */       Character.valueOf('Y'), Items.blaze_powder, 
/* 282 */       Character.valueOf('U'), new ItemStack(ModItems.compressedPaladium), 
/* 283 */       Character.valueOf('X'), MaterialRegister.TITANE_INGOT, 
/* 284 */       Character.valueOf('Z'), ModItems.paladiumCore });
/*     */     
/* 286 */     GameRegistry.addRecipe(new ItemStack(BOW_MACHINE_BLOCK), new Object[] { "XXX", "XYX", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 290 */       Character.valueOf('Y'), ModItems.compressedPaladium, 
/* 291 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 297 */     GameRegistry.addRecipe(new ItemStack(PALADIUM_FURNACE), new Object[] { "XXX", "X X", "XXX", 
/*     */     
/*     */ 
/*     */ 
/* 301 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/*     */ 
/*     */ 
/* 305 */     GameRegistry.addRecipe(new ItemStack(FURNACE_UPGRADE, 4), new Object[] { " X ", "XUX", " X ", 
/*     */     
/*     */ 
/*     */ 
/* 309 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 310 */       Character.valueOf('U'), new ItemStack(Items.diamond) });
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 318 */     GameRegistry.addRecipe(new ItemStack(UNCLAIMFINDER, 1), new Object[] { " X ", "YZY", " X ", 
/*     */     
/*     */ 
/*     */ 
/* 322 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT), 
/* 323 */       Character.valueOf('Z'), new ItemStack(MaterialRegister.FINDIUM), Character.valueOf('Y'), new ItemStack(ModItems.paladiumCore) });
/*     */     
/*     */ 
/*     */ 
/* 327 */     GameRegistry.addRecipe(new ItemStack(DYNAMITE, 4), new Object[] { "X", "Z", "Z", 
/*     */     
/*     */ 
/*     */ 
/* 331 */       Character.valueOf('X'), new ItemStack(ModItems.diamondString), 
/* 332 */       Character.valueOf('Z'), new ItemStack(Blocks.tnt) });
/*     */     
/* 334 */     GameRegistry.addRecipe(new ItemStack(BIG_DYNAMITE, 1), new Object[] { "XXX", 
/*     */     
/* 336 */       Character.valueOf('X'), new ItemStack(DYNAMITE) });
/*     */     
/* 338 */     GameRegistry.addRecipe(new ItemStack(NINJA_DYNAMITE, 1), new Object[] { "XYX", "XYX", "XYX", 
/*     */     
/*     */ 
/*     */ 
/* 342 */       Character.valueOf('X'), new ItemStack(MaterialRegister.TITANE_INGOT), 
/* 343 */       Character.valueOf('Y'), new ItemStack(DYNAMITE) });
/*     */     
/*     */ 
/* 346 */     GameRegistry.addRecipe(new ItemStack(EXTRAPOLATED_BUCKET), new Object[] { "X X", " X ", 
/*     */     
/*     */ 
/* 349 */       Character.valueOf('X'), new ItemStack(MaterialRegister.PALADIUM_INGOT) });
/*     */     
/*     */ 
/* 352 */     GameRegistry.addRecipe(new ItemStack(TWOLIFE_OBSIDIAN_BLOCK), new Object[] { " X ", "XYX", " X ", 
/*     */     
/*     */ 
/*     */ 
/* 356 */       Character.valueOf('X'), new ItemStack(Items.golden_apple), 
/* 357 */       Character.valueOf('Y'), new ItemStack(Blocks.obsidian) });
/*     */     
/*     */ 
/* 360 */     GameRegistry.addRecipe(new ItemStack(EXPLODE_OBSIDIAN_BLOCK), new Object[] { " X ", "XYX", " X ", 
/*     */     
/*     */ 
/*     */ 
/* 364 */       Character.valueOf('X'), new ItemStack(DYNAMITE), 
/* 365 */       Character.valueOf('Y'), new ItemStack(Blocks.obsidian) });
/*     */     
/*     */ 
/* 368 */     GameRegistry.addRecipe(new ItemStack(FAKE_OBSIDIAN_BLOCK), new Object[] { " X ", "XYX", " X ", 
/*     */     
/*     */ 
/*     */ 
/* 372 */       Character.valueOf('X'), new ItemStack(bucketSulfuric), 
/* 373 */       Character.valueOf('Y'), new ItemStack(Blocks.obsidian) });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void registerPaladiumMachineRecipies()
/*     */   {
/* 381 */     PaladiumMachineRecipies.getManager().add(new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.smallRing, 1));
/*     */     
/*     */ 
/*     */ 
/* 385 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.smallRing), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.mediumRing, 1));
/*     */     
/*     */ 
/*     */ 
/* 389 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.mediumRing), new ItemStack(ModItems.compressedPaladium), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.compressedPaladium), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.bigRing, 1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 395 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.smallRing), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.smallRing, 1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 400 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.mediumRing), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(ModItems.mediumRing, 1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 405 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.bigRing), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(MaterialRegister.PALADIUM_INGOT), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.bigRing, 1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 413 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.speedOrb), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.speedStick, 1));
/*     */     
/*     */ 
/*     */ 
/* 417 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.strenghtOrb), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.strenghtStick, 1));
/*     */     
/*     */ 
/*     */ 
/* 421 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.jumpOrb), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.jumpStick, 1));
/*     */     
/*     */ 
/*     */ 
/* 425 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.healOrb), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.healStick, 1));
/*     */     
/*     */ 
/* 428 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.healStick), new ItemStack(ModItems.strenghtStick), new ItemStack(ModItems.paladiumCore), new ItemStack(ModItems.speedStick), new ItemStack(ModItems.paladiumCore), new ItemStack(ModItems.godStick, 1));
/*     */     
/*     */ 
/* 431 */     PaladiumMachineRecipies.getManager().add(new ItemStack(ModItems.jumpOrb), new ItemStack(ModItems.jumpStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.jumpStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.hyperJumpStick, 1));
/*     */     
/*     */ 
/*     */ 
/* 435 */     PaladiumMachineRecipies.getManager().add(new ItemStack(Items.potionitem, 1, 8204), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.paladiumStick), new ItemStack(DecorativeRegister.PALADIUM_BLOCK), new ItemStack(ModItems.damageStick, 1));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 443 */     PaladiumMachineRecipies.getManager().add(new ItemStack(UNCLAIMFINDER, 1, 0), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(UNCLAIMFINDER, 1, 1));
/*     */     
/*     */ 
/*     */ 
/* 447 */     PaladiumMachineRecipies.getManager().add(new ItemStack(UNCLAIMFINDER, 1, 1), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(MaterialRegister.FINDIUM), new ItemStack(UNCLAIMFINDER, 1, 2));
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\PaladiumRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */