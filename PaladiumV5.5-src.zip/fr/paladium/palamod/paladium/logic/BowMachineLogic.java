/*     */ package fr.paladium.palamod.paladium.logic;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.recipies.BowMachineRecipies;
/*     */ import fr.paladium.palamod.util.BowHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BowMachineLogic extends TileEntity implements net.minecraft.inventory.IInventory, net.minecraft.inventory.ISidedInventory
/*     */ {
/*     */   public ItemStack[] content;
/*     */   public int workedTime;
/*     */   public int timeNeeded;
/*     */   
/*     */   public BowMachineLogic()
/*     */   {
/*  22 */     this.content = new ItemStack[2];
/*  23 */     this.timeNeeded = 200;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  28 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  33 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  38 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  41 */       if (this.content[slotIndex].stackSize <= amount) {
/*  42 */         ItemStack itemstack = this.content[slotIndex];
/*  43 */         this.content[slotIndex] = null;
/*  44 */         markDirty();
/*     */         
/*  46 */         return itemstack;
/*     */       }
/*     */       
/*  49 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  51 */       if (this.content[slotIndex].stackSize == 0) {
/*  52 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  55 */       markDirty();
/*     */       
/*  57 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  61 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  67 */     if (this.content[slotIndex] != null) {
/*  68 */       ItemStack itemstack = this.content[slotIndex];
/*  69 */       this.content[slotIndex] = null;
/*     */       
/*  71 */       return itemstack;
/*     */     }
/*     */     
/*  74 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  80 */     this.content[slotIndex] = stack;
/*     */     
/*  82 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  83 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  86 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  91 */     return "tile.BowMachine";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 101 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 109 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/* 125 */     super.updateEntity();
/*     */     
/* 127 */     if (!canSmelt()) {
/* 128 */       this.workedTime = 0;
/* 129 */       return;
/*     */     }
/* 131 */     if ((canSmelt()) && (this.workedTime < this.timeNeeded)) {
/* 132 */       this.workedTime += 1;
/*     */     }
/* 134 */     if ((canSmelt()) && (this.workedTime >= this.timeNeeded)) {
/* 135 */       smeltItem();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canSmelt() {
/* 140 */     if ((this.content[0] == null) || (this.content[1] == null)) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (!BowMachineRecipies.instance.hasRecipie(this.content[0].getItem())) {
/* 144 */       return false;
/*     */     }
/* 146 */     if (!BowHelper.canApply(this.content[1], BowMachineRecipies.instance.getModifier(this.content[0].getItem()))) {
/* 147 */       return false;
/*     */     }
/*     */     
/* 150 */     return true;
/*     */   }
/*     */   
/*     */   public void smeltItem() {
/* 154 */     if ((this.content[0] == null) || (this.content[1] == null)) {
/* 155 */       return;
/*     */     }
/*     */     
/* 158 */     if (!BowMachineRecipies.instance.hasRecipie(this.content[0].getItem())) {
/* 159 */       return;
/*     */     }
/*     */     
/* 162 */     if (BowHelper.canApply(this.content[1], BowMachineRecipies.instance.getModifier(this.content[0].getItem()))) {
/* 163 */       BowHelper.applyModifiers(this.content[1], BowMachineRecipies.instance.getModifier(this.content[0].getItem()));
/* 164 */       this.content[0].stackSize -= 1;
/*     */       
/* 166 */       if (this.content[0].stackSize <= 0) {
/* 167 */         this.content[0] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 174 */     super.writeToNBT(compound);
/* 175 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 177 */     for (int i = 0; i < this.content.length; i++) {
/* 178 */       if (this.content[i] != null) {
/* 179 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 180 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 181 */         this.content[i].writeToNBT(nbttagcompound1);
/* 182 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/* 185 */     compound.setInteger("workedTime", this.workedTime);
/* 186 */     compound.setTag("Items", nbttaglist);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 191 */     super.readFromNBT(compound);
/*     */     
/* 193 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 194 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 196 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 197 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 198 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 200 */       if ((j >= 0) && (j < this.content.length)) {
/* 201 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/* 204 */     this.workedTime = compound.getInteger("workedTime");
/*     */   }
/*     */   
/*     */   public boolean isBurning() {
/* 208 */     return this.workedTime > 0;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getCookProgressScaled(int value) {
/* 213 */     return value * this.workedTime / this.timeNeeded;
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 218 */     return new int[0];
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 223 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 228 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\logic\BowMachineLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */