/*     */ package fr.paladium.palamod.paladium.logic;
/*     */ 
/*     */ import fr.paladium.palamod.items.ItemRingBase;
/*     */ import fr.paladium.palamod.items.armors.RepairableArmor;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ 
/*     */ public class PaladiumChestLogic extends TileEntity implements net.minecraft.inventory.IInventory, ISidedInventory
/*     */ {
/*     */   public ItemStack[] content;
/*     */   public boolean openning;
/*     */   public boolean closing;
/*     */   public float prevLid;
/*     */   public float lid;
/*     */   
/*     */   public PaladiumChestLogic()
/*     */   {
/*  22 */     this.content = new ItemStack[112];
/*     */     
/*  24 */     this.openning = false;
/*  25 */     this.closing = false;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  30 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  35 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  40 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  43 */       if (this.content[slotIndex].stackSize <= amount) {
/*  44 */         ItemStack itemstack = this.content[slotIndex];
/*     */         
/*  46 */         this.content[slotIndex] = null;
/*  47 */         markDirty();
/*     */         
/*  49 */         return itemstack;
/*     */       }
/*     */       
/*  52 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  54 */       if (this.content[slotIndex].stackSize == 0) {
/*  55 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  58 */       markDirty();
/*  59 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  63 */     return null;
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/*  68 */     for (int i = 108; i < 112; i++) {
/*  69 */       ItemStack ring = this.content[i];
/*     */       
/*  71 */       if ((ring != null) && (ring.getItemDamage() < ring.getMaxDamage())) {
/*  72 */         for (int j = 0; j < 12; j++) {
/*  73 */           ItemStack armor = this.content[j];
/*     */           
/*  75 */           if ((armor != null) && ((armor.getItem() instanceof RepairableArmor)) && (armor.getItemDamage() > 0)) {
/*  76 */             ((RepairableArmor)armor.getItem()).repair(armor, ring);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  85 */     if (this.content[slotIndex] != null) {
/*  86 */       ItemStack itemstack = this.content[slotIndex];
/*  87 */       this.content[slotIndex] = null;
/*     */       
/*  89 */       return itemstack;
/*     */     }
/*     */     
/*  92 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  98 */     this.content[slotIndex] = stack;
/*     */     
/* 100 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/* 101 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 104 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/* 109 */     return "tile.PaladiumChest";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 119 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 124 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */   public void openInventory()
/*     */   {
/* 129 */     this.openning = true;
/*     */   }
/*     */   
/*     */   public void closeInventory()
/*     */   {
/* 134 */     this.closing = true;
/*     */   }
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack item)
/*     */   {
/* 139 */     if (slot < 108) {
/* 140 */       return true;
/*     */     }
/* 142 */     if ((item.getItem() instanceof ItemRingBase)) {
/* 143 */       return true;
/*     */     }
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 150 */     super.writeToNBT(compound);
/* 151 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 153 */     for (int i = 0; i < this.content.length; i++) {
/* 154 */       if (this.content[i] != null) {
/* 155 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 156 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 157 */         this.content[i].writeToNBT(nbttagcompound1);
/* 158 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/* 161 */     compound.setTag("Items", nbttaglist);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 166 */     super.readFromNBT(compound);
/*     */     
/* 168 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 169 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 171 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 172 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 173 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 175 */       if ((j >= 0) && (j < this.content.length)) {
/* 176 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 183 */     int[] slots = new int[108];
/* 184 */     for (int i = 0; i < 108; i++) {
/* 185 */       slots[i] = i;
/*     */     }
/* 187 */     return slots;
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 192 */     if (slot < 108) {
/* 193 */       return true;
/*     */     }
/* 195 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot) {
/* 199 */     if (slot < 108) {
/* 200 */       return true;
/*     */     }
/* 202 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\logic\PaladiumChestLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */