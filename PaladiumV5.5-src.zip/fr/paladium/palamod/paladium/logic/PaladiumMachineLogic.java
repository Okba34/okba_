/*     */ package fr.paladium.palamod.paladium.logic;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.recipies.PaladiumMachineRecipies;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class PaladiumMachineLogic extends TileEntity implements net.minecraft.inventory.IInventory, net.minecraft.inventory.ISidedInventory
/*     */ {
/*     */   private ItemStack[] content;
/*     */   private int workingTime;
/*     */   private int timeNeeded;
/*     */   
/*     */   public PaladiumMachineLogic()
/*     */   {
/*  20 */     this.content = new ItemStack[6];
/*     */     
/*  22 */     this.workingTime = 0;
/*  23 */     this.timeNeeded = 200;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  28 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  33 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  36 */       if (this.content[slotIndex].stackSize <= amount) {
/*  37 */         ItemStack itemstack = this.content[slotIndex];
/*     */         
/*  39 */         this.content[slotIndex] = null;
/*  40 */         markDirty();
/*     */         
/*  42 */         return itemstack;
/*     */       }
/*     */       
/*  45 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  47 */       if (this.content[slotIndex].stackSize == 0) {
/*  48 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  51 */       markDirty();
/*  52 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  56 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  62 */     if (this.content[slotIndex] != null) {
/*  63 */       ItemStack itemstack = this.content[slotIndex];
/*  64 */       this.content[slotIndex] = null;
/*     */       
/*  66 */       return itemstack;
/*     */     }
/*     */     
/*  69 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  75 */     this.content[slotIndex] = stack;
/*     */     
/*  77 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  78 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  81 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  86 */     return "tile.PaladiumMachine";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/*  96 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 101 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 112 */     return slot != 5;
/*     */   }
/*     */   
/*     */   public boolean isBurning() {
/* 116 */     return this.workingTime > 0;
/*     */   }
/*     */   
/*     */   private boolean canSmelt() {
/* 120 */     if ((this.content[0] == null) || (this.content[1] == null) || (this.content[2] == null) || (this.content[3] == null) || (this.content[4] == null)) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     ItemStack itemstack = PaladiumMachineRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[0], this.content[1], this.content[2], this.content[3], this.content[4] });
/* 125 */     if (itemstack == null) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (this.content[5] == null) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (!this.content[5].isItemEqual(itemstack)) {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     int result = this.content[5].stackSize + itemstack.stackSize;
/* 136 */     return (result <= getInventoryStackLimit()) && (result <= this.content[5].getMaxStackSize());
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 142 */     super.writeToNBT(compound);
/*     */     
/* 144 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 146 */     for (int i = 0; i < this.content.length; i++) {
/* 147 */       if (this.content[i] != null) {
/* 148 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 149 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 150 */         this.content[i].writeToNBT(nbttagcompound1);
/* 151 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 155 */     compound.setTag("Items", nbttaglist);
/* 156 */     compound.setShort("workingTime", (short)this.workingTime);
/* 157 */     compound.setShort("workingTimeNeeded", (short)this.timeNeeded);
/*     */   }
/*     */   
/*     */   @SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */   public int getCookProgress() {
/* 162 */     return this.workingTime * 16 / this.timeNeeded;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 167 */     super.readFromNBT(compound);
/*     */     
/* 169 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 170 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 172 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 173 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 174 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 176 */       if ((j >= 0) && (j < this.content.length)) {
/* 177 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 181 */     this.workingTime = compound.getShort("workingTime");
/* 182 */     this.timeNeeded = compound.getShort("workingTimeNeeded");
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/* 187 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/* 192 */     if ((isBurning()) && (canSmelt())) {
/* 193 */       this.workingTime += 1;
/*     */     }
/* 195 */     if ((canSmelt()) && (!isBurning())) {
/* 196 */       this.workingTime = 1;
/*     */     }
/* 198 */     if ((canSmelt()) && (this.workingTime == this.timeNeeded)) {
/* 199 */       smeltItem();
/* 200 */       this.workingTime = 0;
/*     */     }
/* 202 */     if (!canSmelt()) {
/* 203 */       this.workingTime = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public void smeltItem() {
/* 208 */     if (canSmelt()) {
/* 209 */       ItemStack itemstack = PaladiumMachineRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[0], this.content[1], this.content[2], this.content[3], this.content[4] });
/* 210 */       if (this.content[5] == null) {
/* 211 */         this.content[5] = itemstack.copy();
/*     */       }
/* 213 */       else if (this.content[5].getItem() == itemstack.getItem()) {
/* 214 */         this.content[5].stackSize += itemstack.stackSize;
/*     */       }
/*     */       
/* 217 */       this.content[0].stackSize -= 1;
/* 218 */       this.content[1].stackSize -= 1;
/* 219 */       this.content[2].stackSize -= 1;
/* 220 */       this.content[3].stackSize -= 1;
/* 221 */       this.content[4].stackSize -= 1;
/*     */       
/* 223 */       if (this.content[0].stackSize <= 0) {
/* 224 */         this.content[0] = null;
/*     */       }
/* 226 */       if (this.content[1].stackSize <= 0) {
/* 227 */         this.content[1] = null;
/*     */       }
/* 229 */       if (this.content[2].stackSize <= 0) {
/* 230 */         this.content[2] = null;
/*     */       }
/* 232 */       if (this.content[3].stackSize <= 0) {
/* 233 */         this.content[3] = null;
/*     */       }
/* 235 */       if (this.content[4].stackSize <= 0) {
/* 236 */         this.content[4] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 243 */     return new int[0];
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 248 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 253 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\logic\PaladiumMachineLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */