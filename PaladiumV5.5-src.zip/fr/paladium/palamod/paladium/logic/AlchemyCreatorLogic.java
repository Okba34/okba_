/*     */ package fr.paladium.palamod.paladium.logic;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.recipies.AlchemyCreatorArrowRecipies;
/*     */ import fr.paladium.palamod.recipies.AlchemyCreatorPotionRecipies;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class AlchemyCreatorLogic
/*     */   extends TileEntity
/*     */   implements IInventory, ISidedInventory
/*     */ {
/*     */   public ItemStack[] content;
/*     */   private int[] workingTime;
/*     */   private int[] timeNeeded;
/*     */   public static int POTION;
/*     */   public static int ARROW;
/*  26 */   public static HashMap<EntityPlayer, AlchemyCreatorLogic> oppenedGui = new HashMap();
/*     */   
/*     */   public AlchemyCreatorLogic() {
/*  29 */     this.content = new ItemStack[9];
/*     */     
/*  31 */     this.workingTime = new int[2];
/*  32 */     this.timeNeeded = new int[2];
/*  33 */     this.timeNeeded[0] = 200;
/*  34 */     this.timeNeeded[1] = 20;
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  39 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  44 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  49 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  52 */       if (this.content[slotIndex].stackSize <= amount) {
/*  53 */         ItemStack itemstack = this.content[slotIndex];
/*  54 */         this.content[slotIndex] = null;
/*  55 */         markDirty();
/*  56 */         return itemstack;
/*     */       }
/*     */       
/*  59 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  61 */       if (this.content[slotIndex].stackSize == 0) {
/*  62 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  65 */       markDirty();
/*  66 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  70 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  76 */     if (this.content[slotIndex] != null) {
/*  77 */       ItemStack itemstack = this.content[slotIndex];
/*  78 */       this.content[slotIndex] = null;
/*  79 */       return itemstack;
/*     */     }
/*     */     
/*  82 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  88 */     this.content[slotIndex] = stack;
/*     */     
/*  90 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  91 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  94 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  99 */     return "tile.AlchemyCreator";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 109 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 114 */     return (this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) instanceof AlchemyCreatorLogic);
/*     */   }
/*     */   
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 130 */     super.writeToNBT(compound);
/* 131 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 133 */     for (int i = 0; i < this.content.length; i++) {
/* 134 */       if (this.content[i] != null) {
/* 135 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 136 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 137 */         this.content[i].writeToNBT(nbttagcompound1);
/* 138 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/* 141 */     compound.setTag("Items", nbttaglist);
/*     */     
/* 143 */     compound.setInteger("workingTimePotion", this.workingTime[0]);
/* 144 */     compound.setInteger("workingTimeArrow", this.timeNeeded[1]);
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 149 */     super.readFromNBT(compound);
/*     */     
/* 151 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 152 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 154 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 155 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 156 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 158 */       if ((j >= 0) && (j < this.content.length)) {
/* 159 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/* 162 */     this.workingTime[0] = compound.getInteger("workingTimePotion");
/* 163 */     this.timeNeeded[1] = compound.getInteger("workingTimeArrow");
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/* 168 */     if (!canSmeltPotion()) {
/* 169 */       this.workingTime[0] = 0;
/*     */     }
/*     */     
/* 172 */     if ((isBurningPotion()) && (canSmeltPotion())) {
/* 173 */       this.workingTime[0] += 1;
/*     */     }
/*     */     
/* 176 */     if ((canSmeltPotion()) && (!isBurningPotion())) {
/* 177 */       this.workingTime[0] = 1;
/*     */     }
/* 179 */     if ((canSmeltPotion()) && (this.workingTime[0] == this.timeNeeded[0])) {
/* 180 */       smeltItemPotion();
/* 181 */       this.workingTime[0] = 0;
/*     */     }
/*     */     
/* 184 */     if (!canSmeltArrow()) {
/* 185 */       this.workingTime[1] = 0;
/*     */     }
/*     */     
/* 188 */     if ((isBurningArrow()) && (canSmeltArrow())) {
/* 189 */       this.workingTime[1] += 1;
/*     */     }
/*     */     
/* 192 */     if ((canSmeltArrow()) && (!isBurningArrow())) {
/* 193 */       this.workingTime[1] = 1;
/*     */     }
/* 195 */     if ((canSmeltArrow()) && (this.workingTime[1] == this.timeNeeded[1])) {
/* 196 */       smeltItemArrow();
/* 197 */       this.workingTime[1] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canSmeltPotion()
/*     */   {
/* 203 */     if ((this.content[0] == null) || (this.content[1] == null) || (this.content[2] == null) || (this.content[3] == null)) {
/* 204 */       return false;
/*     */     }
/*     */     
/* 207 */     ItemStack itemstack = AlchemyCreatorPotionRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[0], this.content[1], this.content[2], this.content[3] });
/* 208 */     if (itemstack == null) {
/* 209 */       return false;
/*     */     }
/*     */     
/* 212 */     return true;
/*     */   }
/*     */   
/*     */   private boolean canSmeltArrow() {
/* 216 */     if ((this.content[4] == null) || (this.content[5] == null) || (this.content[6] == null) || (this.content[7] == null)) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     ItemStack itemstack = AlchemyCreatorArrowRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[4], this.content[5], this.content[6], this.content[7] });
/*     */     
/* 222 */     if (itemstack == null) {
/* 223 */       return false;
/*     */     }
/*     */     
/* 226 */     if ((this.content[8] != null) && (this.content[8].stackSize > getInventoryStackLimit() - itemstack.stackSize)) {
/* 227 */       return false;
/*     */     }
/* 229 */     if ((this.content[8] != null) && (itemstack.getItem() != this.content[8].getItem())) {
/* 230 */       return false;
/*     */     }
/* 232 */     if (this.content[7].stackSize < itemstack.stackSize) {
/* 233 */       return false;
/*     */     }
/*     */     
/* 236 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isBurningPotion() {
/* 240 */     return this.workingTime[0] > 0;
/*     */   }
/*     */   
/*     */   public boolean isBurningArrow() {
/* 244 */     return this.workingTime[1] > 0;
/*     */   }
/*     */   
/*     */   public void smeltItemPotion() {
/* 248 */     if (canSmeltPotion()) {
/* 249 */       ItemStack itemstack = AlchemyCreatorPotionRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[0], this.content[1], this.content[2], this.content[3] });
/*     */       
/* 251 */       this.content[3] = itemstack.copy();
/*     */       
/* 253 */       this.content[0].stackSize -= 1;
/* 254 */       this.content[1].stackSize -= 1;
/* 255 */       this.content[2].stackSize -= 1;
/*     */       
/* 257 */       if (this.content[0].stackSize <= 0) {
/* 258 */         this.content[0] = null;
/*     */       }
/* 260 */       if (this.content[1].stackSize <= 0) {
/* 261 */         this.content[1] = null;
/*     */       }
/* 263 */       if (this.content[2].stackSize <= 0) {
/* 264 */         this.content[2] = null;
/*     */       }
/* 266 */       if (this.content[3].stackSize <= 0)
/* 267 */         this.content[3] = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void smeltItemArrow() {
/* 272 */     if (canSmeltArrow()) {
/* 273 */       ItemStack itemstack = AlchemyCreatorArrowRecipies.getManager().getSmeltingResult(new ItemStack[] { this.content[4], this.content[5], this.content[6], this.content[7] });
/*     */       
/* 275 */       if (this.content[8] == null) {
/* 276 */         this.content[8] = itemstack.copy();
/*     */       }
/* 278 */       else if (this.content[8].stackSize > 0) {
/* 279 */         this.content[8].stackSize += itemstack.stackSize;
/*     */       }
/*     */       
/* 282 */       this.content[4].stackSize -= 1;
/* 283 */       this.content[5].stackSize -= 1;
/* 284 */       this.content[6].stackSize -= 1;
/*     */       
/* 286 */       this.content[7].stackSize -= itemstack.stackSize;
/*     */       
/* 288 */       if (this.content[4].stackSize <= 0) {
/* 289 */         this.content[4] = null;
/*     */       }
/* 291 */       if (this.content[5].stackSize <= 0) {
/* 292 */         this.content[5] = null;
/*     */       }
/* 294 */       if (this.content[6].stackSize <= 0) {
/* 295 */         this.content[6] = null;
/*     */       }
/* 297 */       if (this.content[7].stackSize <= 0) {
/* 298 */         this.content[7] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getCookProgressPotion() {
/* 305 */     return this.workingTime[0];
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getCookProgressArrow() {
/* 310 */     return this.workingTime[1];
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 315 */     return new int[0];
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 325 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\logic\AlchemyCreatorLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */