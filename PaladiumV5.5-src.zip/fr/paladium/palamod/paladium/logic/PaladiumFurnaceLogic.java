/*     */ package fr.paladium.palamod.paladium.logic;
/*     */ 
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.paladium.block.BlockPaladiumFurnace;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemHoe;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.item.ItemTool;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class PaladiumFurnaceLogic extends TileEntity implements net.minecraft.inventory.IInventory, ISidedInventory
/*     */ {
/*  26 */   private static final int[] slotsTop = { 0 };
/*  27 */   private static final int[] slotsBottom = { 2, 1 };
/*  28 */   private static final int[] slotsSides = { 1 };
/*     */   
/*  30 */   private ItemStack[] content = new ItemStack[4];
/*     */   
/*     */   public int furnaceBurnTime;
/*     */   
/*     */   public int currentItemBurnTime;
/*     */   public int furnaceCookTime;
/*  36 */   public int timeNeeded = 200;
/*     */   
/*     */   private String furnaceName;
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  42 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  47 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  52 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  55 */       if (this.content[slotIndex].stackSize <= amount) {
/*  56 */         ItemStack itemstack = this.content[slotIndex];
/*  57 */         this.content[slotIndex] = null;
/*     */         
/*  59 */         return itemstack;
/*     */       }
/*     */       
/*  62 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  64 */       if (this.content[slotIndex].stackSize == 0) {
/*  65 */         this.content[slotIndex] = null;
/*     */       }
/*  67 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*  71 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  77 */     if (this.content[slotIndex] != null) {
/*  78 */       ItemStack itemstack = this.content[slotIndex];
/*  79 */       this.content[slotIndex] = null;
/*     */       
/*  81 */       return itemstack;
/*     */     }
/*     */     
/*  84 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  90 */     this.content[slotIndex] = stack;
/*     */     
/*  92 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  93 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  99 */     return hasCustomInventoryName() ? this.furnaceName : "tile.PaladiumFurnace";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 104 */     return (this.furnaceName != null) && (this.furnaceName.length() > 0);
/*     */   }
/*     */   
/*     */   public void furnaceName(String furnaceName) {
/* 108 */     this.furnaceName = furnaceName;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound) {
/* 112 */     super.readFromNBT(compound);
/*     */     
/* 114 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 115 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 117 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 118 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 119 */       byte b0 = nbttagcompound1.getByte("Slot");
/*     */       
/* 121 */       if ((b0 >= 0) && (b0 < this.content.length)) {
/* 122 */         this.content[b0] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 126 */     this.furnaceBurnTime = compound.getShort("BurnTime");
/* 127 */     this.furnaceCookTime = compound.getShort("CookTime");
/* 128 */     this.currentItemBurnTime = getItemBurnTime(this.content[1]);
/*     */     
/* 130 */     this.timeNeeded = compound.getShort("workingTimeNeeded");
/*     */     
/* 132 */     if (compound.hasKey("CustomName", 8)) {
/* 133 */       this.furnaceName = compound.getString("CustomName");
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound compound) {
/* 138 */     super.writeToNBT(compound);
/*     */     
/* 140 */     compound.setShort("BurnTime", (short)this.furnaceBurnTime);
/* 141 */     compound.setShort("CookTime", (short)this.furnaceCookTime);
/* 142 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 144 */     for (int i = 0; i < this.content.length; i++) {
/* 145 */       if (this.content[i] != null) {
/* 146 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 147 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 148 */         this.content[i].writeToNBT(nbttagcompound1);
/* 149 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 153 */     compound.setTag("Items", nbttaglist);
/*     */     
/* 155 */     compound.setShort("workingTimeNeeded", (short)this.timeNeeded);
/*     */     
/* 157 */     if (hasCustomInventoryName()) {
/* 158 */       compound.setString("CustomName", this.furnaceName);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 164 */     return 64;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getCookProgressScaled(int value) {
/* 169 */     return this.furnaceCookTime * value / this.timeNeeded;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getBurnTimeRemainingScaled(int value) {
/* 174 */     if (this.currentItemBurnTime == 0) {
/* 175 */       this.currentItemBurnTime = 200;
/*     */     }
/*     */     
/* 178 */     return this.furnaceBurnTime * value / this.currentItemBurnTime;
/*     */   }
/*     */   
/*     */   public boolean isBurning() {
/* 182 */     return this.furnaceBurnTime > 0;
/*     */   }
/*     */   
/*     */   public void updateEntity()
/*     */   {
/* 187 */     boolean flag = this.furnaceBurnTime > 0;
/* 188 */     boolean flag1 = false;
/*     */     int modifier;
/*     */     int modifier;
/* 191 */     if ((this.content[3] != null) && (this.content[3].stackSize > 0)) {
/* 192 */       modifier = this.content[3].stackSize;
/*     */     }
/*     */     else {
/* 195 */       modifier = 1;
/*     */     }
/*     */     
/* 198 */     if (this.furnaceBurnTime > 0) {
/* 199 */       this.furnaceBurnTime -= modifier;
/*     */     }
/*     */     
/* 202 */     this.timeNeeded = (200 / modifier);
/*     */     
/* 204 */     if (((this.furnaceBurnTime != 0) || ((this.content[0] != null) && (this.content[1] != null))) && 
/* 205 */       (this.furnaceBurnTime <= 0) && (canSmelt())) {
/* 206 */       this.currentItemBurnTime = (this.furnaceBurnTime = getItemBurnTime(this.content[1]));
/*     */       
/* 208 */       if (this.furnaceBurnTime > 0) {
/* 209 */         flag1 = true;
/* 210 */         this.content[1].stackSize -= 1;
/*     */         
/* 212 */         if (this.content[1].stackSize <= 0) {
/* 213 */           this.content[1] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 219 */     if ((!isBurning()) && (canSmelt())) {
/* 220 */       this.furnaceCookTime = 1;
/*     */     }
/*     */     
/* 223 */     if ((isBurning()) && (canSmelt()) && (this.furnaceBurnTime != 0)) {
/* 224 */       this.furnaceCookTime += 1;
/*     */       
/* 226 */       if (this.furnaceCookTime >= this.timeNeeded) {
/* 227 */         this.furnaceCookTime = 0;
/* 228 */         smeltItem();
/* 229 */         flag1 = true;
/*     */       }
/*     */     }
/*     */     else {
/* 233 */       this.furnaceCookTime = 0;
/*     */     }
/*     */     
/* 236 */     if (flag != this.furnaceBurnTime > 0) {
/* 237 */       BlockPaladiumFurnace.updateFurnaceBlockState(this.furnaceBurnTime > 0, this.worldObj, this.xCoord, this.yCoord, this.zCoord);
/*     */     }
/*     */     
/* 240 */     if (flag1) {
/* 241 */       markDirty();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canSmelt() {
/* 246 */     if (this.content[0] == null) {
/* 247 */       return false;
/*     */     }
/*     */     
/* 250 */     ItemStack itemstack = FurnaceRecipes.smelting().getSmeltingResult(this.content[0]);
/* 251 */     if (itemstack == null) {
/* 252 */       return false;
/*     */     }
/* 254 */     if (this.content[2] == null) {
/* 255 */       return true;
/*     */     }
/* 257 */     if (!this.content[2].isItemEqual(itemstack)) {
/* 258 */       return false;
/*     */     }
/*     */     
/* 261 */     int result = this.content[2].stackSize + itemstack.stackSize;
/* 262 */     return (result <= getInventoryStackLimit()) && (result <= this.content[2].getMaxStackSize());
/*     */   }
/*     */   
/*     */   public void smeltItem()
/*     */   {
/* 267 */     if (canSmelt()) {
/* 268 */       ItemStack itemstack = FurnaceRecipes.smelting().getSmeltingResult(this.content[0]);
/*     */       
/* 270 */       if (this.content[2] == null) {
/* 271 */         this.content[2] = itemstack.copy();
/*     */       }
/* 273 */       else if (this.content[2].getItem() == itemstack.getItem()) {
/* 274 */         this.content[2].stackSize += itemstack.stackSize;
/*     */       }
/*     */       
/* 277 */       this.content[0].stackSize -= 1;
/*     */       
/* 279 */       if (this.content[0].stackSize <= 0) {
/* 280 */         this.content[0] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getItemBurnTime(ItemStack p_145952_0_) {
/* 286 */     if (p_145952_0_ == null) {
/* 287 */       return 0;
/*     */     }
/*     */     
/* 290 */     Item item = p_145952_0_.getItem();
/*     */     
/* 292 */     if (((item instanceof ItemBlock)) && (Block.getBlockFromItem(item) != Blocks.air)) {
/* 293 */       Block block = Block.getBlockFromItem(item);
/*     */       
/* 295 */       if (block == Blocks.wooden_slab) {
/* 296 */         return 150;
/*     */       }
/*     */       
/* 299 */       if (block.getMaterial() == net.minecraft.block.material.Material.wood) {
/* 300 */         return 300;
/*     */       }
/*     */       
/* 303 */       if (block == Blocks.coal_block) {
/* 304 */         return 16000;
/*     */       }
/*     */     }
/*     */     
/* 308 */     if (((item instanceof ItemTool)) && (((ItemTool)item).getToolMaterialName().equals("WOOD"))) {
/* 309 */       return 200;
/*     */     }
/* 311 */     if (((item instanceof ItemSword)) && (((ItemSword)item).getToolMaterialName().equals("WOOD"))) {
/* 312 */       return 200;
/*     */     }
/* 314 */     if (((item instanceof ItemHoe)) && (((ItemHoe)item).getToolMaterialName().equals("WOOD"))) {
/* 315 */       return 200;
/*     */     }
/* 317 */     if (item == Items.stick) {
/* 318 */       return 100;
/*     */     }
/* 320 */     if (item == Items.coal) {
/* 321 */       return 1600;
/*     */     }
/* 323 */     if (item == Items.lava_bucket) {
/* 324 */       return 20000;
/*     */     }
/* 326 */     if (item == Item.getItemFromBlock(Blocks.sapling)) {
/* 327 */       return 100;
/*     */     }
/* 329 */     if (item == Items.blaze_rod) {
/* 330 */       return 2400;
/*     */     }
/* 332 */     return GameRegistry.getFuelValue(p_145952_0_);
/*     */   }
/*     */   
/*     */   public static boolean isItemFuel(ItemStack p_145954_0_)
/*     */   {
/* 337 */     return getItemBurnTime(p_145954_0_) > 0;
/*     */   }
/*     */   
/*     */   public boolean isUseableByPlayer(EntityPlayer p_70300_1_)
/*     */   {
/* 342 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 353 */     return slot != 2;
/*     */   }
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 358 */     return side == 1 ? slotsTop : side == 0 ? slotsBottom : slotsSides;
/*     */   }
/*     */   
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 363 */     return isItemValidForSlot(side, stack);
/*     */   }
/*     */   
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 368 */     return (slot != 0) || (side != 1) || (stack.getItem() == Items.bucket);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\logic\PaladiumFurnaceLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */