/*     */ package fr.paladium.palamod.paladium.entitie.projectile;
/*     */ 
/*     */ import fr.paladium.palamod.common.SilentExplosion;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.DataWatcher;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.entity.projectile.EntityArrow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class DynamiteEntity extends EntityArrow implements cpw.mods.fml.common.registry.IThrowableEntity
/*     */ {
/*     */   public static final int NO_PICKUP = 0;
/*     */   public static final int PICKUP_ALL = 1;
/*     */   public static final int PICKUP_CREATIVE = 2;
/*     */   public static final int PICKUP_OWNER = 3;
/*     */   protected int xTile;
/*     */   protected int yTile;
/*     */   protected int zTile;
/*     */   protected Block inTile;
/*     */   protected int inData;
/*     */   protected boolean inGround;
/*     */   public int pickupMode;
/*     */   protected int ticksInGround;
/*     */   protected int ticksInAir;
/*     */   public boolean beenInGround;
/*     */   public float extraDamage;
/*     */   public int knockBack;
/*     */   private int explodefuse;
/*     */   private boolean extinguished;
/*  45 */   public boolean stuck = true;
/*     */   
/*  47 */   public static int DEFAULT = 0;
/*  48 */   public static int NINJA = 1;
/*  49 */   public static int BIG = 2;
/*     */   int type;
/*     */   
/*     */   public DynamiteEntity(World world)
/*     */   {
/*  54 */     super(world);
/*     */     
/*  56 */     this.xTile = -1;
/*  57 */     this.yTile = -1;
/*  58 */     this.zTile = -1;
/*     */     
/*  60 */     this.inTile = null;
/*  61 */     this.inData = 0;
/*  62 */     this.inGround = false;
/*  63 */     this.arrowShake = 0;
/*  64 */     this.ticksInAir = 0;
/*  65 */     this.yOffset = 0.0F;
/*  66 */     this.pickupMode = 0;
/*     */     
/*  68 */     setPickupMode(0);
/*  69 */     this.extinguished = false;
/*  70 */     this.explodefuse = 500;
/*     */     
/*  72 */     this.extraDamage = 0.0F;
/*  73 */     this.knockBack = 0;
/*     */     
/*  75 */     setSize(0.5F, 0.5F);
/*     */   }
/*     */   
/*     */   public DynamiteEntity(World world, double d, double d1, double d2) {
/*  79 */     this(world);
/*     */     
/*  81 */     setPosition(d, d1, d2);
/*     */   }
/*     */   
/*     */   public DynamiteEntity(World world, EntityLivingBase entityliving, int i, int type) {
/*  85 */     this(world);
/*     */     
/*  87 */     this.type = type;
/*     */     
/*  89 */     this.shootingEntity = entityliving;
/*  90 */     setLocationAndAngles(entityliving.posX, entityliving.posY + entityliving.getEyeHeight(), entityliving.posZ, entityliving.rotationYaw, entityliving.rotationPitch);
/*     */     
/*  92 */     this.posX -= MathHelper.cos(this.rotationYaw / 180.0F * 3.141593F) * 0.16F;
/*  93 */     this.posY -= 0.1D;
/*  94 */     this.posZ -= MathHelper.sin(this.rotationYaw / 180.0F * 3.141593F) * 0.16F;
/*     */     
/*  96 */     setPosition(this.posX, this.posY, this.posZ);
/*     */     
/*  98 */     this.motionX = (-MathHelper.sin(this.rotationYaw / 180.0F * 3.141593F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.141593F));
/*  99 */     this.motionZ = (MathHelper.cos(this.rotationYaw / 180.0F * 3.141593F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.141593F));
/* 100 */     this.motionY = (-MathHelper.sin(this.rotationPitch / 180.0F * 3.141593F));
/*     */     
/* 102 */     setThrowableHeading(this.motionX, this.motionY, this.motionZ, 0.7F, 4.0F);
/* 103 */     this.explodefuse = i;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void entityInit() {}
/*     */   
/*     */   public Entity getThrower()
/*     */   {
/* 111 */     return this.shootingEntity;
/*     */   }
/*     */   
/*     */   public void setThrower(Entity entity)
/*     */   {
/* 116 */     this.shootingEntity = entity;
/*     */   }
/*     */   
/*     */   protected void setPickupModeFromEntity(EntityLivingBase entityliving) {
/* 120 */     if ((entityliving instanceof EntityPlayer)) {
/* 121 */       if (((EntityPlayer)entityliving).capabilities.isCreativeMode) {
/* 122 */         setPickupMode(2);
/*     */       }
/*     */     }
/*     */     else {
/* 126 */       setPickupMode(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setThrowableHeading(double x, double y, double z, float speed, float deviation)
/*     */   {
/* 132 */     float f2 = MathHelper.sqrt_double(x * x + y * y + z * z);
/*     */     
/* 134 */     x /= f2;
/* 135 */     y /= f2;
/* 136 */     z /= f2;
/*     */     
/* 138 */     x += this.rand.nextGaussian() * 0.007499999832361937D * deviation;
/* 139 */     y += this.rand.nextGaussian() * 0.007499999832361937D * deviation;
/* 140 */     z += this.rand.nextGaussian() * 0.007499999832361937D * deviation;
/*     */     
/* 142 */     x *= speed;
/* 143 */     y *= speed;
/* 144 */     z *= speed;
/*     */     
/* 146 */     this.motionX = x;
/* 147 */     this.motionY = y;
/* 148 */     this.motionZ = z;
/*     */     
/* 150 */     float f3 = MathHelper.sqrt_double(x * x + z * z);
/* 151 */     this.prevRotationYaw = (this.rotationYaw = (float)(Math.atan2(x, z) * 180.0D / 3.141592653589793D));
/* 152 */     this.prevRotationPitch = (this.rotationPitch = (float)(Math.atan2(y, f3) * 180.0D / 3.141592653589793D));
/* 153 */     this.ticksInGround = 0;
/*     */   }
/*     */   
/*     */   public void setVelocity(double d, double d1, double d2)
/*     */   {
/* 158 */     this.motionX = d;
/* 159 */     this.motionY = d1;
/* 160 */     this.motionZ = d2;
/*     */     
/* 162 */     if ((aimRotation()) && (this.prevRotationPitch == 0.0F) && (this.prevRotationYaw == 0.0F)) {
/* 163 */       float f = MathHelper.sqrt_double(d * d + d2 * d2);
/* 164 */       this.prevRotationYaw = (this.rotationYaw = (float)(Math.atan2(d, d2) * 180.0D / 3.141592653589793D));
/* 165 */       this.prevRotationPitch = (this.rotationPitch = (float)(Math.atan2(d1, f) * 180.0D / 3.141592653589793D));
/* 166 */       setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
/* 167 */       this.ticksInGround = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public void onUpdate()
/*     */   {
/* 173 */     onEntityUpdate();
/* 174 */     if ((!this.inGround) && (!this.beenInGround)) {
/* 175 */       this.rotationPitch -= 50.0F;
/*     */     }
/*     */     else {
/* 178 */       this.rotationPitch = 180.0F;
/*     */     }
/*     */     
/* 181 */     if ((isInWater()) && (!this.extinguished)) {
/* 182 */       this.extinguished = true;
/*     */       
/* 184 */       if (this.type != NINJA) {
/* 185 */         this.worldObj.playSoundAtEntity(this, "random.fizz", 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
/*     */       }
/*     */       
/* 188 */       for (int k = 0; k < 8; k++) {
/* 189 */         float f6 = 0.25F;
/* 190 */         this.worldObj.spawnParticle("explode", this.posX - this.motionX * f6, this.posY - this.motionY * f6, this.posZ - this.motionZ * f6, this.motionX, this.motionY, this.motionZ);
/*     */       }
/*     */     }
/*     */     
/* 194 */     this.explodefuse -= 1;
/*     */     
/* 196 */     if (this.explodefuse <= 0) {
/* 197 */       detonate();
/* 198 */       setDead();
/*     */     }
/* 200 */     else if (this.explodefuse > 0) {
/* 201 */       this.worldObj.spawnParticle("smoke", this.posX, this.posY, this.posZ, 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onEntityUpdate()
/*     */   {
/* 207 */     super.onEntityUpdate();
/*     */     
/* 209 */     if (aimRotation()) {
/* 210 */       float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
/* 211 */       this.prevRotationYaw = (this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0D / 3.141592653589793D));
/* 212 */       this.prevRotationPitch = (this.rotationPitch = (float)(Math.atan2(this.motionY, f) * 180.0D / 3.141592653589793D));
/*     */     }
/*     */     
/* 215 */     Block i = this.worldObj.getBlock(this.xTile, this.yTile, this.zTile);
/* 216 */     if (i != null) {
/* 217 */       i.setBlockBoundsBasedOnState(this.worldObj, this.xTile, this.yTile, this.zTile);
/* 218 */       AxisAlignedBB axisalignedbb = i.getCollisionBoundingBoxFromPool(this.worldObj, this.xTile, this.yTile, this.zTile);
/* 219 */       if ((axisalignedbb != null) && (axisalignedbb.isVecInside(Vec3.createVectorHelper(this.posX, this.posY, this.posZ)))) {
/* 220 */         this.inGround = true;
/*     */       }
/*     */     }
/*     */     
/* 224 */     if (this.arrowShake > 0) {
/* 225 */       this.arrowShake -= 1;
/*     */     }
/*     */     
/* 228 */     if (this.inGround) {
/* 229 */       Block j = this.worldObj.getBlock(this.xTile, this.yTile, this.zTile);
/* 230 */       int k = this.worldObj.getBlockMetadata(this.xTile, this.yTile, this.zTile);
/*     */       
/* 232 */       if ((j == this.inTile) && (k == this.inData)) {
/* 233 */         this.ticksInGround += 1;
/*     */         
/* 235 */         int t = getMaxLifetime();
/* 236 */         if ((t != 0) && (this.ticksInGround >= t)) {
/* 237 */           setDead();
/*     */         }
/*     */       }
/*     */       else {
/* 241 */         this.inGround = false;
/*     */         
/* 243 */         this.motionX *= this.rand.nextFloat() * 0.2F;
/* 244 */         this.motionY *= this.rand.nextFloat() * 0.2F;
/* 245 */         this.motionZ *= this.rand.nextFloat() * 0.2F;
/*     */         
/* 247 */         this.ticksInGround = 0;
/* 248 */         this.ticksInAir = 0;
/*     */       }
/* 250 */       return;
/*     */     }
/*     */     
/* 253 */     this.ticksInAir += 1;
/*     */     
/* 255 */     Vec3 vec3d = Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
/* 256 */     Vec3 vec3d1 = Vec3.createVectorHelper(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
/*     */     
/* 258 */     MovingObjectPosition movingobjectposition = this.worldObj.func_147447_a(vec3d, vec3d1, false, true, false);
/*     */     
/* 260 */     vec3d = Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
/* 261 */     vec3d1 = Vec3.createVectorHelper(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
/*     */     
/* 263 */     if (movingobjectposition != null) {
/* 264 */       vec3d1 = Vec3.createVectorHelper(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
/*     */     }
/*     */     
/* 267 */     Entity entity = null;
/* 268 */     List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0D, 1.0D, 1.0D));
/*     */     
/* 270 */     double d = 0.0D;
/* 271 */     for (int l = 0; l < list.size(); l++) {
/* 272 */       Entity entity1 = (Entity)list.get(l);
/* 273 */       if ((entity1.canBeCollidedWith()) && ((entity1 != this.shootingEntity) || (this.ticksInAir >= 5)))
/*     */       {
/*     */ 
/*     */ 
/* 277 */         float f4 = 0.3F;
/* 278 */         AxisAlignedBB axisalignedbb1 = entity1.boundingBox.expand(f4, f4, f4);
/* 279 */         MovingObjectPosition movingobjectposition1 = axisalignedbb1.calculateIntercept(vec3d, vec3d1);
/* 280 */         if (movingobjectposition1 != null)
/*     */         {
/*     */ 
/* 283 */           double d1 = vec3d.distanceTo(movingobjectposition1.hitVec);
/* 284 */           if ((d1 < d) || (d == 0.0D)) {
/* 285 */             entity = entity1;
/* 286 */             d = d1;
/*     */           }
/*     */         }
/*     */       } }
/* 290 */     if (entity != null) {
/* 291 */       movingobjectposition = new MovingObjectPosition(entity);
/*     */     }
/*     */     
/* 294 */     if (movingobjectposition != null) {
/* 295 */       if (movingobjectposition.entityHit != null) {
/* 296 */         onEntityHit(movingobjectposition.entityHit);
/*     */       }
/*     */       else {
/* 299 */         onGroundHit(movingobjectposition);
/*     */       }
/*     */     }
/*     */     
/* 303 */     if (getIsCritical()) {
/* 304 */       for (int i1 = 0; i1 < 2; i1++) {
/* 305 */         this.worldObj.spawnParticle("crit", this.posX + this.motionX * i1 / 4.0D, this.posY + this.motionY * i1 / 4.0D, this.posZ + this.motionZ * i1 / 4.0D, -this.motionX, -this.motionY + 0.2D, -this.motionZ);
/*     */       }
/*     */     }
/*     */     
/* 309 */     this.posX += this.motionX;
/* 310 */     this.posY += this.motionY;
/* 311 */     this.posZ += this.motionZ;
/*     */     
/* 313 */     if (aimRotation()) {
/* 314 */       float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
/* 315 */       this.rotationYaw = ((float)(Math.atan2(this.motionX, this.motionZ) * 180.0D / 3.141592653589793D));
/*     */       
/* 317 */       for (this.rotationPitch = ((float)(Math.atan2(this.motionY, f2) * 180.0D / 3.141592653589793D)); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F) {}
/* 318 */       while (this.rotationPitch - this.prevRotationPitch >= 180.0F) this.prevRotationPitch += 360.0F;
/* 319 */       while (this.rotationYaw - this.prevRotationYaw < -180.0F) this.prevRotationYaw -= 360.0F;
/* 320 */       while (this.rotationYaw - this.prevRotationYaw >= 180.0F) { this.prevRotationYaw += 360.0F;
/*     */       }
/* 322 */       this.rotationPitch = (this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F);
/* 323 */       this.rotationYaw = (this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F);
/*     */     }
/*     */     
/* 326 */     float res = getAirResistance();
/* 327 */     float grav = getGravity();
/*     */     
/* 329 */     if (isInWater()) {
/* 330 */       this.beenInGround = true;
/* 331 */       for (int i1 = 0; i1 < 4; i1++) {
/* 332 */         float f6 = 0.25F;
/* 333 */         this.worldObj.spawnParticle("bubble", this.posX - this.motionX * f6, this.posY - this.motionY * f6, this.posZ - this.motionZ * f6, this.motionX, this.motionY, this.motionZ);
/*     */       }
/* 335 */       res *= 0.8080808F;
/*     */     }
/*     */     
/* 338 */     this.motionX *= res;
/* 339 */     this.motionY *= res;
/* 340 */     this.motionZ *= res;
/* 341 */     this.motionY -= grav;
/*     */     
/* 343 */     setPosition(this.posX, this.posY, this.posZ);
/*     */     
/* 345 */     func_145775_I();
/*     */   }
/*     */   
/*     */   public void onEntityHit(Entity entity) {
/* 349 */     bounceBack();
/* 350 */     applyEntityHitEffects(entity);
/*     */   }
/*     */   
/*     */   public void applyEntityHitEffects(Entity entity) {
/* 354 */     if ((isBurning()) && (!(entity instanceof net.minecraft.entity.monster.EntityEnderman))) {
/* 355 */       entity.setFire(5);
/*     */     }
/* 357 */     if ((entity instanceof EntityLivingBase)) {
/* 358 */       EntityLivingBase entityliving = (EntityLivingBase)entity;
/* 359 */       if (this.knockBack > 0) {
/* 360 */         float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
/* 361 */         if (f > 0.0F) {
/* 362 */           entity.addVelocity(this.motionX * this.knockBack * 0.6D / f, 0.1D, this.motionZ * this.knockBack * 0.6D / f);
/*     */         }
/*     */       }
/* 365 */       if ((this.shootingEntity instanceof EntityLivingBase)) {
/* 366 */         EnchantmentHelper.func_151384_a(entityliving, this.shootingEntity);
/* 367 */         EnchantmentHelper.func_151385_b((EntityLivingBase)this.shootingEntity, entityliving);
/*     */       }
/* 369 */       if (((this.shootingEntity instanceof EntityPlayerMP)) && (this.shootingEntity != entity) && ((entity instanceof EntityPlayer))) {
/* 370 */         ((EntityPlayerMP)this.shootingEntity).playerNetServerHandler.sendPacket(new net.minecraft.network.play.server.S2BPacketChangeGameState(6, 0.0F));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onGroundHit(MovingObjectPosition mop) {
/* 376 */     this.xTile = mop.blockX;
/* 377 */     this.yTile = mop.blockY;
/* 378 */     this.zTile = mop.blockZ;
/* 379 */     this.inTile = this.worldObj.getBlock(this.xTile, this.yTile, this.zTile);
/*     */     
/* 381 */     this.motionX = ((float)(mop.hitVec.xCoord - this.posX));
/* 382 */     this.motionY = ((float)(mop.hitVec.yCoord - this.posY));
/* 383 */     this.motionZ = ((float)(mop.hitVec.zCoord - this.posZ));
/* 384 */     float f1 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
/*     */     
/* 386 */     this.posX -= this.motionX / f1 * 0.05D;
/* 387 */     this.posY -= this.motionY / f1 * 0.05D;
/* 388 */     this.posZ -= this.motionZ / f1 * 0.05D;
/*     */     
/* 390 */     this.motionX *= -0.2D;
/* 391 */     this.motionZ *= -0.2D;
/*     */     
/* 393 */     if (mop.sideHit == 1) {
/* 394 */       this.inGround = true;
/* 395 */       this.beenInGround = true;
/*     */     }
/*     */     else {
/* 398 */       this.inGround = false;
/* 399 */       if (this.type != NINJA) {
/* 400 */         this.worldObj.playSoundAtEntity(this, "random.fizz", 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
/*     */       }
/*     */     }
/*     */     
/* 404 */     if (this.inTile != null) {
/* 405 */       this.inTile.onEntityCollidedWithBlock(this.worldObj, this.xTile, this.yTile, this.zTile, this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void detonate() {
/* 410 */     if ((this.posY <= 0.0D) || (this.posY >= 256.0D)) {
/* 411 */       return;
/*     */     }
/*     */     
/* 414 */     float f = 3.0F;
/*     */     
/* 416 */     if (this.type == BIG) {
/* 417 */       f = 4.5F;
/*     */     }
/* 419 */     if (this.type == DEFAULT) {
/* 420 */       f = 2.5F;
/*     */     }
/*     */     
/* 423 */     if (this.type != NINJA) {
/* 424 */       this.worldObj.createExplosion(this, this.posX, this.posY, this.posZ, f, true);
/*     */     }
/*     */     else {
/* 427 */       SilentExplosion.newExplosion(this, this.posX, this.posY, this.posZ, f, false, false, this.worldObj);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void bounceBack() {
/* 432 */     this.motionX *= -0.1D;
/* 433 */     this.motionY *= -0.1D;
/* 434 */     this.motionZ *= -0.1D;
/*     */     
/* 436 */     this.rotationYaw += 180.0F;
/* 437 */     this.prevRotationYaw += 180.0F;
/* 438 */     this.ticksInAir = 0;
/*     */   }
/*     */   
/*     */   public int getType() {
/* 442 */     return this.type;
/*     */   }
/*     */   
/*     */   public final double getTotalVelocity() {
/* 446 */     return Math.sqrt(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
/*     */   }
/*     */   
/*     */   public boolean aimRotation() {
/* 450 */     return false;
/*     */   }
/*     */   
/*     */   public int getMaxLifetime() {
/* 454 */     return 1200;
/*     */   }
/*     */   
/*     */   public ItemStack getPickupItem() {
/* 458 */     return null;
/*     */   }
/*     */   
/*     */   public float getAirResistance() {
/* 462 */     return 0.99F;
/*     */   }
/*     */   
/*     */   public float getGravity() {
/* 466 */     return 0.05F;
/*     */   }
/*     */   
/*     */   public int getMaxArrowShake() {
/* 470 */     return 0;
/*     */   }
/*     */   
/*     */   public void playHitSound() {
/* 474 */     if (this.type != NINJA) {
/* 475 */       this.worldObj.playSoundAtEntity(this, "random.fizz", 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canBeCritical() {
/* 480 */     return false;
/*     */   }
/*     */   
/*     */   public void setIsCritical(boolean flag)
/*     */   {
/* 485 */     if (canBeCritical()) {
/* 486 */       this.dataWatcher.updateObject(16, Byte.valueOf((byte)(flag ? 1 : 0)));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean getIsCritical()
/*     */   {
/* 492 */     return (canBeCritical()) && (this.dataWatcher.getWatchableObjectByte(16) != 0);
/*     */   }
/*     */   
/*     */   public void setExtraDamage(float f) {
/* 496 */     this.extraDamage = f;
/*     */   }
/*     */   
/*     */   public void setKnockbackStrength(int i)
/*     */   {
/* 501 */     this.knockBack = i;
/*     */   }
/*     */   
/*     */   public void setPickupMode(int i) {
/* 505 */     this.pickupMode = i;
/*     */   }
/*     */   
/*     */   public int getPickupMode() {
/* 509 */     return this.pickupMode;
/*     */   }
/*     */   
/*     */   public boolean canPickup(EntityPlayer entityplayer) {
/* 513 */     if (this.pickupMode == 1) {
/* 514 */       return true;
/*     */     }
/* 516 */     if (this.pickupMode == 2) {
/* 517 */       return entityplayer.capabilities.isCreativeMode;
/*     */     }
/* 519 */     if (this.pickupMode == 3) {
/* 520 */       return entityplayer == this.shootingEntity;
/*     */     }
/*     */     
/* 523 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void onCollideWithPlayer(EntityPlayer entityplayer)
/*     */   {
/* 529 */     if ((this.inGround) && (this.arrowShake <= 0) && 
/* 530 */       (canPickup(entityplayer)) && 
/* 531 */       (!this.worldObj.isRemote)) {
/* 532 */       ItemStack item = getPickupItem();
/* 533 */       if (item == null) {
/* 534 */         return;
/*     */       }
/*     */       
/* 537 */       if (((this.pickupMode == 2) && (entityplayer.capabilities.isCreativeMode)) || (entityplayer.inventory.addItemStackToInventory(item))) {
/* 538 */         if (this.type != NINJA) {
/* 539 */           this.worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
/*     */         }
/* 541 */         onItemPickup(entityplayer);
/* 542 */         setDead();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void onItemPickup(EntityPlayer entityplayer)
/*     */   {
/* 550 */     entityplayer.onItemPickup(this, 1);
/*     */   }
/*     */   
/*     */   @cpw.mods.fml.relauncher.SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */   public float getShadowSize()
/*     */   {
/* 556 */     return 0.0F;
/*     */   }
/*     */   
/*     */   protected boolean canTriggerWalking()
/*     */   {
/* 561 */     return false;
/*     */   }
/*     */   
/*     */   public void writeEntityToNBT(NBTTagCompound nbttagcompound)
/*     */   {
/* 566 */     nbttagcompound.setShort("xTile", (short)this.xTile);
/* 567 */     nbttagcompound.setShort("yTile", (short)this.yTile);
/* 568 */     nbttagcompound.setShort("zTile", (short)this.zTile);
/*     */     
/* 570 */     nbttagcompound.setByte("inTile", (byte)Block.getIdFromBlock(this.inTile));
/* 571 */     nbttagcompound.setByte("inData", (byte)this.inData);
/* 572 */     nbttagcompound.setByte("shake", (byte)this.arrowShake);
/* 573 */     nbttagcompound.setBoolean("inGround", this.inGround);
/* 574 */     nbttagcompound.setBoolean("beenInGround", this.beenInGround);
/* 575 */     nbttagcompound.setByte("pickup", (byte)this.pickupMode);
/* 576 */     nbttagcompound.setByte("fuse", (byte)this.explodefuse);
/* 577 */     nbttagcompound.setBoolean("off", this.extinguished);
/*     */   }
/*     */   
/*     */   public void readEntityFromNBT(NBTTagCompound nbttagcompound)
/*     */   {
/* 582 */     this.xTile = nbttagcompound.getShort("xTile");
/* 583 */     this.yTile = nbttagcompound.getShort("yTile");
/* 584 */     this.zTile = nbttagcompound.getShort("zTile");
/*     */     
/* 586 */     this.inTile = Block.getBlockById(nbttagcompound.getByte("inTile") & 0xFF);
/* 587 */     this.inData = (nbttagcompound.getByte("inData") & 0xFF);
/* 588 */     this.arrowShake = (nbttagcompound.getByte("shake") & 0xFF);
/* 589 */     this.inGround = nbttagcompound.getBoolean("inGround");
/* 590 */     this.beenInGround = nbttagcompound.getBoolean("beenInGrond");
/* 591 */     this.pickupMode = nbttagcompound.getByte("pickup");
/* 592 */     this.explodefuse = nbttagcompound.getByte("fuse");
/* 593 */     this.extinguished = nbttagcompound.getBoolean("off");
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\entitie\projectile\DynamiteEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */