/*    */ package fr.paladium.palamod.paladium.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumMachineLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class PaladiumMachineContainer extends net.minecraft.inventory.Container
/*    */ {
/*    */   private PaladiumMachineLogic tilePaladiumMachine;
/*    */   
/*    */   public PaladiumMachineContainer(PaladiumMachineLogic tile, InventoryPlayer inventory)
/*    */   {
/* 15 */     this.tilePaladiumMachine = tile;
/* 16 */     addSlotToContainer(new Slot(tile, 0, 89, 95));
/* 17 */     addSlotToContainer(new Slot(tile, 1, 25, 103));
/* 18 */     addSlotToContainer(new Slot(tile, 2, 53, 123));
/* 19 */     addSlotToContainer(new Slot(tile, 3, 153, 103));
/* 20 */     addSlotToContainer(new Slot(tile, 4, 125, 123));
/*    */     
/* 22 */     addSlotToContainer(new fr.paladium.palamod.common.slot.SlotResult(tile, 5, 89, 146));
/*    */     
/* 24 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 29 */     for (int i = 0; i < 3; i++) {
/* 30 */       for (int j = 0; j < 9; j++) {
/* 31 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 17 + j * 18, 171 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 35 */     for (i = 0; i < 9; i++) {
/* 36 */       addSlotToContainer(new Slot(inventory, i, 17 + i * 18, 229));
/*    */     }
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int slot)
/*    */   {
/* 42 */     ItemStack stack = null;
/* 43 */     Slot slots = (Slot)this.inventorySlots.get(slot);
/*    */     
/* 45 */     if ((slots != null) && (slots.getHasStack())) {
/* 46 */       ItemStack stack1 = slots.getStack();
/* 47 */       stack = stack1.copy();
/*    */       
/* 49 */       if (slot < 6) {
/* 50 */         if (!mergeItemStack(stack1, 6, 42, true)) {
/* 51 */           return null;
/*    */         }
/* 53 */         slots.onSlotChange(stack1, stack);
/*    */       }
/*    */       
/* 56 */       if (slot >= 6) {
/* 57 */         if (!mergeItemStack(stack1, 0, 5, false)) {
/* 58 */           return null;
/*    */         }
/* 60 */         slots.onSlotChange(stack1, stack);
/*    */       }
/*    */       
/* 63 */       if (stack1.stackSize == 0) {
/* 64 */         slots.putStack((ItemStack)null);
/*    */       }
/*    */       else {
/* 67 */         slots.onSlotChanged();
/*    */       }
/*    */       
/* 70 */       if (stack1.stackSize == stack.stackSize) {
/* 71 */         return null;
/*    */       }
/*    */       
/* 74 */       slots.onPickupFromSlot(player, stack1);
/*    */     }
/* 76 */     return stack;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 81 */     super.onContainerClosed(player);
/* 82 */     this.tilePaladiumMachine.closeInventory();
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 87 */     return this.tilePaladiumMachine.isUseableByPlayer(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\inventory\PaladiumMachineContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */