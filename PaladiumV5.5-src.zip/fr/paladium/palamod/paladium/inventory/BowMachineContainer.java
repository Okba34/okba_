/*    */ package fr.paladium.palamod.paladium.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.logic.BowMachineLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class BowMachineContainer extends Container
/*    */ {
/*    */   public BowMachineLogic tile;
/*    */   
/*    */   public BowMachineContainer(BowMachineLogic tile, InventoryPlayer inventory)
/*    */   {
/* 16 */     this.tile = tile;
/*    */     
/* 18 */     addSlotToContainer(new Slot(tile, 0, 81, 35));
/* 19 */     addSlotToContainer(new fr.paladium.palamod.common.slot.SlotSingle(tile, 1, 150, 35, fr.paladium.palamod.items.ModItems.paladiumBow));
/*    */     
/* 21 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 26 */     for (int i = 0; i < 3; i++) {
/* 27 */       for (int j = 0; j < 9; j++) {
/* 28 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 32 */     for (i = 0; i < 9; i++) {
/* 33 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 142));
/*    */     }
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int slot)
/*    */   {
/* 39 */     ItemStack stack = null;
/* 40 */     Slot slots = (Slot)this.inventorySlots.get(slot);
/*    */     
/* 42 */     if ((slots != null) && (slots.getHasStack())) {
/* 43 */       ItemStack stack1 = slots.getStack();
/* 44 */       stack = stack1.copy();
/*    */       
/* 46 */       if (slot < 2) {
/* 47 */         if (!mergeItemStack(stack1, 3, 38, true)) {
/* 48 */           return null;
/*    */         }
/* 50 */         slots.onSlotChange(stack1, stack);
/*    */       }
/*    */       
/* 53 */       if ((slot >= 2) && 
/* 54 */         (!mergeItemStack(stack1, 0, 1, true))) {
/* 55 */         return null;
/*    */       }
/*    */       
/*    */ 
/* 59 */       if (stack1.stackSize == 0) {
/* 60 */         slots.putStack((ItemStack)null);
/*    */       }
/*    */       else {
/* 63 */         slots.onSlotChanged();
/*    */       }
/*    */       
/* 66 */       if (stack1.stackSize == stack.stackSize) {
/* 67 */         return null;
/*    */       }
/*    */       
/* 70 */       slots.onPickupFromSlot(player, stack1);
/*    */     }
/* 72 */     return stack;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 77 */     super.onContainerClosed(player);
/*    */     
/* 79 */     this.tile.closeInventory();
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 84 */     return this.tile.isUseableByPlayer(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\inventory\BowMachineContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */