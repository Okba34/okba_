/*    */ package fr.paladium.palamod.paladium.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ 
/*    */ public class AlchemyCreatorPotionContainer extends Container
/*    */ {
/*    */   private net.minecraft.entity.player.InventoryPlayer inventory;
/*    */   private AlchemyCreatorLogic tile;
/*    */   
/*    */   public AlchemyCreatorPotionContainer(AlchemyCreatorLogic tile, EntityPlayer player)
/*    */   {
/* 16 */     this.inventory = player.inventory;
/* 17 */     this.tile = tile;
/*    */     
/* 19 */     addSlotToContainer(new Slot(tile, 0, 50, 35));
/* 20 */     addSlotToContainer(new Slot(tile, 1, 79, 17));
/* 21 */     addSlotToContainer(new Slot(tile, 2, 108, 35));
/* 22 */     addSlotToContainer(new fr.paladium.palamod.common.slot.SlotSize(tile, 3, 79, 53, 1));
/*    */     
/* 24 */     bindPlayerInventory();
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory()
/*    */   {
/* 29 */     for (int i = 0; i < 3; i++) {
/* 30 */       for (int j = 0; j < 9; j++) {
/* 31 */         addSlotToContainer(new Slot(this.inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 35 */     for (i = 0; i < 9; i++) {
/* 36 */       addSlotToContainer(new Slot(this.inventory, i, 8 + i * 18, 142));
/*    */     }
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack transferStackInSlot(EntityPlayer player, int quantity)
/*    */   {
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 47 */     super.onContainerClosed(player);
/*    */     
/* 49 */     if (AlchemyCreatorLogic.oppenedGui.containsKey(player)) {
/* 50 */       AlchemyCreatorLogic.oppenedGui.remove(player);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 56 */     if (!AlchemyCreatorLogic.oppenedGui.containsKey(player)) {
/* 57 */       AlchemyCreatorLogic.oppenedGui.put(player, this.tile);
/*    */     }
/* 59 */     return this.tile.isUseableByPlayer(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\inventory\AlchemyCreatorPotionContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */