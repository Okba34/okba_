/*    */ package fr.paladium.palamod.paladium.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Slot;
/*    */ 
/*    */ public class AlchemyCreatorArrowContainer extends net.minecraft.inventory.Container
/*    */ {
/*    */   private net.minecraft.entity.player.InventoryPlayer inventory;
/*    */   private AlchemyCreatorLogic tile;
/*    */   
/*    */   public AlchemyCreatorArrowContainer(AlchemyCreatorLogic tile, EntityPlayer player)
/*    */   {
/* 15 */     this.inventory = player.inventory;
/* 16 */     this.tile = tile;
/*    */     
/* 18 */     addSlotToContainer(new Slot(tile, 4, 55, 15));
/* 19 */     addSlotToContainer(new Slot(tile, 5, 79, 15));
/* 20 */     addSlotToContainer(new Slot(tile, 6, 103, 15));
/* 21 */     addSlotToContainer(new Slot(tile, 7, 79, 37));
/* 22 */     addSlotToContainer(new Slot(tile, 8, 79, 59));
/*    */     
/* 24 */     bindPlayerInventory();
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory()
/*    */   {
/* 29 */     for (int i = 0; i < 3; i++) {
/* 30 */       for (int j = 0; j < 9; j++) {
/* 31 */         addSlotToContainer(new Slot(this.inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 35 */     for (i = 0; i < 9; i++) {
/* 36 */       addSlotToContainer(new Slot(this.inventory, i, 8 + i * 18, 142));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 42 */     if (!AlchemyCreatorLogic.oppenedGui.containsKey(player)) {
/* 43 */       AlchemyCreatorLogic.oppenedGui.put(player, this.tile);
/*    */     }
/*    */     
/* 46 */     return this.tile.isUseableByPlayer(player);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack transferStackInSlot(EntityPlayer player, int quantity) {
/* 50 */     return null;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 55 */     super.onContainerClosed(player);
/*    */     
/* 57 */     if (AlchemyCreatorLogic.oppenedGui.containsKey(player)) {
/* 58 */       AlchemyCreatorLogic.oppenedGui.remove(player);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\inventory\AlchemyCreatorArrowContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */