/*     */ package fr.paladium.palamod.paladium.inventory;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.common.slot.SlotSingle;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.ICrafting;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ 
/*     */ public class PaladiumFurnaceContainer extends Container
/*     */ {
/*     */   private PaladiumFurnaceLogic tile;
/*     */   private int lastCookTime;
/*     */   private int lastBurnTime;
/*     */   private int lastItemBurnTime;
/*     */   
/*     */   public PaladiumFurnaceContainer(InventoryPlayer inventory, PaladiumFurnaceLogic tile)
/*     */   {
/*  25 */     this.tile = tile;
/*     */     
/*  27 */     addSlotToContainer(new Slot(tile, 0, 56, 17));
/*  28 */     addSlotToContainer(new Slot(tile, 1, 56, 53));
/*  29 */     addSlotToContainer(new net.minecraft.inventory.SlotFurnace(inventory.player, tile, 2, 116, 35));
/*  30 */     addSlotToContainer(new SlotSingle(tile, 3, 19, 35, PaladiumRegister.FURNACE_UPGRADE));
/*     */     
/*     */ 
/*  33 */     for (int i = 0; i < 3; i++) {
/*  34 */       for (int j = 0; j < 9; j++) {
/*  35 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
/*     */       }
/*     */     }
/*     */     
/*  39 */     for (i = 0; i < 9; i++) {
/*  40 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 142));
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCraftingToCrafters(ICrafting p_75132_1_) {
/*  45 */     super.addCraftingToCrafters(p_75132_1_);
/*     */     
/*  47 */     p_75132_1_.sendProgressBarUpdate(this, 0, this.tile.furnaceCookTime);
/*  48 */     p_75132_1_.sendProgressBarUpdate(this, 1, this.tile.furnaceBurnTime);
/*  49 */     p_75132_1_.sendProgressBarUpdate(this, 2, this.tile.currentItemBurnTime);
/*     */   }
/*     */   
/*     */   public void detectAndSendChanges() {
/*  53 */     super.detectAndSendChanges();
/*     */     
/*  55 */     for (int i = 0; i < this.crafters.size(); i++) {
/*  56 */       ICrafting icrafting = (ICrafting)this.crafters.get(i);
/*     */       
/*  58 */       if (this.lastCookTime != this.tile.furnaceCookTime) {
/*  59 */         icrafting.sendProgressBarUpdate(this, 0, this.tile.furnaceCookTime);
/*     */       }
/*     */       
/*  62 */       if (this.lastBurnTime != this.tile.furnaceBurnTime) {
/*  63 */         icrafting.sendProgressBarUpdate(this, 1, this.tile.furnaceBurnTime);
/*     */       }
/*     */       
/*  66 */       if (this.lastItemBurnTime != this.tile.currentItemBurnTime) {
/*  67 */         icrafting.sendProgressBarUpdate(this, 2, this.tile.currentItemBurnTime);
/*     */       }
/*     */     }
/*     */     
/*  71 */     this.lastCookTime = this.tile.furnaceCookTime;
/*  72 */     this.lastBurnTime = this.tile.furnaceBurnTime;
/*  73 */     this.lastItemBurnTime = this.tile.currentItemBurnTime;
/*     */   }
/*     */   
/*     */   @SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */   public void updateProgressBar(int p_75137_1_, int p_75137_2_) {
/*  78 */     if (p_75137_1_ == 0) {
/*  79 */       this.tile.furnaceCookTime = p_75137_2_;
/*     */     }
/*     */     
/*  82 */     if (p_75137_1_ == 1) {
/*  83 */       this.tile.furnaceBurnTime = p_75137_2_;
/*     */     }
/*     */     
/*  86 */     if (p_75137_1_ == 2) {
/*  87 */       this.tile.currentItemBurnTime = p_75137_2_;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer p_75145_1_) {
/*  92 */     return this.tile.isUseableByPlayer(p_75145_1_);
/*     */   }
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer p_82846_1_, int p_82846_2_) {
/*  96 */     ItemStack itemstack = null;
/*  97 */     Slot slot = (Slot)this.inventorySlots.get(p_82846_2_);
/*     */     
/*  99 */     if ((slot != null) && (slot.getHasStack())) {
/* 100 */       ItemStack itemstack1 = slot.getStack();
/* 101 */       itemstack = itemstack1.copy();
/*     */       
/* 103 */       if (p_82846_2_ == 2) {
/* 104 */         if (!mergeItemStack(itemstack1, 3, 39, true)) {
/* 105 */           return null;
/*     */         }
/*     */         
/* 108 */         slot.onSlotChange(itemstack1, itemstack);
/*     */       }
/* 110 */       else if ((p_82846_2_ != 1) && (p_82846_2_ != 0)) {
/* 111 */         if (FurnaceRecipes.smelting().getSmeltingResult(itemstack1) != null) {
/* 112 */           if (!mergeItemStack(itemstack1, 0, 1, false)) {
/* 113 */             return null;
/*     */           }
/*     */         }
/* 116 */         else if (PaladiumFurnaceLogic.isItemFuel(itemstack1)) {
/* 117 */           if (!mergeItemStack(itemstack1, 1, 2, false)) {
/* 118 */             return null;
/*     */           }
/*     */         }
/* 121 */         else if (itemstack.getItem().equals(PaladiumRegister.FURNACE_UPGRADE)) {
/* 122 */           if (!mergeItemStack(itemstack1, 3, 1, true)) {
/* 123 */             return null;
/*     */           }
/*     */         }
/* 126 */         else if ((p_82846_2_ >= 3) && (p_82846_2_ < 30)) {
/* 127 */           if (!mergeItemStack(itemstack1, 30, 39, false)) {
/* 128 */             return null;
/*     */           }
/*     */         }
/* 131 */         else if ((p_82846_2_ >= 30) && (p_82846_2_ < 39) && (!mergeItemStack(itemstack1, 3, 30, false))) {
/* 132 */           return null;
/*     */         }
/*     */       }
/* 135 */       else if (!mergeItemStack(itemstack1, 3, 39, false)) {
/* 136 */         return null;
/*     */       }
/*     */       
/* 139 */       if (itemstack1.stackSize == 0) {
/* 140 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else {
/* 143 */         slot.onSlotChanged();
/*     */       }
/*     */       
/* 146 */       if (itemstack1.stackSize == itemstack.stackSize) {
/* 147 */         return null;
/*     */       }
/* 149 */       slot.onPickupFromSlot(p_82846_1_, itemstack1);
/*     */     }
/* 151 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\inventory\PaladiumFurnaceContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */