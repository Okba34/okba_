/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.common.PassiveExplosion;
/*     */ import fr.paladium.palamod.items.ItemObsidianUpgrade.Upgrade;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.tiles.TileEntityUpgradedObsidian;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockUpgradedObsidian
/*     */   extends Block implements ITileEntityProvider
/*     */ {
/*     */   public BlockUpgradedObsidian()
/*     */   {
/*  27 */     super(Material.rock);
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  33 */     return new TileEntityUpgradedObsidian();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasTileEntity(int metadata)
/*     */   {
/*  39 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/*  45 */     Boolean flag = Boolean.valueOf(false);Boolean flag1 = Boolean.valueOf(false);
/*  46 */     TileEntity tile = world.getTileEntity(x, y, z);
/*  47 */     if ((tile instanceof TileEntityUpgradedObsidian))
/*     */     {
/*  49 */       TileEntityUpgradedObsidian te = (TileEntityUpgradedObsidian)tile;
/*  50 */       if ((te.hasUpgrade(ItemObsidianUpgrade.Upgrade.TwoLife).booleanValue()) && 
/*  51 */         (te.isAlife()))
/*  52 */         flag = Boolean.valueOf(true);
/*  53 */       if (te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Fake).booleanValue())
/*  54 */         flag1 = Boolean.valueOf(true);
/*  55 */       if (te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Explode).booleanValue()) {
/*  56 */         PassiveExplosion.newExplosion(null, x, y, z, 4.0F, true, false, world);
/*     */       }
/*  58 */       if (flag.booleanValue())
/*     */       {
/*  60 */         world.setBlock(x, y, z, block);
/*  61 */         world.setTileEntity(x, y, z, te);
/*     */       }
/*     */       else
/*     */       {
/*  65 */         super.breakBlock(world, x, y, z, block, metadata);
/*  66 */         world.removeTileEntity(x, y, z);
/*  67 */         if (flag1.booleanValue()) {
/*  68 */           world.setBlock(x, y, z, PaladiumRegister.sulfuricWater);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/*  73 */       super.breakBlock(world, x, y, z, block, metadata);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack)
/*     */   {
/*  79 */     TileEntity tile = world.getTileEntity(x, y, z);
/*  80 */     if (((tile instanceof TileEntityUpgradedObsidian)) && (stack.hasTagCompound()))
/*     */     {
/*  82 */       TileEntityUpgradedObsidian te = (TileEntityUpgradedObsidian)tile;
/*  83 */       NBTTagCompound compound = stack.getTagCompound();
/*  84 */       List<ItemObsidianUpgrade.Upgrade> upgrades = new ArrayList();
/*     */       
/*  86 */       if (compound.getBoolean("Explode"))
/*  87 */         upgrades.add(ItemObsidianUpgrade.Upgrade.Explode);
/*  88 */       if (compound.getBoolean("Fake"))
/*  89 */         upgrades.add(ItemObsidianUpgrade.Upgrade.Fake);
/*  90 */       if (compound.getBoolean("TwoLife"))
/*  91 */         upgrades.add(ItemObsidianUpgrade.Upgrade.TwoLife);
/*  92 */       if (compound.getBoolean("Camouflage")) {
/*  93 */         upgrades.add(ItemObsidianUpgrade.Upgrade.Camouflage);
/*     */       }
/*  95 */       te.setInformations(upgrades);
/*  96 */       te.setBaseLife();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune)
/*     */   {
/* 103 */     ArrayList<ItemStack> drops = new ArrayList();
/* 104 */     drops.add(getUpgradedObsidian(world, x, y, z));
/* 105 */     return drops;
/*     */   }
/*     */   
/*     */   public ItemStack getUpgradedObsidian(World world, int x, int y, int z)
/*     */   {
/* 110 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 111 */     if ((tile instanceof TileEntityUpgradedObsidian))
/*     */     {
/* 113 */       TileEntityUpgradedObsidian te = (TileEntityUpgradedObsidian)tile;
/* 114 */       if ((te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Explode).booleanValue()) || (te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Fake).booleanValue()) || (te.hasUpgrade(ItemObsidianUpgrade.Upgrade.TwoLife).booleanValue()) || (te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Camouflage).booleanValue()))
/*     */       {
/* 116 */         ItemStack stack = new ItemStack(PaladiumRegister.UPGRADED_OBSIDIAN);
/* 117 */         if (!stack.hasTagCompound()) {
/* 118 */           stack.setTagCompound(new NBTTagCompound());
/*     */         }
/* 120 */         NBTTagCompound compound = stack.getTagCompound();
/* 121 */         compound.setBoolean("Explode", te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Explode).booleanValue());
/* 122 */         compound.setBoolean("Fake", te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Fake).booleanValue());
/* 123 */         compound.setBoolean("TwoLife", te.hasUpgrade(ItemObsidianUpgrade.Upgrade.TwoLife).booleanValue());
/* 124 */         compound.setBoolean("Camouflage", te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Camouflage).booleanValue());
/* 125 */         stack.setTagCompound(compound);
/* 126 */         return stack;
/*     */       }
/*     */     }
/* 129 */     return new ItemStack(Blocks.obsidian);
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int colorMultiplier(IBlockAccess access, int x, int y, int z)
/*     */   {
/* 136 */     TileEntity tile = access.getTileEntity(x, y, z);
/* 137 */     if ((tile instanceof TileEntityUpgradedObsidian))
/*     */     {
/* 139 */       TileEntityUpgradedObsidian te = (TileEntityUpgradedObsidian)tile;
/* 140 */       if (!te.hasUpgrade(ItemObsidianUpgrade.Upgrade.Camouflage).booleanValue())
/* 141 */         return -16711936;
/*     */     }
/* 143 */     return 16777215;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockUpgradedObsidian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */