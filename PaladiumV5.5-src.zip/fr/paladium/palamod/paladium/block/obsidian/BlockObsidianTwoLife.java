/*    */ package fr.paladium.palamod.paladium.block.obsidian;
/*    */ 
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockObsidianTwoLife extends BaseBlock
/*    */ {
/*    */   public BlockObsidianTwoLife(String unlocalizedName)
/*    */   {
/* 11 */     super(unlocalizedName, net.minecraft.block.material.Material.rock);
/*    */     
/* 13 */     setResistance(6000.0F);
/* 14 */     setHardness(50.0F);
/* 15 */     setHarvestLevel("pickaxe", 4);
/*    */   }
/*    */   
/*    */   public void breakBlock(World worldIn, int x, int y, int z, Block block, int p_149749_6_)
/*    */   {
/* 20 */     super.breakBlock(worldIn, x, y, z, block, p_149749_6_);
/*    */     
/* 22 */     worldIn.setBlock(x, y, z, net.minecraft.init.Blocks.obsidian);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\obsidian\BlockObsidianTwoLife.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */