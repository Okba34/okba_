/*    */ package fr.paladium.palamod.paladium.block.obsidian;
/*    */ 
/*    */ import fr.paladium.palamod.library.block.BaseBlock;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockObsidianExplode extends BaseBlock
/*    */ {
/*    */   public BlockObsidianExplode(String unlocalizedName)
/*    */   {
/* 11 */     super(unlocalizedName, net.minecraft.block.material.Material.rock);
/*    */     
/* 13 */     setResistance(6000.0F);
/* 14 */     setHardness(50.0F);
/* 15 */     setHarvestLevel("pickaxe", 4);
/* 16 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public void breakBlock(World worldIn, int x, int y, int z, Block block, int p_149749_6_)
/*    */   {
/* 21 */     super.breakBlock(worldIn, x, y, z, block, p_149749_6_);
/*    */     
/* 23 */     worldIn.createExplosion(null, x, y, z, 2.0F, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\obsidian\BlockObsidianExplode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */