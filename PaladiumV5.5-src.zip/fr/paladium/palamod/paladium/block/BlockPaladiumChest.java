/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockPaladiumChest extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   
/*     */   public BlockPaladiumChest(String unlocalizedName)
/*     */   {
/*  28 */     super(net.minecraft.block.material.Material.iron);
/*     */     
/*  30 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  32 */     setBlockName(this.unlocalizedName);
/*  33 */     setBlockTextureName("palamod:paladium_block");
/*     */     
/*  35 */     setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*     */     
/*  37 */     setHardness(12.0F);
/*  38 */     setResistance(8.0F);
/*     */     
/*  40 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  42 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  47 */     return new PaladiumChestLogic();
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity()
/*     */   {
/*  52 */     return true;
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack)
/*     */   {
/*  57 */     byte b0 = 0;
/*  58 */     int l = MathHelper.floor_double(entity.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3;
/*     */     
/*  60 */     if (l == 0) {
/*  61 */       b0 = 2;
/*     */     }
/*     */     
/*  64 */     if (l == 1) {
/*  65 */       b0 = 5;
/*     */     }
/*     */     
/*  68 */     if (l == 2) {
/*  69 */       b0 = 3;
/*     */     }
/*     */     
/*  72 */     if (l == 3) {
/*  73 */       b0 = 4;
/*     */     }
/*     */     
/*  76 */     world.setBlockMetadataWithNotify(x, y, z, b0, 2);
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  81 */     if (!world.getBlock(x, y + 1, z).isNormalCube()) {
/*  82 */       if (!world.isRemote) {
/*  83 */         player.openGui(PalaMod.instance, 4, world, x, y, z);
/*     */       }
/*  85 */       return true;
/*     */     }
/*  87 */     return true;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/*  92 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*     */     
/*  94 */     if ((tileentity instanceof IInventory)) {
/*  95 */       IInventory inv = (IInventory)tileentity;
/*  96 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++) {
/*  97 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/*  99 */         if (itemstack != null) {
/* 100 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/* 101 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/* 104 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem)) {
/* 105 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/* 107 */             if (j1 > itemstack.stackSize) {
/* 108 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/* 111 */             itemstack.stackSize -= j1;
/* 112 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/*     */             
/* 114 */             float f3 = 0.05F;
/* 115 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/* 116 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/* 117 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/* 119 */             if (itemstack.hasTagCompound()) {
/* 120 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 125 */       world.func_147453_f(x, y, z, block);
/*     */     }
/* 127 */     super.breakBlock(world, x, y, z, block, metadata);
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock()
/*     */   {
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   public int getRenderType()
/*     */   {
/* 137 */     return 22;
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/* 142 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister icon) {
/* 147 */     this.blockIcon = icon.registerIcon("palamod:PaladiumBlock");
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockPaladiumChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */