/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import fr.paladium.palamod.items.ItemGuardianStone;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockGuardian extends Block
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   
/*     */   public BlockGuardian(String unlocalizedName)
/*     */   {
/*  21 */     super(net.minecraft.block.material.Material.iron);
/*     */     
/*  23 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  25 */     setBlockName(this.unlocalizedName);
/*  26 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*     */     
/*  28 */     setHardness(40.0F);
/*     */     
/*  30 */     setResistance(10.0F);
/*     */     
/*  32 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  34 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int p_149727_6_, float p_149727_7_, float p_149727_8_, float p_149727_9_)
/*     */   {
/*  41 */     if ((player.getHeldItem() == null) || (!(player.getHeldItem().getItem() instanceof ItemGuardianStone))) {
/*  42 */       return false;
/*     */     }
/*  44 */     ItemStack stack = player.getHeldItem();
/*  45 */     if (!world.isRemote)
/*     */     {
/*  47 */       Block block = world.getBlock(x, y, z);
/*  48 */       if ((block instanceof BlockGuardian)) {
/*  49 */         if ((world.getBlock(x + 1, y, z).equals(DecorativeRegister.PALADIUM_BLOCK)) && 
/*  50 */           (world.getBlock(x - 1, y, z).equals(DecorativeRegister.PALADIUM_BLOCK)) && 
/*  51 */           (world.getBlock(x, y - 1, z).equals(DecorativeRegister.PALADIUM_BLOCK))) {
/*  52 */           world.setBlock(x, y, z, Blocks.air);
/*  53 */           world.setBlock(x + 1, y, z, Blocks.air);
/*  54 */           world.setBlock(x - 1, y, z, Blocks.air);
/*  55 */           world.setBlock(x, y - 1, z, Blocks.air);
/*  56 */           EntityGuardianGolem golem = new EntityGuardianGolem(world);
/*  57 */           golem.setLocationAndAngles(x + 0.5D, y, z + 0.5D, 0.0F, 0.0F);
/*     */           
/*  59 */           golem.setOwner(player);
/*  60 */           if (stack.hasTagCompound()) {
/*  61 */             spawnCustomGolem(world, golem, stack, player);
/*     */           } else
/*  63 */             world.spawnEntityInWorld(golem);
/*  64 */           stack.stackSize = 0;
/*  65 */           return true;
/*     */         }
/*  67 */         if ((world.getBlock(x, y, z + 1).equals(DecorativeRegister.PALADIUM_BLOCK)) && 
/*  68 */           (world.getBlock(x, y, z - 1).equals(DecorativeRegister.PALADIUM_BLOCK)) && 
/*  69 */           (world.getBlock(x, y - 1, z).equals(DecorativeRegister.PALADIUM_BLOCK))) {
/*  70 */           world.setBlock(x, y, z, Blocks.air);
/*  71 */           world.setBlock(x, y, z + 1, Blocks.air);
/*  72 */           world.setBlock(x, y, z - 1, Blocks.air);
/*  73 */           world.setBlock(x, y - 1, z, Blocks.air);
/*  74 */           EntityGuardianGolem golem = new EntityGuardianGolem(world);
/*  75 */           golem.setOwner(player);
/*  76 */           golem.setLocationAndAngles(x + 0.5D, y, z + 0.5D, 0.0F, 0.0F);
/*  77 */           if (stack.hasTagCompound()) {
/*  78 */             spawnCustomGolem(world, golem, stack, player);
/*     */           } else
/*  80 */             world.spawnEntityInWorld(golem);
/*  81 */           stack.stackSize = 0;
/*  82 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   private void spawnCustomGolem(World world, EntityGuardianGolem golem, ItemStack stack, EntityPlayer player) {
/*  91 */     NBTTagCompound tag = stack.getTagCompound();
/*  92 */     NBTTagList nbttaglist = tag.getTagList("Items", 10);
/*  93 */     ItemStack[] content = new ItemStack[golem.getSizeInventory()];
/*     */     
/*  95 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/*  96 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/*  97 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/*  99 */       if ((j >= 0) && (j < content.length)) {
/* 100 */         content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 104 */     int level = tag.getInteger("Levels");
/* 105 */     int subLevel = tag.getInteger("SubLevels");
/*     */     
/* 107 */     String ownerUUID = tag.getString("player");
/* 108 */     golem.addInformations(content, level, subLevel, ownerUUID);
/* 109 */     world.spawnEntityInWorld(golem);
/* 110 */     golem.sync();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockGuardian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */