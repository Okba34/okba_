/*    */ package fr.paladium.palamod.paladium.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ public class BlockCave extends Block
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   
/*    */   public BlockCave(String unlocalizedName)
/*    */   {
/* 12 */     super(net.minecraft.block.material.Material.glass);
/*    */     
/* 14 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 16 */     setBlockName(this.unlocalizedName);
/* 17 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*    */     
/* 19 */     setHardness(4.0F);
/*    */     
/* 21 */     setResistance(4.0F);
/*    */     
/* 23 */     setHarvestLevel("pickaxe", 1);
/*    */     
/* 25 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public int getRenderType()
/*    */   {
/* 30 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean isOpaqueCube()
/*    */   {
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockCave.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */