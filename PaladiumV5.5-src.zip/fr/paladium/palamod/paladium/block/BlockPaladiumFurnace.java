/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockPaladiumFurnace
/*     */   extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   private IIcon front;
/*     */   private final boolean isActive;
/*     */   private static boolean isBurning;
/*  35 */   private final Random random = new Random();
/*     */   
/*     */   public BlockPaladiumFurnace(String unlocalizedName, boolean isActive) {
/*  38 */     super(Material.iron);
/*     */     
/*  40 */     this.unlocalizedName = unlocalizedName;
/*  41 */     this.isActive = isActive;
/*     */     
/*  43 */     setBlockName(this.unlocalizedName);
/*     */     
/*  45 */     setHardness(12.0F);
/*  46 */     setResistance(8.0F);
/*     */     
/*  48 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  50 */     if (!this.isActive) {
/*  51 */       setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */     }
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  57 */     return new PaladiumFurnaceLogic();
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  62 */     if (!world.isRemote) {
/*  63 */       player.openGui(PalaMod.instance, 3, world, x, y, z);
/*     */     }
/*  65 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iiconRegister)
/*     */   {
/*  71 */     this.blockIcon = iiconRegister.registerIcon("palamod:paladium_furnace_side");
/*  72 */     this.front = iiconRegister.registerIcon(this.isActive ? "palamod:paladium_furnace_front_on" : "palamod:paladium_furnace_front_off");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/*  78 */     if ((metadata == 0) && (side == 3)) {
/*  79 */       return this.front;
/*     */     }
/*  81 */     return side != metadata ? this.blockIcon : this.front;
/*     */   }
/*     */   
/*     */   public Item getItemDropped(int p_149650_1_, Random p_149650_2_, int p_149650_3_)
/*     */   {
/*  86 */     return Item.getItemFromBlock(PaladiumRegister.PALADIUM_FURNACE);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void onBlockAdded(World world, int x, int y, int z)
/*     */   {
/*  92 */     super.onBlockAdded(world, x, y, z);
/*  93 */     direction(world, x, y, z);
/*     */   }
/*     */   
/*     */   private void direction(World world, int x, int y, int z) {
/*  97 */     if (!world.isRemote) {
/*  98 */       byte byte0 = 3;
/*     */       
/*     */ 
/* 101 */       Block direction = world.getBlock(x, y, z - 1);
/* 102 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 103 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 107 */       Block direction = world.getBlock(x, y, z + 1);
/* 108 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 109 */         byte0 = 2;
/*     */       }
/*     */       
/*     */ 
/* 113 */       Block direction = world.getBlock(x - 1, y, z);
/* 114 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 115 */         byte0 = 5;
/*     */       }
/*     */       
/*     */ 
/* 119 */       Block direction = world.getBlock(x + 1, y, z);
/* 120 */       if ((direction.func_149730_j()) && (direction.func_149730_j())) {
/* 121 */         byte0 = 3;
/*     */       }
/*     */       
/*     */ 
/* 125 */       world.setBlockMetadataWithNotify(x, y, z, byte0, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack itemStack)
/*     */   {
/* 131 */     int direction = MathHelper.floor_double(entity.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3;
/*     */     
/* 133 */     if (direction == 0) {
/* 134 */       world.setBlockMetadataWithNotify(x, y, z, 2, 2);
/*     */     }
/* 136 */     else if (direction == 1) {
/* 137 */       world.setBlockMetadataWithNotify(x, y, z, 5, 2);
/*     */     }
/* 139 */     else if (direction == 2) {
/* 140 */       world.setBlockMetadataWithNotify(x, y, z, 3, 2);
/*     */     }
/* 142 */     else if (direction == 3) {
/* 143 */       world.setBlockMetadataWithNotify(x, y, z, 4, 2);
/*     */     }
/*     */     
/* 146 */     if (itemStack.hasDisplayName()) {
/* 147 */       ((PaladiumFurnaceLogic)world.getTileEntity(x, y, z)).furnaceName(itemStack.getDisplayName());
/*     */     }
/*     */   }
/*     */   
/*     */   public static void updateFurnaceBlockState(boolean burning, World world, int x, int y, int z) {
/* 152 */     int direction = world.getBlockMetadata(x, y, z);
/*     */     
/* 154 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/* 155 */     isBurning = true;
/*     */     
/* 157 */     if (burning) {
/* 158 */       world.setBlock(x, y, z, PaladiumRegister.LIT_PALADIUM_FURNACE);
/*     */     }
/*     */     else {
/* 161 */       world.setBlock(x, y, z, PaladiumRegister.PALADIUM_FURNACE);
/*     */     }
/*     */     
/* 164 */     isBurning = false;
/*     */     
/* 166 */     world.setBlockMetadataWithNotify(x, y, z, direction, 2);
/*     */     
/* 168 */     if (tileentity != null) {
/* 169 */       tileentity.validate();
/* 170 */       world.setTileEntity(x, y, z, tileentity);
/*     */     }
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int meta)
/*     */   {
/* 176 */     if (!isBurning) {
/* 177 */       PaladiumFurnaceLogic tileentitytutfurnace = (PaladiumFurnaceLogic)world.getTileEntity(x, y, z);
/*     */       
/* 179 */       if (tileentitytutfurnace != null) {
/* 180 */         for (int i = 0; i < tileentitytutfurnace.getSizeInventory(); i++) {
/* 181 */           ItemStack itemstack = tileentitytutfurnace.getStackInSlot(i);
/*     */           
/* 183 */           if (itemstack != null) {
/* 184 */             float f = this.random.nextFloat() * 0.6F + 0.1F;
/* 185 */             float f1 = this.random.nextFloat() * 0.6F + 0.1F;
/* 186 */             float f2 = this.random.nextFloat() * 0.6F + 0.1F;
/*     */             
/* 188 */             while (itemstack.stackSize > 0) {
/* 189 */               int j = this.random.nextInt(21) + 10;
/*     */               
/* 191 */               if (j > itemstack.stackSize) {
/* 192 */                 j = itemstack.stackSize;
/*     */               }
/*     */               
/* 195 */               itemstack.stackSize -= j;
/* 196 */               EntityItem entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j, itemstack.getItemDamage()));
/*     */               
/* 198 */               if (itemstack.hasTagCompound()) {
/* 199 */                 entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */               }
/*     */               
/* 202 */               float f3 = 0.025F;
/* 203 */               entityitem.motionX = ((float)this.random.nextGaussian() * f3);
/* 204 */               entityitem.motionY = ((float)this.random.nextGaussian() * f3 + 0.1F);
/* 205 */               entityitem.motionZ = ((float)this.random.nextGaussian() * f3);
/* 206 */               world.spawnEntityInWorld(entityitem);
/*     */             }
/*     */           }
/*     */         }
/* 210 */         world.func_147453_f(x, y, z, block);
/*     */       }
/*     */     }
/* 213 */     super.breakBlock(world, x, y, z, block, meta);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World p_149734_1_, int p_149734_2_, int p_149734_3_, int p_149734_4_, Random p_149734_5_) {
/* 218 */     if (this.isActive) {
/* 219 */       int l = p_149734_1_.getBlockMetadata(p_149734_2_, p_149734_3_, p_149734_4_);
/*     */       
/* 221 */       float f = p_149734_2_ + 0.5F;
/* 222 */       float f1 = p_149734_3_ + 0.0F + p_149734_5_.nextFloat() * 6.0F / 16.0F;
/* 223 */       float f2 = p_149734_4_ + 0.5F;
/* 224 */       float f3 = 0.52F;
/* 225 */       float f4 = p_149734_5_.nextFloat() * 0.6F - 0.3F;
/*     */       
/* 227 */       if (l == 4) {
/* 228 */         p_149734_1_.spawnParticle("smoke", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 229 */         p_149734_1_.spawnParticle("flame", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 231 */       else if (l == 5) {
/* 232 */         p_149734_1_.spawnParticle("smoke", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 233 */         p_149734_1_.spawnParticle("flame", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 235 */       else if (l == 2) {
/* 236 */         p_149734_1_.spawnParticle("smoke", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/* 237 */         p_149734_1_.spawnParticle("flame", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 239 */       else if (l == 3) {
/* 240 */         p_149734_1_.spawnParticle("smoke", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/* 241 */         p_149734_1_.spawnParticle("flame", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item getItem(World p_149694_1_, int p_149694_2_, int p_149694_3_, int p_149694_4_) {
/* 248 */     return Item.getItemFromBlock(PaladiumRegister.PALADIUM_FURNACE);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockPaladiumFurnace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */