/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.proxy.ClientProxy;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.ITileEntityProvider;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockObsidianUpgrader
/*     */   extends Block
/*     */   implements ITileEntityProvider
/*     */ {
/*  33 */   private IIcon[] icons = new IIcon[4];
/*     */   
/*     */   public BlockObsidianUpgrader()
/*     */   {
/*  37 */     super(Material.rock);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOpaqueCube()
/*     */   {
/*  43 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean renderAsNormalBlock()
/*     */   {
/*  49 */     return false;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getRenderType()
/*     */   {
/*  55 */     return ClientProxy.renderObsidianUpgraderId;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean shouldSideBeRendered(IBlockAccess blockAccess, int x, int y, int z, int side)
/*     */   {
/*  61 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  67 */     return new TileEntityObsidianUpgrader();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasTileEntity(int metadata)
/*     */   {
/*  73 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerBlockIcons(IIconRegister register)
/*     */   {
/*  79 */     this.blockIcon = register.registerIcon("palamod:obsidian_upgrader");
/*  80 */     this.icons[0] = register.registerIcon("palamod:obsidian_upgrader_top_ul");
/*  81 */     this.icons[1] = register.registerIcon("palamod:obsidian_upgrader_top_ur");
/*  82 */     this.icons[2] = register.registerIcon("palamod:obsidian_upgrader_top_dl");
/*  83 */     this.icons[3] = register.registerIcon("palamod:obsidian_upgrader_top_dr");
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCollisionBoxesToList(World world, int x, int y, int z, AxisAlignedBB mark, List list, Entity entity)
/*     */   {
/*  89 */     if ((world.getTileEntity(x, y, z) instanceof TileEntityObsidianUpgrader))
/*     */     {
/*  91 */       TileEntityObsidianUpgrader tile = (TileEntityObsidianUpgrader)world.getTileEntity(x, y, z);
/*  92 */       if (tile.hasMaster())
/*     */       {
/*  94 */         TileEntityObsidianUpgrader master = (TileEntityObsidianUpgrader)world.getTileEntity(tile.getMasterX(), tile.getMasterY(), tile.getMasterZ());
/*     */         
/*  96 */         boolean flag = isSame(x + 1, y, z, tile);boolean flag1 = isSame(x, y, z + 1, tile);boolean flag2 = isSame(x - 1, y, z, tile);boolean flag3 = isSame(x, y, z - 1, tile);
/*  97 */         if ((flag) && (flag1))
/*     */         {
/*  99 */           setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.1F, 1.0F);
/* 100 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 102 */           setBlockBounds(0.0F, 0.1F, 0.0F, 0.1F, 1.0F, 1.0F);
/* 103 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 105 */           setBlockBounds(0.0F, 0.1F, 0.0F, 1.0F, 1.0F, 0.1F);
/* 106 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 108 */           setBlockBounds(0.1F, 0.1F, 0.1F, 1.0F, master.getObsidian() / 64.0F, 1.0F);
/* 109 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */         }
/* 111 */         else if ((flag2) && (flag1))
/*     */         {
/* 113 */           setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.1F, 1.0F);
/* 114 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 116 */           setBlockBounds(0.9F, 0.1F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 117 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 119 */           setBlockBounds(0.0F, 0.1F, 0.0F, 1.0F, 1.0F, 0.1F);
/* 120 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 122 */           setBlockBounds(0.0F, 0.1F, 0.1F, 0.9F, master.getObsidian() / 64.0F, 1.0F);
/* 123 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */         }
/* 125 */         else if ((flag) && (flag3))
/*     */         {
/* 127 */           setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.1F, 1.0F);
/* 128 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 130 */           setBlockBounds(0.0F, 0.1F, 0.0F, 0.1F, 1.0F, 1.0F);
/* 131 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 133 */           setBlockBounds(0.0F, 0.1F, 0.9F, 1.0F, 1.0F, 1.0F);
/* 134 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 136 */           setBlockBounds(0.1F, 0.1F, 0.0F, 1.0F, master.getObsidian() / 64.0F, 0.9F);
/* 137 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */         }
/* 139 */         else if ((flag2) && (flag3))
/*     */         {
/* 141 */           setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.1F, 1.0F);
/* 142 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 144 */           setBlockBounds(0.9F, 0.1F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 145 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 147 */           setBlockBounds(0.0F, 0.1F, 0.9F, 1.0F, 1.0F, 1.0F);
/* 148 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */           
/* 150 */           setBlockBounds(0.0F, 0.1F, 0.0F, 0.9F, master.getObsidian() / 64.0F, 0.9F);
/* 151 */           super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 156 */         setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 157 */         super.addCollisionBoxesToList(world, x, y, z, mark, list, entity);
/*     */       }
/*     */     }
/* 160 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public IIcon getIcon(IBlockAccess world, int x, int y, int z, int side)
/*     */   {
/* 166 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 167 */     if ((tile instanceof TileEntityObsidianUpgrader))
/*     */     {
/* 169 */       TileEntityObsidianUpgrader te = (TileEntityObsidianUpgrader)tile;
/* 170 */       if (te.hasMaster())
/*     */       {
/* 172 */         TileEntityObsidianUpgrader master = (TileEntityObsidianUpgrader)world.getTileEntity(te.getMasterX(), te.getMasterY(), te.getMasterZ());
/* 173 */         if ((side == 1) && (master.hasObsidian().booleanValue()))
/*     */         {
/* 175 */           boolean flag = isSame(x + 1, y, z, te);boolean flag1 = isSame(x, y, z + 1, te);boolean flag2 = isSame(x - 1, y, z, te);boolean flag3 = isSame(x, y, z - 1, te);
/* 176 */           if ((flag) && (flag1))
/* 177 */             return this.icons[0];
/* 178 */           if ((flag2) && (flag1))
/* 179 */             return this.icons[1];
/* 180 */           if ((flag) && (flag3))
/* 181 */             return this.icons[2];
/* 182 */           if ((flag2) && (flag3))
/* 183 */             return this.icons[3];
/*     */         }
/*     */       }
/*     */     }
/* 187 */     return this.blockIcon;
/*     */   }
/*     */   
/*     */   private boolean isSame(int x, int y, int z, TileEntityObsidianUpgrader te)
/*     */   {
/* 192 */     World world = te.getWorldObj();
/* 193 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 194 */     if ((tile instanceof TileEntityObsidianUpgrader))
/*     */     {
/* 196 */       TileEntityObsidianUpgrader te2 = (TileEntityObsidianUpgrader)tile;
/* 197 */       return (te.getMasterX() == te2.getMasterX()) && (te.getMasterY() == te2.getMasterY()) && (te.getMasterZ() == te2.getMasterZ());
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/* 205 */     return this.blockIcon;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/* 211 */     if (world.isRemote) {
/* 212 */       return true;
/*     */     }
/*     */     
/* 215 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 216 */     if ((tile instanceof TileEntityObsidianUpgrader))
/*     */     {
/* 218 */       TileEntityObsidianUpgrader te = (TileEntityObsidianUpgrader)tile;
/* 219 */       if (te.hasMaster())
/*     */       {
/* 221 */         player.openGui(PalaMod.instance, 26, world, te.getMasterX(), te.getMasterY(), te.getMasterZ());
/* 222 */         return true;
/*     */       }
/*     */     }
/* 225 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/* 231 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*     */     
/* 233 */     if ((tileentity instanceof IInventory))
/*     */     {
/* 235 */       IInventory inv = (IInventory)tileentity;
/* 236 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++)
/*     */       {
/* 238 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/* 240 */         if (itemstack != null)
/*     */         {
/* 242 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/* 243 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/* 246 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem))
/*     */           {
/* 248 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/* 250 */             if (j1 > itemstack.stackSize)
/*     */             {
/* 252 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/* 255 */             itemstack.stackSize -= j1;
/* 256 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/* 257 */             float f3 = 0.05F;
/* 258 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/* 259 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/* 260 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/* 262 */             if (itemstack.hasTagCompound())
/*     */             {
/* 264 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 269 */       world.func_147453_f(x, y, z, block);
/*     */     }
/* 271 */     super.breakBlock(world, x, y, z, block, metadata);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockObsidianUpgrader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */