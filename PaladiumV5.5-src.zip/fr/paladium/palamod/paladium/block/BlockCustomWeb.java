/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockCustomWeb
/*     */   extends Block
/*     */ {
/*     */   IIcon icon1;
/*     */   IIcon icon2;
/*     */   IIcon icon3;
/*     */   IIcon icon4;
/*     */   
/*     */   public BlockCustomWeb()
/*     */   {
/*  25 */     super(Material.web);
/*  26 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*  27 */     setStepSound(soundTypeStone);
/*  28 */     setHarvestLevel("sword", 1);
/*  29 */     setBlockName("customweb");
/*  30 */     setBlockTextureName("palamod:CustomWeb");
/*  31 */     setResistance(4.0F);
/*  32 */     setHardness(4.0F);
/*  33 */     setTickRandomly(true);
/*     */   }
/*     */   
/*     */   public void onEntityCollidedWithBlock(World p_149670_1_, int p_149670_2_, int p_149670_3_, int p_149670_4_, Entity p_149670_5_)
/*     */   {
/*  38 */     p_149670_5_.setInWeb();
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube() {
/*  42 */     return false;
/*     */   }
/*     */   
/*     */   public void registerBlockIcons(IIconRegister icon)
/*     */   {
/*  47 */     this.icon1 = icon.registerIcon("palamod:Web1");
/*  48 */     this.icon2 = icon.registerIcon("palamod:Web2");
/*  49 */     this.icon3 = icon.registerIcon("palamod:Web3");
/*  50 */     this.icon4 = icon.registerIcon("palamod:Web4");
/*     */   }
/*     */   
/*     */   public IIcon getIcon(int side, int meta)
/*     */   {
/*  55 */     switch (meta) {
/*     */     case 0: 
/*  57 */       return this.icon1;
/*     */     case 1: 
/*  59 */       return this.icon2;
/*     */     case 2: 
/*  61 */       return this.icon3;
/*     */     case 3: 
/*  63 */       return this.icon4;
/*     */     case 4: 
/*  65 */       return this.icon4;
/*     */     }
/*  67 */     return this.icon1;
/*     */   }
/*     */   
/*     */   public void updateTick(World world, int x, int y, int z, Random random1)
/*     */   {
/*  72 */     if (world.isRemote)
/*  73 */       return;
/*  74 */     int meta = world.getBlockMetadata(x, y, z);
/*     */     
/*  76 */     if (meta < 4) {
/*  77 */       world.setBlock(x, y, z, this, meta + 2, 3);
/*     */     }
/*  79 */     if (meta > 4) {
/*  80 */       world.setBlockToAir(x, y, z);
/*     */     }
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World p_149668_1_, int p_149668_2_, int p_149668_3_, int p_149668_4_) {
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   public int getRenderType() {
/*  89 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public Item getItemDropped(int p_149650_1_, Random p_149650_2_, int p_149650_3_) {
/*  97 */     return Items.string;
/*     */   }
/*     */   
/*     */   protected boolean canSilkHarvest() {
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockCustomWeb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */