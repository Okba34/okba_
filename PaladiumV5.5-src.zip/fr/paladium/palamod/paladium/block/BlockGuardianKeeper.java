/*    */ package fr.paladium.palamod.paladium.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockGuardianKeeper extends Block
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   private IIcon top;
/*    */   private IIcon sides;
/*    */   
/*    */   public BlockGuardianKeeper(String unlocalizedName)
/*    */   {
/* 18 */     super(net.minecraft.block.material.Material.iron);
/*    */     
/* 20 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 22 */     setBlockName(this.unlocalizedName);
/* 23 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*    */     
/* 25 */     setHardness(4.0F);
/*    */     
/* 27 */     setResistance(4.0F);
/*    */     
/* 29 */     setHarvestLevel("pickaxe", 1);
/*    */     
/* 31 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*    */   {
/* 36 */     if (!world.getBlock(x, y + 1, z).isNormalCube()) {
/* 37 */       if (!world.isRemote) {
/* 38 */         player.openGui(fr.paladium.palamod.PalaMod.instance, 16, world, x, y, z);
/*    */       }
/* 40 */       return true;
/*    */     }
/* 42 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void registerBlockIcons(IIconRegister iiconRegister)
/*    */   {
/* 50 */     this.sides = iiconRegister.registerIcon("palamod:GuardianKeeper_Sides");
/* 51 */     this.top = iiconRegister.registerIcon("palamod:GuardianKeeper_Top");
/*    */   }
/*    */   
/*    */   public IIcon getIcon(int side, int metadata)
/*    */   {
/* 56 */     if ((side == 1) || (side == 0)) {
/* 57 */       return this.top;
/*    */     }
/* 59 */     return this.sides;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockGuardianKeeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */