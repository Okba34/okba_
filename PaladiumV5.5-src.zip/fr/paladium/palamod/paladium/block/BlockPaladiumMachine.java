/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumMachineLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockPaladiumMachine extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   private IIcon top;
/*     */   
/*     */   public BlockPaladiumMachine(String unlocalizedName)
/*     */   {
/*  29 */     super(Material.iron);
/*     */     
/*  31 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  33 */     setBlockName(this.unlocalizedName);
/*     */     
/*  35 */     setLightLevel(0.0F);
/*  36 */     setHardness(12.0F);
/*     */     
/*  38 */     setResistance(8.0F);
/*     */     
/*  40 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  42 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  47 */     return new PaladiumMachineLogic();
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity(int metadata)
/*     */   {
/*  52 */     return true;
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  57 */     if (!world.isRemote) {
/*  58 */       player.openGui(PalaMod.instance, 0, world, x, y, z);
/*     */     }
/*  60 */     return true;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/*  65 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*     */     
/*  67 */     if ((tileentity instanceof IInventory)) {
/*  68 */       IInventory inv = (IInventory)tileentity;
/*     */       
/*  70 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++) {
/*  71 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/*  73 */         if (itemstack != null) {
/*  74 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/*  75 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/*  78 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem)) {
/*  79 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/*  81 */             if (j1 > itemstack.stackSize) {
/*  82 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/*  85 */             itemstack.stackSize -= j1;
/*  86 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/*     */             
/*  88 */             float f3 = 0.05F;
/*  89 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/*  90 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/*  91 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/*  93 */             if (itemstack.hasTagCompound()) {
/*  94 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  99 */       world.func_147453_f(x, y, z, block);
/*     */     }
/* 101 */     super.breakBlock(world, x, y, z, block, metadata);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iiconRegister)
/*     */   {
/* 107 */     this.blockIcon = iiconRegister.registerIcon("palamod:machines/" + this.unlocalizedName);
/* 108 */     this.top = iiconRegister.registerIcon("palamod:machines/" + this.unlocalizedName + "_top");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/* 114 */     if (side == 1) {
/* 115 */       return this.top;
/*     */     }
/* 117 */     return this.blockIcon;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockPaladiumMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */