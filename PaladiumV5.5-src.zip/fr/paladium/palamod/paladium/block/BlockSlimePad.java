/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.Block.SoundType;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockSlimePad extends Block
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   
/*     */   public BlockSlimePad(String unlocalizedName)
/*     */   {
/*  19 */     super(net.minecraft.block.material.Material.glass);
/*     */     
/*  21 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  23 */     setBlockBounds(0.125F, 0.0625F, 0.125F, 0.875F, 0.625F, 0.875F);
/*     */     
/*  25 */     setBlockName(this.unlocalizedName);
/*  26 */     setBlockTextureName("palamod:" + this.unlocalizedName);
/*     */     
/*  28 */     setHardness(12.0F);
/*     */     
/*  30 */     setResistance(8.0F);
/*     */     
/*  32 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  34 */     setCreativeTab(fr.paladium.palamod.client.creativetab.CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) {
/*  38 */     return null;
/*     */   }
/*     */   
/*     */   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
/*  42 */     if (!world.isBlockIndirectlyGettingPowered(x, y, z)) {
/*  43 */       double moveX = 0.0D;
/*  44 */       double moveZ = 0.0D;
/*     */       
/*  46 */       double speed = 0.25D;
/*     */       
/*  48 */       int meta = world.getBlockMetadata(x, y, z);
/*  49 */       switch (meta % 8) {
/*     */       case 6: 
/*  51 */         moveX += speed;
/*  52 */         break;
/*     */       case 7: 
/*  54 */         moveX += speed;
/*  55 */         moveZ += speed;
/*  56 */         break;
/*     */       case 0: 
/*  58 */         moveZ += speed;
/*  59 */         break;
/*     */       case 1: 
/*  61 */         moveZ += speed;
/*  62 */         moveX -= speed;
/*  63 */         break;
/*     */       case 2: 
/*  65 */         moveX -= speed;
/*  66 */         break;
/*     */       case 3: 
/*  68 */         moveX -= speed;
/*  69 */         moveZ -= speed;
/*  70 */         break;
/*     */       case 4: 
/*  72 */         moveZ -= speed;
/*  73 */         break;
/*     */       case 5: 
/*  75 */         moveZ -= speed;
/*  76 */         moveX += speed;
/*     */       }
/*  78 */       if ((entity instanceof EntityItem)) {
/*  79 */         entity.posY += 1.0D;
/*     */       }
/*  81 */       entity.fallDistance = 0.0F;
/*  82 */       entity.addVelocity(moveX, speed * 2.0D, moveZ);
/*  83 */       world.playSoundEffect(x + 0.5F, y + 0.5F, z + 0.5F, this.stepSound.getStepResourcePath(), this.stepSound
/*  84 */         .getVolume() / 2.0F, this.stepSound.getPitch() * 0.65F);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isBlockReplaceable(World world, int x, int y, int z) {
/*  89 */     return false;
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack) {
/*  93 */     int face = MathHelper.floor_double(entity.rotationYaw * 8.0F / 360.0F + 0.5D) + (entity.isSneaking() ? 4 : 0) & 0x7;
/*     */     
/*  95 */     int meta = world.getBlockMetadata(x, y, z) & 0x8;
/*  96 */     world.setBlockMetadataWithNotify(x, y, z, face | meta, 2);
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock() {
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube() {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public int getRenderBlockPass() {
/* 108 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockSlimePad.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */