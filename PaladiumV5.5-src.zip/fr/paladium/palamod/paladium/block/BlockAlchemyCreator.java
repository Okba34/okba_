/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockAlchemyCreator extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   
/*     */   public BlockAlchemyCreator(String unlocalizedName)
/*     */   {
/*  23 */     super(net.minecraft.block.material.Material.iron);
/*     */     
/*  25 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  27 */     setBlockName(this.unlocalizedName);
/*  28 */     setBlockTextureName("minecraft:stone");
/*     */     
/*  30 */     setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.8F, 1.0F);
/*     */     
/*  32 */     setHardness(1.5F);
/*  33 */     setResistance(8.0F);
/*     */     
/*  35 */     setHarvestLevel("pickaxe", 1);
/*     */     
/*  37 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  42 */     return new fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic();
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  47 */     if (!world.isRemote) {
/*  48 */       player.openGui(PalaMod.instance, 1, world, x, y, z);
/*     */     }
/*  50 */     return true;
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase entity, ItemStack stack)
/*     */   {
/*  55 */     super.onBlockPlacedBy(world, x, y, z, entity, stack);
/*     */     
/*  57 */     byte b0 = 3;
/*  58 */     b0 = rotateBlock(b0, entity);
/*  59 */     world.setBlockMetadataWithNotify(x, y, z, b0, 2);
/*     */   }
/*     */   
/*     */   public byte rotateBlock(byte b0, EntityLivingBase entity) {
/*  63 */     if (((entity.rotationYaw >= 135.0F) && (entity.rotationYaw <= 181.0F)) || ((entity.rotationYaw <= -135.0F) && (entity.rotationYaw >= -181.0F))) {
/*  64 */       b0 = 3;
/*     */     }
/*  66 */     else if ((entity.rotationYaw > -135.0F) && (entity.rotationYaw < -45.0F)) {
/*  67 */       b0 = 4;
/*     */     }
/*  69 */     else if ((entity.rotationYaw >= -45.0F) && (entity.rotationYaw <= 45.0F)) {
/*  70 */       b0 = 2;
/*     */     }
/*  72 */     else if ((entity.rotationYaw > 45.0F) && (entity.rotationYaw < 135.0F)) {
/*  73 */       b0 = 5;
/*     */     }
/*  75 */     else if (entity.rotationYaw >= 181.0F) {
/*  76 */       entity.rotationYaw -= 360.0F;
/*  77 */       b0 = rotateBlock(b0, entity);
/*     */     }
/*  79 */     else if (entity.rotationYaw <= -181.0F) {
/*  80 */       entity.rotationYaw += 360.0F;
/*  81 */       b0 = rotateBlock(b0, entity);
/*     */     }
/*  83 */     return b0;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/*  88 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*     */     
/*  90 */     if ((tileentity instanceof IInventory)) {
/*  91 */       IInventory inv = (IInventory)tileentity;
/*  92 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++) {
/*  93 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/*  95 */         if (itemstack != null) {
/*  96 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/*  97 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/* 100 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem)) {
/* 101 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/* 103 */             if (j1 > itemstack.stackSize) {
/* 104 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/* 107 */             itemstack.stackSize -= j1;
/* 108 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/*     */             
/* 110 */             float f3 = 0.05F;
/* 111 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/* 112 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/* 113 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/* 115 */             if (itemstack.hasTagCompound()) {
/* 116 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 121 */       world.func_147453_f(x, y, z, block);
/*     */     }
/* 123 */     super.breakBlock(world, x, y, z, block, metadata);
/*     */   }
/*     */   
/*     */   public int getRenderType()
/*     */   {
/* 128 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean isOpaqueCube()
/*     */   {
/* 133 */     return false;
/*     */   }
/*     */   
/*     */   public boolean renderAsNormalBlock()
/*     */   {
/* 138 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockAlchemyCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */