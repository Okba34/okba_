/*    */ package fr.paladium.palamod.paladium.block;
/*    */ 
/*    */ import fr.paladium.palamod.tiles.TileEntityCamera;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.ITileEntityProvider;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockCamera
/*    */   extends Block implements ITileEntityProvider
/*    */ {
/*    */   public BlockCamera()
/*    */   {
/* 19 */     super(Material.rock);
/* 20 */     setBlockTextureName("palamod:TitaneBlock");
/*    */   }
/*    */   
/*    */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase living, ItemStack stack)
/*    */   {
/* 25 */     int direction = ((MathHelper.floor_double(living.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3) + 0) % 4;
/* 26 */     world.setBlockMetadataWithNotify(x, y, z, direction, 2);
/*    */   }
/*    */   
/*    */ 
/*    */   public int getRenderType()
/*    */   {
/* 32 */     return -1;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isOpaqueCube()
/*    */   {
/* 38 */     return false;
/*    */   }
/*    */   
/*    */   public boolean renderAsNormalBlock()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public TileEntity createNewTileEntity(World world, int metadata)
/*    */   {
/* 49 */     return new TileEntityCamera();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasTileEntity()
/*    */   {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setBlockBoundsBasedOnState(IBlockAccess access, int x, int y, int z)
/*    */   {
/* 61 */     switch (access.getBlockMetadata(x, y, z))
/*    */     {
/*    */     case 0: 
/* 64 */       setBlockBounds(0.3F, 0.33F, 0.33F, 0.66F, 0.66F, 1.0F);
/* 65 */       break;
/*    */     case 1: 
/* 67 */       setBlockBounds(0.0F, 0.33F, 0.33F, 0.66F, 0.66F, 0.7F);
/* 68 */       break;
/*    */     case 2: 
/* 70 */       setBlockBounds(0.33F, 0.33F, 0.0F, 0.66F, 0.66F, 0.7F);
/* 71 */       break;
/*    */     case 3: 
/* 73 */       setBlockBounds(0.3F, 0.33F, 0.33F, 1.0F, 0.66F, 0.7F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */