/*     */ package fr.paladium.palamod.paladium.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.paladium.logic.BowMachineLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockBowMachine extends BlockContainer
/*     */ {
/*     */   protected String unlocalizedName;
/*     */   private IIcon[] icons;
/*     */   
/*     */   public BlockBowMachine(String unlocalizedName)
/*     */   {
/*  29 */     super(Material.iron);
/*     */     
/*  31 */     this.unlocalizedName = unlocalizedName;
/*  32 */     this.icons = new IIcon[2];
/*     */     
/*  34 */     setBlockName(this.unlocalizedName);
/*     */     
/*  36 */     setLightOpacity(255);
/*  37 */     setLightLevel(0.0F);
/*     */     
/*  39 */     setHardness(1.5F);
/*  40 */     setResistance(8.0F);
/*     */     
/*  42 */     setHarvestLevel("pickaxe", 1);
/*     */     
/*  44 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int metadata)
/*     */   {
/*  49 */     return new BowMachineLogic();
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity()
/*     */   {
/*  54 */     return true;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata)
/*     */   {
/*  59 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/*     */     
/*  61 */     if ((tileentity instanceof IInventory)) {
/*  62 */       IInventory inv = (IInventory)tileentity;
/*  63 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++) {
/*  64 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/*  66 */         if (itemstack != null) {
/*  67 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/*  68 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/*  71 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem)) {
/*  72 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/*  74 */             if (j1 > itemstack.stackSize) {
/*  75 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/*  78 */             itemstack.stackSize -= j1;
/*  79 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/*     */             
/*  81 */             float f3 = 0.05F;
/*  82 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/*  83 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/*  84 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/*  86 */             if (itemstack.hasTagCompound()) {
/*  87 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  92 */       world.func_147453_f(x, y, z, block);
/*     */     }
/*  94 */     super.breakBlock(world, x, y, z, block, metadata);
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*     */   {
/*  99 */     if (!world.isRemote) {
/* 100 */       player.openGui(PalaMod.instance, 5, world, x, y, z);
/*     */     }
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister icon)
/*     */   {
/* 108 */     this.icons[0] = icon.registerIcon("palamod:machines/" + this.unlocalizedName + "_top");
/* 109 */     this.icons[1] = icon.registerIcon("palamod:machines/" + this.unlocalizedName + "_side");
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/* 115 */     if ((side == 1) || (side == 0)) {
/* 116 */       return this.icons[0];
/*     */     }
/* 118 */     return this.icons[1];
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockBowMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */