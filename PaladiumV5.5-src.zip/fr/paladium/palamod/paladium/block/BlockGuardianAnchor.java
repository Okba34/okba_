/*    */ package fr.paladium.palamod.paladium.block;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemGuardianWand;
/*    */ import fr.paladium.palamod.tiles.TileEntityGuardianAnchor;
/*    */ import net.minecraft.block.BlockContainer;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockGuardianAnchor
/*    */   extends BlockContainer
/*    */ {
/*    */   public BlockGuardianAnchor()
/*    */   {
/* 20 */     super(Material.rock);
/* 21 */     setResistance(8.0F);
/* 22 */     setHarvestLevel("pickaxe", 2);
/* 23 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/* 24 */     setBlockName("guardianradius");
/* 25 */     setBlockTextureName("palamod:GuardianAnchor");
/* 26 */     setHardness(12.0F);
/*    */   }
/*    */   
/*    */   public TileEntity createNewTileEntity(World world, int metadata)
/*    */   {
/* 31 */     return new TileEntityGuardianAnchor();
/*    */   }
/*    */   
/*    */   public boolean hasTileEntity(int metadata)
/*    */   {
/* 36 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ)
/*    */   {
/* 42 */     if ((player.getHeldItem() != null) && ((player.getHeldItem().getItem() instanceof ItemGuardianWand))) {
/* 43 */       ItemStack stack = player.getHeldItem();
/* 44 */       EntityGuardianGolem golem = ItemGuardianWand.getGolem(stack, world);
/*    */       
/* 46 */       if ((golem != null) && (golem.checkWhitelist(player)))
/* 47 */         golem.setAnchor(x, y, z);
/* 48 */       return true;
/*    */     }
/*    */     
/* 51 */     if (!world.isRemote) {
/* 52 */       player.openGui(PalaMod.instance, 23, world, x, y, z);
/*    */     }
/*    */     
/* 55 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onBlockClicked(World world, int x, int y, int z, EntityPlayer p)
/*    */   {
/* 62 */     super.onBlockClicked(world, x, y, z, p);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockGuardianAnchor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */