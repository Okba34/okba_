/*    */ package fr.paladium.palamod.paladium.block;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.tiles.TileEntityOnlineDetector;
/*    */ import net.minecraft.block.BlockContainer;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.client.renderer.texture.IIconRegister;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.IIcon;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BlockOnlineDetector extends BlockContainer
/*    */ {
/*    */   protected String unlocalizedName;
/*    */   private IIcon[] icons;
/*    */   
/*    */   public BlockOnlineDetector(String unlocalizedName)
/*    */   {
/* 21 */     super(Material.iron);
/*    */     
/* 23 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 25 */     setBlockName(this.unlocalizedName);
/*    */     
/* 27 */     setLightOpacity(255);
/* 28 */     setLightLevel(0.0F);
/* 29 */     setHardness(4.0F);
/* 30 */     setResistance(4.0F);
/*    */     
/* 32 */     setHarvestLevel("pickaxe", 1);
/*    */     
/* 34 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int p_149727_6_, float p_149727_7_, float p_149727_8_, float p_149727_9_)
/*    */   {
/* 39 */     if (!world.isRemote) {
/* 40 */       player.openGui(PalaMod.instance, 9, world, x, y, z);
/*    */     }
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   public TileEntity createNewTileEntity(World world, int meta)
/*    */   {
/* 47 */     return new TileEntityOnlineDetector();
/*    */   }
/*    */   
/*    */   public void registerBlockIcons(IIconRegister icon)
/*    */   {
/* 52 */     this.icons = new IIcon[2];
/* 53 */     this.icons[0] = icon.registerIcon("palamod:OnlineDetector_off");
/* 54 */     this.icons[1] = icon.registerIcon("palamod:OnlineDetector_on");
/*    */   }
/*    */   
/*    */   public IIcon getIcon(int side, int meta)
/*    */   {
/* 59 */     return this.icons[meta];
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\block\BlockOnlineDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */