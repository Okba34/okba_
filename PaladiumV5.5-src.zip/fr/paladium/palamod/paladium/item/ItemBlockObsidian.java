/*    */ package fr.paladium.palamod.paladium.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import fr.paladium.palamod.job.Job;
/*    */ import fr.paladium.palamod.job.JobsXPManager;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemBlockObsidian extends ItemBlock
/*    */ {
/*    */   private Block block;
/*    */   
/*    */   public ItemBlockObsidian(Block block)
/*    */   {
/* 25 */     super(block);
/*    */     
/* 27 */     this.block = block;
/*    */     
/* 29 */     setMaxDamage(0);
/* 30 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */   
/*    */   public int getMetadata(int meta) {
/* 34 */     return meta;
/*    */   }
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int metadata)
/*    */   {
/* 39 */     if (world.isRemote) {
/* 40 */       return false;
/*    */     }
/*    */     
/* 43 */     JobsXPManager jobsXPManager = (JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString());
/* 44 */     if (this.block == PaladiumRegister.EXPLODE_OBSIDIAN_BLOCK) {
/* 45 */       if (((Job)ModJobs.jobs.get(Integer.valueOf(5))).getLevel(jobsXPManager.getXP(5)) > 15) {
/* 46 */         return true;
/*    */       }
/* 48 */       player.addChatComponentMessage(new ChatComponentText(EnumChatFormatting.DARK_RED + "[PalaMod-Jobs] " + EnumChatFormatting.RED + "Il faut 15 Lvl en Hunter Min."));
/*    */     }
/* 50 */     else if (this.block == PaladiumRegister.FAKE_OBSIDIAN_BLOCK) {
/* 51 */       if (((Job)ModJobs.jobs.get(Integer.valueOf(5))).getLevel(jobsXPManager.getXP(5)) > 5) {
/* 52 */         return true;
/*    */       }
/* 54 */       player.addChatComponentMessage(new ChatComponentText(EnumChatFormatting.DARK_RED + "[PalaMod-Jobs] " + EnumChatFormatting.RED + "Il faut 5 Lvl en Hunter Min."));
/*    */     }
/* 56 */     else if (this.block == PaladiumRegister.TWOLIFE_OBSIDIAN_BLOCK) {
/* 57 */       if (((Job)ModJobs.jobs.get(Integer.valueOf(5))).getLevel(jobsXPManager.getXP(5)) > 10) {
/* 58 */         return true;
/*    */       }
/* 60 */       player.addChatComponentMessage(new ChatComponentText(EnumChatFormatting.DARK_RED + "[PalaMod-Jobs] " + EnumChatFormatting.RED + "Il faut 10 Lvl en Hunter Min."));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 65 */     return false;
/*    */   }
/*    */   
/*    */   public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean b)
/*    */   {
/* 70 */     super.addInformation(stack, player, list, b);
/* 71 */     list.add(EnumChatFormatting.GRAY + StatCollector.translateToLocal("tooltip.show"));
/*    */     
/* 73 */     String jobXpPrefix = EnumChatFormatting.GREEN + StatCollector.translateToLocal("tooltip.jobXpPrefix");
/* 74 */     if (net.minecraft.client.gui.GuiScreen.isShiftKeyDown()) {
/* 75 */       if (this.block == PaladiumRegister.EXPLODE_OBSIDIAN_BLOCK) {
/* 76 */         list.add(jobXpPrefix + " Lvl 15 Hunter Min");
/*    */       }
/* 78 */       else if (this.block == PaladiumRegister.FAKE_OBSIDIAN_BLOCK) {
/* 79 */         list.add(jobXpPrefix + " Lvl 5 Hunter Min");
/*    */       }
/* 81 */       else if (this.block == PaladiumRegister.TWOLIFE_OBSIDIAN_BLOCK) {
/* 82 */         list.add(jobXpPrefix + " Lvl 10 Hunter Min");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\item\ItemBlockObsidian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */