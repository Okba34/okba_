/*    */ package fr.paladium.palamod.paladium.item;
/*    */ 
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemExtrapolatedBucket extends fr.paladium.palamod.library.item.BaseItem
/*    */ {
/*    */   public ItemExtrapolatedBucket(String unlocalizedName)
/*    */   {
/* 13 */     super(unlocalizedName);
/*    */     
/* 15 */     setMaxStackSize(1);
/* 16 */     setMaxDamage(16);
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
/*    */   {
/* 21 */     MovingObjectPosition movingobjectposition = getMovingObjectPositionFromPlayer(par2World, par3EntityPlayer, true);
/*    */     
/* 23 */     if (movingobjectposition == null) {
/* 24 */       return par1ItemStack;
/*    */     }
/*    */     
/* 27 */     if (movingobjectposition.typeOfHit == net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK) {
/* 28 */       int i = movingobjectposition.blockX;
/* 29 */       int j = movingobjectposition.blockY;
/* 30 */       int k = movingobjectposition.blockZ;
/*    */       
/* 32 */       if (!par2World.canMineBlock(par3EntityPlayer, i, j, k)) {
/* 33 */         return par1ItemStack;
/*    */       }
/* 35 */       if (!par3EntityPlayer.canPlayerEdit(i, j, k, movingobjectposition.sideHit, par1ItemStack)) {
/* 36 */         return par1ItemStack;
/*    */       }
/*    */       
/* 39 */       Material material = par2World.getBlock(i, j, k).getMaterial();
/* 40 */       int l = par2World.getBlockMetadata(i, j, k);
/*    */       
/* 42 */       if ((material == Material.water) && (l == 0)) {
/* 43 */         par2World.setBlockToAir(i, j, k);
/* 44 */         par1ItemStack.damageItem(1, par3EntityPlayer);
/* 45 */         return par1ItemStack;
/*    */       }
/*    */       
/* 48 */       if ((material == Material.lava) && (l == 0)) {
/* 49 */         par2World.setBlockToAir(i, j, k);
/* 50 */         par1ItemStack.damageItem(1, par3EntityPlayer);
/* 51 */         return par1ItemStack;
/*    */       }
/*    */     }
/* 54 */     return par1ItemStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\item\ItemExtrapolatedBucket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */