/*    */ package fr.paladium.palamod.paladium.item;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ItemDynamiteBig extends BaseItemDynamite
/*    */ {
/*    */   public ItemDynamiteBig(String unlocalizedName)
/*    */   {
/* 10 */     super(unlocalizedName);
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack onItemRightClick(net.minecraft.item.ItemStack itemstack, World world, EntityPlayer entityplayer)
/*    */   {
/* 15 */     if ((entityplayer.inventory.consumeInventoryItem(this)) && 
/* 16 */       (!world.isRemote)) {
/* 17 */       world.spawnEntityInWorld(new fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity(world, entityplayer, 40 + itemRand.nextInt(10), fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity.BIG));
/*    */     }
/*    */     
/* 20 */     return itemstack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\item\ItemDynamiteBig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */