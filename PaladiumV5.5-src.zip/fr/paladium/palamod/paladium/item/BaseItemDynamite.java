/*    */ package fr.paladium.palamod.paladium.item;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class BaseItemDynamite extends fr.paladium.palamod.library.item.BaseItem
/*    */ {
/*    */   public BaseItemDynamite(String unlocalizedName)
/*    */   {
/* 13 */     super(unlocalizedName);
/*    */   }
/*    */   
/*    */   public int getItemEnchantability()
/*    */   {
/* 18 */     return 0;
/*    */   }
/*    */   
/*    */   public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
/*    */   {
/* 23 */     if (entityplayer.inventory.consumeInventoryItem(this)) {
/* 24 */       world.playSoundAtEntity(entityplayer, "game.tnt.primed", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 0.8F));
/* 25 */       if (!world.isRemote) {
/* 26 */         world.spawnEntityInWorld(new fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity(world, entityplayer, 40 + itemRand.nextInt(10), fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity.DEFAULT));
/*    */       }
/*    */     }
/* 29 */     return itemstack;
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.relauncher.SideOnly(Side.CLIENT)
/*    */   public boolean shouldRotateAroundWhenRendering()
/*    */   {
/* 35 */     return true;
/*    */   }
/*    */   
/*    */   @cpw.mods.fml.relauncher.SideOnly(Side.CLIENT)
/*    */   public boolean isFull3D()
/*    */   {
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\paladium\item\BaseItemDynamite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */