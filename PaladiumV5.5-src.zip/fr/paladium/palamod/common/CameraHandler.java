/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.WorldProvider;
/*    */ 
/*    */ 
/*    */ public class CameraHandler
/*    */ {
/*    */   public static final class CameraData
/*    */   {
/*    */     public final Vec3 position;
/*    */     public final float pitch;
/*    */     public final float yaw;
/*    */     public final int dimension;
/*    */     
/*    */     public CameraData(Vec3 position, float pitch, float yaw)
/*    */     {
/* 21 */       this.position = position;
/* 22 */       this.pitch = pitch;
/* 23 */       this.yaw = yaw;
/* 24 */       this.dimension = Minecraft.getMinecraft().theWorld.provider.dimensionId;
/*    */     }
/*    */   }
/*    */   
/* 28 */   public static CameraData[] cameras = new CameraData['Ā'];
/*    */   
/*    */   public static int createCamera(double x, double y, double z, float pitch, float yaw)
/*    */   {
/* 32 */     CameraData cameraData = new CameraData(Vec3.createVectorHelper(x, y, z), pitch, yaw);
/* 33 */     for (int i = 0; i < cameras.length; i++)
/*    */     {
/* 35 */       if (cameras[i] == null)
/*    */       {
/* 37 */         cameras[i] = cameraData;
/* 38 */         return i;
/*    */       }
/*    */     }
/* 41 */     return -1;
/*    */   }
/*    */   
/*    */   public static int createCamera(EntityPlayer player)
/*    */   {
/* 46 */     CameraData cameraData = new CameraData(Vec3.createVectorHelper(player.posX, player.posY + player.getEyeHeight(), player.posZ), player.rotationPitch, player.rotationYawHead);
/* 47 */     for (int i = 0; i < cameras.length; i++)
/*    */     {
/* 49 */       if (cameras[i] == null)
/*    */       {
/* 51 */         cameras[i] = cameraData;
/* 52 */         return i;
/*    */       }
/*    */     }
/* 55 */     return -1;
/*    */   }
/*    */   
/*    */   public static CameraData getCamera(int id)
/*    */   {
/* 60 */     if ((id < 0) || (id >= cameras.length))
/*    */     {
/* 62 */       return null;
/*    */     }
/* 64 */     return cameras[id];
/*    */   }
/*    */   
/*    */   public static void removeCamera(int id)
/*    */   {
/* 69 */     if ((id < 0) || (id >= cameras.length))
/*    */     {
/* 71 */       return;
/*    */     }
/* 73 */     cameras[id] = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\CameraHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */