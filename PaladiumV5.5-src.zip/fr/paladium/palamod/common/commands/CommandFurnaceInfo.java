/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.util.PlayerHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandFurnaceInfo
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 22 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 27 */     return "finfo";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 32 */     return "finfo [pseudo]";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 42 */     if (command.length == 0)
/* 43 */       sender.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Mauvais usage !"));
/* 44 */     EntityPlayer p = PlayerHelper.getPlayerByName(command[0]);
/* 45 */     if (p != null) {
/* 46 */       p.openGui("palamod", 18, p.getEntityWorld(), 0, 0, 0);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender) {
/* 51 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 57 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 63 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandFurnaceInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */