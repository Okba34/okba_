/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.job.JobsXPManager;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.util.PlayerHelper;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ public class CommandSetXpJobs
/*    */   implements ICommand
/*    */ {
/*    */   public String getCommandName()
/*    */   {
/* 20 */     return "setxpjobs";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender p_71518_1_)
/*    */   {
/* 25 */     return "setxpjobs [PLAYER] [ID JOBS] [XP]";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 30 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender p_71515_1_, String[] p_71515_2_)
/*    */   {
/* 35 */     if (p_71515_2_.length == 3) {
/* 36 */       EntityPlayer p = PlayerHelper.getPlayerByName(p_71515_2_[0]);
/* 37 */       if ((p != null) && (isInteger(p_71515_2_[1])) && (isInteger(p_71515_2_[2]))) {
/* 38 */         int idjobs = Integer.parseInt(p_71515_2_[1]);
/* 39 */         int xp = Integer.parseInt(p_71515_2_[2]);
/* 40 */         if ((idjobs > 0) && (idjobs <= 5)) {
/* 41 */           JobsXPManager jobsXPManager = (JobsXPManager)ModJobs.allJobsXpManager.get(p.getUniqueID().toString());
/* 42 */           jobsXPManager.setXP(idjobs, xp);
/* 43 */           ModJobs.allJobsXpManager.remove(p.getUniqueID().toString());
/* 44 */           ModJobs.allJobsXpManager.put(p.getUniqueID().toString(), jobsXPManager);
/* 45 */           p_71515_1_.addChatMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + xp + " Xp est set sur le jobs id: " + idjobs + " pour le player: " + p.getDisplayName(), new Object[0]));
/*    */         } else {
/* 47 */           p_71515_1_.addChatMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Id Jobs incorrect", new Object[0]));
/*    */         }
/*    */       } else {
/* 50 */         p_71515_1_.addChatMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Commands incorrect: /setxpjobs [PLAYER] [ID JOBS] [XP]", new Object[0]));
/*    */       }
/*    */     } else {
/* 53 */       p_71515_1_.addChatMessage(new ChatComponentTranslation(EnumChatFormatting.DARK_RED + "[Paladium-Jobs] " + EnumChatFormatting.RED + "Commands incorrect: /setxpjobs [PLAYER] [ID JOBS] [XP]", new Object[0]));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender p_71519_1_)
/*    */   {
/* 59 */     return true;
/*    */   }
/*    */   
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 64 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 69 */     return false;
/*    */   }
/*    */   
/*    */   public int compareTo(Object o)
/*    */   {
/* 74 */     return 0;
/*    */   }
/*    */   
/*    */   public static boolean isInteger(String s) {
/*    */     try {
/* 79 */       Integer.parseInt(s);
/*    */     } catch (NumberFormatException e) {
/* 81 */       return false;
/*    */     } catch (NullPointerException e) {
/* 83 */       return false;
/*    */     }
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandSetXpJobs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */