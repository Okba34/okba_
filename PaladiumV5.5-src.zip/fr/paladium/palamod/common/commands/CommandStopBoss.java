/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.common.BossHandler;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketMessageBoss;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandStopBoss
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 21 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 26 */     return "sboss";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 31 */     return "sboss";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 36 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 41 */     PacketMessageBoss packet = new PacketMessageBoss();
/* 42 */     packet.addInformations(0, 0, (byte)1, 0);
/* 43 */     CommonProxy.packetPipeline.sendToAll(packet);
/* 44 */     BossHandler.reset();
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 49 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 55 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 61 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandStopBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */