/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.util.PlayerHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandFactions
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 23 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 28 */     return "fannounce";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 33 */     return "aboss [x] [z] [time]";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 38 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 43 */     if (command.length == 0) {
/* 44 */       sender.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Mauvais usage !"));
/* 45 */       return;
/*    */     }
/* 47 */     EntityPlayer p = PlayerHelper.getPlayerByName(command[0]);
/* 48 */     if (p != null) {
/* 49 */       p.openGui("palamod", 19, p.getEntityWorld(), 0, 0, 0);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender) {
/* 54 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 60 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandFactions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */