/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.common.BossHandler;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketMessageBoss;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.server.management.ServerConfigurationManager;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandAnnounceBoss
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 25 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 30 */     return "aboss";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 35 */     return "aboss [x] [z] [time]";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 45 */     if (command.length <= 3) {
/* 46 */       sender.addChatMessage(new ChatComponentTranslation("Mauvais usage", new Object[0]));
/* 47 */       return;
/*    */     }
/*    */     
/* 50 */     PacketMessageBoss packet = new PacketMessageBoss();
/* 51 */     int time = 0;
/* 52 */     int x = 0;
/* 53 */     int z = 0;
/*    */     try
/*    */     {
/* 56 */       time = Integer.parseInt(command[3]);
/* 57 */       x = Integer.parseInt(command[1]);
/* 58 */       z = Integer.parseInt(command[2]);
/* 59 */       player = MinecraftServer.getServer().getConfigurationManager().func_152612_a(command[0]);
/*    */     } catch (NumberFormatException e) { EntityPlayerMP player;
/* 61 */       sender.addChatMessage(new ChatComponentTranslation("Mauvais usage", new Object[0])); return;
/*    */     }
/*    */     EntityPlayerMP player;
/* 64 */     packet.addInformations(x, z, (byte)0, time);
/* 65 */     CommonProxy.packetPipeline.sendTo(packet, player);
/* 66 */     BossHandler.enable(time, x, z);
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 71 */     return true;
/*    */   }
/*    */   
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 76 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 82 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandAnnounceBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */