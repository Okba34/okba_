/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketSendMessage;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import fr.paladium.palamod.util.PlayerHelper;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandSendMessage
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 23 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 28 */     return "overlay";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 33 */     return "overlay [title] [subtitle] [time] [player/@all]";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 38 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 43 */     if (command.length <= 3) {
/* 44 */       sender.addChatMessage(new ChatComponentTranslation("Mauvais usage", new Object[0]));
/* 45 */       return;
/*    */     }
/*    */     
/* 48 */     PacketSendMessage packet = new PacketSendMessage();
/* 49 */     int time = 0;
/*    */     try {
/* 51 */       time = Integer.parseInt(command[2]);
/*    */     } catch (NumberFormatException e) {
/* 53 */       sender.addChatMessage(new ChatComponentTranslation("Mauvais usage", new Object[0]));
/* 54 */       return;
/*    */     }
/* 56 */     command[0].replaceAll("_", " ");
/* 57 */     command[1].replaceAll("_", " ");
/* 58 */     packet.addInformations(command[0], command[1], time);
/* 59 */     if (command[3].equalsIgnoreCase("@all")) {
/* 60 */       CommonProxy.packetPipeline.sendToAll(packet);
/*    */     } else {
/* 62 */       EntityPlayer p = PlayerHelper.getPlayerByName(command[3]);
/* 63 */       if (p == null)
/* 64 */         return;
/* 65 */       CommonProxy.packetPipeline.sendTo(packet, (EntityPlayerMP)p);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 71 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 77 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 83 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandSendMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */