/*    */ package fr.paladium.palamod.common.commands;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.crafting.FurnaceRecipes;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandFurnace
/*    */   implements ICommand
/*    */ {
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 25 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 30 */     return "furnace";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 35 */     return "furnace";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 40 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 45 */     if ((sender instanceof EntityPlayer)) {
/* 46 */       EntityPlayer player = (EntityPlayer)sender;
/* 47 */       ItemStack item = player.getHeldItem();
/* 48 */       if (item == null) {
/* 49 */         player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Vous devez avoir l'item que vous voulez cuire dans votre main !"));
/*    */         
/* 51 */         return;
/*    */       }
/* 53 */       ItemStack itemResult = FurnaceRecipes.smelting().getSmeltingResult(item);
/* 54 */       if (itemResult == null) {
/* 55 */         player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Cet item ne peux pas Ãªtre cuit !"));
/*    */         
/* 57 */         return;
/*    */       }
/* 59 */       itemResult.stackSize = player.inventory.getStackInSlot(player.inventory.currentItem).stackSize;
/* 60 */       player.inventory.setInventorySlotContents(player.inventory.currentItem, null);
/* 61 */       player.inventory.addItemStackToInventory(itemResult);
/* 62 */       player.addChatMessage(new ChatComponentText(EnumChatFormatting.RED + "Le contenu de votre main a ete cuit !"));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 69 */     return true;
/*    */   }
/*    */   
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 79 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\commands\CommandFurnace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */