/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import net.minecraftforge.common.util.EnumHelper;
/*    */ 
/*    */ public class ToolMaterialPaladium
/*    */ {
/*    */   public static net.minecraft.item.Item.ToolMaterial toolTypePaladium;
/*    */   public static net.minecraft.item.Item.ToolMaterial toolTypeAmethyst;
/*    */   public static net.minecraft.item.Item.ToolMaterial toolTypeTitane;
/*    */   public static net.minecraft.item.Item.ToolMaterial toolTypeEndium;
/*    */   
/*    */   public static void init() {
/* 13 */     toolTypePaladium = EnumHelper.addToolMaterial("paladiumTool", 3, 4999, 30.0F, 6.0F, 35);
/* 14 */     toolTypeAmethyst = EnumHelper.addToolMaterial("amethystTool", 3, 1999, 20.0F, 4.0F, 20);
/* 15 */     toolTypeTitane = EnumHelper.addToolMaterial("titaneTool", 3, 2999, 23.0F, 5.0F, 25);
/* 16 */     toolTypeEndium = EnumHelper.addToolMaterial("endiumTool", 4, 4999, 28.0F, 7.0F, 35);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\ToolMaterialPaladium.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */