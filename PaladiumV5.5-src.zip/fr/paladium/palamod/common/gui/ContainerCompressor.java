/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ 
/*    */ public class ContainerCompressor
/*    */   extends Container
/*    */ {
/*    */   public boolean canInteractWith(EntityPlayer p_75145_1_)
/*    */   {
/* 11 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerCompressor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */