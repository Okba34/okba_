/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.job.JobsXPManager;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketSendData;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.UUID;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ 
/*    */ public class ContainerJobUnified extends ContainerUnified
/*    */ {
/*    */   EntityPlayer player;
/*    */   
/*    */   public ContainerJobUnified(EntityPlayer player)
/*    */   {
/* 22 */     super(44);
/* 23 */     this.player = player;
/*    */     
/* 25 */     if (!player.worldObj.isRemote)
/* 26 */       loadDataAndSendToClient(player.getUniqueID(), player);
/*    */   }
/*    */   
/*    */   private void loadDataAndSendToClient(UUID uniqueID, EntityPlayer player) {
/* 30 */     JobsXPManager jobs = (JobsXPManager)ModJobs.allJobsXpManager.get(player.getUniqueID().toString());
/*    */     
/* 32 */     if (jobs == null) {
/* 33 */       return;
/*    */     }
/* 35 */     HashMap<Integer, Integer> map = jobs.getAllJobs();
/*    */     
/* 37 */     if (map == null) {
/* 38 */       return;
/*    */     }
/* 40 */     JSONObject obj = new JSONObject();
/* 41 */     if (map.size() != 0) {
/* 42 */       JSONArray array = new JSONArray();
/* 43 */       for (Map.Entry<Integer, Integer> e : map.entrySet()) {
/* 44 */         JSONObject subObject = new JSONObject();
/* 45 */         subObject.put("id", e.getKey());
/* 46 */         subObject.put("xp", e.getValue());
/* 47 */         array.add(subObject);
/*    */       }
/* 49 */       obj.put("jobs", array);
/*    */     }
/*    */     
/* 52 */     CommonProxy.packetPipeline.sendTo(new PacketSendData("localJobs", "" + obj.toJSONString()), player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerJobUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */