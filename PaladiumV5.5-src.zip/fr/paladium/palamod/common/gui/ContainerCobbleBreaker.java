/*     */ package fr.paladium.palamod.common.gui;
/*     */ 
/*     */ import fr.paladium.palamod.job.logic.TileCobbleBreaker;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ public class ContainerCobbleBreaker extends Container
/*     */ {
/*     */   private TileCobbleBreaker tileCobbleBreaker;
/*     */   
/*     */   public ContainerCobbleBreaker(TileCobbleBreaker tile, InventoryPlayer inventory, EntityPlayer player)
/*     */   {
/*  20 */     this.tileCobbleBreaker = tile;
/*     */     
/*  22 */     this.tileCobbleBreaker.openInventory();
/*     */     
/*  24 */     addSlotToContainer(new Slot(tile, 0, 91, 10)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  27 */         if (stack.getItem().equals(Item.getItemFromBlock(net.minecraft.init.Blocks.cobblestone))) {
/*  28 */           return true;
/*     */         }
/*  30 */         return false;
/*     */       }
/*  32 */     });
/*  33 */     addSlotToContainer(new Slot(tile, 1, 39, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  36 */         return false;
/*     */       }
/*  38 */     });
/*  39 */     addSlotToContainer(new Slot(tile, 2, 60, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  42 */         return false;
/*     */       }
/*  44 */     });
/*  45 */     addSlotToContainer(new Slot(tile, 3, 79, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  48 */         return false;
/*     */       }
/*  50 */     });
/*  51 */     addSlotToContainer(new Slot(tile, 4, 99, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  54 */         return false;
/*     */       }
/*  56 */     });
/*  57 */     addSlotToContainer(new Slot(tile, 5, 119, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  60 */         return false;
/*     */       }
/*  62 */     });
/*  63 */     addSlotToContainer(new Slot(tile, 6, 139, 52)
/*     */     {
/*     */       public boolean isItemValid(@Nullable ItemStack stack) {
/*  66 */         return false;
/*     */       }
/*     */       
/*  69 */     });
/*  70 */     bingPInventory(inventory);
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer playerIn)
/*     */   {
/*  75 */     return this.tileCobbleBreaker.isUseableByPlayer(playerIn);
/*     */   }
/*     */   
/*     */   private void bingPInventory(InventoryPlayer inventoryPlayer) {
/*  79 */     int l1 = 7;
/*  80 */     for (int l = 9; l <= 17; l++) {
/*  81 */       addSlotToContainer(new Slot(inventoryPlayer, l, l1, 83));
/*  82 */       l1 += 20;
/*     */     }
/*     */     
/*  85 */     int a1 = 7;
/*  86 */     for (int a = 18; a <= 26; a++) {
/*  87 */       addSlotToContainer(new Slot(inventoryPlayer, a, a1, 105));
/*  88 */       a1 += 20;
/*     */     }
/*     */     
/*  91 */     int b1 = 7;
/*  92 */     for (int b = 27; b <= 35; b++) {
/*  93 */       addSlotToContainer(new Slot(inventoryPlayer, b, b1, 127));
/*  94 */       b1 += 20;
/*     */     }
/*     */     
/*  97 */     int c1 = 7;
/*  98 */     for (int c = 0; c <= 8; c++) {
/*  99 */       addSlotToContainer(new Slot(inventoryPlayer, c, c1, 150));
/* 100 */       c1 += 20;
/*     */     }
/*     */   }
/*     */   
/*     */   public void onContainerClosed(EntityPlayer playerIn)
/*     */   {
/* 106 */     super.onContainerClosed(playerIn);
/* 107 */     this.tileCobbleBreaker.closeInventory();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ItemStack transferStackInSlot(EntityPlayer playerIn, int index)
/*     */   {
/* 113 */     ItemStack itemstack = null;
/* 114 */     Slot slot = (Slot)this.inventorySlots.get(index);
/* 115 */     return itemstack;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerCobbleBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */