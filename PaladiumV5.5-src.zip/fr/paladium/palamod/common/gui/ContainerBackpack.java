/*     */ package fr.paladium.palamod.common.gui;
/*     */ 
/*     */ import fr.paladium.palamod.common.inventory.InventoryBackpack;
/*     */ import fr.paladium.palamod.items.ItemBackpack;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.util.PlayerHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ public class ContainerBackpack extends Container
/*     */ {
/*     */   int rows;
/*     */   InventoryBackpack inventoryBackpack;
/*     */   
/*     */   public ContainerBackpack(InventoryPlayer inventory, InventoryBackpack inventoryBackpack)
/*     */   {
/*  22 */     this.inventoryBackpack = inventoryBackpack;
/*  23 */     this.rows = (inventoryBackpack.getSizeInventory() / 9);
/*     */     
/*     */ 
/*  26 */     System.out.println(this.rows);
/*  27 */     for (int j = 0; j < this.rows; j++) {
/*  28 */       for (int k = 0; k < 9; k++) {
/*  29 */         addSlotToContainer(new fr.paladium.palamod.common.slot.SlotBackpack(inventoryBackpack, k + j * 9, 8 + k * 18, 18 + j * 18));
/*     */       }
/*     */     }
/*  32 */     bindPlayerInventory(inventory);
/*     */   }
/*     */   
/*     */   private void bindPlayerInventory(InventoryPlayer inventory)
/*     */   {
/*  37 */     for (int i = 0; i < 3; i++) {
/*  38 */       for (int j = 0; j < 9; j++) {
/*  39 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 140 + i * 18));
/*     */       }
/*     */     }
/*     */     
/*  43 */     for (i = 0; i < 9; i++) {
/*  44 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 198));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound stack) {
/*  49 */     if (stack == null)
/*  50 */       return;
/*  51 */     this.inventoryBackpack.writeToNBT(stack);
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer player)
/*     */   {
/*  56 */     writeToNBT(player.getEntityData());
/*  57 */     if (!PlayerHelper.hasItem(ModItems.backpack, player))
/*  58 */       player.addChatMessage(new net.minecraft.util.ChatComponentText("Vous n'avez pas de Backpack"));
/*  59 */     return PlayerHelper.hasItem(ModItems.backpack, player);
/*     */   }
/*     */   
/*     */   public void onContainerClosed(EntityPlayer player)
/*     */   {
/*  64 */     writeToNBT(player.getEntityData());
/*  65 */     player.getEntityData().setBoolean("Open", false);
/*  66 */     super.onContainerClosed(player);
/*     */   }
/*     */   
/*     */   protected boolean mergeItemStack(ItemStack stack, int p_75135_2_, int p_75135_3_, boolean p_75135_4_)
/*     */   {
/*  71 */     return super.mergeItemStack(stack, p_75135_2_, p_75135_3_, p_75135_4_);
/*     */   }
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer player, int index)
/*     */   {
/*  76 */     ItemStack itemstack = null;
/*  77 */     Slot slot = (Slot)this.inventorySlots.get(index);
/*     */     
/*  79 */     if ((slot != null) && (slot.getHasStack())) {
/*  80 */       ItemStack itemstack1 = slot.getStack();
/*  81 */       itemstack = itemstack1.copy();
/*     */       
/*  83 */       if ((itemstack.getItem() instanceof ItemBackpack)) {
/*  84 */         writeToNBT(player.getEntityData());
/*  85 */         return null;
/*     */       }
/*     */       
/*  88 */       if (index < this.inventoryBackpack.getSizeInventory()) {
/*  89 */         if (!mergeItemStack(itemstack1, this.inventoryBackpack.getSizeInventory(), this.inventorySlots
/*  90 */           .size(), true)) {
/*  91 */           return null;
/*     */         }
/*  93 */       } else if (!mergeItemStack(itemstack1, 0, this.inventoryBackpack.getSizeInventory(), false)) {
/*  94 */         return null;
/*     */       }
/*     */       
/*  97 */       if (itemstack1.stackSize == 0) {
/*  98 */         slot.putStack((ItemStack)null);
/*     */       } else
/* 100 */         slot.onSlotChanged();
/*     */     }
/* 102 */     writeToNBT(player.getEntityData());
/* 103 */     return itemstack;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*     */   {
/* 109 */     writeToNBT(player.getEntityData());
/* 110 */     if ((flag == 2) && (buttonPressed == player.inventory.currentItem))
/* 111 */       return null;
/* 112 */     if (slotIndex - this.inventoryBackpack.getSizeInventory() - 27 == player.inventory.currentItem)
/* 113 */       return null;
/* 114 */     return super.slotClick(slotIndex, buttonPressed, flag, player);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerBackpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */