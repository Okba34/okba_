/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.slot.SlotRing;
/*    */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerPaladiumChest extends net.minecraft.inventory.Container
/*    */ {
/*    */   private PaladiumChestLogic tile;
/*    */   private net.minecraft.entity.player.InventoryPlayer inventory;
/*    */   
/*    */   public ContainerPaladiumChest(PaladiumChestLogic tile, net.minecraft.entity.player.InventoryPlayer inventory)
/*    */   {
/* 16 */     this.inventory = inventory;
/* 17 */     this.tile = tile;
/* 18 */     tile.openInventory();
/* 19 */     int i = 0;
/*    */     
/* 21 */     for (i = 0; i < 9; i++) {
/* 22 */       for (int j = 0; j < 12; j++) {
/* 23 */         addSlotToContainer(new Slot(tile, j + i * 12, 12 + j * 18, 8 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 27 */     addSlotToContainer(new SlotRing(tile, 108, 228, 8));
/* 28 */     addSlotToContainer(new SlotRing(tile, 109, 228, 26));
/* 29 */     addSlotToContainer(new SlotRing(tile, 110, 228, 44));
/* 30 */     addSlotToContainer(new SlotRing(tile, 111, 228, 62));
/*    */     
/* 32 */     bindPlayerInventory();
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory()
/*    */   {
/* 37 */     for (int i = 0; i < 3; i++) {
/* 38 */       for (int j = 0; j < 9; j++) {
/* 39 */         addSlotToContainer(new Slot(this.inventory, j + i * 9 + 9, 39 + j * 18, 174 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 43 */     for (i = 0; i < 9; i++) {
/* 44 */       addSlotToContainer(new Slot(this.inventory, i, 39 + i * 18, 232));
/*    */     }
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int slot) {
/* 49 */     ItemStack stack = null;
/* 50 */     Slot slots = (Slot)this.inventorySlots.get(slot);
/*    */     
/* 52 */     if ((slots != null) && (slots.getHasStack())) {
/* 53 */       ItemStack stack1 = slots.getStack();
/* 54 */       stack = stack1.copy();
/*    */       
/* 56 */       if (slot < 112) {
/* 57 */         if (!mergeItemStack(stack1, 112, 148, true)) {
/* 58 */           return null;
/*    */         }
/* 60 */         slots.onSlotChange(stack1, stack);
/*    */       }
/*    */       
/* 63 */       if (slot >= 112) {
/* 64 */         if (!mergeItemStack(stack1, 0, 108, false)) {
/* 65 */           return null;
/*    */         }
/* 67 */         slots.onSlotChange(stack1, stack);
/*    */       }
/*    */       
/* 70 */       if (stack1.stackSize == 0) {
/* 71 */         slots.putStack((ItemStack)null);
/*    */       } else {
/* 73 */         slots.onSlotChanged();
/*    */       }
/*    */       
/* 76 */       if (stack1.stackSize == stack.stackSize) {
/* 77 */         return null;
/*    */       }
/*    */       
/* 80 */       slots.onPickupFromSlot(player, stack1);
/*    */     }
/* 82 */     return stack;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player) {
/* 86 */     super.onContainerClosed(player);
/* 87 */     this.tile.closeInventory();
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 92 */     return this.tile.isUseableByPlayer(player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerPaladiumChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */