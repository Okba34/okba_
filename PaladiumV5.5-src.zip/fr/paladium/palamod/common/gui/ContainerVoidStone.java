/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryDummy;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerVoidStone extends Container
/*    */ {
/*    */   public ContainerVoidStone(InventoryPlayer inventory)
/*    */   {
/* 14 */     addSlotToContainer(new Slot(new InventoryDummy(), 0, 80, 18));
/* 15 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 20 */     for (int i = 0; i < 3; i++) {
/* 21 */       for (int j = 0; j < 9; j++) {
/* 22 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 40 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 26 */     for (i = 0; i < 9; i++) {
/* 27 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 98));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int slot)
/*    */   {
/* 38 */     ItemStack stack = null;
/* 39 */     Slot slots = (Slot)this.inventorySlots.get(slot);
/*    */     
/* 41 */     if ((slots != null) && (slots.getHasStack())) {
/* 42 */       ItemStack stack1 = slots.getStack();
/* 43 */       stack = stack1.copy();
/* 44 */       System.out.println(slot);
/* 45 */       if ((slot >= 1) && (!(stack.getItem() instanceof fr.paladium.palamod.items.ItemVoidStone)) && 
/* 46 */         (!mergeItemStack(stack1, 0, 1, true))) {
/* 47 */         return null;
/*    */       }
/*    */       
/*    */ 
/* 51 */       if (stack1.stackSize == 0) {
/* 52 */         slots.putStack((ItemStack)null);
/*    */       } else {
/* 54 */         slots.onSlotChanged();
/*    */       }
/*    */       
/* 57 */       if (stack1.stackSize == stack.stackSize) {
/* 58 */         return null;
/*    */       }
/*    */       
/* 61 */       slots.onPickupFromSlot(player, stack1);
/*    */     }
/* 63 */     return stack;
/*    */   }
/*    */   
/*    */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*    */   {
/* 68 */     if ((flag == 2) && (buttonPressed == player.inventory.currentItem))
/* 69 */       return null;
/* 70 */     if (slotIndex - 1 - 27 == player.inventory.currentItem)
/* 71 */       return null;
/* 72 */     return super.slotClick(slotIndex, buttonPressed, flag, player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerVoidStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */