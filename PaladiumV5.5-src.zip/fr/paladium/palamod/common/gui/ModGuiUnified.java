/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.client.gui.unified.UnifiedItem;
/*    */ import fr.paladium.palamod.libs.LibRessources;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.resources.I18n;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModGuiUnified
/*    */ {
/*    */   static UnifiedItem unifiedInventory;
/*    */   static UnifiedItem unifiedFaction;
/*    */   static UnifiedItem unifiedCapacity;
/*    */   static UnifiedItem unifiedSpells;
/*    */   static UnifiedItem unifiedJobs;
/*    */   static UnifiedItem unifiedCosmetics;
/* 20 */   static ArrayList<UnifiedItem> unifiedItems = new ArrayList();
/*    */   
/*    */   public static void init()
/*    */   {
/* 24 */     unifiedInventory = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.inventory", new Object[0]), 40, LibRessources.INVENTORY_UNIFIED_ICON);
/*    */     
/* 26 */     unifiedCapacity = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.level", new Object[0]), 42, LibRessources.LEVEL_UNIFIED_ICON);
/*    */     
/* 28 */     unifiedSpells = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.spells", new Object[0]), 43, LibRessources.SPELL_UNIFIED_ICON);
/*    */     
/* 30 */     unifiedFaction = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.faction", new Object[0]), 41, LibRessources.FACTION_UNIFIED_ICON);
/*    */     
/* 32 */     unifiedJobs = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.jobs", new Object[0]), 44, LibRessources.JOB_UNIFIED_ICON);
/*    */     
/* 34 */     unifiedCosmetics = new UnifiedItem(new ResourceLocation(LibRessources.GUI_ELEMENTS), 0, 0, I18n.format("gui.cosmetic", new Object[0]), 45, LibRessources.COSMETIC_UNIFIED_ICON);
/*    */     
/* 36 */     addUnifiedGui(unifiedInventory);
/* 37 */     addUnifiedGui(unifiedCapacity);
/* 38 */     addUnifiedGui(unifiedSpells);
/* 39 */     addUnifiedGui(unifiedFaction);
/* 40 */     addUnifiedGui(unifiedJobs);
/* 41 */     addUnifiedGui(unifiedCosmetics);
/*    */   }
/*    */   
/*    */   public static void addUnifiedGui(UnifiedItem item) {
/* 45 */     unifiedItems.add(item);
/*    */   }
/*    */   
/*    */   public static ArrayList<UnifiedItem> getAllItems() {
/* 49 */     return unifiedItems;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ModGuiUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */