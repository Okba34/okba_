/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryGuardianMore;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemBackpack;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerGuardianUpgrade extends Container
/*    */ {
/*    */   private EntityGuardianGolem golem;
/*    */   private InventoryGuardianMore inventoryGuardian;
/*    */   
/*    */   public ContainerGuardianUpgrade(EntityGuardianGolem entity, InventoryPlayer inventory)
/*    */   {
/* 20 */     this.golem = entity;
/* 21 */     this.inventoryGuardian = new InventoryGuardianMore(this.golem);
/*    */     
/* 23 */     bindPlayerInventory(inventory);
/* 24 */     for (int j = 0; j < 9; j++) {
/* 25 */       addSlotToContainer(new fr.paladium.palamod.common.slot.SlotGuardianUpgrade(this.inventoryGuardian, j, 39 + j * 18, 50, this.golem));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 32 */     for (int i = 0; i < 3; i++) {
/* 33 */       for (int j = 0; j < 9; j++) {
/* 34 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, j * 18 + 39, 71 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 38 */     for (i = 0; i < 9; i++) {
/* 39 */       addSlotToContainer(new Slot(inventory, i, i * 18 + 39, 129));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 45 */     super.onContainerClosed(player);
/* 46 */     this.inventoryGuardian.writeToNBT(this.golem.getEntityData());
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 51 */     return this.golem.isUseableByPlayer(player);
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int index)
/*    */   {
/* 56 */     ItemStack itemstack = null;
/* 57 */     Slot slot = (Slot)this.inventorySlots.get(index);
/*    */     
/* 59 */     if ((slot != null) && (slot.getHasStack())) {
/* 60 */       ItemStack itemstack1 = slot.getStack();
/* 61 */       itemstack = itemstack1.copy();
/*    */       
/* 63 */       if ((itemstack.getItem() instanceof ItemBackpack)) {
/* 64 */         this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 65 */         return null;
/*    */       }
/*    */       
/* 68 */       if (index < this.inventoryGuardian.getSizeInventory()) {
/* 69 */         if (!mergeItemStack(itemstack1, this.inventoryGuardian.getSizeInventory(), this.inventorySlots
/* 70 */           .size(), true)) {
/* 71 */           return null;
/*    */         }
/* 73 */       } else if (!mergeItemStack(itemstack1, 0, this.inventoryGuardian.getSizeInventory(), false)) {
/* 74 */         return null;
/*    */       }
/*    */       
/* 77 */       if (itemstack1.stackSize == 0) {
/* 78 */         slot.putStack((ItemStack)null);
/*    */       } else
/* 80 */         slot.onSlotChanged();
/*    */     }
/* 82 */     this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 83 */     return itemstack;
/*    */   }
/*    */   
/*    */ 
/*    */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*    */   {
/* 89 */     this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 90 */     if (slotIndex - this.inventoryGuardian.getSizeInventory() - 27 == player.inventory.currentItem)
/* 91 */       return null;
/* 92 */     return super.slotClick(slotIndex, buttonPressed, flag, player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerGuardianUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */