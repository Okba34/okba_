/*     */ package fr.paladium.palamod.common.gui;
/*     */ 
/*     */ import fr.paladium.palamod.common.slot.SlotFuel;
/*     */ import fr.paladium.palamod.common.slot.SlotItemList;
/*     */ import fr.paladium.palamod.common.slot.SlotResult;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.Container;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.tileentity.TileEntityFurnace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerObsidianUpgrader
/*     */   extends Container
/*     */ {
/*     */   private TileEntityObsidianUpgrader tileMachine;
/*     */   
/*     */   public ContainerObsidianUpgrader(TileEntityObsidianUpgrader tile, InventoryPlayer inventory)
/*     */   {
/*  31 */     this.tileMachine = tile;
/*  32 */     List<Item> items0 = new ArrayList();
/*  33 */     items0.add(Item.getItemFromBlock(Blocks.obsidian));
/*  34 */     items0.add(Item.getItemFromBlock(PaladiumRegister.UPGRADED_OBSIDIAN));
/*  35 */     List<Item> items1 = new ArrayList();
/*  36 */     items1.add(ModItems.explode_obsidian_upgrade);
/*  37 */     items1.add(ModItems.fake_obsidian_upgrade);
/*  38 */     items1.add(ModItems.twoLife_obsidian_upgrade);
/*  39 */     items1.add(ModItems.camouflage_obsidian_upgrade);
/*     */     
/*  41 */     addSlotToContainer(new SlotItemList(tile, 0, 60, 14, items0));
/*  42 */     addSlotToContainer(new SlotItemList(tile, 1, 11, 54, items1));
/*  43 */     addSlotToContainer(new Slot(tile, 2, 129, 45));
/*  44 */     addSlotToContainer(new Slot(tile, 3, 129, 63));
/*  45 */     addSlotToContainer(new SlotResult(tile, 4, 183, 54));
/*  46 */     addSlotToContainer(new SlotFuel(tile, 5, 108, 14));
/*  47 */     bindPlayerInventory(inventory);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canInteractWith(EntityPlayer player)
/*     */   {
/*  53 */     return this.tileMachine.isUseableByPlayer(player);
/*     */   }
/*     */   
/*     */ 
/*     */   private void bindPlayerInventory(InventoryPlayer inventory)
/*     */   {
/*  59 */     for (int i = 0; i < 3; i++)
/*     */     {
/*  61 */       for (int j = 0; j < 9; j++)
/*     */       {
/*  63 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 23 + j * 18, 103 + i * 18));
/*     */       }
/*     */     }
/*     */     
/*  67 */     for (i = 0; i < 9; i++)
/*     */     {
/*  69 */       addSlotToContainer(new Slot(inventory, i, 23 + i * 18, 161));
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemStack transferStackInSlot(EntityPlayer player, int slotIndex)
/*     */   {
/*  75 */     ItemStack itemstack = null;
/*  76 */     Slot slot = (Slot)this.inventorySlots.get(slotIndex);
/*     */     
/*  78 */     if ((slot != null) && (slot.getHasStack()))
/*     */     {
/*  80 */       ItemStack itemstack1 = slot.getStack();
/*  81 */       itemstack = itemstack1.copy();
/*     */       
/*  83 */       if (slotIndex < this.tileMachine.getSizeInventory())
/*     */       {
/*  85 */         if (!mergeItemStack(itemstack1, this.tileMachine.getSizeInventory(), this.inventorySlots.size(), true)) {
/*  86 */           return null;
/*     */         }
/*  88 */       } else if (!mergeItemStack(itemstack1, 0, this.tileMachine.getSizeInventory(), false))
/*     */       {
/*  90 */         if ((FurnaceRecipes.smelting().getSmeltingResult(itemstack1) != null) && 
/*  91 */           (!mergeItemStack(itemstack1, 1, 2, true))) {
/*  92 */           return null;
/*     */         }
/*  94 */         if ((TileEntityFurnace.isItemFuel(itemstack1)) && 
/*  95 */           (!mergeItemStack(itemstack1, 2, 3, true))) {
/*  96 */           return null;
/*     */         }
/*  98 */         if ((itemstack.getItem().equals(PaladiumRegister.FURNACE_UPGRADE)) && 
/*  99 */           (!mergeItemStack(itemstack1, 0, 1, true))) {
/* 100 */           return null;
/*     */         }
/*     */       }
/* 103 */       if (itemstack1.stackSize == 0) {
/* 104 */         slot.putStack((ItemStack)null);
/*     */       } else {
/* 106 */         slot.onSlotChanged();
/*     */       }
/*     */     }
/* 109 */     return itemstack;
/*     */   }
/*     */   
/*     */   public void onContainerClosed(EntityPlayer player)
/*     */   {
/* 114 */     super.onContainerClosed(player);
/* 115 */     this.tileMachine.closeInventory();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerObsidianUpgrader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */