/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.slot.SlotChestExplorer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ 
/*    */ public class ContainerChestExplorer extends Container
/*    */ {
/*    */   IInventory inventory;
/*    */   
/*    */   public ContainerChestExplorer(TileEntity tile)
/*    */   {
/* 16 */     this.inventory = ((IInventory)tile);
/*    */     
/* 18 */     int i = 0;
/* 19 */     int j = 0;
/*    */     
/* 21 */     for (i = 0; i < 108; i++) {
/* 22 */       if (i % 12 == 0)
/* 23 */         j++;
/* 24 */       int u = i % 12 + 1;
/* 25 */       if (i < this.inventory.getSizeInventory()) {
/* 26 */         addSlotToContainer(new SlotChestExplorer(this.inventory, i, u * 18 - 6, j * 18 - 10));
/*    */       } else {
/* 28 */         addSlotToContainer(new SlotChestExplorer(new fr.paladium.palamod.common.inventory.InventoryDummy(), 0, u * 18 - 6, j * 18 - 10));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player) {
/* 34 */     return this.inventory.isUseableByPlayer(player);
/*    */   }
/*    */   
/*    */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*    */   {
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int quantity)
/*    */   {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerChestExplorer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */