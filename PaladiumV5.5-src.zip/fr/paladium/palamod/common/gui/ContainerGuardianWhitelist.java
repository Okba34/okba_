/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerGuardianWhitelist
/*    */   extends Container
/*    */ {
/*    */   public ContainerGuardianWhitelist(InventoryPlayer inventory)
/*    */   {
/* 14 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 19 */     for (int i = 0; i < 3; i++) {
/* 20 */       for (int j = 0; j < 9; j++) {
/* 21 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 65 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 25 */     for (i = 0; i < 9; i++) {
/* 26 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 123));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 32 */     return true;
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int quantity) {
/* 36 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerGuardianWhitelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */