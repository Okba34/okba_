/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryGuardianChest;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemBackpack;
/*    */ import java.util.List;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerGuardianChest extends Container
/*    */ {
/*    */   private EntityGuardianGolem golem;
/*    */   private InventoryGuardianChest inventoryGuardian;
/*    */   
/*    */   public ContainerGuardianChest(EntityGuardianGolem entity, InventoryPlayer inventory)
/*    */   {
/* 20 */     this.golem = entity;
/* 21 */     this.inventoryGuardian = new InventoryGuardianChest(this.golem);
/*    */     
/* 23 */     bindPlayerInventory(inventory);
/* 24 */     for (int i = 0; i < 3; i++) {
/* 25 */       for (int j = 0; j < 9; j++) {
/* 26 */         if (i * 9 + j > this.golem.getMaxChestSlots())
/* 27 */           return;
/* 28 */         addSlotToContainer(new fr.paladium.palamod.common.slot.SlotGuardianChest(this.inventoryGuardian, i * 9 + j, 39 + j * 18, 39 + i * 18, this.golem));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 35 */     for (int i = 0; i < 3; i++) {
/* 36 */       for (int j = 0; j < 9; j++) {
/* 37 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, j * 18 + 39, 99 + i * 18));
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 42 */     for (i = 0; i < 9; i++) {
/* 43 */       addSlotToContainer(new Slot(inventory, i, i * 18 + 39, 157));
/*    */     }
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 49 */     super.onContainerClosed(player);
/* 50 */     this.inventoryGuardian.writeToNBT(this.golem.getEntityData());
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 55 */     return this.golem.isUseableByPlayer(player);
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int index)
/*    */   {
/* 60 */     ItemStack itemstack = null;
/* 61 */     Slot slot = (Slot)this.inventorySlots.get(index);
/*    */     
/* 63 */     if ((slot != null) && (slot.getHasStack())) {
/* 64 */       ItemStack itemstack1 = slot.getStack();
/* 65 */       itemstack = itemstack1.copy();
/*    */       
/* 67 */       if ((itemstack.getItem() instanceof ItemBackpack)) {
/* 68 */         this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 69 */         return null;
/*    */       }
/*    */       
/* 72 */       if (index < this.inventoryGuardian.getSizeInventory()) {
/* 73 */         if (!mergeItemStack(itemstack1, this.inventoryGuardian.getSizeInventory(), this.inventorySlots
/* 74 */           .size(), true)) {
/* 75 */           return null;
/*    */         }
/* 77 */       } else if (!mergeItemStack(itemstack1, 0, this.inventoryGuardian.getSizeInventory(), false)) {
/* 78 */         return null;
/*    */       }
/*    */       
/* 81 */       if (itemstack1.stackSize == 0) {
/* 82 */         slot.putStack((ItemStack)null);
/*    */       } else
/* 84 */         slot.onSlotChanged();
/*    */     }
/* 86 */     this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 87 */     return itemstack;
/*    */   }
/*    */   
/*    */ 
/*    */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*    */   {
/* 93 */     this.inventoryGuardian.writeToNBT(player.getEntityData());
/* 94 */     if (slotIndex - this.inventoryGuardian.getSizeInventory() - 27 == player.inventory.currentItem)
/* 95 */       return null;
/* 96 */     return super.slotClick(slotIndex, buttonPressed, flag, player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerGuardianChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */