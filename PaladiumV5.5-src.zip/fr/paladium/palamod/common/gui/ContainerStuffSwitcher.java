/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryStuffSwitcher;
/*    */ import fr.paladium.palamod.common.slot.SlotStuffSwitcher;
/*    */ import fr.paladium.palamod.items.ItemStuffSwitcher;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerStuffSwitcher
/*    */   extends Container
/*    */ {
/*    */   int rows;
/*    */   InventoryStuffSwitcher inventoryStuff;
/*    */   
/*    */   public ContainerStuffSwitcher(InventoryPlayer inventory, InventoryStuffSwitcher inventoryStuff)
/*    */   {
/* 23 */     this.inventoryStuff = inventoryStuff;
/* 24 */     addSlotToContainer(new SlotStuffSwitcher(inventoryStuff, 0, 44, 11, 0));
/* 25 */     addSlotToContainer(new SlotStuffSwitcher(inventoryStuff, 1, 67, 11, 1));
/* 26 */     addSlotToContainer(new SlotStuffSwitcher(inventoryStuff, 2, 91, 11, 2));
/* 27 */     addSlotToContainer(new SlotStuffSwitcher(inventoryStuff, 3, 116, 11, 3));
/* 28 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 33 */     for (int i = 0; i < 3; i++) {
/* 34 */       for (int j = 0; j < 9; j++) {
/* 35 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 35 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 39 */     for (i = 0; i < 9; i++) {
/* 40 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 93));
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeToNBT(ItemStack stack) {
/* 45 */     if (stack == null)
/* 46 */       return;
/* 47 */     if (stack.getItem() == null)
/* 48 */       return;
/* 49 */     if (!(stack.getItem() instanceof ItemStuffSwitcher))
/* 50 */       return;
/* 51 */     if (!stack.hasTagCompound())
/* 52 */       stack.setTagCompound(new NBTTagCompound());
/* 53 */     if ((!stack.getTagCompound().hasKey("Open")) || (!stack.getTagCompound().getBoolean("Open")))
/* 54 */       return;
/* 55 */     this.inventoryStuff.writeToNBT(stack.getTagCompound());
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 60 */     writeToNBT(player.getHeldItem());
/* 61 */     boolean open = false;
/* 62 */     if ((player.getHeldItem() == null) || (
/* 63 */       (!(player.getHeldItem().getItem() instanceof ItemStuffSwitcher)) && (player.getHeldItem().stackSize <= 1)))
/* 64 */       player.closeScreen();
/* 65 */     if ((player.getHeldItem().hasTagCompound()) && (player.getHeldItem().getTagCompound().hasKey("Open"))) {
/* 66 */       open = player.getHeldItem().getTagCompound().getBoolean("Open");
/*    */     }
/* 68 */     if (!open)
/* 69 */       player.closeScreen();
/* 70 */     return open;
/*    */   }
/*    */   
/*    */   public void onContainerClosed(EntityPlayer player)
/*    */   {
/* 75 */     writeToNBT(player.getHeldItem());
/* 76 */     super.onContainerClosed(player);
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int index)
/*    */   {
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   protected boolean mergeItemStack(ItemStack stack, int p_75135_2_, int p_75135_3_, boolean p_75135_4_)
/*    */   {
/* 86 */     return super.mergeItemStack(stack, p_75135_2_, p_75135_3_, p_75135_4_);
/*    */   }
/*    */   
/*    */   public ItemStack slotClick(int slotIndex, int buttonPressed, int flag, EntityPlayer player)
/*    */   {
/* 91 */     if ((flag == 2) && (buttonPressed == player.inventory.currentItem))
/* 92 */       return null;
/* 93 */     if (slotIndex - this.inventoryStuff.getSizeInventory() - 27 == player.inventory.currentItem)
/* 94 */       return null;
/* 95 */     writeToNBT(player.getHeldItem());
/* 96 */     return super.slotClick(slotIndex, buttonPressed, flag, player);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerStuffSwitcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */