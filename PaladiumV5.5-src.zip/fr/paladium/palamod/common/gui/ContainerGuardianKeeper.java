/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.GuardianKeeperHandler;
/*    */ import fr.paladium.palamod.common.slot.SlotKeeper;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ContainerGuardianKeeper extends Container
/*    */ {
/*    */   public ContainerGuardianKeeper(EntityPlayer player)
/*    */   {
/* 15 */     GuardianKeeperHandler handler = GuardianKeeperHandler.get(player.worldObj);
/* 16 */     fr.paladium.palamod.common.inventory.InventoryGuardianKeeper inventory = handler.getStoneFromUUID(player.getUniqueID().toString());
/* 17 */     addSlotToContainer(new SlotKeeper(inventory, 0, 80, 18));
/* 18 */     bindPlayerInventory(player.inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 23 */     for (int i = 0; i < 3; i++) {
/* 24 */       for (int j = 0; j < 9; j++) {
/* 25 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 40 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 29 */     for (i = 0; i < 9; i++) {
/* 30 */       addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 98));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 36 */     return true;
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int slot) {
/* 40 */     ItemStack stack = null;
/* 41 */     Slot slots = (Slot)this.inventorySlots.get(slot);
/*    */     
/* 43 */     if ((slots != null) && (slots.getHasStack())) {
/* 44 */       ItemStack stack1 = slots.getStack();
/* 45 */       stack = stack1.copy();
/*    */       
/* 47 */       if ((slot < 1) && 
/* 48 */         (!mergeItemStack(stack1, 0, 37, true))) {
/* 49 */         return null;
/*    */       }
/*    */       
/*    */ 
/* 53 */       if (stack1.stackSize == 0) {
/* 54 */         slots.putStack((ItemStack)null);
/*    */       } else {
/* 56 */         slots.onSlotChanged();
/*    */       }
/*    */       
/* 59 */       if (stack1.stackSize == stack.stackSize) {
/* 60 */         return null;
/*    */       }
/*    */       
/* 63 */       slots.onPickupFromSlot(player, stack1);
/*    */     }
/* 65 */     return stack;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerGuardianKeeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */