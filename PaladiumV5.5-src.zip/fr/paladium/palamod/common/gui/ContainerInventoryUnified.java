/*     */ package fr.paladium.palamod.common.gui;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemArmor;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.CraftingManager;
/*     */ import net.minecraft.util.IIcon;
/*     */ 
/*     */ public class ContainerInventoryUnified extends ContainerUnified
/*     */ {
/*  16 */   public InventoryCrafting craftMatrix = new InventoryCrafting(this, 2, 2);
/*  17 */   public IInventory craftResult = new net.minecraft.inventory.InventoryCraftResult();
/*     */   
/*     */   public boolean isLocalWorld;
/*     */   private final EntityPlayer thePlayer;
/*     */   private static final String __OBFID = "CL_00001754";
/*     */   
/*     */   public ContainerInventoryUnified(int id, InventoryPlayer p_i1819_1_, boolean p_i1819_2_, EntityPlayer p_i1819_3_, int offsetX, int offsetY)
/*     */   {
/*  25 */     super(id, p_i1819_1_, offsetY, offsetY);
/*  26 */     this.isLocalWorld = p_i1819_2_;
/*  27 */     this.thePlayer = p_i1819_3_;
/*  28 */     addSlotToContainer(new net.minecraft.inventory.SlotCrafting(p_i1819_1_.player, this.craftMatrix, this.craftResult, 0, 154, 28 - offsetY));
/*     */     
/*     */ 
/*     */ 
/*  32 */     for (int i = 0; i < 2; i++)
/*     */     {
/*  34 */       for (int j = 0; j < 2; j++)
/*     */       {
/*  36 */         addSlotToContainer(new Slot(this.craftMatrix, j + i * 2, 98 + j * 18, 18 + i * 18 - offsetY));
/*     */       }
/*     */     }
/*     */     
/*  40 */     for (i = 0; i < 4; i++)
/*     */     {
/*  42 */       final int k = i;
/*  43 */       addSlotToContainer(new Slot(p_i1819_1_, 36 + (3 - k), 8, 8 + k * 18 - offsetY)
/*     */       {
/*     */         private static final String __OBFID = "CL_00001755";
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         public int getSlotStackLimit()
/*     */         {
/*  52 */           return 1;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         public boolean isItemValid(ItemStack p_75214_1_)
/*     */         {
/*  59 */           if (p_75214_1_ == null) return false;
/*  60 */           return p_75214_1_.getItem().isValidArmor(p_75214_1_, k, ContainerInventoryUnified.this.thePlayer);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */         @cpw.mods.fml.relauncher.SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */         public IIcon getBackgroundIconIndex()
/*     */         {
/*  68 */           return ItemArmor.func_94602_b(k);
/*     */         }
/*     */       });
/*     */     }
/*     */     
/*  73 */     for (int l = 0; l < 3; l++) {
/*  74 */       for (int j1 = 0; j1 < 9; j1++) {
/*  75 */         addSlotToContainer(new Slot(p_i1819_1_, j1 + (l + 1) * 9, 8 + j1 * 18, 84 + l * 18 - offsetY));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  80 */     for (int i1 = 0; i1 < 9; i1++) {
/*  81 */       addSlotToContainer(new Slot(p_i1819_1_, i1, 8 + i1 * 18, 142 - offsetY));
/*     */     }
/*     */     
/*  84 */     onCraftMatrixChanged(this.craftMatrix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onCraftMatrixChanged(IInventory p_75130_1_)
/*     */   {
/*  92 */     this.craftResult.setInventorySlotContents(0, CraftingManager.getInstance().findMatchingRecipe(this.craftMatrix, this.thePlayer.worldObj));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onContainerClosed(EntityPlayer p_75134_1_)
/*     */   {
/* 100 */     super.onContainerClosed(p_75134_1_);
/*     */     
/* 102 */     for (int i = 0; i < 4; i++)
/*     */     {
/* 104 */       ItemStack itemstack = this.craftMatrix.getStackInSlotOnClosing(i);
/*     */       
/* 106 */       if (itemstack != null)
/*     */       {
/* 108 */         p_75134_1_.dropPlayerItemWithRandomChoice(itemstack, false);
/*     */       }
/*     */     }
/*     */     
/* 112 */     this.craftResult.setInventorySlotContents(0, (ItemStack)null);
/*     */   }
/*     */   
/*     */   public boolean canInteractWith(EntityPlayer p_75145_1_)
/*     */   {
/* 117 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemStack transferStackInSlot(EntityPlayer p_82846_1_, int p_82846_2_)
/*     */   {
/* 125 */     ItemStack itemstack = null;
/* 126 */     Slot slot = (Slot)this.inventorySlots.get(p_82846_2_);
/*     */     
/* 128 */     if ((slot != null) && (slot.getHasStack()))
/*     */     {
/* 130 */       ItemStack itemstack1 = slot.getStack();
/* 131 */       itemstack = itemstack1.copy();
/*     */       
/* 133 */       if (p_82846_2_ == 0)
/*     */       {
/* 135 */         if (!mergeItemStack(itemstack1, 9, 45, true))
/*     */         {
/* 137 */           return null;
/*     */         }
/*     */         
/* 140 */         slot.onSlotChange(itemstack1, itemstack);
/*     */       }
/* 142 */       else if ((p_82846_2_ >= 1) && (p_82846_2_ < 5))
/*     */       {
/* 144 */         if (!mergeItemStack(itemstack1, 9, 45, false))
/*     */         {
/* 146 */           return null;
/*     */         }
/*     */       }
/* 149 */       else if ((p_82846_2_ >= 5) && (p_82846_2_ < 9))
/*     */       {
/* 151 */         if (!mergeItemStack(itemstack1, 9, 45, false))
/*     */         {
/* 153 */           return null;
/*     */         }
/*     */       }
/* 156 */       else if (((itemstack.getItem() instanceof ItemArmor)) && (!((Slot)this.inventorySlots.get(5 + ((ItemArmor)itemstack.getItem()).armorType)).getHasStack()))
/*     */       {
/* 158 */         int j = 5 + ((ItemArmor)itemstack.getItem()).armorType;
/*     */         
/* 160 */         if (!mergeItemStack(itemstack1, j, j + 1, false))
/*     */         {
/* 162 */           return null;
/*     */         }
/*     */       }
/* 165 */       else if ((p_82846_2_ >= 9) && (p_82846_2_ < 36))
/*     */       {
/* 167 */         if (!mergeItemStack(itemstack1, 36, 45, false))
/*     */         {
/* 169 */           return null;
/*     */         }
/*     */       }
/* 172 */       else if ((p_82846_2_ >= 36) && (p_82846_2_ < 45))
/*     */       {
/* 174 */         if (!mergeItemStack(itemstack1, 9, 36, false))
/*     */         {
/* 176 */           return null;
/*     */         }
/*     */       }
/* 179 */       else if (!mergeItemStack(itemstack1, 9, 45, false))
/*     */       {
/* 181 */         return null;
/*     */       }
/*     */       
/* 184 */       if (itemstack1.stackSize == 0)
/*     */       {
/* 186 */         slot.putStack((ItemStack)null);
/*     */       }
/*     */       else
/*     */       {
/* 190 */         slot.onSlotChanged();
/*     */       }
/*     */       
/* 193 */       if (itemstack1.stackSize == itemstack.stackSize)
/*     */       {
/* 195 */         return null;
/*     */       }
/*     */       
/* 198 */       slot.onPickupFromSlot(p_82846_1_, itemstack1);
/*     */     }
/*     */     
/* 201 */     return itemstack;
/*     */   }
/*     */   
/*     */   public boolean func_94530_a(ItemStack p_94530_1_, Slot p_94530_2_)
/*     */   {
/* 206 */     return (p_94530_2_.inventory != this.craftResult) && (super.func_94530_a(p_94530_1_, p_94530_2_));
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerInventoryUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */