/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ 
/*    */ public class ContainerUnified extends net.minecraft.inventory.Container
/*    */ {
/*    */   InventoryPlayer inventory;
/*    */   int id;
/*    */   
/*    */   public ContainerUnified(int id)
/*    */   {
/* 13 */     this.id = id;
/*    */   }
/*    */   
/*    */   public ContainerUnified(int id, InventoryPlayer invetory, int offsetX, int offsetY) {
/* 17 */     this(id);
/* 18 */     this.inventory = invetory;
/*    */   }
/*    */   
/*    */ 
/*    */   public void bindPlayerInventory(int offsetX, int offsetY) {}
/*    */   
/*    */   public int getGuiId()
/*    */   {
/* 26 */     return this.id;
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer playerIn)
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */