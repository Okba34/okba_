/*    */ package fr.paladium.palamod.common.gui;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerEmpty
/*    */   extends Container
/*    */ {
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 15 */     return true;
/*    */   }
/*    */   
/*    */   public ItemStack transferStackInSlot(EntityPlayer player, int quantity) {
/* 19 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\gui\ContainerEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */