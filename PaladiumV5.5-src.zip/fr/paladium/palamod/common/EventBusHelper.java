/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.common.eventhandler.EventBus;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ 
/*    */ 
/*    */ public class EventBusHelper
/*    */ {
/*    */   public static enum Type
/*    */   {
/* 12 */     FORGE, 
/* 13 */     FML, 
/* 14 */     BOTH;
/*    */     
/*    */     private Type() {} }
/*    */   
/* 18 */   public static void register(Object handler, Type type) { if ((type == Type.FORGE) || (type == Type.BOTH)) {
/* 19 */       MinecraftForge.EVENT_BUS.register(handler);
/*    */     }
/*    */     
/* 22 */     if ((type == Type.FML) || (type == Type.BOTH)) {
/* 23 */       FMLCommonHandler.instance().bus().register(handler);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\EventBusHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */