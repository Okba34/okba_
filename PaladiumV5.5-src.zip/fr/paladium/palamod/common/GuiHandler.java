/*     */ package fr.paladium.palamod.common;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.GuiBowMachine;
/*     */ import fr.paladium.palamod.client.gui.GuiCameraTablet;
/*     */ import fr.paladium.palamod.client.gui.GuiCobbleBreaker;
/*     */ import fr.paladium.palamod.client.gui.GuiFurnaceInfo;
/*     */ import fr.paladium.palamod.client.gui.GuiGuardianChest;
/*     */ import fr.paladium.palamod.client.gui.GuiGuardianKeeper;
/*     */ import fr.paladium.palamod.client.gui.GuiStuffSwitcher;
/*     */ import fr.paladium.palamod.client.gui.unified.GuiFactionUnified;
/*     */ import fr.paladium.palamod.common.gui.ContainerBackpack;
/*     */ import fr.paladium.palamod.common.gui.ContainerChestExplorer;
/*     */ import fr.paladium.palamod.common.gui.ContainerCobbleBreaker;
/*     */ import fr.paladium.palamod.common.gui.ContainerEmpty;
/*     */ import fr.paladium.palamod.common.gui.ContainerFactionUnified;
/*     */ import fr.paladium.palamod.common.gui.ContainerGuardianWhitelist;
/*     */ import fr.paladium.palamod.common.gui.ContainerInventoryUnified;
/*     */ import fr.paladium.palamod.common.gui.ContainerJobUnified;
/*     */ import fr.paladium.palamod.common.gui.ContainerVoidStone;
/*     */ import fr.paladium.palamod.common.inventory.InventoryBackpack;
/*     */ import fr.paladium.palamod.common.inventory.InventoryStuffSwitcher;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import fr.paladium.palamod.job.gui.ForgeGui;
/*     */ import fr.paladium.palamod.job.logic.ForgeLogic;
/*     */ import fr.paladium.palamod.job.logic.TileCobbleBreaker;
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import fr.paladium.palamod.paladium.gui.PaladiumChestGui;
/*     */ import fr.paladium.palamod.paladium.gui.PaladiumMachineGui;
/*     */ import fr.paladium.palamod.paladium.inventory.AlchemyCreatorPotionContainer;
/*     */ import fr.paladium.palamod.paladium.inventory.PaladiumFurnaceContainer;
/*     */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*     */ import fr.paladium.palamod.paladium.logic.BowMachineLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumChestLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumFurnaceLogic;
/*     */ import fr.paladium.palamod.paladium.logic.PaladiumMachineLogic;
/*     */ import fr.paladium.palamod.smeltery.inventory.GrinderContainer;
/*     */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class GuiHandler implements cpw.mods.fml.common.network.IGuiHandler
/*     */ {
/*     */   public static final int PALADIUM_MACHINE = 0;
/*     */   public static final int ALCHEMY_CREATOR_POTION = 1;
/*     */   public static final int ALCHEMY_CREATOR_ARROW = 2;
/*     */   public static final int PALADIUM_FURNACE = 3;
/*     */   public static final int PALADIUM_CHEST = 4;
/*     */   public static final int BOW_MACHINE = 5;
/*     */   public static final int ALCHEMY_STACKER = 6;
/*     */   public static final int GUARDIAN_GOLEM = 7;
/*     */   public static final int BACKPACK = 8;
/*     */   public static final int ONLINE_DETECTOR = 9;
/*     */   public static final int VOID_STONE = 10;
/*     */   public static final int BOOK = 11;
/*     */   public static final int GRINDER = 12;
/*     */   public static final int CHEST_EXPLORER = 13;
/*     */   public static final int STUFF_SWITCHER = 14;
/*     */   public static final int GUARDIAN_WHITELIST = 15;
/*     */   public static final int GUARDIAN_KEEPER = 16;
/*     */   public static final int PALADIUM_OVEN = 17;
/*     */   public static final int FURNACE_INFO = 18;
/*     */   public static final int FACTION_INFO = 19;
/*     */   public static final int MAGICAL_ANVIL_ADD = 20;
/*     */   public static final int ARMOR_COMPRESSOR = 21;
/*     */   public static final int MULTICOLOR_BLOCK = 22;
/*     */   public static final int GUARDIAN_ANCHOR = 23;
/*     */   public static final int GUARDIAN_CHEST = 24;
/*     */   public static final int GUARDIAN_UPGRADE = 25;
/*     */   public static final int OBSIDIAN_UPGRADER = 26;
/*     */   public static final int CAMERA_TABLET = 27;
/*     */   public static final int FORGE = 28;
/*     */   public static final int COBBLEBREAKER = 29;
/*     */   
/*     */   public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/*  77 */     switch (ID) {
/*     */     case 0: 
/*  79 */       return new fr.paladium.palamod.paladium.inventory.PaladiumMachineContainer((PaladiumMachineLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 1: 
/*  81 */       return new AlchemyCreatorPotionContainer((AlchemyCreatorLogic)world.getTileEntity(x, y, z), player);
/*     */     case 2: 
/*  83 */       return new fr.paladium.palamod.paladium.inventory.AlchemyCreatorArrowContainer((AlchemyCreatorLogic)world.getTileEntity(x, y, z), player);
/*     */     case 3: 
/*  85 */       return new PaladiumFurnaceContainer(player.inventory, (PaladiumFurnaceLogic)world.getTileEntity(x, y, z));
/*     */     case 4: 
/*  87 */       return new fr.paladium.palamod.common.gui.ContainerPaladiumChest((PaladiumChestLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 5: 
/*  89 */       return new fr.paladium.palamod.paladium.inventory.BowMachineContainer((BowMachineLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 7: 
/*  91 */       return new fr.paladium.palamod.common.gui.ContainerGuardianGolem((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 8: 
/*  93 */       return new ContainerBackpack(player.inventory, new InventoryBackpack(player));
/*     */     case 9: 
/*  95 */       return new ContainerEmpty();
/*     */     case 10: 
/*  97 */       return new ContainerVoidStone(player.inventory);
/*     */     case 12: 
/*  99 */       return new GrinderContainer(player.inventory, (GrinderLogic)world.getTileEntity(x, y, z));
/*     */     case 13: 
/* 101 */       return new ContainerChestExplorer(world.getTileEntity(x, y, z));
/*     */     case 14: 
/* 103 */       return new fr.paladium.palamod.common.gui.ContainerStuffSwitcher(player.inventory, new InventoryStuffSwitcher(player.getHeldItem()));
/*     */     case 15: 
/* 105 */       return new ContainerGuardianWhitelist(player.inventory);
/*     */     case 16: 
/* 107 */       return new fr.paladium.palamod.common.gui.ContainerGuardianKeeper(player);
/*     */     case 18: 
/* 109 */       return new ContainerEmpty();
/*     */     case 19: 
/* 111 */       return new ContainerEmpty();
/*     */     case 22: 
/* 113 */       return null;
/*     */     case 26: 
/* 115 */       return new fr.paladium.palamod.common.gui.ContainerObsidianUpgrader((TileEntityObsidianUpgrader)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 27: 
/* 117 */       return null;
/*     */     case 23: 
/* 119 */       return new ContainerEmpty();
/*     */     case 24: 
/* 121 */       return new fr.paladium.palamod.common.gui.ContainerGuardianChest((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 25: 
/* 123 */       return new fr.paladium.palamod.common.gui.ContainerGuardianUpgrade((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 40: 
/* 125 */       return new ContainerInventoryUnified(ID, player.inventory, true, player, 30, 0);
/*     */     case 41: 
/* 127 */       return new ContainerFactionUnified();
/*     */     case 44: 
/* 129 */       return new ContainerJobUnified(player);
/*     */     case 45: 
/* 131 */       return new ContainerFactionUnified();
/*     */     case 28: 
/* 133 */       return new fr.paladium.palamod.job.inventory.ForgeContainer((ForgeLogic)world.getTileEntity(x, y, z), player.inventory, player);
/*     */     case 29: 
/* 135 */       return new ContainerCobbleBreaker((TileCobbleBreaker)world.getTileEntity(x, y, z), player.inventory, player);
/*     */     }
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
/*     */   {
/* 142 */     switch (ID) {
/*     */     case 0: 
/* 144 */       return new PaladiumMachineGui((PaladiumMachineLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 1: 
/* 146 */       return new fr.paladium.palamod.paladium.gui.AlchemyCreatorPotionGui((AlchemyCreatorLogic)world.getTileEntity(x, y, z), player);
/*     */     case 2: 
/* 148 */       return new fr.paladium.palamod.paladium.gui.AlchemyCreatorArrowGui((AlchemyCreatorLogic)world.getTileEntity(x, y, z), player);
/*     */     case 3: 
/* 150 */       return new fr.paladium.palamod.paladium.gui.PaladiumFurnaceGui(player.inventory, (PaladiumFurnaceLogic)world.getTileEntity(x, y, z));
/*     */     case 4: 
/* 152 */       return new PaladiumChestGui((PaladiumChestLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 5: 
/* 154 */       return new GuiBowMachine((BowMachineLogic)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 7: 
/* 156 */       return new fr.paladium.palamod.client.gui.GuiGuardianGolem((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 8: 
/* 158 */       return new fr.paladium.palamod.client.gui.GuiBackpack(player.inventory, new InventoryBackpack(player));
/*     */     case 9: 
/* 160 */       return new fr.paladium.palamod.client.gui.GuiOnlineDetector((fr.paladium.palamod.tiles.TileEntityOnlineDetector)world.getTileEntity(x, y, z));
/*     */     case 10: 
/* 162 */       return new fr.paladium.palamod.client.gui.GuiVoidStone(player.inventory);
/*     */     case 12: 
/* 164 */       return new fr.paladium.palamod.smeltery.gui.GrinderGui(player.inventory, (GrinderLogic)world.getTileEntity(x, y, z));
/*     */     case 13: 
/* 166 */       return new fr.paladium.palamod.client.gui.GuiChestExplorer(world.getTileEntity(x, y, z));
/*     */     case 14: 
/* 168 */       return new GuiStuffSwitcher(player.inventory, new InventoryStuffSwitcher(player.getHeldItem()));
/*     */     case 15: 
/* 170 */       return new fr.paladium.palamod.client.gui.GuiGuardianWhitelist(player.getHeldItem(), player.inventory);
/*     */     case 16: 
/* 172 */       return new GuiGuardianKeeper(player);
/*     */     case 18: 
/* 174 */       return new GuiFurnaceInfo();
/*     */     case 19: 
/* 176 */       return new fr.paladium.palamod.client.gui.GuiFAnnounce();
/*     */     case 26: 
/* 178 */       return new fr.paladium.palamod.client.gui.GuiObsidianUpgrader((TileEntityObsidianUpgrader)world.getTileEntity(x, y, z), player.inventory);
/*     */     case 27: 
/* 180 */       return new GuiCameraTablet(player);
/*     */     case 23: 
/* 182 */       return new fr.paladium.palamod.client.gui.GuiGuardianAnchor((fr.paladium.palamod.tiles.TileEntityGuardianAnchor)world.getTileEntity(x, y, z));
/*     */     case 24: 
/* 184 */       return new GuiGuardianChest((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 25: 
/* 186 */       return new fr.paladium.palamod.client.gui.GuiGuardianUpgrade((EntityGuardianGolem)world.getEntityByID(x), player.inventory);
/*     */     case 40: 
/* 188 */       return new fr.paladium.palamod.client.gui.unified.GuiInventoryUnified(new ContainerInventoryUnified(ID, player.inventory, true, player, 40, 0), LibRessources.INVENTORY_UNIFIED);
/*     */     case 41: 
/* 190 */       return new GuiFactionUnified(new ContainerFactionUnified(), LibRessources.FACTION_UNIFIED);
/*     */     case 44: 
/* 192 */       return new fr.paladium.palamod.client.gui.unified.GuiJobUnified(new ContainerJobUnified(player), LibRessources.JOB_UNIFIED);
/*     */     case 45: 
/* 194 */       return new fr.paladium.palamod.client.gui.unified.GuiCosmeticUnified(new ContainerFactionUnified(), LibRessources.COSMETIC_UNIFIED);
/*     */     case 28: 
/* 196 */       return new ForgeGui((ForgeLogic)world.getTileEntity(x, y, z), player.inventory, player);
/*     */     case 29: 
/* 198 */       return new GuiCobbleBreaker((TileCobbleBreaker)world.getTileEntity(x, y, z), player.inventory, player);
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\GuiHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */