/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import fr.paladium.palamod.common.inventory.InventoryGuardianKeeper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.nbt.NBTTagList;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraft.world.WorldSavedData;
/*    */ 
/*    */ public class GuardianKeeperHandler
/*    */   extends WorldSavedData
/*    */ {
/*    */   private static final String DATA_NAME = "palamod_GuardianKeeper";
/*    */   HashMap<String, InventoryGuardianKeeper> guardianMap;
/*    */   
/*    */   public GuardianKeeperHandler(String name)
/*    */   {
/* 20 */     super(name);
/* 21 */     this.guardianMap = new HashMap();
/*    */   }
/*    */   
/*    */   public GuardianKeeperHandler() {
/* 25 */     super("palamod_GuardianKeeper");
/* 26 */     this.guardianMap = new HashMap();
/*    */   }
/*    */   
/*    */   public void readFromNBT(NBTTagCompound tag)
/*    */   {
/* 31 */     NBTTagList list = tag.getTagList("data", 10);
/* 32 */     for (int i = 0; i < list.tagCount(); i++) {
/* 33 */       NBTTagCompound entry = list.getCompoundTagAt(i);
/* 34 */       String uuid = entry.getString("uuid");
/* 35 */       ItemStack stack = ItemStack.loadItemStackFromNBT(entry.getCompoundTag("item"));
/* 36 */       InventoryGuardianKeeper inventory = new InventoryGuardianKeeper();
/* 37 */       inventory.setInventorySlotContents(0, stack);
/* 38 */       this.guardianMap.put(uuid, inventory);
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeToNBT(NBTTagCompound tag)
/*    */   {
/* 44 */     NBTTagList list = new NBTTagList();
/* 45 */     for (Map.Entry<String, InventoryGuardianKeeper> entry : this.guardianMap.entrySet()) {
/* 46 */       NBTTagCompound tag2 = new NBTTagCompound();
/* 47 */       tag2.setString("uuid", (String)entry.getKey());
/* 48 */       NBTTagCompound inventory = new NBTTagCompound();
/* 49 */       NBTTagCompound stackComp = new NBTTagCompound();
/* 50 */       ItemStack stack = ((InventoryGuardianKeeper)entry.getValue()).getStackInSlot(0);
/* 51 */       if (stack != null)
/* 52 */         stack.writeToNBT(stackComp);
/* 53 */       tag2.setTag("item", stackComp);
/* 54 */       list.appendTag(tag2);
/*    */     }
/* 56 */     tag.setTag("data", list);
/*    */   }
/*    */   
/*    */   public InventoryGuardianKeeper getStoneFromUUID(String uuid) {
/* 60 */     if (!this.guardianMap.containsKey(uuid))
/* 61 */       this.guardianMap.put(uuid, new InventoryGuardianKeeper());
/* 62 */     markDirty();
/* 63 */     return (InventoryGuardianKeeper)this.guardianMap.get(uuid);
/*    */   }
/*    */   
/*    */   public static GuardianKeeperHandler get(World worldObj) {
/* 67 */     GuardianKeeperHandler handler = (GuardianKeeperHandler)worldObj.loadItemData(GuardianKeeperHandler.class, "palamod_GuardianKeeper");
/*    */     
/*    */ 
/* 70 */     if (handler == null) {
/* 71 */       handler = new GuardianKeeperHandler();
/* 72 */       worldObj.setItemData("palamod_GuardianKeeper", handler);
/*    */     }
/*    */     
/* 75 */     return handler;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\GuardianKeeperHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */