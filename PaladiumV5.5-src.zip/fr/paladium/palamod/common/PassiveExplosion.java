/*     */ package fr.paladium.palamod.common;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.enchantment.EnchantmentProtection;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityTNTPrimed;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.ChunkPosition;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ 
/*     */ 
/*     */ public class PassiveExplosion
/*     */   extends Explosion
/*     */ {
/*  29 */   public boolean isSmoking = true;
/*  30 */   private int field_77289_h = 16;
/*  31 */   private Random explosionRNG = new Random();
/*     */   private World worldObj;
/*     */   public double explosionX;
/*     */   public double explosionY;
/*     */   public double explosionZ;
/*     */   public Entity exploder;
/*     */   public float explosionSize;
/*  38 */   private Map field_77288_k = new HashMap();
/*     */   private static final String __OBFID = "CL_00000134";
/*     */   
/*     */   public PassiveExplosion(World world, Entity entity, double x, double y, double z, float size)
/*     */   {
/*  43 */     super(world, entity, x, y, z, size);
/*  44 */     this.worldObj = world;
/*  45 */     this.explosionSize = size;
/*  46 */     this.explosionX = x;
/*  47 */     this.explosionY = y;
/*  48 */     this.explosionZ = z;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doExplosionA()
/*     */   {
/*  56 */     float f = this.explosionSize;
/*  57 */     HashSet hashset = new HashSet();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */     for (int i = 0; i < this.field_77289_h; i++)
/*     */     {
/*  67 */       for (int j = 0; j < this.field_77289_h; j++)
/*     */       {
/*  69 */         for (int k = 0; k < this.field_77289_h; k++)
/*     */         {
/*  71 */           if ((i == 0) || (i == this.field_77289_h - 1) || (j == 0) || (j == this.field_77289_h - 1) || (k == 0) || (k == this.field_77289_h - 1))
/*     */           {
/*  73 */             double d0 = i / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
/*  74 */             double d1 = j / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
/*  75 */             double d2 = k / (this.field_77289_h - 1.0F) * 2.0F - 1.0F;
/*  76 */             double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
/*  77 */             d0 /= d3;
/*  78 */             d1 /= d3;
/*  79 */             d2 /= d3;
/*  80 */             float f1 = this.explosionSize * (0.7F + this.worldObj.rand.nextFloat() * 0.6F);
/*  81 */             double d5 = this.explosionX;
/*  82 */             double d6 = this.explosionY;
/*  83 */             double d7 = this.explosionZ;
/*     */             
/*  85 */             for (float f2 = 0.3F; f1 > 0.0F; f1 -= f2 * 0.75F)
/*     */             {
/*  87 */               int j1 = MathHelper.floor_double(d5);
/*  88 */               int k1 = MathHelper.floor_double(d6);
/*  89 */               int l1 = MathHelper.floor_double(d7);
/*     */               
/*  91 */               d5 += d0 * f2;
/*  92 */               d6 += d1 * f2;
/*  93 */               d7 += d2 * f2;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 100 */     this.explosionSize *= 2.0F;
/* 101 */     i = MathHelper.floor_double(this.explosionX - this.explosionSize - 1.0D);
/* 102 */     int j = MathHelper.floor_double(this.explosionX + this.explosionSize + 1.0D);
/* 103 */     int k = MathHelper.floor_double(this.explosionY - this.explosionSize - 1.0D);
/* 104 */     int i2 = MathHelper.floor_double(this.explosionY + this.explosionSize + 1.0D);
/* 105 */     int l = MathHelper.floor_double(this.explosionZ - this.explosionSize - 1.0D);
/* 106 */     int j2 = MathHelper.floor_double(this.explosionZ + this.explosionSize + 1.0D);
/* 107 */     List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(null, AxisAlignedBB.getBoundingBox(i, k, l, j, i2, j2));
/* 108 */     ForgeEventFactory.onExplosionDetonate(this.worldObj, this, list, this.explosionSize);
/* 109 */     Vec3 vec3 = Vec3.createVectorHelper(this.explosionX, this.explosionY, this.explosionZ);
/*     */     
/* 111 */     for (int i1 = 0; i1 < list.size(); i1++)
/*     */     {
/* 113 */       Entity entity = (Entity)list.get(i1);
/* 114 */       double d4 = entity.getDistance(this.explosionX, this.explosionY, this.explosionZ) / this.explosionSize;
/*     */       
/* 116 */       if (d4 <= 1.0D)
/*     */       {
/* 118 */         double d5 = entity.posX - this.explosionX;
/* 119 */         double d6 = entity.posY + entity.getEyeHeight() - this.explosionY;
/* 120 */         double d7 = entity.posZ - this.explosionZ;
/* 121 */         double d9 = MathHelper.sqrt_double(d5 * d5 + d6 * d6 + d7 * d7);
/*     */         
/* 123 */         if (d9 != 0.0D)
/*     */         {
/* 125 */           d5 /= d9;
/* 126 */           d6 /= d9;
/* 127 */           d7 /= d9;
/* 128 */           double d10 = this.worldObj.getBlockDensity(vec3, entity.boundingBox);
/* 129 */           double d11 = (1.0D - d4) * d10;
/* 130 */           entity.attackEntityFrom(DamageSource.setExplosionSource(this), (int)((d11 * d11 + d11) / 2.0D * 8.0D * this.explosionSize + 1.0D));
/* 131 */           double d8 = EnchantmentProtection.func_92092_a(entity, d11);
/* 132 */           entity.motionX += d5 * d8;
/* 133 */           entity.motionY += d6 * d8;
/* 134 */           entity.motionZ += d7 * d8;
/*     */           
/* 136 */           if ((entity instanceof EntityPlayer))
/*     */           {
/* 138 */             this.field_77288_k.put((EntityPlayer)entity, Vec3.createVectorHelper(d5 * d11, d6 * d11, d7 * d11));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 144 */     this.explosionSize = f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doExplosionB(boolean p_77279_1_)
/*     */   {
/* 152 */     this.worldObj.playSoundEffect(this.explosionX, this.explosionY, this.explosionZ, "random.explode", 4.0F, (1.0F + (this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.2F) * 0.7F);
/*     */     
/* 154 */     if ((this.explosionSize >= 2.0F) && (this.isSmoking))
/*     */     {
/* 156 */       this.worldObj.spawnParticle("hugeexplosion", this.explosionX, this.explosionY, this.explosionZ, 1.0D, 0.0D, 0.0D);
/*     */     }
/*     */     else
/*     */     {
/* 160 */       this.worldObj.spawnParticle("largeexplode", this.explosionX, this.explosionY, this.explosionZ, 1.0D, 0.0D, 0.0D);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     if (this.isSmoking)
/*     */     {
/* 172 */       Iterator iterator = this.affectedBlockPositions.iterator();
/*     */       
/* 174 */       while (iterator.hasNext())
/*     */       {
/* 176 */         ChunkPosition chunkposition = (ChunkPosition)iterator.next();
/* 177 */         int i = chunkposition.chunkPosX;
/* 178 */         int j = chunkposition.chunkPosY;
/* 179 */         int k = chunkposition.chunkPosZ;
/* 180 */         Block block = this.worldObj.getBlock(i, j, k);
/*     */         
/* 182 */         if (p_77279_1_)
/*     */         {
/* 184 */           double d0 = i + this.worldObj.rand.nextFloat();
/* 185 */           double d1 = j + this.worldObj.rand.nextFloat();
/* 186 */           double d2 = k + this.worldObj.rand.nextFloat();
/* 187 */           double d3 = d0 - this.explosionX;
/* 188 */           double d4 = d1 - this.explosionY;
/* 189 */           double d5 = d2 - this.explosionZ;
/* 190 */           double d6 = MathHelper.sqrt_double(d3 * d3 + d4 * d4 + d5 * d5);
/* 191 */           d3 /= d6;
/* 192 */           d4 /= d6;
/* 193 */           d5 /= d6;
/* 194 */           double d7 = 0.5D / (d6 / this.explosionSize + 0.1D);
/* 195 */           d7 *= (this.worldObj.rand.nextFloat() * this.worldObj.rand.nextFloat() + 0.3F);
/* 196 */           d3 *= d7;
/* 197 */           d4 *= d7;
/* 198 */           d5 *= d7;
/* 199 */           this.worldObj.spawnParticle("explode", (d0 + this.explosionX * 1.0D) / 2.0D, (d1 + this.explosionY * 1.0D) / 2.0D, (d2 + this.explosionZ * 1.0D) / 2.0D, d3, d4, d5);
/* 200 */           this.worldObj.spawnParticle("smoke", d0, d1, d2, d3, d4, d5);
/*     */         }
/*     */         
/* 203 */         if (block.getMaterial() != Material.air)
/*     */         {
/* 205 */           if (block.canDropFromExplosion(this))
/*     */           {
/* 207 */             block.dropBlockAsItemWithChance(this.worldObj, i, j, k, this.worldObj.getBlockMetadata(i, j, k), 1.0F / this.explosionSize, 0);
/*     */           }
/*     */           
/* 210 */           block.onBlockExploded(this.worldObj, i, j, k, this);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Map func_77277_b()
/*     */   {
/* 218 */     return this.field_77288_k;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityLivingBase getExplosivePlacedBy()
/*     */   {
/* 226 */     return (this.exploder instanceof EntityLivingBase) ? (EntityLivingBase)this.exploder : (this.exploder instanceof EntityTNTPrimed) ? ((EntityTNTPrimed)this.exploder).getTntPlacedBy() : this.exploder == null ? null : null;
/*     */   }
/*     */   
/*     */   public static Explosion newExplosion(Entity e, double x, double y, double z, float f, boolean smoking, boolean flaming, World world)
/*     */   {
/* 231 */     PassiveExplosion explosion = new PassiveExplosion(world, e, x, y, z, f);
/* 232 */     if (ForgeEventFactory.onExplosionStart(world, explosion)) return explosion;
/* 233 */     explosion.doExplosionA();
/* 234 */     explosion.doExplosionB(true);
/* 235 */     return explosion;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\PassiveExplosion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */