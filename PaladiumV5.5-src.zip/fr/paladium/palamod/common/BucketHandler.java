package fr.paladium.palamod.common;

public class BucketHandler {}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\BucketHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */