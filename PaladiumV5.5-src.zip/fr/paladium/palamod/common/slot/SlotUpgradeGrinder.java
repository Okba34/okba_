/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.items.tools.ItemPaladiumHammer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotUpgradeGrinder extends Slot
/*    */ {
/*    */   public SlotUpgradeGrinder(IInventory inventory, int id, int x, int y)
/*    */   {
/* 13 */     super(inventory, id, x, y);
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 18 */     if ((stack.getItem() instanceof ItemPaladiumHammer))
/* 19 */       return true;
/* 20 */     if ((stack.getItem() instanceof fr.paladium.palamod.items.weapons.ItemPaladiumBroadsword))
/* 21 */       return true;
/* 22 */     if ((stack.getItem() instanceof fr.paladium.palamod.items.weapons.ItemPaladiumFastsword)) {
/* 23 */       return true;
/*    */     }
/* 25 */     return false;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int amount) {
/* 29 */     return super.decrStackSize(amount);
/*    */   }
/*    */   
/*    */   public void onPickupFromSlot(EntityPlayer player, ItemStack stack) {
/* 33 */     super.onCrafting(stack);
/* 34 */     super.onPickupFromSlot(player, stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotUpgradeGrinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */