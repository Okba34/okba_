/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class SlotGuardianChest
/*    */   extends Slot
/*    */ {
/* 12 */   ResourceLocation disabled = new ResourceLocation("palamod:textures/gui/SlotsGui.png");
/*    */   EntityGuardianGolem golem;
/*    */   int id;
/*    */   
/*    */   public SlotGuardianChest(IInventory inventory, int id, int x, int y, EntityGuardianGolem golem) {
/* 17 */     super(inventory, id, x, y);
/* 18 */     this.id = id;
/* 19 */     this.golem = golem;
/* 20 */     if (this.id > golem.getMaxChestSlots()) {
/* 21 */       setBackgroundIconTexture(this.disabled);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 27 */     if (this.id > this.golem.getMaxChestSlots())
/* 28 */       return false;
/* 29 */     return true;
/*    */   }
/*    */   
/*    */   public ResourceLocation getBackgroundIconTexture()
/*    */   {
/* 34 */     return super.getBackgroundIconTexture();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotGuardianChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */