/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotSingle extends Slot
/*    */ {
/*    */   ItemStack item;
/*    */   
/*    */   public SlotSingle(IInventory inventory, int id, int x, int y, net.minecraft.item.Item item)
/*    */   {
/* 14 */     super(inventory, id, x, y);
/* 15 */     this.item = new ItemStack(item);
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 20 */     if (stack.getItem() == this.item.getItem()) {
/* 21 */       return true;
/*    */     }
/* 23 */     return false;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int amount) {
/* 27 */     return super.decrStackSize(amount);
/*    */   }
/*    */   
/*    */   public void onPickupFromSlot(EntityPlayer player, ItemStack stack) {
/* 31 */     super.onCrafting(stack);
/* 32 */     super.onPickupFromSlot(player, stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotSingle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */