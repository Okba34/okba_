/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*    */ import fr.paladium.palamod.items.tools.ItemPaladiumPickaxe;
/*    */ import fr.paladium.palamod.items.weapons.ItemPaladiumSword;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotGrinder extends Slot
/*    */ {
/*    */   private GrinderLogic grinder;
/*    */   
/*    */   public SlotGrinder(IInventory inventory, int id, int x, int y, GrinderLogic grinder)
/*    */   {
/* 19 */     super(inventory, id, x, y);
/* 20 */     this.grinder = grinder;
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 25 */     if (this.grinder.getPaladium() == 100) {
/* 26 */       return false;
/*    */     }
/* 28 */     if (stack.getItem() == MaterialRegister.PALADIUM_INGOT) {
/* 29 */       return true;
/*    */     }
/* 31 */     if (stack.getItem() == net.minecraft.item.Item.getItemFromBlock(DecorativeRegister.PALADIUM_BLOCK)) {
/* 32 */       return true;
/*    */     }
/* 34 */     if ((stack.getItem() instanceof fr.paladium.palamod.items.armors.ItemArmorPaladium)) {
/* 35 */       return true;
/*    */     }
/* 37 */     if ((stack.getItem() instanceof ItemPaladiumPickaxe)) {
/* 38 */       return true;
/*    */     }
/* 40 */     if ((stack.getItem() instanceof ItemPaladiumSword)) {
/* 41 */       return true;
/*    */     }
/*    */     
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int amount) {
/* 48 */     return super.decrStackSize(amount);
/*    */   }
/*    */   
/*    */   public int getSlotStackLimit()
/*    */   {
/* 53 */     return 64;
/*    */   }
/*    */   
/*    */   public void onPickupFromSlot(EntityPlayer player, ItemStack stack) {
/* 57 */     super.onCrafting(stack);
/* 58 */     super.onPickupFromSlot(player, stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotGrinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */