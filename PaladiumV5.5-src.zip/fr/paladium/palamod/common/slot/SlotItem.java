/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotItem extends Slot
/*    */ {
/*    */   Item itemYes;
/*    */   
/*    */   public SlotItem(IInventory inventory, int id, int x, int y, Item item)
/*    */   {
/* 14 */     super(inventory, id, x, y);
/*    */     
/* 16 */     this.itemYes = item;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 22 */     return stack.getItem() == this.itemYes;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */