/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.items.ItemBackpack;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotBackpack extends Slot
/*    */ {
/*    */   public SlotBackpack(IInventory inventory, int id, int x, int y)
/*    */   {
/* 12 */     super(inventory, id, x, y);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 18 */     if (!(stack.getItem() instanceof ItemBackpack))
/* 19 */       return true;
/* 20 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotBackpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */