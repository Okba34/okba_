/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotChestExplorer extends Slot
/*    */ {
/*    */   public SlotChestExplorer(net.minecraft.inventory.IInventory p_i1824_1_, int p_i1824_2_, int p_i1824_3_, int p_i1824_4_)
/*    */   {
/* 10 */     super(p_i1824_1_, p_i1824_2_, p_i1824_3_, p_i1824_4_);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack p_75214_1_)
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int p_75209_1_)
/*    */   {
/* 21 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotChestExplorer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */