/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotItemList
/*    */   extends Slot
/*    */ {
/*    */   List<Item> itemsYes;
/*    */   
/*    */   public SlotItemList(IInventory inventory, int id, int x, int y, List<Item> items)
/*    */   {
/* 16 */     super(inventory, id, x, y);
/*    */     
/* 18 */     this.itemsYes = items;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 24 */     for (int i = 0; i < this.itemsYes.size(); i++) {
/* 25 */       if (stack.getItem() == this.itemsYes.get(i))
/* 26 */         return true;
/*    */     }
/* 28 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotItemList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */