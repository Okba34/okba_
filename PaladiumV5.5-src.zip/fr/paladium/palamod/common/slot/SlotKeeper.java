/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotKeeper
/*    */   extends Slot
/*    */ {
/*    */   public SlotKeeper(IInventory inventory, int id, int x, int y)
/*    */   {
/* 12 */     super(inventory, id, x, y);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 18 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotKeeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */