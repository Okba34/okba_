/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemGuardianUpgrade;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotGuardianUpgrade extends Slot
/*    */ {
/*    */   EntityGuardianGolem golem;
/*    */   
/*    */   public SlotGuardianUpgrade(IInventory inventory, int id, int x, int y, EntityGuardianGolem golem)
/*    */   {
/* 15 */     super(inventory, id, x, y);
/*    */     
/* 17 */     this.golem = golem;
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 22 */     if ((stack.getItem() instanceof ItemGuardianUpgrade))
/*    */     {
/* 24 */       if (this.golem.getLevel() >= ((ItemGuardianUpgrade)stack.getItem()).getRequiredLevel())
/* 25 */         return true; }
/* 26 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotGuardianUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */