/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotResult extends Slot
/*    */ {
/*    */   public SlotResult(IInventory inventory, int id, int x, int y)
/*    */   {
/* 11 */     super(inventory, id, x, y);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 17 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */