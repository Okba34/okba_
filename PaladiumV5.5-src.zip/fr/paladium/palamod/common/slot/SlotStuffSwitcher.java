/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotStuffSwitcher
/*    */   extends Slot
/*    */ {
/*    */   public int type;
/*    */   
/*    */   public SlotStuffSwitcher(IInventory inventory, int id, int x, int y, int type)
/*    */   {
/* 15 */     super(inventory, id, x, y);
/* 16 */     this.type = type;
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 21 */     if ((stack.getItem() instanceof ItemArmor)) {
/* 22 */       ItemArmor armor = (ItemArmor)stack.getItem();
/* 23 */       return armor.armorType == this.type;
/*    */     }
/* 25 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotStuffSwitcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */