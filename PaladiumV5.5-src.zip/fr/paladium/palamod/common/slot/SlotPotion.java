/*    */ package fr.paladium.palamod.common.slot;
/*    */ 
/*    */ import fr.paladium.palamod.items.ItemSplashPotion;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class SlotPotion extends Slot
/*    */ {
/*    */   public SlotPotion(IInventory inventory, int id, int x, int y)
/*    */   {
/* 13 */     super(inventory, id, x, y);
/*    */   }
/*    */   
/*    */   public boolean isItemValid(ItemStack stack)
/*    */   {
/* 18 */     if ((((stack.getItem() instanceof net.minecraft.item.ItemPotion)) && 
/* 19 */       (stack.getItemDamage() != 0) && (stack.getItemDamage() != 16) && (stack.getItemDamage() != 16393) && 
/* 20 */       (stack.getItemDamage() != 16425) && (stack.getItemDamage() != 16457)) || 
/* 21 */       ((stack.getItem() instanceof fr.paladium.palamod.items.ItemPotion)) || 
/* 22 */       ((stack.getItem() instanceof ItemSplashPotion))) {
/* 23 */       return true;
/*    */     }
/* 25 */     return false;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int amount) {
/* 29 */     return super.decrStackSize(amount);
/*    */   }
/*    */   
/*    */   public void onPickupFromSlot(EntityPlayer player, ItemStack stack) {
/* 33 */     super.onCrafting(stack);
/* 34 */     super.onPickupFromSlot(player, stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\slot\SlotPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */