/*     */ package fr.paladium.palamod.common;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent.ClientTickEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent.Phase;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent.ServerTickEvent;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.client.gui.GuiButtonPala;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCamera;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import fr.paladium.palamod.entities.projectiles.EntityCustomArrow;
/*     */ import fr.paladium.palamod.items.ItemCameraTablet;
/*     */ import fr.paladium.palamod.job.Job;
/*     */ import fr.paladium.palamod.job.JobsXPManager;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.network.packets.PacketMessageBoss;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import fr.paladium.palamod.util.WitherData;
/*     */ import fr.paladium.palamod.world.WorldRegister;
/*     */ import java.awt.Desktop;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiIngameMenu;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiShareToLan;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.boss.EntityWither;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.PlayerCapabilities;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.server.integrated.IntegratedServer;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Session;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.GuiOpenEvent;
/*     */ import net.minecraftforge.client.event.GuiScreenEvent.ActionPerformedEvent;
/*     */ import net.minecraftforge.client.event.GuiScreenEvent.InitGuiEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*     */ import net.minecraftforge.event.entity.EntityJoinWorldEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingHurtEvent;
/*     */ import net.minecraftforge.event.entity.player.AttackEntityEvent;
/*     */ import net.minecraftforge.event.entity.player.EntityInteractEvent;
/*     */ import net.minecraftforge.event.entity.player.FillBucketEvent;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent.Action;
/*     */ import net.minecraftforge.event.world.BlockEvent.BreakEvent;
/*     */ import net.minecraftforge.event.world.ExplosionEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class EventHandler
/*     */ {
/*  80 */   public static Map<Block, Item> buckets = new HashMap();
/*     */   public static long timeHurt;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingHurt(LivingHurtEvent event) {
/*  85 */     DamageSource source = event.source;
/*  86 */     if (source.isProjectile()) {
/*  87 */       Entity entity = source.getSourceOfDamage();
/*  88 */       if (((entity instanceof EntityCustomArrow)) && ((event.entity instanceof EntityLivingBase))) {
/*  89 */         EntityCustomArrow arrow = (EntityCustomArrow)entity;
/*  90 */         EntityLivingBase base = (EntityLivingBase)event.entity;
/*  91 */         int type = arrow.getType();
/*  92 */         switch (type) {
/*     */         case 0: 
/*  94 */           base.addPotionEffect(new PotionEffect(Potion.poison.id, 100, 2));
/*  95 */           break;
/*     */         case 1: 
/*  97 */           base.addPotionEffect(new PotionEffect(Potion.wither.id, 100, 2));
/*  98 */           break;
/*     */         case 2: 
/* 100 */           base.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 100, 2));
/* 101 */           break;
/*     */         case 3: 
/* 103 */           event.ammount = 0.0F;
/* 104 */           arrow.getPlayer().addPotionEffect(new PotionEffect(Potion.confusion.id, 250, 255));
/* 105 */           double x1 = arrow.getPlayer().posX;
/* 106 */           double y1 = arrow.getPlayer().posY;
/* 107 */           double z1 = arrow.getPlayer().posZ;
/*     */           
/* 109 */           double x2 = base.posX;
/* 110 */           double y2 = base.posY;
/* 111 */           double z2 = base.posZ;
/* 112 */           if (!(base instanceof EntityPlayer)) {
/* 113 */             arrow.getPlayer().setPositionAndUpdate(x2, y2, z2);
/* 114 */             base.setPosition(x1, y1, z1);
/* 115 */             event.ammount = 0.0F;
/*     */           }
/* 117 */           event.setCanceled(true);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onDeath(LivingDeathEvent event)
/*     */   {
/* 127 */     if ((event.entity instanceof EntityPlayer)) {
/* 128 */       EntityPlayer player = (EntityPlayer)event.entity;
/* 129 */       NBTTagCompound tag = player.getEntityData();
/* 130 */       if (tag.hasKey("contentBackpack")) {
/* 131 */         NBTTagList nbtlist = tag.getTagList("contentBackpack", 10);
/* 132 */         for (int i = 0; i < nbtlist.tagCount(); i++) {
/* 133 */           NBTTagCompound comp1 = nbtlist.getCompoundTagAt(i);
/* 134 */           int slot = comp1.getInteger("Slot");
/* 135 */           ItemStack toDrop = ItemStack.loadItemStackFromNBT(comp1);
/* 136 */           EntityItem entityItem = new EntityItem(player.worldObj, player.posX, player.posY + 1.0D, player.posZ, toDrop);
/*     */           
/* 138 */           player.worldObj.spawnEntityInWorld(entityItem);
/*     */         }
/* 140 */         ItemStack[] content = new ItemStack[54];
/* 141 */         NBTTagList nbtlist2 = new NBTTagList();
/*     */         
/* 143 */         for (int i = 0; i < content.length; i++)
/*     */         {
/* 145 */           if (content[i] != null) {
/* 146 */             NBTTagCompound comp1 = new NBTTagCompound();
/* 147 */             comp1.setInteger("Slot", i);
/* 148 */             content[i].writeToNBT(comp1);
/* 149 */             nbtlist2.appendTag(comp1);
/*     */           }
/*     */         }
/* 152 */         tag.setTag("contentBackpack", nbtlist2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onAttack(AttackEntityEvent event) {
/* 159 */     if (event.entity.worldObj.isRemote) {
/* 160 */       if (EntityCamera.isActive()) {
/* 161 */         event.setCanceled(true);
/* 162 */         return;
/*     */       }
/*     */       
/* 165 */       if (((event.entityLiving instanceof EntityPlayer)) && 
/* 166 */         ((EntityPlayer)event.entityLiving == Minecraft.getMinecraft().thePlayer) && (
/* 167 */         ((EntityPlayer)event.entityLiving == Minecraft.getMinecraft().thePlayer) || 
/* 168 */         (event.entityPlayer == Minecraft.getMinecraft().thePlayer))) {
/* 169 */         timeHurt = System.currentTimeMillis() + 5000L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerMove(LivingEvent.LivingUpdateEvent e) {
/* 176 */     if ((e.entity instanceof EntityPlayer)) {
/* 177 */       EntityPlayer p = (EntityPlayer)e.entity;
/* 178 */       if ((p.getHeldItem() != null) && ((p.getHeldItem().getItem() instanceof ItemCameraTablet)) && 
/* 179 */         (ItemCameraTablet.isWorking(p.getHeldItem())) && (!p.isSneaking()))
/*     */       {
/* 181 */         if (p.worldObj.isRemote) {
/* 182 */           EntityCamera.rotateCamera(p.motionX);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void worldTick(TickEvent.ClientTickEvent event)
/*     */   {
/* 191 */     if ((timeHurt != 0L) && 
/* 192 */       (timeHurt <= System.currentTimeMillis())) {
/* 193 */       timeHurt = 0L;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 198 */   public static final String[] directions = { "Sud", "Ouest", "Nord", "Est" };
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=EventPriority.HIGHEST)
/*     */   public void onOverlay(RenderGameOverlayEvent.Pre event) {
/* 203 */     Minecraft mc = Minecraft.getMinecraft();
/* 204 */     if (event.type == RenderGameOverlayEvent.ElementType.DEBUG) {
/* 205 */       FontRenderer v2 = Minecraft.getMinecraft().fontRenderer;
/*     */       
/* 207 */       v2.drawStringWithShadow("x: " + (int)mc.thePlayer.posX, 30, 30, 
/* 208 */         Keyboard.isKeyDown(19) ? 16711680 : 16777215);
/* 209 */       v2.drawStringWithShadow("y: " + (int)mc.thePlayer.posY, 30, 40, 16777215);
/* 210 */       v2.drawStringWithShadow("z: " + (int)mc.thePlayer.posZ, 30, 50, 
/* 211 */         Keyboard.isKeyDown(19) ? 16711680 : 16777215);
/* 212 */       v2.drawStringWithShadow("yawl: " + (int)mc.thePlayer.rotationYaw, 120, 30, 16777215);
/* 213 */       v2.drawStringWithShadow("pitch: " + ((int)mc.thePlayer.rotationPitch == -90 ? "666" : 
/*     */       
/* 215 */         Integer.valueOf((int)mc.thePlayer.rotationPitch)), 120, 40, 16777215);
/*     */       
/* 217 */       v2.drawStringWithShadow(Minecraft.getMinecraft().debug, 30, 60, 16777215);
/* 218 */       v2.drawStringWithShadow("direction: " + directions[
/* 219 */         (net.minecraft.util.MathHelper.floor_double(
/* 220 */         Minecraft.getMinecraft().thePlayer.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3)], 120, 50, 16777215);
/*     */       
/*     */ 
/*     */ 
/* 223 */       if ((Keyboard.isKeyDown(50)) && (Keyboard.isKeyDown(25))) {
/* 224 */         v2.drawStringWithShadow("Sam54 et HeavenIsALie sont des beau gosses", 50, 100, 16711680);
/*     */       }
/* 226 */       event.setCanceled(true);
/*     */     }
/*     */     
/* 229 */     if (event.type == RenderGameOverlayEvent.ElementType.DEBUG) {
/* 230 */       FontRenderer v2 = Minecraft.getMinecraft().fontRenderer;
/*     */       
/* 232 */       v2.drawStringWithShadow("x: " + (int)mc.thePlayer.posX, 30, 30, 
/* 233 */         Keyboard.isKeyDown(19) ? 16711680 : 16777215);
/* 234 */       v2.drawStringWithShadow("y: " + (int)mc.thePlayer.posY, 30, 40, 16777215);
/* 235 */       v2.drawStringWithShadow("z: " + (int)mc.thePlayer.posZ, 30, 50, 
/* 236 */         Keyboard.isKeyDown(19) ? 16711680 : 16777215);
/* 237 */       v2.drawStringWithShadow("yawl: " + (int)mc.thePlayer.rotationYaw, 120, 30, 16777215);
/* 238 */       v2.drawStringWithShadow("pitch: " + ((int)mc.thePlayer.rotationPitch == -90 ? "666" : 
/*     */       
/* 240 */         Integer.valueOf((int)mc.thePlayer.rotationPitch)), 120, 40, 16777215);
/*     */       
/* 242 */       v2.drawStringWithShadow(Minecraft.getMinecraft().debug, 30, 60, 16777215);
/* 243 */       v2.drawStringWithShadow("direction: " + directions[
/* 244 */         (net.minecraft.util.MathHelper.floor_double(
/* 245 */         Minecraft.getMinecraft().thePlayer.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3)], 120, 50, 16777215);
/*     */       
/*     */ 
/*     */ 
/* 248 */       if ((Keyboard.isKeyDown(50)) && (Keyboard.isKeyDown(25))) {
/* 249 */         v2.drawStringWithShadow("Sam54 et HeavenIsALie sont des beau gosses", 50, 100, 16711680);
/*     */       }
/* 251 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=EventPriority.HIGHEST)
/*     */   public void initGui(GuiScreenEvent.InitGuiEvent v1) {
/* 258 */     Minecraft mc = Minecraft.getMinecraft();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int[] v3;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */     if ((v1.gui instanceof fr.paladium.palamod.client.gui.custom.GuiMainMenu))
/*     */     {
/* 298 */       GuiScreen v2 = v1.gui;
/* 299 */       v3 = new int[] { mc.getSession().getToken() == "FML" ? -1 : 1, 14, 6, 2 };
/* 300 */       for (Object o : v1.buttonList) {
/* 301 */         GuiButtonPala v4 = (GuiButtonPala)o;
/* 302 */         for (v : v3) {
/* 303 */           if (v == v4.id)
/* 304 */             v4.visible = false;
/*     */         }
/* 306 */         for (??? = v1.buttonList.iterator(); ((Iterator)???).hasNext();) { Object o1 = ((Iterator)???).next();
/* 307 */           GuiButtonPala btn1 = (GuiButtonPala)o1;
/* 308 */           for (int v : v3) {
/* 309 */             if (v == btn1.id) {
/* 310 */               btn1.visible = false;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int v;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onClick(PlayerInteractEvent e)
/*     */   {
/* 344 */     EntityPlayer player = e.entityPlayer;
/* 345 */     if ((e.action == PlayerInteractEvent.Action.LEFT_CLICK_BLOCK) && (player.isSneaking()) && 
/* 346 */       (player.getHeldItem() != null) && ((player.getHeldItem().getItem() instanceof fr.paladium.palamod.items.ItemChestExplorer))) {
/* 347 */       e.setCanceled(true);
/*     */     }
/* 349 */     if ((e.action == PlayerInteractEvent.Action.RIGHT_CLICK_AIR) && 
/* 350 */       (player.getHeldItem() != null) && (player.getHeldItem().equals(new ItemStack(DecorativeRegister.INVISIBLE_BLOCK)))) {
/* 351 */       DecorativeRegister.INVISIBLE_BLOCK.setBlockTextureName("palamod:InvisibleBlock_Crea");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 356 */   private static long v2 = 0L;
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=EventPriority.HIGHEST)
/*     */   public void onAction(GuiScreenEvent.ActionPerformedEvent v1) {
/* 361 */     if ((v1.gui instanceof GuiShareToLan))
/* 362 */       v1.gui.mc.shutdown();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   @SubscribeEvent(priority=EventPriority.HIGHEST)
/*     */   public void openGuiEvent(GuiOpenEvent v1) {
/* 368 */     if ((v1.gui instanceof cpw.mods.fml.client.GuiIngameModOptions)) {
/* 369 */       v1.setCanceled(true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */     if ((v1.gui instanceof net.minecraft.client.gui.GuiMainMenu))
/*     */     {
/* 385 */       v1.gui = new fr.paladium.palamod.client.gui.custom.GuiMainMenu();
/*     */     }
/* 387 */     if ((v1.gui instanceof GuiIngameMenu)) {
/* 388 */       v1.gui = new GuiIngameMenu() {
/* 389 */         private int counter = 0;
/*     */         
/*     */         protected void actionPerformed(GuiButton v2)
/*     */         {
/* 393 */           if (v2.id == 12) {
/*     */             try {
/* 395 */               Desktop.getDesktop().browse(new java.net.URI("ts3server://ts.paladium-pvp.fr/?nickname=" + 
/* 396 */                 Minecraft.getMinecraft().getSession().getUsername()));
/*     */             } catch (Exception e) {
/* 398 */               e.printStackTrace();
/*     */             }
/*     */           } else {
/* 401 */             super.actionPerformed(v2);
/*     */           }
/*     */         }
/*     */         
/*     */         public void initGui() {
/* 406 */           super.initGui();
/* 407 */           GuiButton v3 = (GuiButton)this.buttonList.get(0);
/* 408 */           v3.displayString = "(Patientez 5 secondes)";
/* 409 */           v3.enabled = false;
/* 410 */           GuiButton v4 = (GuiButton)this.buttonList.get(3);
/* 411 */           v4.displayString = "Teamspeak";
/*     */         }
/*     */         
/*     */         public void updateScreen()
/*     */         {
/* 416 */           super.updateScreen();
/* 417 */           GuiButton v3 = (GuiButton)this.buttonList.get(0);
/* 418 */           this.counter += 1;
/* 419 */           if (this.counter < 20) {
/* 420 */             v3.displayString = "(Patientez 5 secondes)";
/* 421 */             v3.enabled = false;
/* 422 */           } else if ((this.counter > 20) && (this.counter < 40)) {
/* 423 */             v3.displayString = "(Patientez 4 secondes)";
/* 424 */             v3.enabled = false;
/* 425 */           } else if ((this.counter > 40) && (this.counter < 60)) {
/* 426 */             v3.displayString = "(Patientez 3 secondes)";
/* 427 */             v3.enabled = false;
/* 428 */           } else if ((this.counter > 60) && (this.counter < 80)) {
/* 429 */             v3.displayString = "(Patientez 2 secondes)";
/* 430 */             v3.enabled = false;
/* 431 */           } else if ((this.counter > 80) && (this.counter < 100)) {
/* 432 */             v3.displayString = "(Patientez 1 secondes)";
/* 433 */             v3.enabled = false;
/* 434 */           } else if (this.counter > 100) {
/* 435 */             v3.displayString = net.minecraft.client.resources.I18n.format("menu.disconnect", new Object[0]);
/* 436 */             v3.enabled = true;
/*     */           }
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onBucketFill(FillBucketEvent event)
/*     */   {
/* 447 */     ItemStack result = fillCustomBucket(event.world, event.target, event.entityPlayer);
/*     */     
/* 449 */     if (result == null) {
/* 450 */       return;
/*     */     }
/* 452 */     event.result = result;
/* 453 */     event.setResult(cpw.mods.fml.common.eventhandler.Event.Result.ALLOW);
/*     */   }
/*     */   
/*     */   private ItemStack fillCustomBucket(World world, MovingObjectPosition pos, EntityPlayer player)
/*     */   {
/* 458 */     Block block = world.getBlock(pos.blockX, pos.blockY, pos.blockZ);
/*     */     
/* 460 */     if (!player.canHarvestBlock(block)) {
/* 461 */       return null;
/*     */     }
/* 463 */     Item bucket = (Item)buckets.get(block);
/* 464 */     if ((bucket != null) && (world.getBlockMetadata(pos.blockX, pos.blockY, pos.blockZ) == 0)) {
/* 465 */       world.setBlockToAir(pos.blockX, pos.blockY, pos.blockZ);
/* 466 */       return new ItemStack(bucket);
/*     */     }
/* 468 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onJoin(EntityJoinWorldEvent event)
/*     */   {
/* 475 */     if (!(event.entity instanceof EntityPlayer))
/* 476 */       return;
/* 477 */     EntityPlayer entityPlayer = (EntityPlayer)event.entity;
/* 478 */     if (BossHandler.check()) {
/* 479 */       PacketMessageBoss packet = new PacketMessageBoss();
/* 480 */       packet.addInformations(BossHandler.x, BossHandler.z, (byte)0, BossHandler.time);
/* 481 */       CommonProxy.packetPipeline.sendTo(packet, (net.minecraft.entity.player.EntityPlayerMP)event.entity);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTick(TickEvent.ServerTickEvent event) {
/* 487 */     if (event.phase == TickEvent.Phase.END)
/* 488 */       BossHandler.tick();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onItemToolTip(ItemTooltipEvent event) {
/* 493 */     if (((event.itemStack.getItem() == Item.getItemFromBlock(PaladiumRegister.UPGRADED_OBSIDIAN)) || 
/* 494 */       (event.itemStack.getItem() == Item.getItemFromBlock(Blocks.obsidian))) && 
/* 495 */       (event.itemStack.hasTagCompound())) {
/* 496 */       NBTTagCompound compound = event.itemStack.getTagCompound();
/* 497 */       if (compound.getBoolean("Explode"))
/* 498 */         event.toolTip.add(EnumChatFormatting.DARK_PURPLE + "Explode");
/* 499 */       if (compound.getBoolean("Fake"))
/* 500 */         event.toolTip.add(EnumChatFormatting.DARK_PURPLE + "Fake");
/* 501 */       if (compound.getBoolean("TwoLife"))
/* 502 */         event.toolTip.add(EnumChatFormatting.DARK_PURPLE + "TwoLifes");
/* 503 */       if (compound.getBoolean("Camouflage")) {
/* 504 */         event.toolTip.add(EnumChatFormatting.DARK_PURPLE + "Camouflage");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onEntityInteractEvent(EntityInteractEvent event) {
/* 511 */     if ((event.entityPlayer.getHeldItem() == null) || 
/* 512 */       (!(event.entityPlayer.getHeldItem().getItem() instanceof fr.paladium.palamod.items.ItemWitherUnSummoner)))
/* 513 */       return;
/* 514 */     if (event.entityPlayer.capabilities.isCreativeMode) {
/* 515 */       if (((event.target instanceof EntityCustomWither)) || ((event.target instanceof EntityWither))) {
/* 516 */         event.target.setRotationYawHead(0.0F);
/* 517 */         event.target.setDead();
/*     */       }
/*     */     }
/* 520 */     else if (((event.target instanceof EntityCustomWither)) && 
/* 521 */       (((EntityCustomWither)event.target).getWitherData().remote)) {
/* 522 */       event.target.setRotationYawHead(0.0F);
/* 523 */       event.target.setDead();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @SubscribeEvent
/*     */   public void onEntityHurt(LivingHurtEvent event)
/*     */   {
/* 531 */     EntityLivingBase entityLiving = event.entityLiving;
/*     */     
/* 533 */     if ((entityLiving instanceof EntityCustomWither)) {
/* 534 */       WitherData witherData = ((EntityCustomWither)entityLiving).getWitherData();
/* 535 */       if ((event.source.isExplosion()) && (witherData.explosion != 0)) {
/* 536 */         switch (witherData.explosion) {
/*     */         default: 
/*     */           break;
/*     */         case 1: 
/* 540 */           event.ammount /= 2.0F;
/* 541 */           break;
/*     */         case 2: 
/* 543 */           event.ammount /= 10.0F;
/*     */         }
/*     */         
/*     */       }
/* 547 */       if ((event.source == DamageSource.anvil) && (witherData.anvil != 0)) {
/* 548 */         switch (witherData.anvil) {
/*     */         default: 
/*     */           break;
/*     */         case 1: 
/* 552 */           event.ammount /= 2.0F;
/* 553 */           break;
/*     */         case 2: 
/* 555 */           event.ammount = 0.0F;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onExplode(ExplosionEvent event)
/*     */   {
/* 565 */     Explosion explosion = event.explosion;
/* 566 */     if ((explosion.getExplosivePlacedBy() != null) && ((explosion.getExplosivePlacedBy() instanceof EntityWither)))
/* 567 */       return;
/* 568 */     double x = explosion.explosionX;
/* 569 */     double y = explosion.explosionY;
/* 570 */     double z = explosion.explosionZ;
/*     */     
/* 572 */     List e = event.world.getEntitiesWithinAABB(EntityGuardianGolem.class, 
/* 573 */       net.minecraft.util.AxisAlignedBB.getBoundingBox(x - 6.0D, y - 6.0D, z - 6.0D, x + 6.0D, y + 6.0D, z + 6.0D));
/* 574 */     if (e.size() != 0) {
/* 575 */       EntityGuardianGolem golem = (EntityGuardianGolem)e.get(0);
/* 576 */       if ((golem == null) || (!fr.paladium.palamod.util.GuardianHelper.hasUpgrade(golem, 16)))
/* 577 */         return;
/* 578 */       explosion.explosionSize = 0.0F;
/*     */       
/* 580 */       Minecraft.getMinecraft().getIntegratedServer().worldServerForDimension(golem.dimension)
/* 581 */         .func_147487_a("explode", golem.posX, golem.posY, golem.posZ, 32, 0.0D, 0.0D, 0.0D, 1.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onJump(LivingEvent.LivingJumpEvent event)
/*     */   {
/* 588 */     if (((event.entityLiving instanceof EntityCustomWither)) && 
/* 589 */       (((EntityCustomWither)event.entityLiving).getWitherData().nofly)) {
/* 590 */       ((EntityCustomWither)event.entityLiving).motionY += 0.25D;
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void FarmerDropHandler(BlockEvent.BreakEvent event)
/*     */   {
/* 597 */     JobsXPManager jobsXPManager = (JobsXPManager)ModJobs.allJobsXpManager.get(event.getPlayer().getUniqueID().toString());
/* 598 */     int lvl = ((Job)ModJobs.jobs.get(Integer.valueOf(2))).getLevel(jobsXPManager.getXP(2));
/* 599 */     if ((event.world.getBlock(event.x, event.y, event.z) != null) && (event.world.getBlock(event.x, event.y, event.z).equals(Blocks.tallgrass))) {
/* 600 */       int random1 = (int)(Math.random() * 10000.0D);
/* 601 */       int random2 = (int)(Math.random() * 10000.0D);
/* 602 */       int random3 = (int)(Math.random() * 10000.0D);
/* 603 */       int random4 = (int)(Math.random() * 10000.0D);
/* 604 */       if ((random1 <= 2000) && 
/* 605 */         (lvl >= 5)) {
/* 606 */         event.world.spawnEntityInWorld(new EntityItem(event.world, event.x, event.y, event.z, new ItemStack(WorldRegister.EGGPLANT_SEED, 1, 0)));
/*     */       }
/*     */       
/*     */ 
/* 610 */       if ((random2 <= 2000) && 
/* 611 */         (lvl >= 10)) {
/* 612 */         event.world.spawnEntityInWorld(new EntityItem(event.world, event.x, event.y, event.z, new ItemStack(WorldRegister.CHERVIL_SEED, 1, 0)));
/*     */       }
/*     */       
/*     */ 
/* 616 */       if ((random3 <= 25) && 
/* 617 */         (lvl >= 15)) {
/* 618 */         event.world.spawnEntityInWorld(new EntityItem(event.world, event.x, event.y, event.z, new ItemStack(WorldRegister.KIWANO_SEED, 1, 0)));
/*     */       }
/*     */       
/*     */ 
/* 622 */       if ((random4 <= 5) && 
/* 623 */         (lvl >= 20)) {
/* 624 */         event.world.spawnEntityInWorld(new EntityItem(event.world, event.x, event.y, event.z, new ItemStack(WorldRegister.ORANGEBLUE_SEED, 1, 0)));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\EventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */