/*    */ package fr.paladium.palamod.common.inventory;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InventoryGuardianWeapon
/*    */   implements IInventory
/*    */ {
/*    */   public int getSizeInventory()
/*    */   {
/* 18 */     return 1;
/*    */   }
/*    */   
/*    */   public ItemStack getStackInSlot(int slot)
/*    */   {
/* 23 */     return null;
/*    */   }
/*    */   
/*    */   public ItemStack decrStackSize(int slotIndex, int amount)
/*    */   {
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*    */   {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setInventorySlotContents(int slotIndex, ItemStack stack) {}
/*    */   
/*    */ 
/*    */   public String getInventoryName()
/*    */   {
/* 43 */     return "Inventory.Dummy";
/*    */   }
/*    */   
/*    */   public boolean hasCustomInventoryName()
/*    */   {
/* 48 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getInventoryStackLimit()
/*    */   {
/* 54 */     return 64;
/*    */   }
/*    */   
/*    */ 
/*    */   public void markDirty() {}
/*    */   
/*    */ 
/*    */   public boolean isUseableByPlayer(EntityPlayer player)
/*    */   {
/* 63 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void openInventory() {}
/*    */   
/*    */ 
/*    */   public void closeInventory() {}
/*    */   
/*    */ 
/*    */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*    */   {
/* 76 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\inventory\InventoryGuardianWeapon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */