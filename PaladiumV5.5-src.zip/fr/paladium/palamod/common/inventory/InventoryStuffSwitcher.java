/*     */ package fr.paladium.palamod.common.inventory;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ public class InventoryStuffSwitcher implements IInventory
/*     */ {
/*     */   ItemStack[] content;
/*     */   
/*     */   public InventoryStuffSwitcher(ItemStack item)
/*     */   {
/*  15 */     this.content = new ItemStack[4];
/*  16 */     if (!item.hasTagCompound()) item.setTagCompound(new NBTTagCompound());
/*  17 */     readFromNBT(item.getTagCompound());
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  22 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  27 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  32 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  35 */       if (this.content[slotIndex].stackSize <= amount) {
/*  36 */         ItemStack itemstack = this.content[slotIndex];
/*  37 */         this.content[slotIndex] = null;
/*  38 */         markDirty();
/*  39 */         return itemstack;
/*     */       }
/*  41 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  43 */       if (this.content[slotIndex].stackSize == 0) {
/*  44 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  47 */       markDirty();
/*  48 */       return itemstack;
/*     */     }
/*     */     
/*  51 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  57 */     if (this.content[slotIndex] != null) {
/*  58 */       ItemStack itemstack = this.content[slotIndex];
/*  59 */       this.content[slotIndex] = null;
/*  60 */       return itemstack;
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  68 */     this.content[slotIndex] = stack;
/*     */     
/*  70 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  71 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  74 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  79 */     return "Item.Backpack";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  84 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/*  89 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/*  98 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 111 */     return true;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound comp) {
/* 115 */     NBTTagList nbtlist = comp.getTagList("Inventory", 10);
/*     */     
/* 117 */     for (int i = 0; i < nbtlist.tagCount(); i++) {
/* 118 */       NBTTagCompound comp1 = nbtlist.getCompoundTagAt(i);
/* 119 */       int slot = comp1.getInteger("Slot");
/* 120 */       this.content[slot] = ItemStack.loadItemStackFromNBT(comp1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound comp) {
/* 125 */     NBTTagList nbtlist = new NBTTagList();
/*     */     
/* 127 */     for (int i = 0; i < this.content.length; i++) {
/* 128 */       if (this.content[i] != null) {
/* 129 */         NBTTagCompound comp1 = new NBTTagCompound();
/* 130 */         comp1.setInteger("Slot", i);
/* 131 */         this.content[i].writeToNBT(comp1);
/* 132 */         nbtlist.appendTag(comp1);
/*     */       }
/*     */     }
/* 135 */     comp.setTag("Inventory", nbtlist);
/*     */   }
/*     */   
/*     */   public void switchStuff(EntityPlayer player) {
/* 139 */     ItemStack[] oldContent = (ItemStack[])this.content.clone();
/* 140 */     for (int i = 0; i < 4; i++) {
/* 141 */       if (this.content[i] != null) {
/* 142 */         this.content[i] = player.getCurrentArmor(3 - i);
/* 143 */         player.setCurrentItemOrArmor(4 - i, oldContent[i]);
/* 144 */         writeToNBT(player.getHeldItem().getTagCompound());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\inventory\InventoryStuffSwitcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */