/*     */ package fr.paladium.palamod.common.inventory;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ public class InventoryBackpack implements IInventory
/*     */ {
/*     */   ItemStack[] content;
/*     */   
/*     */   public InventoryBackpack(EntityPlayer player)
/*     */   {
/*  16 */     this.content = new ItemStack[54];
/*  17 */     readFromNBT(player.getEntityData());
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  22 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  27 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  32 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  35 */       if (this.content[slotIndex].stackSize <= amount) {
/*  36 */         ItemStack itemstack = this.content[slotIndex];
/*  37 */         this.content[slotIndex] = null;
/*  38 */         markDirty();
/*  39 */         return itemstack;
/*     */       }
/*  41 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  43 */       if (this.content[slotIndex].stackSize == 0) {
/*  44 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  47 */       markDirty();
/*  48 */       return itemstack;
/*     */     }
/*     */     
/*  51 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  57 */     if (this.content[slotIndex] != null) {
/*  58 */       ItemStack itemstack = this.content[slotIndex];
/*  59 */       this.content[slotIndex] = null;
/*  60 */       return itemstack;
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  68 */     this.content[slotIndex] = stack;
/*     */     
/*  70 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  71 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  74 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  79 */     return "Item.Backpack";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  84 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getInventoryStackLimit()
/*     */   {
/*  90 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound comp) {
/* 116 */     NBTTagList nbtlist = comp.getTagList("contentBackpack", 10);
/*     */     
/* 118 */     for (int i = 0; i < nbtlist.tagCount(); i++) {
/* 119 */       NBTTagCompound comp1 = nbtlist.getCompoundTagAt(i);
/* 120 */       int slot = comp1.getInteger("Slot");
/* 121 */       this.content[slot] = ItemStack.loadItemStackFromNBT(comp1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound comp) {
/* 126 */     NBTTagList nbtlist = new NBTTagList();
/*     */     
/* 128 */     for (int i = 0; i < this.content.length; i++) {
/* 129 */       if (this.content[i] != null) {
/* 130 */         NBTTagCompound comp1 = new NBTTagCompound();
/* 131 */         comp1.setInteger("Slot", i);
/* 132 */         this.content[i].writeToNBT(comp1);
/* 133 */         nbtlist.appendTag(comp1);
/*     */       }
/*     */     }
/* 136 */     System.out.println("aa");
/* 137 */     comp.setTag("contentBackpack", nbtlist);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\inventory\InventoryBackpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */