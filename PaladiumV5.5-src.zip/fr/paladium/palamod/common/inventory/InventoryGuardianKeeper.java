/*     */ package fr.paladium.palamod.common.inventory;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ 
/*     */ public class InventoryGuardianKeeper implements net.minecraft.inventory.IInventory
/*     */ {
/*     */   ItemStack[] content;
/*     */   
/*     */   public InventoryGuardianKeeper()
/*     */   {
/*  13 */     this.content = new ItemStack[1];
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  18 */     return 1;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  23 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  28 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  31 */       if (this.content[slotIndex].stackSize <= amount) {
/*  32 */         ItemStack itemstack = this.content[slotIndex];
/*  33 */         this.content[slotIndex] = null;
/*  34 */         markDirty();
/*  35 */         return itemstack;
/*     */       }
/*  37 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  39 */       if (this.content[slotIndex].stackSize == 0) {
/*  40 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  43 */       markDirty();
/*  44 */       return itemstack;
/*     */     }
/*     */     
/*  47 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  53 */     if (this.content[slotIndex] != null) {
/*  54 */       ItemStack itemstack = this.content[slotIndex];
/*  55 */       this.content[slotIndex] = null;
/*  56 */       return itemstack;
/*     */     }
/*  58 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  64 */     this.content[slotIndex] = stack;
/*     */     
/*  66 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  67 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  70 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  75 */     return "TileEntity.GuardianKeeper";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  80 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getInventoryStackLimit()
/*     */   {
/*  86 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/*  95 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound comp) {}
/*     */   
/*     */   public void writeToNBT(NBTTagCompound comp) {}
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\inventory\InventoryGuardianKeeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */