/*     */ package fr.paladium.palamod.common.inventory;
/*     */ 
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ 
/*     */ public class InventoryGuardianChest
/*     */   implements IInventory
/*     */ {
/*     */   ItemStack[] content;
/*     */   
/*     */   public InventoryGuardianChest(EntityGuardianGolem golem)
/*     */   {
/*  17 */     this.content = new ItemStack[27];
/*  18 */     readFromNBT(golem.getEntityData());
/*     */   }
/*     */   
/*     */   public int getSizeInventory()
/*     */   {
/*  23 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  28 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  33 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*  36 */       if (this.content[slotIndex].stackSize <= amount) {
/*  37 */         ItemStack itemstack = this.content[slotIndex];
/*  38 */         this.content[slotIndex] = null;
/*  39 */         markDirty();
/*  40 */         return itemstack;
/*     */       }
/*  42 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  44 */       if (this.content[slotIndex].stackSize == 0) {
/*  45 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  48 */       markDirty();
/*  49 */       return itemstack;
/*     */     }
/*     */     
/*  52 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  58 */     if (this.content[slotIndex] != null) {
/*  59 */       ItemStack itemstack = this.content[slotIndex];
/*  60 */       this.content[slotIndex] = null;
/*  61 */       return itemstack;
/*     */     }
/*  63 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/*  69 */     this.content[slotIndex] = stack;
/*     */     
/*  71 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/*  72 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/*  75 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/*  80 */     return "Guardian.Chest";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/*  85 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getInventoryStackLimit()
/*     */   {
/*  91 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 100 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound comp) {
/* 117 */     NBTTagList nbtlist = comp.getTagList("contentChest", 10);
/*     */     
/* 119 */     for (int i = 0; i < nbtlist.tagCount(); i++) {
/* 120 */       NBTTagCompound comp1 = nbtlist.getCompoundTagAt(i);
/* 121 */       int slot = comp1.getInteger("Slot");
/* 122 */       this.content[slot] = ItemStack.loadItemStackFromNBT(comp1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeToNBT(NBTTagCompound comp) {
/* 127 */     NBTTagList nbtlist = new NBTTagList();
/*     */     
/* 129 */     for (int i = 0; i < this.content.length; i++) {
/* 130 */       if (this.content[i] != null) {
/* 131 */         NBTTagCompound comp1 = new NBTTagCompound();
/* 132 */         comp1.setInteger("Slot", i);
/* 133 */         this.content[i].writeToNBT(comp1);
/* 134 */         nbtlist.appendTag(comp1);
/*     */       }
/*     */     }
/* 137 */     comp.setTag("contentChest", nbtlist);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\inventory\InventoryGuardianChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */