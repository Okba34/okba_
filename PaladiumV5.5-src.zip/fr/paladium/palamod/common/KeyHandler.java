/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.common.gameevent.InputEvent.KeyInputEvent;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*    */ import fr.paladium.palamod.proxy.ClientProxy;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.entity.player.PlayerCapabilities;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onKeyEvent(InputEvent.KeyInputEvent event)
/*    */   {
/* 24 */     Minecraft mc = Minecraft.getMinecraft();
/* 25 */     if (ClientProxy.BACKPACK_KEY.getIsKeyPressed())
/*    */     {
/* 27 */       PacketOpenGui p = new PacketOpenGui();
/* 28 */       p.setInformations((byte)8);
/* 29 */       CommonProxy.packetPipeline.sendToServer(p);
/*    */     }
/* 31 */     else if (ClientProxy.NEXT_CAMERA_KEY.getIsKeyPressed())
/*    */     {
/* 33 */       ItemStack stack = mc.thePlayer.getHeldItem();
/* 34 */       if (stack != null)
/*    */       {
/* 36 */         if (!stack.hasTagCompound())
/*    */         {
/* 38 */           stack.setTagCompound(new NBTTagCompound());
/* 39 */           stack.getTagCompound().setInteger("Index", 0);
/*    */         }
/*    */         
/* 42 */         NBTTagCompound compound = stack.getTagCompound();
/* 43 */         int index = compound.getInteger("Index");
/* 44 */         index++;
/* 45 */         if (index > 2) {
/* 46 */           index = 0;
/*    */         }
/* 48 */         compound.setInteger("Index", index);
/* 49 */         mc.thePlayer.getHeldItem().setTagCompound(compound);
/*    */       }
/*    */     }
/* 52 */     if (!Minecraft.getMinecraft().thePlayer.capabilities.isCreativeMode) {
/* 53 */       if (Minecraft.getMinecraft().gameSettings.keyBindInventory.isPressed())
/*    */       {
/* 55 */         PacketOpenGui packet = new PacketOpenGui();
/* 56 */         packet.setInformations((byte)40);
/* 57 */         CommonProxy.packetPipeline.sendToServer(packet);
/*    */       }
/* 59 */       return;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\KeyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */