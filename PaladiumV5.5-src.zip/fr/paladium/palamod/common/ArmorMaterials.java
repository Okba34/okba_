/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ import net.minecraft.item.ItemArmor.ArmorMaterial;
/*    */ 
/*    */ public class ArmorMaterials
/*    */ {
/*    */   public static ItemArmor.ArmorMaterial armorPaladium;
/*    */   public static ItemArmor.ArmorMaterial armorTitane;
/*    */   public static ItemArmor.ArmorMaterial armorAmethyst;
/*    */   public static ItemArmor.ArmorMaterial armorEndium;
/*    */   
/*    */   public static void init()
/*    */   {
/* 14 */     armorPaladium = net.minecraftforge.common.util.EnumHelper.addArmorMaterial("paladiumArmor", 320, new int[] { 4, 7, 5, 6 }, 21);
/* 15 */     armorTitane = net.minecraftforge.common.util.EnumHelper.addArmorMaterial("titaneArmor", 190, new int[] { 3, 7, 6, 3 }, 19);
/* 16 */     armorAmethyst = net.minecraftforge.common.util.EnumHelper.addArmorMaterial("amethystArmor", 160, new int[] { 3, 7, 6, 3 }, 21);
/* 17 */     armorEndium = net.minecraftforge.common.util.EnumHelper.addArmorMaterial("endiumArmor", 370, new int[] { 4, 7, 5, 6 }, 30);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\ArmorMaterials.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */