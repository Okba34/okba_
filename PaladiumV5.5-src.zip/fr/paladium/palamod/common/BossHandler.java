/*    */ package fr.paladium.palamod.common;
/*    */ 
/*    */ 
/*    */ public class BossHandler
/*    */ {
/*    */   public static long ms;
/*    */   public static long tick;
/*    */   public static int time;
/*    */   public static int x;
/*    */   public static int z;
/*    */   
/*    */   public static void reset()
/*    */   {
/* 14 */     ms = 0L;
/*    */   }
/*    */   
/*    */   public static void enable(int time, int x, int z) {
/* 18 */     ms = System.currentTimeMillis() + time * 1000L;
/* 19 */     time = time;
/* 20 */     x = x;
/* 21 */     z = z;
/*    */   }
/*    */   
/*    */   public static boolean check() {
/*    */     boolean flag;
/* 26 */     if ((System.currentTimeMillis() >= ms) && (ms != 0L)) {
/* 27 */       boolean flag = false;
/* 28 */       reset();
/*    */     } else { boolean flag;
/* 30 */       if (ms == 0L) {
/* 31 */         flag = false;
/*    */       } else
/* 33 */         flag = true;
/*    */     }
/* 35 */     return flag;
/*    */   }
/*    */   
/*    */   public static void tick() {
/* 39 */     if (ms == 0L)
/* 40 */       return;
/* 41 */     if (tick <= System.currentTimeMillis()) {
/* 42 */       time -= 1;
/* 43 */       tick = System.currentTimeMillis() + 1000L;
/* 44 */       if (time <= 0) {
/* 45 */         reset();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\common\BossHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */