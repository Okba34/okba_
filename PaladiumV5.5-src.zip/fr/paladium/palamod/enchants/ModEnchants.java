/*    */ package fr.paladium.palamod.enchants;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ 
/*    */ public class ModEnchants
/*    */ {
/*    */   static Enchantment deathBringer;
/*    */   static Enchantment witherHunter;
/*    */   static Enchantment implants;
/*    */   
/*    */   public static void init() {
/* 12 */     deathBringer = new EnchantDeathbringer(200, 4);
/* 13 */     witherHunter = new EnchantWither(202, 2);
/* 14 */     implants = new EnchantImplants(203, 4);
/*    */     
/* 16 */     Enchantment.addToBookList(deathBringer);
/* 17 */     Enchantment.addToBookList(witherHunter);
/* 18 */     Enchantment.addToBookList(implants);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\enchants\ModEnchants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */