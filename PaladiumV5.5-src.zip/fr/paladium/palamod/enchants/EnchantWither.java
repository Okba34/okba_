/*    */ package fr.paladium.palamod.enchants;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ 
/*    */ public class EnchantWither extends Enchantment
/*    */ {
/*    */   protected EnchantWither(int id, int weight)
/*    */   {
/*  9 */     super(id, weight, net.minecraft.enchantment.EnumEnchantmentType.armor);
/* 10 */     setName("witherhunter");
/*    */   }
/*    */   
/*    */   public int getMinEnchantability(int par1)
/*    */   {
/* 15 */     return 5;
/*    */   }
/*    */   
/*    */   public int getMinLevel()
/*    */   {
/* 20 */     return 1;
/*    */   }
/*    */   
/*    */   public int getMaxLevel()
/*    */   {
/* 25 */     return 4;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\enchants\EnchantWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */