/*    */ package fr.paladium.palamod.enchants;
/*    */ 
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ 
/*    */ public class EnchantDeathbringer extends Enchantment
/*    */ {
/*    */   protected EnchantDeathbringer(int id, int weight)
/*    */   {
/*  9 */     super(id, weight, net.minecraft.enchantment.EnumEnchantmentType.weapon);
/* 10 */     setName("deathbringer");
/*    */   }
/*    */   
/*    */   public int getMinEnchantability(int par1)
/*    */   {
/* 15 */     return 13;
/*    */   }
/*    */   
/*    */   public int getMinLevel()
/*    */   {
/* 20 */     return 1;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getMaxLevel()
/*    */   {
/* 26 */     return 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\enchants\EnchantDeathbringer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */