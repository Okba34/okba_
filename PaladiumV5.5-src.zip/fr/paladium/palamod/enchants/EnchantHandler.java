/*    */ package fr.paladium.palamod.enchants;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import java.util.Map;
/*    */ import java.util.Random;
/*    */ import net.minecraft.enchantment.Enchantment;
/*    */ import net.minecraft.enchantment.EnchantmentHelper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.boss.EntityWither;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.event.entity.living.LivingHurtEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnchantHandler
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onMobDamage(LivingHurtEvent event)
/*    */   {
/* 27 */     if ((event.entityLiving != null) && (!event.entityLiving.worldObj.isRemote) && (event.source != null) && 
/* 28 */       (event.source.getSourceOfDamage() != null))
/*    */     {
/* 30 */       Entity player = event.source.getSourceOfDamage();
/* 31 */       EntityLivingBase victim = event.entityLiving;
/*    */       
/* 33 */       if ((player instanceof EntityPlayer)) {
/* 34 */         ItemStack currentItem = ((EntityPlayer)player).getCurrentEquippedItem();
/* 35 */         weaponEnchants((EntityPlayer)player, victim, currentItem, event);
/*    */       }
/*    */       
/* 38 */       if ((victim instanceof EntityPlayer)) {
/* 39 */         armorEnchants((EntityPlayer)victim, player, event);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private void armorEnchants(EntityPlayer player, Entity attacker, LivingHurtEvent event)
/*    */   {
/* 47 */     int wither = countEnchantLevels(player, ModEnchants.witherHunter.effectId);
/* 48 */     if ((wither > 0) && ((attacker instanceof EntityWither))) {
/* 49 */       event.ammount /= wither;
/*    */     }
/*    */     
/* 52 */     int implants = countEnchantLevels(player, ModEnchants.implants.effectId);
/* 53 */     if (implants > 0) {
/* 54 */       Random rand = player.worldObj.rand;
/* 55 */       if (rand.nextInt(150) >= 149 - implants) {
/* 56 */         if (event.ammount > 7.0F)
/* 57 */           player.heal(2.0F);
/* 58 */         event.ammount = 0.0F;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private void weaponEnchants(EntityPlayer player, EntityLivingBase mob, ItemStack currentItem, LivingHurtEvent event)
/*    */   {
/* 66 */     if (currentItem != null)
/*    */     {
/*    */ 
/*    */ 
/* 70 */       if (EnchantmentHelper.getEnchantmentLevel(ModEnchants.deathBringer.effectId, currentItem) > 0) {
/* 71 */         int enchLevel = EnchantmentHelper.getEnchantmentLevel(ModEnchants.deathBringer.effectId, currentItem);
/* 72 */         Random rand = player.worldObj.rand;
/* 73 */         if (rand.nextInt(15) >= 14 - enchLevel) {
/* 74 */           event.ammount *= 2.0F;
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static int countEnchantLevels(EntityPlayer player, int enchant) {
/* 81 */     if (player != null) {
/* 82 */       int count = 0;
/* 83 */       for (ItemStack stack : player.inventory.armorInventory) {
/* 84 */         if (stack != null) {
/* 85 */           Map<Integer, Integer> enchantments = EnchantmentHelper.getEnchantments(stack);
/* 86 */           Integer ench = (Integer)enchantments.get(Integer.valueOf(enchant));
/* 87 */           if (ench != null) {
/* 88 */             count += ench.intValue();
/*    */           }
/*    */         }
/*    */       }
/* 92 */       return count;
/*    */     }
/* 94 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\enchants\EnchantHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */