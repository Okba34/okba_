/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PacketGolem
/*    */   extends AbstractPacket
/*    */ {
/*    */   int level;
/*    */   int subLevel;
/*    */   int id;
/*    */   ItemStack weapon;
/*    */   
/*    */   public void addInformations(int level, int subLevel, int id, ItemStack weapon)
/*    */   {
/* 22 */     this.level = level;
/* 23 */     this.subLevel = subLevel;
/* 24 */     this.id = id;
/* 25 */     this.weapon = weapon;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 30 */     buffer.writeInt(this.level);
/* 31 */     buffer.writeInt(this.subLevel);
/* 32 */     buffer.writeInt(this.id);
/* 33 */     ByteBufUtils.writeItemStack(buffer, this.weapon);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 38 */     this.level = buffer.readInt();
/* 39 */     this.subLevel = buffer.readInt();
/* 40 */     this.id = buffer.readInt();
/* 41 */     this.weapon = ByteBufUtils.readItemStack(buffer);
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player)
/*    */   {
/* 46 */     if (player == null)
/* 47 */       return;
/* 48 */     EntityGuardianGolem golem = (EntityGuardianGolem)player.worldObj.getEntityByID(this.id);
/* 49 */     if (golem != null) {
/* 50 */       golem.setClientInfos(this.level, this.subLevel, this.weapon);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */