/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import fr.paladium.palamod.paladium.logic.AlchemyCreatorLogic;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class PacketOpenGui
/*    */   extends AbstractPacket
/*    */ {
/*    */   AlchemyCreatorLogic tile;
/*    */   byte id;
/*    */   int x;
/*    */   int y;
/*    */   int z;
/*    */   
/*    */   public void setInformations(byte id)
/*    */   {
/* 23 */     this.id = id;
/*    */   }
/*    */   
/*    */   public void setInformations(byte id, int x, int y, int z) {
/* 27 */     this.id = id;
/* 28 */     this.x = x;
/* 29 */     this.y = y;
/* 30 */     this.z = z;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 35 */     buffer.writeByte(this.id);
/* 36 */     buffer.writeInt(this.x);
/* 37 */     buffer.writeInt(this.y);
/* 38 */     buffer.writeInt(this.z);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 43 */     this.id = buffer.readByte();
/* 44 */     this.x = buffer.readInt();
/* 45 */     this.y = buffer.readInt();
/* 46 */     this.z = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleClientSide(EntityPlayer player) {}
/*    */   
/*    */ 
/*    */   public void handleServerSide(EntityPlayer player)
/*    */   {
/* 56 */     if ((this.id == 2) || (this.id == 1)) {
/* 57 */       AlchemyCreatorLogic tile = (AlchemyCreatorLogic)AlchemyCreatorLogic.oppenedGui.get(player);
/* 58 */       if (tile != null)
/* 59 */         player.openGui(PalaMod.instance, this.id, player.worldObj, tile.xCoord, tile.yCoord, tile.zCoord);
/* 60 */       return;
/*    */     }
/* 62 */     player.openGui(PalaMod.instance, this.id, player.worldObj, this.x, this.y, this.z);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketOpenGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */