/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.client.local.LocalValues;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PacketSendData
/*    */   extends AbstractPacket
/*    */ {
/*    */   private String key;
/*    */   private String valueString;
/*    */   private int valueInt;
/*    */   
/*    */   public PacketSendData() {}
/*    */   
/*    */   public PacketSendData(String key, String value)
/*    */   {
/* 21 */     this.key = key;
/* 22 */     this.valueString = (value == null ? "" : value);
/*    */   }
/*    */   
/*    */   public PacketSendData(String key, int value) {
/* 26 */     this.key = key;
/* 27 */     this.valueInt = value;
/* 28 */     this.valueString = "";
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 34 */     ByteBufUtils.writeUTF8String(buffer, this.key);
/* 35 */     ByteBufUtils.writeUTF8String(buffer, this.valueString);
/* 36 */     buffer.writeInt(this.valueInt);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 41 */     this.key = ByteBufUtils.readUTF8String(buffer);
/* 42 */     this.valueString = ByteBufUtils.readUTF8String(buffer);
/* 43 */     this.valueInt = buffer.readInt();
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player)
/*    */   {
/* 48 */     if (this.valueString.equals("")) {
/* 49 */       LocalValues.setValue(this.key, this.valueInt);
/*    */     } else {
/* 51 */       LocalValues.setValue(this.key, this.valueString);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketSendData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */