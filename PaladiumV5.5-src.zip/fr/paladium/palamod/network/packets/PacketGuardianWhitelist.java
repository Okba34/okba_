/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.items.ItemGuardianWhitelist;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class PacketGuardianWhitelist
/*    */   extends AbstractPacket
/*    */ {
/*    */   String player;
/*    */   boolean b;
/*    */   
/*    */   public void addInformations(String player, boolean b)
/*    */   {
/* 20 */     this.player = player;
/* 21 */     this.b = b;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 26 */     ByteBufUtils.writeUTF8String(buffer, this.player);
/* 27 */     buffer.writeBoolean(this.b);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 32 */     this.player = ByteBufUtils.readUTF8String(buffer);
/* 33 */     this.b = buffer.readBoolean();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleClientSide(EntityPlayer player) {}
/*    */   
/*    */ 
/*    */   public void handleServerSide(EntityPlayer player)
/*    */   {
/* 43 */     ItemStack stack = player.getHeldItem();
/* 44 */     if (stack == null)
/* 45 */       return;
/* 46 */     if (this.player.equals(""))
/* 47 */       return;
/* 48 */     if (this.b) {
/* 49 */       ItemGuardianWhitelist.setList(ItemGuardianWhitelist.addName(this.player, ItemGuardianWhitelist.getList(stack)), stack);
/*    */     } else {
/* 51 */       ItemGuardianWhitelist.setList(ItemGuardianWhitelist.removeName(this.player, ItemGuardianWhitelist.getList(stack)), stack);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketGuardianWhitelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */