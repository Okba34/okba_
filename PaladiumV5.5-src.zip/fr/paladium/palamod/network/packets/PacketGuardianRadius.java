/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import fr.paladium.palamod.tiles.TileEntityGuardianAnchor;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class PacketGuardianRadius
/*    */   extends AbstractPacket
/*    */ {
/*    */   int radius;
/*    */   int x;
/*    */   int y;
/*    */   int z;
/*    */   TileEntityGuardianAnchor te;
/*    */   
/*    */   public void addInformations(int radius, TileEntityGuardianAnchor te)
/*    */   {
/* 22 */     this.radius = radius;
/* 23 */     this.te = te;
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 28 */     this.radius = buffer.readInt();
/* 29 */     this.x = buffer.readInt();
/* 30 */     this.y = buffer.readInt();
/* 31 */     this.z = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 37 */     buffer.writeInt(this.radius);
/* 38 */     buffer.writeInt(this.x);
/* 39 */     buffer.writeInt(this.y);
/* 40 */     buffer.writeInt(this.z);
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player)
/*    */   {
/* 45 */     TileEntityGuardianAnchor guardianAnchor = (TileEntityGuardianAnchor)player.worldObj.getTileEntity(this.x, this.y, this.z);
/* 46 */     if (guardianAnchor != null) {
/* 47 */       guardianAnchor.setRadius(this.radius);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketGuardianRadius.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */