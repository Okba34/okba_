/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.client.DisplayMessage;
/*    */ import fr.paladium.palamod.client.overlay.OverlayMessage;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class PacketSendMessage
/*    */   extends AbstractPacket
/*    */ {
/*    */   String message;
/*    */   String subMessage;
/*    */   int time;
/*    */   
/*    */   public void addInformations(String title, String subTitle, int time)
/*    */   {
/* 21 */     this.message = title;
/* 22 */     this.subMessage = subTitle;
/* 23 */     this.time = time;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 28 */     ByteBufUtils.writeUTF8String(buffer, this.message);
/* 29 */     ByteBufUtils.writeUTF8String(buffer, this.subMessage);
/* 30 */     buffer.writeInt(this.time);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 35 */     this.message = ByteBufUtils.readUTF8String(buffer);
/* 36 */     this.subMessage = ByteBufUtils.readUTF8String(buffer);
/* 37 */     this.time = buffer.readInt();
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player)
/*    */   {
/* 42 */     DisplayMessage message = new DisplayMessage(this.message, this.subMessage, this.time);
/* 43 */     OverlayMessage.addMessageToQueue(message);
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketSendMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */