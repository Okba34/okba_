/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ 
/*    */ 
/*    */ public class PacketCamera
/*    */   extends AbstractPacket
/*    */ {
/*    */   NBTTagCompound compound;
/*    */   
/*    */   public void addInformations(NBTTagCompound compound)
/*    */   {
/* 18 */     this.compound = compound;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 24 */     buffer.writeBoolean(this.compound.getBoolean("cam1"));
/* 25 */     buffer.writeInt(this.compound.getInteger("cam1X"));
/* 26 */     buffer.writeInt(this.compound.getInteger("cam1Y"));
/* 27 */     buffer.writeInt(this.compound.getInteger("cam1Z"));
/* 28 */     buffer.writeInt(this.compound.getInteger("cam1Yaw"));
/*    */     
/* 30 */     buffer.writeBoolean(this.compound.getBoolean("cam2"));
/* 31 */     buffer.writeInt(this.compound.getInteger("cam2X"));
/* 32 */     buffer.writeInt(this.compound.getInteger("cam2Y"));
/* 33 */     buffer.writeInt(this.compound.getInteger("cam2Z"));
/* 34 */     buffer.writeInt(this.compound.getInteger("cam2Yaw"));
/*    */     
/* 36 */     buffer.writeBoolean(this.compound.getBoolean("cam3"));
/* 37 */     buffer.writeInt(this.compound.getInteger("cam3X"));
/* 38 */     buffer.writeInt(this.compound.getInteger("cam3Y"));
/* 39 */     buffer.writeInt(this.compound.getInteger("cam3Z"));
/* 40 */     buffer.writeInt(this.compound.getInteger("cam3Yaw"));
/*    */     
/* 42 */     buffer.writeInt(this.compound.getInteger("Index"));
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 48 */     this.compound = new NBTTagCompound();
/* 49 */     this.compound.setBoolean("cam1", buffer.readBoolean());
/* 50 */     this.compound.setInteger("cam1X", buffer.readInt());
/* 51 */     this.compound.setInteger("cam1Y", buffer.readInt());
/* 52 */     this.compound.setInteger("cam1Z", buffer.readInt());
/* 53 */     this.compound.setInteger("cam1Yaw", buffer.readInt());
/*    */     
/* 55 */     this.compound.setBoolean("cam2", buffer.readBoolean());
/* 56 */     this.compound.setInteger("cam2X", buffer.readInt());
/* 57 */     this.compound.setInteger("cam2Y", buffer.readInt());
/* 58 */     this.compound.setInteger("cam2Z", buffer.readInt());
/* 59 */     this.compound.setInteger("cam2Yaw", buffer.readInt());
/*    */     
/* 61 */     this.compound.setBoolean("cam3", buffer.readBoolean());
/* 62 */     this.compound.setInteger("cam3X", buffer.readInt());
/* 63 */     this.compound.setInteger("cam3Y", buffer.readInt());
/* 64 */     this.compound.setInteger("cam3Z", buffer.readInt());
/* 65 */     this.compound.setInteger("cam3Yaw", buffer.readInt());
/*    */     
/* 67 */     this.compound.setInteger("Index", buffer.readInt());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleClientSide(EntityPlayer player) {}
/*    */   
/*    */ 
/*    */   public void handleServerSide(EntityPlayer player)
/*    */   {
/* 77 */     if (player.getHeldItem() != null) {
/* 78 */       player.getHeldItem().setTagCompound(this.compound);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */