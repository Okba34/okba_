/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import fr.paladium.palamod.tiles.TileEntityOnlineDetector;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class PacketOnlineDetector
/*    */   extends AbstractPacket
/*    */ {
/*    */   String player;
/*    */   TileEntityOnlineDetector te;
/*    */   int x;
/*    */   int y;
/*    */   int z;
/*    */   
/*    */   public void addInformations(String player, TileEntityOnlineDetector te)
/*    */   {
/* 22 */     this.player = player;
/* 23 */     this.te = te;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 28 */     ByteBufUtils.writeUTF8String(buffer, this.player);
/* 29 */     buffer.writeInt(this.te.xCoord);
/* 30 */     buffer.writeInt(this.te.yCoord);
/* 31 */     buffer.writeInt(this.te.zCoord);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 36 */     this.player = ByteBufUtils.readUTF8String(buffer);
/* 37 */     this.x = buffer.readInt();
/* 38 */     this.y = buffer.readInt();
/* 39 */     this.z = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleClientSide(EntityPlayer player) {}
/*    */   
/*    */ 
/*    */   public void handleServerSide(EntityPlayer player)
/*    */   {
/* 49 */     TileEntityOnlineDetector detector = (TileEntityOnlineDetector)player.worldObj.getTileEntity(this.x, this.y, this.z);
/* 50 */     if (detector != null) {
/* 51 */       detector.setName(this.player);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketOnlineDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */