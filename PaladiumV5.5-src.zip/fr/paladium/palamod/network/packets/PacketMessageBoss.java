/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import fr.paladium.palamod.client.overlay.OverlayMessageBoss;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ 
/*    */ public class PacketMessageBoss
/*    */   extends AbstractPacket
/*    */ {
/*    */   public static final byte START = 0;
/*    */   public static final byte STOP = 1;
/*    */   byte type;
/*    */   int x;
/*    */   int z;
/*    */   int time;
/*    */   
/*    */   public void addInformations(int x, int z, byte type, int time)
/*    */   {
/* 22 */     this.type = type;
/* 23 */     this.x = x;
/* 24 */     this.z = z;
/* 25 */     this.time = time;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 30 */     buffer.writeInt(this.x);
/* 31 */     buffer.writeInt(this.z);
/* 32 */     buffer.writeInt(this.time);
/* 33 */     buffer.writeByte(this.type);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 38 */     this.x = buffer.readInt();
/* 39 */     this.z = buffer.readInt();
/* 40 */     this.time = buffer.readInt();
/* 41 */     this.type = buffer.readByte();
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player)
/*    */   {
/* 46 */     if (this.type == 1) {
/* 47 */       OverlayMessageBoss.reset();
/*    */     } else {
/* 49 */       OverlayMessageBoss.startCd(this.x, this.z, this.time);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketMessageBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */