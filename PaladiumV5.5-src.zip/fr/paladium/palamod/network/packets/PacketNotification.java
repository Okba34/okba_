/*    */ package fr.paladium.palamod.network.packets;
/*    */ 
/*    */ import cpw.mods.fml.common.network.ByteBufUtils;
/*    */ import fr.paladium.palamod.client.local.LocalValues;
/*    */ import fr.paladium.palamod.network.AbstractPacket;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PacketNotification extends AbstractPacket
/*    */ {
/*    */   public String message;
/*    */   
/*    */   public PacketNotification() {}
/*    */   
/*    */   public PacketNotification(String message)
/*    */   {
/* 18 */     this.message = message;
/*    */   }
/*    */   
/*    */   public void encodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 23 */     ByteBufUtils.writeUTF8String(buffer, this.message);
/*    */   }
/*    */   
/*    */   public void decodeInto(ChannelHandlerContext ctx, ByteBuf buffer)
/*    */   {
/* 28 */     this.message = ByteBufUtils.readUTF8String(buffer);
/*    */   }
/*    */   
/*    */   public void handleClientSide(EntityPlayer player)
/*    */   {
/* 33 */     LocalValues.addNotification(this.message);
/*    */   }
/*    */   
/*    */   public void handleServerSide(EntityPlayer player) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\packets\PacketNotification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */