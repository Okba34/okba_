/*     */ package fr.paladium.palamod.network;
/*     */ 
/*     */ import cpw.mods.fml.common.network.FMLEmbeddedChannel;
/*     */ import cpw.mods.fml.common.network.FMLOutboundHandler;
/*     */ import cpw.mods.fml.common.network.FMLOutboundHandler.OutboundTarget;
/*     */ import cpw.mods.fml.common.network.NetworkRegistry;
/*     */ import cpw.mods.fml.common.network.internal.FMLProxyPacket;
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import fr.paladium.palamod.network.packets.PacketGuardianRadius;
/*     */ import fr.paladium.palamod.network.packets.PacketHash;
/*     */ import fr.paladium.palamod.network.packets.PacketSendMessage;
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import io.netty.buffer.Unpooled;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandler.Sharable;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.util.Attribute;
/*     */ import java.util.Comparator;
/*     */ import java.util.EnumMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.INetHandler;
/*     */ import net.minecraft.network.NetHandlerPlayServer;
/*     */ 
/*     */ @ChannelHandler.Sharable
/*     */ public class PacketPipeline extends io.netty.handler.codec.MessageToMessageCodec<FMLProxyPacket, AbstractPacket>
/*     */ {
/*     */   private EnumMap<Side, FMLEmbeddedChannel> channels;
/*  32 */   private LinkedList<Class<? extends AbstractPacket>> packets = new LinkedList();
/*  33 */   private boolean isPostInitialised = false;
/*     */   
/*     */   public boolean registerPacket(Class<? extends AbstractPacket> clazz)
/*     */   {
/*  37 */     if (this.packets.size() > 256) {
/*  38 */       return false;
/*     */     }
/*  40 */     if (this.packets.contains(clazz)) {
/*  41 */       return false;
/*     */     }
/*  43 */     if (this.isPostInitialised) {
/*  44 */       return false;
/*     */     }
/*  46 */     this.packets.add(clazz);
/*  47 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void encode(ChannelHandlerContext ctx, AbstractPacket msg, List<Object> out)
/*     */     throws Exception
/*     */   {
/*  54 */     ByteBuf buffer = Unpooled.buffer();
/*  55 */     Class<? extends AbstractPacket> clazz = msg.getClass();
/*  56 */     if (!this.packets.contains(msg.getClass()))
/*     */     {
/*  58 */       throw new NullPointerException("No Packet Registered for: " + msg.getClass().getCanonicalName());
/*     */     }
/*     */     
/*  61 */     byte discriminator = (byte)this.packets.indexOf(clazz);
/*  62 */     buffer.writeByte(discriminator);
/*  63 */     msg.encodeInto(ctx, buffer);
/*  64 */     FMLProxyPacket proxyPacket = new FMLProxyPacket(buffer.copy(), (String)ctx.channel().attr(NetworkRegistry.FML_CHANNEL).get());
/*  65 */     out.add(proxyPacket);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void decode(ChannelHandlerContext ctx, FMLProxyPacket msg, List<Object> out)
/*     */     throws Exception
/*     */   {
/*  72 */     ByteBuf payload = msg.payload();
/*  73 */     byte discriminator = payload.readByte();
/*  74 */     Class<? extends AbstractPacket> clazz = (Class)this.packets.get(discriminator);
/*  75 */     if (clazz == null)
/*     */     {
/*  77 */       throw new NullPointerException("No packet registered for discriminator: " + discriminator);
/*     */     }
/*     */     
/*  80 */     AbstractPacket pkt = (AbstractPacket)clazz.newInstance();
/*  81 */     pkt.decodeInto(ctx, payload.slice());
/*     */     
/*     */ 
/*  84 */     switch (cpw.mods.fml.common.FMLCommonHandler.instance().getEffectiveSide())
/*     */     {
/*     */     case CLIENT: 
/*  87 */       EntityPlayer player = getClientPlayer();
/*  88 */       pkt.handleClientSide(player);
/*  89 */       break;
/*     */     
/*     */     case SERVER: 
/*  92 */       INetHandler netHandler = (INetHandler)ctx.channel().attr(NetworkRegistry.NET_HANDLER).get();
/*  93 */       EntityPlayer player = ((NetHandlerPlayServer)netHandler).playerEntity;
/*  94 */       pkt.handleServerSide(player);
/*  95 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void initalise()
/*     */   {
/* 104 */     this.channels = NetworkRegistry.INSTANCE.newChannel("PalaMod", new ChannelHandler[] { this });
/* 105 */     registerPackets();
/*     */   }
/*     */   
/*     */   public void registerPackets()
/*     */   {
/* 110 */     registerPacket(fr.paladium.palamod.network.packets.PacketOpenGui.class);
/* 111 */     registerPacket(fr.paladium.palamod.network.packets.PacketOnlineDetector.class);
/* 112 */     registerPacket(fr.paladium.palamod.network.packets.PacketGuardianWhitelist.class);
/* 113 */     registerPacket(fr.paladium.palamod.network.packets.PacketGolem.class);
/* 114 */     registerPacket(PacketSendMessage.class);
/* 115 */     registerPacket(fr.paladium.palamod.network.packets.PacketMessageBoss.class);
/* 116 */     registerPacket(fr.paladium.palamod.network.packets.PacketCrash.class);
/* 117 */     registerPacket(PacketHash.class);
/* 118 */     registerPacket(PacketGuardianRadius.class);
/* 119 */     registerPacket(fr.paladium.palamod.network.packets.PacketCamera.class);
/* 120 */     registerPacket(fr.paladium.palamod.network.packets.PacketSendData.class);
/* 121 */     registerPacket(fr.paladium.palamod.network.packets.PacketNotification.class);
/*     */   }
/*     */   
/*     */   public void postInitialise()
/*     */   {
/* 126 */     if (this.isPostInitialised)
/*     */     {
/* 128 */       return;
/*     */     }
/*     */     
/* 131 */     this.isPostInitialised = true;
/* 132 */     java.util.Collections.sort(this.packets, new Comparator()
/*     */     {
/*     */ 
/*     */       public int compare(Class<? extends AbstractPacket> clazz1, Class<? extends AbstractPacket> clazz2)
/*     */       {
/* 137 */         int com = String.CASE_INSENSITIVE_ORDER.compare(clazz1.getCanonicalName(), clazz2.getCanonicalName());
/* 138 */         if (com == 0)
/*     */         {
/* 140 */           com = clazz1.getCanonicalName().compareTo(clazz2.getCanonicalName());
/*     */         }
/*     */         
/* 143 */         return com;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   @cpw.mods.fml.relauncher.SideOnly(Side.CLIENT)
/*     */   private EntityPlayer getClientPlayer()
/*     */   {
/* 151 */     return Minecraft.getMinecraft().thePlayer;
/*     */   }
/*     */   
/*     */   public void sendToAll(AbstractPacket message)
/*     */   {
/* 156 */     ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.ALL);
/* 157 */     ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).writeAndFlush(message);
/*     */   }
/*     */   
/*     */   public void sendTo(AbstractPacket message, EntityPlayer player)
/*     */   {
/* 162 */     ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.PLAYER);
/* 163 */     ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).attr(FMLOutboundHandler.FML_MESSAGETARGETARGS).set(player);
/* 164 */     ((FMLEmbeddedChannel)this.channels.get(Side.SERVER)).writeAndFlush(message);
/*     */   }
/*     */   
/*     */   public void sendToServer(AbstractPacket message)
/*     */   {
/* 169 */     ((FMLEmbeddedChannel)this.channels.get(Side.CLIENT)).attr(FMLOutboundHandler.FML_MESSAGETARGET).set(FMLOutboundHandler.OutboundTarget.TOSERVER);
/* 170 */     ((FMLEmbeddedChannel)this.channels.get(Side.CLIENT)).writeAndFlush(message);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\network\PacketPipeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */