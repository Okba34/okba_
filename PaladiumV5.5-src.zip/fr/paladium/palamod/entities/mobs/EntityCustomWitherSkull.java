/*    */ package fr.paladium.palamod.entities.mobs;
/*    */ 
/*    */ import fr.paladium.palamod.common.SilentExplosion;
/*    */ import fr.paladium.palamod.util.WitherData;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.projectile.EntityWitherSkull;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.world.GameRules;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityCustomWitherSkull
/*    */   extends EntityWitherSkull
/*    */ {
/* 22 */   private WitherData data = new WitherData();
/*    */   
/*    */   public EntityCustomWitherSkull(World p_i1793_1_) {
/* 25 */     super(p_i1793_1_);
/*    */   }
/*    */   
/*    */   public EntityCustomWitherSkull(World p_i1794_1_, EntityLivingBase p_i1794_2_, double p_i1794_3_, double p_i1794_5_, double p_i1794_7_)
/*    */   {
/* 30 */     super(p_i1794_1_, p_i1794_2_, p_i1794_3_, p_i1794_5_, p_i1794_7_);
/*    */   }
/*    */   
/*    */   protected void onImpact(MovingObjectPosition p_70227_1_)
/*    */   {
/* 35 */     super.onImpact(p_70227_1_);
/*    */     
/* 37 */     if (this.data.nosound) {
/* 38 */       SilentExplosion.newExplosion(this, this.posX, this.posY, this.posZ, this.data.impactDamage, false, this.worldObj
/* 39 */         .getGameRules().getGameRuleBooleanValue("mobGriefing"), this.worldObj);
/*    */     } else
/* 41 */       this.worldObj.newExplosion(this, this.posX, this.posY, this.posZ, this.data.impactDamage, false, this.worldObj
/* 42 */         .getGameRules().getGameRuleBooleanValue("mobGriefing"));
/* 43 */     setDead();
/*    */   }
/*    */   
/*    */ 
/*    */   public void playSound(String p_85030_1_, float p_85030_2_, float p_85030_3_)
/*    */   {
/* 49 */     if (!this.data.nosound)
/* 50 */       super.playSound(p_85030_1_, p_85030_2_, p_85030_3_);
/*    */   }
/*    */   
/*    */   public void setWitherData(WitherData witherData) {
/* 54 */     this.data = witherData;
/*    */   }
/*    */   
/*    */   public WitherData getWitherData() {
/* 58 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityCustomWitherSkull.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */