/*     */ package fr.paladium.palamod.entities.mobs;
/*     */ 
/*     */ import fr.paladium.palamod.util.WitherData;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*     */ import net.minecraft.entity.boss.BossStatus;
/*     */ import net.minecraft.entity.boss.EntityWither;
/*     */ import net.minecraft.entity.boss.IBossDisplayData;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityCustomWither
/*     */   extends EntityWither
/*     */   implements IBossDisplayData
/*     */ {
/*     */   WitherData data;
/*     */   
/*     */   public EntityCustomWither(World world)
/*     */   {
/*  46 */     super(world);
/*  47 */     this.data = new WitherData();
/*  48 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.data.maxlife);
/*     */   }
/*     */   
/*     */   public EntityCustomWither(World world, WitherData witherData) {
/*  52 */     super(world);
/*  53 */     this.data = witherData;
/*  54 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.data.maxlife);
/*     */   }
/*     */   
/*     */   protected void applyEntityAttributes()
/*     */   {
/*  59 */     super.applyEntityAttributes();
/*     */   }
/*     */   
/*     */   public void onLivingUpdate()
/*     */   {
/*  64 */     BossStatus.setBossStatus(this, true);
/*  65 */     super.onLivingUpdate();
/*     */   }
/*     */   
/*     */   public WitherData getWitherData() {
/*  69 */     return this.data;
/*     */   }
/*     */   
/*     */   private void func_82209_a(int p_82209_1_, double p_82209_2_, double p_82209_4_, double p_82209_6_, boolean p_82209_8_)
/*     */   {
/*  74 */     this.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1014, (int)this.posX, (int)this.posY, (int)this.posZ, 0);
/*     */     
/*  76 */     double d3 = func_82214_u(p_82209_1_);
/*  77 */     double d4 = func_82208_v(p_82209_1_);
/*  78 */     double d5 = func_82213_w(p_82209_1_);
/*  79 */     double d6 = p_82209_2_ - d3;
/*  80 */     double d7 = p_82209_4_ - d4;
/*  81 */     double d8 = p_82209_6_ - d5;
/*  82 */     EntityCustomWitherSkull entitywitherskull = new EntityCustomWitherSkull(this.worldObj, this, d6, d7, d8);
/*     */     
/*  84 */     if (p_82209_8_) {
/*  85 */       entitywitherskull.setInvulnerable(true);
/*     */     }
/*     */     
/*  88 */     entitywitherskull.posY = d4;
/*  89 */     entitywitherskull.posX = d3;
/*  90 */     entitywitherskull.posZ = d5;
/*  91 */     this.worldObj.spawnEntityInWorld(entitywitherskull);
/*     */   }
/*     */   
/*     */   private double func_82214_u(int p_82214_1_) {
/*  95 */     if (p_82214_1_ <= 0) {
/*  96 */       return this.posX;
/*     */     }
/*  98 */     float f = (this.renderYawOffset + 180 * (p_82214_1_ - 1)) / 180.0F * 3.1415927F;
/*  99 */     float f1 = MathHelper.cos(f);
/* 100 */     return this.posX + f1 * 1.3D;
/*     */   }
/*     */   
/*     */   private double func_82208_v(int p_82208_1_)
/*     */   {
/* 105 */     return p_82208_1_ <= 0 ? this.posY + 3.0D : this.posY + 2.2D;
/*     */   }
/*     */   
/*     */   private double func_82213_w(int p_82213_1_) {
/* 109 */     if (p_82213_1_ <= 0) {
/* 110 */       return this.posZ;
/*     */     }
/* 112 */     float f = (this.renderYawOffset + 180 * (p_82213_1_ - 1)) / 180.0F * 3.1415927F;
/* 113 */     float f1 = MathHelper.sin(f);
/* 114 */     return this.posZ + f1 * 1.3D;
/*     */   }
/*     */   
/*     */   public void playLivingSound()
/*     */   {
/* 119 */     if (!this.data.nosound) {
/* 120 */       super.playLivingSound();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getLivingSound()
/*     */   {
/* 128 */     return this.data.nosound ? "" : "mob.wither.idle";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getHurtSound()
/*     */   {
/* 136 */     return this.data.nosound ? "" : "mob.wither.hurt";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDeathSound()
/*     */   {
/* 144 */     return this.data.nosound ? "" : "mob.wither.death";
/*     */   }
/*     */   
/*     */   public boolean isArmored()
/*     */   {
/* 149 */     if (isAngry())
/* 150 */       return true;
/* 151 */     return super.isArmored();
/*     */   }
/*     */   
/*     */   public boolean isAngry() {
/* 155 */     return 
/* 156 */       (int)(getHealth() * 100.0F / getEntityAttribute(SharedMonsterAttributes.maxHealth).getBaseValue()) - this.data.angrylevel * 25 <= 50;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityCustomWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */