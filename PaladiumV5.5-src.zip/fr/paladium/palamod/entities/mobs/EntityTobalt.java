/*    */ package fr.paladium.palamod.entities.mobs;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fr.paladium.palamod.items.ModItems;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.SharedMonsterAttributes;
/*    */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*    */ import net.minecraft.entity.boss.BossStatus;
/*    */ import net.minecraft.entity.monster.EntityMob;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityTobalt extends EntityMob implements net.minecraft.entity.boss.IBossDisplayData
/*    */ {
/*    */   public EntityTobalt(World world)
/*    */   {
/* 18 */     super(world);
/* 19 */     setSize(3.0F, 3.0F);
/*    */   }
/*    */   
/*    */   public void applyEntityAttributes() {
/* 23 */     super.applyEntityAttributes();
/* 24 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10000.0D);
/* 25 */     getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
/* 26 */     getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.7D);
/*    */   }
/*    */   
/*    */   public void onLivingUpdate()
/*    */   {
/* 31 */     super.onLivingUpdate();
/* 32 */     if (FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT)
/* 33 */       BossStatus.setBossStatus(this, true);
/*    */   }
/*    */   
/*    */   protected String getLivingSound() {
/* 37 */     return "mob.blaze.breathe";
/*    */   }
/*    */   
/*    */   protected String getHurtSound() {
/* 41 */     return "mob.blaze.hit";
/*    */   }
/*    */   
/*    */   protected String getDeathSound() {
/* 45 */     return "mob.enderman.death";
/*    */   }
/*    */   
/*    */   protected void dropFewItems(boolean par1, int par2)
/*    */   {
/* 50 */     HashMap<Integer, Item> itemEndium = new HashMap();
/* 51 */     itemEndium.put(Integer.valueOf(1), ModItems.endiumChestplate);
/* 52 */     itemEndium.put(Integer.valueOf(2), ModItems.endiumBoots);
/* 53 */     itemEndium.put(Integer.valueOf(3), ModItems.endiumAxe);
/* 54 */     itemEndium.put(Integer.valueOf(4), ModItems.endiumHelmet);
/* 55 */     itemEndium.put(Integer.valueOf(5), ModItems.endiumLeggings);
/* 56 */     itemEndium.put(Integer.valueOf(6), ModItems.endiumSword);
/* 57 */     itemEndium.put(Integer.valueOf(7), ModItems.endiumPickaxe);
/* 58 */     HashMap<Integer, Item> autreLoot = new HashMap();
/* 59 */     autreLoot.put(Integer.valueOf(1), ModItems.paladiumBoots);
/* 60 */     autreLoot.put(Integer.valueOf(2), ModItems.paladiumChestplate);
/* 61 */     autreLoot.put(Integer.valueOf(3), ModItems.paladiumHelmet);
/* 62 */     autreLoot.put(Integer.valueOf(4), ModItems.paladiumLeggings);
/* 63 */     autreLoot.put(Integer.valueOf(5), ModItems.paladiumSword);
/* 64 */     autreLoot.put(Integer.valueOf(6), ModItems.paladiumPickaxe);
/* 65 */     autreLoot.put(Integer.valueOf(7), ModItems.paladiumShovel);
/* 66 */     autreLoot.put(Integer.valueOf(8), ModItems.titaneBoots);
/* 67 */     autreLoot.put(Integer.valueOf(9), ModItems.titaneChestplate);
/* 68 */     autreLoot.put(Integer.valueOf(10), ModItems.titaneLeggings);
/* 69 */     autreLoot.put(Integer.valueOf(11), ModItems.titaneHelmet);
/* 70 */     autreLoot.put(Integer.valueOf(12), ModItems.titaneSword);
/* 71 */     int autreL = autreLoot.size();
/* 72 */     int EndiumL = itemEndium.size();
/* 73 */     double loot = Math.random();
/* 74 */     int nombreloot = 0;
/* 75 */     if (loot < 0.5D) {
/* 76 */       nombreloot = 2;
/* 77 */     } else if (loot < 0.7D) {
/* 78 */       nombreloot = 3;
/* 79 */     } else if (loot < 0.9D) {
/* 80 */       nombreloot = 4;
/*    */     } else {
/* 82 */       nombreloot = 5;
/*    */     }
/* 84 */     double endiumDrop = Math.random() * nombreloot;
/* 85 */     int autreDrop = nombreloot - (int)endiumDrop;
/* 86 */     if ((int)endiumDrop > 0) {
/* 87 */       for (int i = 0; i <= endiumDrop; i++)
/*    */       {
/* 89 */         double z = Math.random() * EndiumL;
/* 90 */         dropItem((Item)itemEndium.get(Integer.valueOf((int)z)), 1);
/*    */       }
/*    */     }
/* 93 */     if (autreDrop > 0) {
/* 94 */       for (int i = 0; i <= autreDrop; i++) {
/* 95 */         double z = Math.random() * autreL;
/* 96 */         dropItem((Item)autreLoot.get(Integer.valueOf((int)z)), 1);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityTobalt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */