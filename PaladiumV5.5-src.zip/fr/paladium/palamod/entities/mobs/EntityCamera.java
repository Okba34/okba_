/*     */ package fr.paladium.palamod.entities.mobs;
/*     */ 
/*     */ import fr.paladium.palamod.tiles.TileEntityCamera;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityCamera
/*     */   extends EntityLivingBase
/*     */ {
/*     */   private static EntityCamera activeCamera;
/*     */   private static EntityLivingBase activePlayer;
/*  17 */   public static int activeCameraId = -1;
/*     */   
/*     */   static TileEntityCamera tileCamera;
/*     */   static int xCam;
/*     */   static int yCam;
/*     */   static int zCam;
/*     */   static float prevYaw;
/*     */   static boolean positive;
/*     */   
/*     */   public static boolean isActive()
/*     */   {
/*  28 */     return activeCamera != null;
/*     */   }
/*     */   
/*     */   public static void createCamera(double x, double y, double z, TileEntityCamera tile, float pitch, float yaw) {
/*  32 */     createCamera(tile);
/*  33 */     xCam = (int)x;
/*  34 */     yCam = (int)y;
/*  35 */     zCam = (int)z;
/*  36 */     moveCamera(x, y, z, pitch, yaw);
/*     */   }
/*     */   
/*     */   public static void createCamera(TileEntityCamera tile) {
/*  40 */     if (activeCamera == null) {
/*  41 */       activeCamera = new EntityCamera(Minecraft.getMinecraft().renderViewEntity.worldObj);
/*  42 */       activePlayer = Minecraft.getMinecraft().renderViewEntity;
/*     */       
/*  44 */       activeCamera.worldObj.spawnEntityInWorld(activeCamera);
/*     */       
/*  46 */       Minecraft.getMinecraft().renderViewEntity = activeCamera;
/*  47 */       tileCamera = tile;
/*     */     }
/*     */   }
/*     */   
/*     */   public static void moveCamera(double x, double y, double z, float pitch, float yaw) {
/*  52 */     if (activeCamera != null) {
/*  53 */       float tempYaw = prevYaw;
/*  54 */       if (positive) {
/*  55 */         tempYaw += 0.1F;
/*     */       } else {
/*  57 */         tempYaw -= 0.1F;
/*     */       }
/*  59 */       if (tempYaw > 360.0F)
/*  60 */         positive = false;
/*  61 */       if (tempYaw < 0.0F) {
/*  62 */         positive = true;
/*     */       }
/*  64 */       activeCamera.setPositionAndRotation(x, y, z, yaw + tempYaw, 0.0F);
/*  65 */       prevYaw = tempYaw;
/*  66 */       if (tileCamera != null)
/*  67 */         tileCamera.setRotation(yaw);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void destroyCamera() {
/*  72 */     if (activeCamera != null) {
/*  73 */       Minecraft.getMinecraft().renderViewEntity = activePlayer;
/*  74 */       activeCamera.worldObj.removeEntity(activeCamera);
/*  75 */       activeCamera.setDead();
/*  76 */       activeCamera = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public EntityCamera(World world) {
/*  81 */     super(world);
/*     */     
/*  83 */     this.width = 0.0F;
/*  84 */     this.height = 0.0F;
/*     */   }
/*     */   
/*     */   public void onEntityUpdate()
/*     */   {
/*  89 */     this.motionX = (this.motionY = this.motionZ = 0.0D);
/*  90 */     super.onEntityUpdate();
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getHeldItem()
/*     */   {
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public ItemStack getEquipmentInSlot(int var1)
/*     */   {
/* 101 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCurrentItemOrArmor(int var1, ItemStack var2) {}
/*     */   
/*     */ 
/*     */   public ItemStack[] getLastActiveItems()
/*     */   {
/* 110 */     return new ItemStack[0];
/*     */   }
/*     */   
/*     */   public static void rotateCamera(double d) {}
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */