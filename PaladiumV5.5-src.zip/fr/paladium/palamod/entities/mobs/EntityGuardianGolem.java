/*     */ package fr.paladium.palamod.entities.mobs;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.ai.EntityAIGuardian;
/*     */ import fr.paladium.palamod.client.CustomBossStatus;
/*     */ import fr.paladium.palamod.common.GuardianKeeperHandler;
/*     */ import fr.paladium.palamod.common.inventory.InventoryGuardianKeeper;
/*     */ import fr.paladium.palamod.items.ItemGuardianCosmeticUpgrade;
/*     */ import fr.paladium.palamod.items.ItemGuardianUpgrade;
/*     */ import fr.paladium.palamod.items.ItemGuardianWand;
/*     */ import fr.paladium.palamod.items.ItemGuardianWhitelist;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.network.packets.PacketGolem;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import fr.paladium.palamod.tiles.TileEntityGuardianAnchor;
/*     */ import fr.paladium.palamod.util.GuardianHelper;
/*     */ import java.util.Random;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityAgeable;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.ai.EntityAIAttackOnCollide;
/*     */ import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
/*     */ import net.minecraft.entity.ai.EntityAIMoveTowardsTarget;
/*     */ import net.minecraft.entity.ai.EntityAITasks;
/*     */ import net.minecraft.entity.ai.EntityAIWander;
/*     */ import net.minecraft.entity.ai.EntityAIWatchClosest;
/*     */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.monster.IMob;
/*     */ import net.minecraft.entity.passive.EntityTameable;
/*     */ import net.minecraft.entity.passive.IAnimals;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.pathfinding.PathNavigate;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class EntityGuardianGolem extends EntityTameable implements IAnimals, IInventory, net.minecraft.entity.boss.IBossDisplayData
/*     */ {
/*     */   public ItemStack[] content;
/*     */   public ItemStack[] contentChest;
/*     */   private String name;
/*     */   private int attackCooldown;
/*     */   private int attackTimer;
/*     */   private boolean isUseable;
/*     */   private int level;
/*     */   private int subLevel;
/*     */   private int requiredXP;
/*     */   public String ownerUUID;
/*     */   private double life;
/*     */   private double speed;
/*     */   private double damages;
/*     */   private int textureid;
/*     */   private int xpmodifier;
/*     */   private TileEntityGuardianAnchor anchor;
/*     */   private int anchorX;
/*     */   private int anchorY;
/*     */   private int anchorZ;
/*  73 */   private boolean anchorInitialized = true;
/*  74 */   private int regenModifier = 1;
/*     */   
/*     */   private ItemStack weapon;
/*     */   private long lastDrop;
/*     */   private long lastXP;
/*  79 */   public final double HEALTH_UP = 100.0D;
/*  80 */   public final double SPEED_UP = 0.02D;
/*  81 */   public final double DAMAGE_UP = 1.0D;
/*     */   
/*  83 */   public final double HEALTH_BASE = 100.0D;
/*  84 */   public final double SPEED_BASE = 0.25D;
/*  85 */   public final double DAMAGE_BASE = 1.0D;
/*     */   
/*  87 */   public final int TEXTURE_DEFAULT = 0;
/*     */   
/*     */   public EntityGuardianGolem(World world) {
/*  90 */     super(world);
/*  91 */     setSize(1.4F, 2.9F);
/*  92 */     getNavigator().setAvoidsWater(true);
/*  93 */     this.tasks.addTask(1, new EntityAIAttackOnCollide(this, 1.0D, true));
/*  94 */     this.tasks.addTask(2, new EntityAIMoveTowardsTarget(this, 0.9D, 32.0F));
/*  95 */     this.tasks.addTask(4, new EntityAIMoveTowardsRestriction(this, 1.0D));
/*  96 */     this.tasks.addTask(6, new EntityAIWander(this, 0.6D));
/*  97 */     this.targetTasks.addTask(8, new EntityAIGuardian(this, EntityPlayer.class, 0, true));
/*  98 */     this.tasks.addTask(7, new EntityAIWatchClosest(this, net.minecraft.entity.boss.EntityWither.class, 15.0F));
/*  99 */     this.tasks.addTask(7, new EntityAIWatchClosest(this, EntityGuardianGolem.class, 15.0F));
/* 100 */     this.tasks.addTask(9, new net.minecraft.entity.ai.EntityAILookIdle(this));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     this.requiredXP = 10;
/* 107 */     this.content = new ItemStack[7];
/* 108 */     this.isUseable = true;
/* 109 */     this.textureid = 0;
/* 110 */     this.name = "Guardian Golem";
/* 111 */     this.xpmodifier = 1;
/* 112 */     this.ignoreFrustumCheck = true;
/* 113 */     this.damages = 1.0D;
/* 114 */     setCurrentItemOrArmor(0, new ItemStack(ModItems.paladiumSword));
/*     */   }
/*     */   
/*     */   public void addInformations(ItemStack[] content, int level, int subLevel, String player) {
/* 118 */     this.content = content;
/* 119 */     this.level = level;
/* 120 */     this.subLevel = subLevel;
/* 121 */     this.ownerUUID = player;
/* 122 */     setHealth(100.0F);
/* 123 */     setRequiredXP(level);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void setClientInfos(int level, int subLevel, ItemStack weapon) {
/* 128 */     this.level = level;
/* 129 */     this.subLevel = subLevel;
/* 130 */     this.weapon = weapon;
/* 131 */     setRequiredXP(level);
/*     */   }
/*     */   
/*     */   public void sync() {
/* 135 */     PacketGolem packet = new PacketGolem();
/* 136 */     packet.addInformations(this.level, this.subLevel, getEntityId(), this.weapon);
/* 137 */     CommonProxy.packetPipeline.sendToAll(packet);
/* 138 */     this.damages = (1.0D + 1.0D * this.level);
/* 139 */     this.speed = (0.25D + 0.02D * this.level);
/* 140 */     this.life = (100.0D + 100.0D * this.level);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onLivingUpdate()
/*     */   {
/* 146 */     super.onLivingUpdate();
/* 147 */     checkForUpgardes();
/*     */     
/* 149 */     if (this.worldObj.isRemote) {
/* 150 */       CustomBossStatus.setBossStatus(this, true);
/*     */     }
/*     */     
/* 153 */     if (this.attackTimer > 0) {
/* 154 */       this.attackTimer -= 1;
/*     */     }
/*     */     
/* 157 */     if ((!this.worldObj.isRemote) && (getHealth() < this.life) && (this.rand.nextInt(20) == 0) && (this.isUseable)) {
/* 158 */       if (GuardianHelper.hasUpgrade(this, 2))
/* 159 */         this.regenModifier = 2;
/* 160 */       if (GuardianHelper.hasUpgrade(this, 3))
/* 161 */         this.regenModifier = 3;
/* 162 */       if (GuardianHelper.hasUpgrade(this, 4))
/* 163 */         this.regenModifier = 4;
/* 164 */       setHealth(getHealth() + this.regenModifier);
/*     */     }
/*     */     
/* 167 */     if ((!this.worldObj.isRemote) && (GuardianHelper.hasUpgrade(this, 21)) && 
/* 168 */       (this.lastDrop + 300000L >= System.currentTimeMillis())) {
/* 169 */       this.lastDrop = System.currentTimeMillis();
/* 170 */       int result = this.worldObj.rand.nextInt(4);
/*     */       EntityItem itemEntity;
/* 172 */       EntityItem itemEntity; EntityItem itemEntity; EntityItem itemEntity; switch (result) {
/*     */       case 0: 
/* 174 */         itemEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(MaterialRegister.AMETHYST_INGOT, 1));
/*     */         
/* 176 */         break;
/*     */       case 1: 
/* 178 */         itemEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(MaterialRegister.TITANE_INGOT, 1));
/*     */         
/* 180 */         break;
/*     */       case 2: 
/* 182 */         itemEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(MaterialRegister.PALADIUM_INGOT, 1));
/*     */         
/* 184 */         break;
/*     */       case 3: 
/* 186 */         itemEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Items.iron_ingot, 1));
/*     */         
/* 188 */         break;
/*     */       case 4: 
/* 190 */         itemEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Items.diamond, 1));
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 195 */     if ((GuardianHelper.hasUpgrade(this, 21)) && (this.lastXP + 300000L >= System.currentTimeMillis())) {
/* 196 */       int result = this.worldObj.rand.nextInt(100);
/* 197 */       this.lastXP = System.currentTimeMillis();
/* 198 */       addXp(result);
/*     */     }
/*     */     
/* 201 */     if ((this.motionX * this.motionX + this.motionZ * this.motionZ > 2.500000277905201E-7D) && (this.rand.nextInt(5) == 0)) {
/* 202 */       int i = MathHelper.floor_double(this.posX);
/* 203 */       int j = MathHelper.floor_double(this.posY - 0.20000000298023224D - this.yOffset);
/* 204 */       int k = MathHelper.floor_double(this.posZ);
/* 205 */       Block block = this.worldObj.getBlock(i, j, k);
/*     */       
/* 207 */       if (block.getMaterial() != Material.air) {
/* 208 */         this.worldObj.spawnParticle("blockcrack_" + 
/* 209 */           Block.getIdFromBlock(block) + "_" + this.worldObj.getBlockMetadata(i, j, k), this.posX + 
/* 210 */           (this.rand.nextFloat() - 0.5D) * this.width, this.boundingBox.minY + 0.1D, this.posZ + 
/*     */           
/* 212 */           (this.rand.nextFloat() - 0.5D) * this.width, 4.0D * (this.rand
/* 213 */           .nextFloat() - 0.5D), 0.5D, 
/* 214 */           (this.rand.nextFloat() - 0.5D) * 4.0D);
/*     */       }
/*     */     }
/*     */     
/* 218 */     if (GuardianHelper.hasUpgrade(this, 7))
/* 219 */       getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.life * 1.1D);
/* 220 */     if (GuardianHelper.hasUpgrade(this, 8))
/* 221 */       getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.life * 1.3D);
/* 222 */     if (GuardianHelper.hasUpgrade(this, 9))
/* 223 */       getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.life * 1.5D);
/* 224 */     if ((!GuardianHelper.hasUpgrade(this, 9)) && (!GuardianHelper.hasUpgrade(this, 8)) && (!GuardianHelper.hasUpgrade(this, 7))) {
/* 225 */       getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.life);
/*     */     }
/* 227 */     if (!this.anchorInitialized) {
/* 228 */       setAnchor(this.anchorX, this.anchorY, this.anchorZ);
/* 229 */       this.weapon = getEquipmentInSlot(0);
/* 230 */       this.anchorInitialized = true;
/*     */     }
/*     */     
/* 233 */     if ((GuardianHelper.hasUpgrade(this, 1)) && 
/* 234 */       (this.anchor != null) && (!this.anchor.inRadius(this.posX, this.posY, this.posZ))) {
/* 235 */       this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ, "mob.endermen.portal", 0.1F, 1.0F);
/* 236 */       setPositionAndUpdate(this.anchor.xCoord, this.anchor.yCoord + 2, this.anchor.zCoord);
/*     */     }
/*     */     
/*     */ 
/* 240 */     if ((!GuardianHelper.hasUpgrade(this, 20)) && (this.weapon != null)) {
/* 241 */       ItemStack weaponCopy = this.weapon.copy();
/* 242 */       this.weapon = null;
/* 243 */       setCurrentItemOrArmor(0, null);
/*     */       
/* 245 */       EntityItem weaponEntity = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, weaponCopy);
/* 246 */       if (!this.worldObj.isRemote) {
/* 247 */         this.worldObj.spawnEntityInWorld(weaponEntity);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onDeath(DamageSource damage) {
/* 253 */     this.isUseable = false;
/* 254 */     ItemStack stack = fromGuardianToStone();
/*     */     
/* 256 */     GuardianKeeperHandler handler = GuardianKeeperHandler.get(this.worldObj);
/* 257 */     InventoryGuardianKeeper inventory = handler.getStoneFromUUID(this.ownerUUID);
/* 258 */     inventory.setInventorySlotContents(0, stack);
/*     */     
/* 260 */     ItemStack[] contentChest = new ItemStack[26];
/*     */     
/* 262 */     NBTTagList nbtlist = getEntityData().getTagList("contentChest", 10);
/* 263 */     NBTTagCompound comp1; int slot; for (int i = 0; i < nbtlist.tagCount(); i++) {
/* 264 */       comp1 = nbtlist.getCompoundTagAt(i);
/* 265 */       slot = comp1.getInteger("Slot");
/* 266 */       contentChest[slot] = ItemStack.loadItemStackFromNBT(comp1);
/*     */     }
/*     */     
/* 269 */     for (ItemStack content : contentChest) {
/* 270 */       if (content != null) {
/* 271 */         EntityItem itemEntity = new EntityItem(this.worldObj, this.posX, this.posY + 1.0D, this.posZ, content);
/* 272 */         this.worldObj.spawnEntityInWorld(itemEntity);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean attackEntityAsMob(Entity entity)
/*     */   {
/* 279 */     if (((entity instanceof EntityPlayer)) && (checkWhitelist((EntityPlayer)entity))) {
/* 280 */       return false;
/*     */     }
/* 282 */     if (this.attackTimer == 0)
/* 283 */       this.attackTimer = this.attackCooldown;
/* 284 */     this.worldObj.setEntityState(this, (byte)4);
/* 285 */     float damageMultiplier = 1.0F;
/* 286 */     float damageAdder = 0.0F;
/*     */     
/* 288 */     if (GuardianHelper.hasUpgrade(this, 10))
/* 289 */       damageMultiplier = 1.1F;
/* 290 */     if (GuardianHelper.hasUpgrade(this, 11))
/* 291 */       damageMultiplier = 1.3F;
/* 292 */     if (GuardianHelper.hasUpgrade(this, 12)) {
/* 293 */       damageMultiplier = 1.5F;
/*     */     }
/* 295 */     if (GuardianHelper.hasUpgrade(this, 13))
/* 296 */       damageAdder = 0.5F;
/* 297 */     if (GuardianHelper.hasUpgrade(this, 14))
/* 298 */       damageAdder = 1.0F;
/* 299 */     if (GuardianHelper.hasUpgrade(this, 15)) {
/* 300 */       damageAdder = 1.5F;
/*     */     }
/* 302 */     boolean flag = entity.attackEntityFrom(DamageSource.causeMobDamage(this), 
/* 303 */       (float)(this.damages + this.rand.nextInt(5)) * damageMultiplier + damageAdder);
/*     */     
/* 305 */     if (flag) {
/* 306 */       entity.motionY += 0.4000000059604645D;
/*     */     }
/*     */     
/* 309 */     playSound("mob.irongolem.throw", 1.0F, 1.0F);
/* 310 */     return flag;
/*     */   }
/*     */   
/*     */   public boolean checkWhitelist(EntityPlayer entity) {
/* 314 */     if (entity == null)
/* 315 */       return false;
/* 316 */     if ((this.ownerUUID != null) && (entity.getUniqueID().toString().equals(this.ownerUUID)))
/* 317 */       return true;
/* 318 */     if (ItemGuardianWhitelist.check(this.content[6], entity.getDisplayName()))
/* 319 */       return true;
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   public boolean interact(EntityPlayer player) {
/* 324 */     if ((player.isSneaking()) && (player.getHeldItem() == null) && (this.weapon != null) && 
/* 325 */       (GuardianHelper.hasUpgrade(this, 20))) {
/* 326 */       player.setCurrentItemOrArmor(0, this.weapon.copy());
/* 327 */       this.weapon = null;
/* 328 */       setCurrentItemOrArmor(0, this.weapon);
/* 329 */       sync();
/* 330 */       return true;
/*     */     }
/* 332 */     if ((player.getHeldItem() != null) && 
/* 333 */       (((player.getHeldItem().getItem() instanceof net.minecraft.item.ItemSword)) || 
/* 334 */       ((player.getHeldItem().getItem() instanceof net.minecraft.item.ItemAxe))) && 
/* 335 */       (GuardianHelper.hasUpgrade(this, 20))) {
/* 336 */       ItemStack stack = player.getHeldItem();
/* 337 */       this.weapon = stack.copy();
/* 338 */       setCurrentItemOrArmor(0, this.weapon);
/* 339 */       player.setCurrentItemOrArmor(0, null);
/* 340 */       sync();
/* 341 */       return true;
/*     */     }
/* 343 */     if ((player.getHeldItem() != null) && (GuardianHelper.checkXPStuff(player.getHeldItem().getItem()))) {
/* 344 */       if (this.level < 80) {
/* 345 */         consumeXP(player);
/* 346 */         this.worldObj.spawnParticle("happyVillager", this.posX + this.rand.nextFloat() * this.width * 2.0F - this.width, this.posY + 0.5D + this.rand
/* 347 */           .nextFloat() * this.height, this.posZ + this.rand.nextFloat() * this.width * 2.0F - this.width, this.motionX, this.motionY, this.motionZ);
/*     */       }
/*     */       
/* 350 */       sync();
/* 351 */       return true;
/*     */     }
/* 353 */     if ((player.getHeldItem() != null) && ((player.getHeldItem().getItem() instanceof ItemGuardianWand)) && 
/* 354 */       (player.isSneaking())) {
/* 355 */       ItemGuardianWand.setGolem(player.getHeldItem(), this);
/* 356 */       sync();
/* 357 */       return true;
/*     */     }
/* 359 */     if ((!this.worldObj.isRemote) && (checkWhitelist(player))) {
/* 360 */       player.openGui(fr.paladium.palamod.PalaMod.instance, 7, this.worldObj, getEntityId(), 0, 0);
/* 361 */       sync();
/* 362 */       return true;
/*     */     }
/* 364 */     return super.interact(player);
/*     */   }
/*     */   
/*     */   protected void collideWithEntity(Entity entity) {
/* 368 */     if (((entity instanceof IMob)) && (getRNG().nextInt(20) == 0)) {
/* 369 */       setAttackTarget((EntityLivingBase)entity);
/*     */     }
/*     */     
/* 372 */     super.collideWithEntity(entity);
/*     */   }
/*     */   
/*     */   protected void applyEntityAttributes() {
/* 376 */     super.applyEntityAttributes();
/* 377 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(100.0D);
/* 378 */     getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D);
/*     */   }
/*     */   
/*     */   protected boolean isAIEnabled()
/*     */   {
/* 383 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean canDespawn() {
/* 387 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void checkForUpgardes()
/*     */   {
/* 393 */     this.xpmodifier = 1;
/* 394 */     for (int i = 0; i < 3; i++) {
/* 395 */       if (this.content[i] != null) {
/* 396 */         int type = ((ItemGuardianUpgrade)this.content[i].getItem()).getType();
/* 397 */         switch (type) {
/*     */         case 0: 
/* 399 */           this.xpmodifier = 2;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 404 */     this.name = "Guardian Golem";
/* 405 */     for (int i = 3; i < 6; i++) {
/* 406 */       if (this.content[i] != null) {
/* 407 */         int type = ((ItemGuardianCosmeticUpgrade)this.content[i].getItem()).getType();
/* 408 */         switch (type) {
/*     */         case 0: 
/* 410 */           if (this.content[i].hasDisplayName()) {
/* 411 */             this.name = this.content[i].getDisplayName();
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getSizeInventory() {
/* 420 */     return this.content.length;
/*     */   }
/*     */   
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/* 425 */     return this.content[slot];
/*     */   }
/*     */   
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/* 430 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/* 433 */       if (this.content[slotIndex].stackSize <= amount) {
/* 434 */         ItemStack itemstack = this.content[slotIndex];
/* 435 */         this.content[slotIndex] = null;
/* 436 */         markDirty();
/* 437 */         return itemstack;
/*     */       }
/* 439 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/* 441 */       if (this.content[slotIndex].stackSize == 0) {
/* 442 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/* 445 */       markDirty();
/* 446 */       return itemstack;
/*     */     }
/*     */     
/* 449 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/* 455 */     if (this.content[slotIndex] != null) {
/* 456 */       ItemStack itemstack = this.content[slotIndex];
/* 457 */       this.content[slotIndex] = null;
/* 458 */       return itemstack;
/*     */     }
/* 460 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/* 466 */     this.content[slotIndex] = stack;
/*     */     
/* 468 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit())) {
/* 469 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 472 */     markDirty();
/*     */   }
/*     */   
/*     */   public String getInventoryName()
/*     */   {
/* 477 */     return "Entity.GuardianGolem";
/*     */   }
/*     */   
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 482 */     return false;
/*     */   }
/*     */   
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 487 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void markDirty() {}
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 496 */     if (!this.isUseable) {
/* 497 */       return false;
/*     */     }
/* 499 */     return player.getDistanceSq(this.posX + 0.5D, this.posY + 0.5D, this.posZ + 0.5D) <= 64.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 513 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public EntityAgeable createChild(EntityAgeable p_90011_1_)
/*     */   {
/* 520 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isTamed()
/*     */   {
/* 525 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 532 */     super.writeToNBT(compound);
/* 533 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 535 */     for (int i = 0; i < this.content.length; i++) {
/* 536 */       if (this.content[i] != null) {
/* 537 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 538 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 539 */         this.content[i].writeToNBT(nbttagcompound1);
/* 540 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/* 543 */     if (this.weapon != null) {
/* 544 */       NBTTagCompound weaponComp = new NBTTagCompound();
/* 545 */       this.weapon.writeToNBT(weaponComp);
/* 546 */       compound.setTag("Weapon", weaponComp);
/*     */     }
/* 548 */     compound.setTag("Items", nbttaglist);
/* 549 */     compound.setInteger("Levels", this.level);
/* 550 */     compound.setInteger("SubLevels", this.subLevel);
/* 551 */     compound.setString("player", this.ownerUUID);
/* 552 */     compound.setBoolean("isUseable", this.isUseable);
/* 553 */     compound.setLong("LastDrop", this.lastDrop);
/* 554 */     compound.setLong("LastXP", this.lastXP);
/*     */     
/* 556 */     if (this.anchor != null) {
/* 557 */       compound.setInteger("anchorX", this.anchor.xCoord);
/* 558 */       compound.setInteger("anchorY", this.anchor.yCoord);
/* 559 */       compound.setInteger("anchorZ", this.anchor.zCoord);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 565 */     super.readFromNBT(compound);
/*     */     
/* 567 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 568 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 570 */     for (int i = 0; i < nbttaglist.tagCount(); i++) {
/* 571 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 572 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 574 */       if ((j >= 0) && (j < this.content.length)) {
/* 575 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 579 */     this.level = compound.getInteger("Levels");
/* 580 */     this.subLevel = compound.getInteger("SubLevels");
/* 581 */     this.ownerUUID = compound.getString("player");
/* 582 */     setRequiredXP(this.level);
/* 583 */     if (compound.hasKey("Weapon")) {
/* 584 */       this.weapon = ItemStack.loadItemStackFromNBT((NBTTagCompound)compound.getTag("Weapon"));
/*     */     }
/* 586 */     this.anchorInitialized = false;
/*     */     
/* 588 */     this.lastDrop = compound.getLong("LastDrop");
/* 589 */     this.lastXP = compound.getLong("LastXP");
/*     */     
/* 591 */     this.anchorX = compound.getInteger("anchorX");
/* 592 */     this.anchorY = compound.getInteger("anchorY");
/* 593 */     this.anchorZ = compound.getInteger("anchorZ");
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLevel()
/*     */   {
/* 599 */     return this.level;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getLife()
/*     */   {
/* 606 */     return (int)this.life;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getSpeed() {
/* 611 */     return (int)(this.speed * 10.0D);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getDamages() {
/* 616 */     return (int)this.damages;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public String getGuardianName() {
/* 621 */     return this.name;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public float getScaledHealth() {
/* 626 */     return getHealth() / getMaxHealth();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public float getRequiredXP() {
/* 631 */     return this.requiredXP;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getTextureId() {
/* 636 */     return this.textureid;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getAttackTimer() {
/* 641 */     return this.attackTimer;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getSubLevel() {
/* 646 */     return this.subLevel;
/*     */   }
/*     */   
/*     */ 
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void handleHealthUpdate(byte byt)
/*     */   {
/* 653 */     if ((byt == 4) && (this.attackTimer == 0)) {
/* 654 */       this.attackTimer = 10;
/* 655 */       playSound("mob.irongolem.throw", 1.0F, 1.0F);
/*     */     } else {
/* 657 */       super.handleHealthUpdate(byt);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setOwner(EntityPlayer player)
/*     */   {
/* 664 */     this.ownerUUID = player.getUniqueID().toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setRequiredXP(int level)
/*     */   {
/* 670 */     this.requiredXP = (1 * level * level + 10);
/*     */   }
/*     */   
/*     */   public void addXp(int xp) {
/* 674 */     this.subLevel += xp * this.xpmodifier;
/* 675 */     if (this.subLevel >= this.requiredXP) {
/* 676 */       this.level += 1;
/* 677 */       this.subLevel -= this.requiredXP;
/* 678 */       setRequiredXP(this.level);
/* 679 */       onLevelUp();
/* 680 */       addXp(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onLevelUp() {
/* 685 */     this.speed += 0.02D;
/* 686 */     this.damages += 1.0D;
/* 687 */     this.life += 100.0D;
/* 688 */     applyLevelModifiers();
/*     */   }
/*     */   
/*     */   public void applyLevelModifiers() {
/* 692 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(this.life);
/* 693 */     getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(this.speed);
/*     */   }
/*     */   
/*     */   private void consumeXP(EntityPlayer player) {
/* 697 */     ItemStack stack = player.getHeldItem();
/* 698 */     addXp(GuardianHelper.getXpFromItem(stack.getItem()));
/* 699 */     stack.stackSize -= 1;
/* 700 */     if (stack.stackSize <= 0)
/* 701 */       stack = null;
/*     */   }
/*     */   
/*     */   public ItemStack fromGuardianToStone() {
/* 705 */     ItemStack stack = new ItemStack(ModItems.guardianStone);
/* 706 */     NBTTagCompound compound = new NBTTagCompound();
/* 707 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 709 */     for (int i = 0; i < this.content.length; i++) {
/* 710 */       if (this.content[i] != null) {
/* 711 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 712 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 713 */         this.content[i].writeToNBT(nbttagcompound1);
/* 714 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/* 717 */     compound.setTag("Items", nbttaglist);
/* 718 */     compound.setInteger("Levels", this.level);
/* 719 */     compound.setInteger("SubLevels", this.subLevel);
/* 720 */     compound.setString("player", this.ownerUUID);
/* 721 */     compound.setBoolean("isUseable", this.isUseable);
/* 722 */     stack.setTagCompound(compound);
/* 723 */     return stack;
/*     */   }
/*     */   
/*     */   public void setAnchor(TileEntityGuardianAnchor anchor) {
/* 727 */     this.anchor = anchor;
/*     */   }
/*     */   
/*     */   public void setAnchor(int x, int y, int z) {
/* 731 */     TileEntity tile = this.worldObj.getTileEntity(x, y, z);
/* 732 */     if ((tile != null) && ((tile instanceof TileEntityGuardianAnchor)))
/* 733 */       this.anchor = ((TileEntityGuardianAnchor)tile);
/*     */   }
/*     */   
/*     */   public String getName() {
/* 737 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getMaxChestSlots() {
/* 741 */     return this.level / 3;
/*     */   }
/*     */   
/*     */   protected void damageEntity(DamageSource source, float ammount)
/*     */   {
/* 746 */     super.damageEntity(source, ammount);
/* 747 */     if ((source.getSourceOfDamage() == null) || (!(source.getSourceOfDamage() instanceof EntityPlayer)))
/* 748 */       return;
/* 749 */     EntityPlayer player = (EntityPlayer)source.getSourceOfDamage();
/* 750 */     if (player == null)
/* 751 */       return;
/* 752 */     float back = 0.0F;
/* 753 */     if (GuardianHelper.hasUpgrade(this, 17))
/* 754 */       back = ammount * 0.1F;
/* 755 */     if (GuardianHelper.hasUpgrade(this, 18))
/* 756 */       back = ammount * 0.15F;
/* 757 */     if (GuardianHelper.hasUpgrade(this, 19))
/* 758 */       back = ammount * 0.2F;
/* 759 */     player.attackEntityFrom(DamageSource.causeMobDamage(this), back);
/*     */   }
/*     */   
/*     */   public ItemStack getWeapon() {
/* 763 */     return this.weapon;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityGuardianGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */