/*    */ package fr.paladium.palamod.entities.mobs;
/*    */ 
/*    */ import cpw.mods.fml.common.FMLCommonHandler;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fr.paladium.palamod.items.ModItems;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.SharedMonsterAttributes;
/*    */ import net.minecraft.entity.ai.attributes.IAttributeInstance;
/*    */ import net.minecraft.entity.monster.EntityMob;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityGarag extends EntityMob implements net.minecraft.entity.boss.IBossDisplayData
/*    */ {
/*    */   public EntityGarag(World world)
/*    */   {
/* 17 */     super(world);
/* 18 */     setSize(4.0F, 4.0F);
/*    */   }
/*    */   
/*    */   public void applyEntityAttributes() {
/* 22 */     super.applyEntityAttributes();
/* 23 */     getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10000.0D);
/* 24 */     getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(25.0D);
/* 25 */     getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.7D);
/*    */   }
/*    */   
/*    */   public void onLivingUpdate()
/*    */   {
/* 30 */     super.onLivingUpdate();
/* 31 */     if (FMLCommonHandler.instance().getEffectiveSide() == Side.CLIENT)
/* 32 */       net.minecraft.entity.boss.BossStatus.setBossStatus(this, true);
/*    */   }
/*    */   
/*    */   protected String getLivingSound() {
/* 36 */     return "mob.blaze.breathe";
/*    */   }
/*    */   
/*    */   protected String getHurtSound() {
/* 40 */     return "mob.blaze.hit";
/*    */   }
/*    */   
/*    */   protected String getDeathSound() {
/* 44 */     return "mob.enderman.death";
/*    */   }
/*    */   
/*    */   protected void dropFewItems(boolean par1, int par2)
/*    */   {
/* 49 */     HashMap<Integer, Item> itemEndium = new HashMap();
/* 50 */     itemEndium.put(Integer.valueOf(1), ModItems.endiumChestplate);
/* 51 */     itemEndium.put(Integer.valueOf(2), ModItems.endiumBoots);
/* 52 */     itemEndium.put(Integer.valueOf(3), ModItems.endiumAxe);
/* 53 */     itemEndium.put(Integer.valueOf(4), ModItems.endiumHelmet);
/* 54 */     itemEndium.put(Integer.valueOf(5), ModItems.endiumLeggings);
/* 55 */     itemEndium.put(Integer.valueOf(6), ModItems.endiumSword);
/* 56 */     itemEndium.put(Integer.valueOf(7), ModItems.endiumPickaxe);
/* 57 */     HashMap<Integer, Item> autreLoot = new HashMap();
/* 58 */     autreLoot.put(Integer.valueOf(1), ModItems.paladiumBoots);
/* 59 */     autreLoot.put(Integer.valueOf(2), ModItems.paladiumChestplate);
/* 60 */     autreLoot.put(Integer.valueOf(3), ModItems.paladiumHelmet);
/* 61 */     autreLoot.put(Integer.valueOf(4), ModItems.paladiumLeggings);
/* 62 */     autreLoot.put(Integer.valueOf(5), ModItems.paladiumSword);
/* 63 */     autreLoot.put(Integer.valueOf(6), ModItems.paladiumPickaxe);
/* 64 */     autreLoot.put(Integer.valueOf(7), ModItems.paladiumShovel);
/* 65 */     autreLoot.put(Integer.valueOf(8), ModItems.titaneBoots);
/* 66 */     autreLoot.put(Integer.valueOf(9), ModItems.titaneChestplate);
/* 67 */     autreLoot.put(Integer.valueOf(10), ModItems.titaneLeggings);
/* 68 */     autreLoot.put(Integer.valueOf(11), ModItems.titaneHelmet);
/* 69 */     autreLoot.put(Integer.valueOf(12), ModItems.titaneSword);
/* 70 */     int autreL = autreLoot.size();
/* 71 */     int EndiumL = itemEndium.size();
/* 72 */     double loot = Math.random();
/* 73 */     int nombreloot = 0;
/* 74 */     if (loot < 0.5D) {
/* 75 */       nombreloot = 2;
/* 76 */     } else if (loot < 0.7D) {
/* 77 */       nombreloot = 3;
/* 78 */     } else if (loot < 0.9D) {
/* 79 */       nombreloot = 4;
/*    */     } else {
/* 81 */       nombreloot = 5;
/*    */     }
/* 83 */     double endiumDrop = Math.random() * nombreloot;
/* 84 */     int autreDrop = nombreloot - (int)endiumDrop;
/* 85 */     if ((int)endiumDrop > 0) {
/* 86 */       for (int i = 0; i <= endiumDrop; i++)
/*    */       {
/* 88 */         double z = Math.random() * EndiumL;
/* 89 */         dropItem((Item)itemEndium.get(Integer.valueOf((int)z)), 1);
/*    */       }
/*    */     }
/* 92 */     if (autreDrop > 0) {
/* 93 */       for (int i = 0; i <= autreDrop; i++) {
/* 94 */         double z = Math.random() * autreL;
/* 95 */         dropItem((Item)autreLoot.get(Integer.valueOf((int)z)), 1);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\mobs\EntityGarag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */