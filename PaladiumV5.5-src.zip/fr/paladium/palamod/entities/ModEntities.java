/*    */ package fr.paladium.palamod.entities;
/*    */ 
/*    */ import cpw.mods.fml.common.registry.EntityRegistry;
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import fr.paladium.palamod.entities.mobs.EntityCamera;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGarag;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.entities.projectiles.EntityCustomArrow;
/*    */ 
/*    */ public class ModEntities
/*    */ {
/*    */   public static void init()
/*    */   {
/* 14 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.projectiles.EntityPotionGun.class, "Gun Potion", 0, PalaMod.instance, 64, 10, true);
/* 15 */     EntityRegistry.registerModEntity(EntityCustomArrow.class, "Custom Arrow", 1, PalaMod.instance, 64, 10, true);
/* 16 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.projectiles.EntitySplashPotion.class, "EntityPotion", 2, PalaMod.instance, 80, 3, true);
/*    */     
/* 18 */     EntityRegistry.registerModEntity(EntityGuardianGolem.class, "GuardianGolem", 3, PalaMod.instance, 80, 3, true);
/* 19 */     EntityRegistry.registerModEntity(EntityGarag.class, "Garag", 4, PalaMod.instance, 80, 3, true);
/* 20 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.mobs.EntityTobalt.class, "Tobalt", 5, PalaMod.instance, 80, 3, true);
/*    */     
/* 22 */     EntityRegistry.registerModEntity(EntityCamera.class, "Camera", 8, PalaMod.instance, 80, 3, true);
/*    */     
/* 24 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.mobs.EntityCustomWither.class, "palawither", 9, PalaMod.instance, 16, 2, true);
/* 25 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.mobs.EntityCustomWitherSkull.class, "palawitherskull", 10, PalaMod.instance, 80, 2, true);
/*    */     
/* 27 */     EntityRegistry.registerModEntity(fr.paladium.palamod.entities.projectiles.EntityTurretBullet.class, "turretBullet", 11, PalaMod.instance, 16, 20, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\ModEntities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */