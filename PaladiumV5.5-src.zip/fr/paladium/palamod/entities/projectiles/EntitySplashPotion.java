/*     */ package fr.paladium.palamod.entities.projectiles;
/*     */ 
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.DataWatcher;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityThrowable;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class EntitySplashPotion extends EntityThrowable
/*     */ {
/*     */   public int damageValue;
/*     */   public boolean isGun;
/*     */   public static final int NAUSEA = 0;
/*     */   public static final int WEB = 1;
/*     */   
/*     */   public EntitySplashPotion(World world)
/*     */   {
/*  26 */     super(world);
/*     */   }
/*     */   
/*     */   public EntitySplashPotion(World world, EntityPlayer player, int damageValue) {
/*  30 */     super(world, player);
/*  31 */     setThrowableHeading(this.motionX, this.motionY, this.motionZ, 0.4F, 0.3F);
/*  32 */     setDamageValue(damageValue);
/*     */   }
/*     */   
/*     */   public EntitySplashPotion(World world, EntityPlayer player, int damageValue, boolean isGun) {
/*  36 */     super(world, player);
/*  37 */     setThrowableHeading(this.motionX, this.motionY, this.motionZ, 0.4F, 0.3F);
/*  38 */     setDamageValue(damageValue);
/*  39 */     this.isGun = isGun;
/*     */   }
/*     */   
/*     */   protected void entityInit()
/*     */   {
/*  44 */     super.entityInit();
/*  45 */     this.dataWatcher.addObject(2, Integer.valueOf(0));
/*     */   }
/*     */   
/*     */   public void setDamageValue(int damageValue) {
/*  49 */     this.damageValue = damageValue;
/*  50 */     if (!this.worldObj.isRemote)
/*  51 */       this.dataWatcher.updateObject(2, Integer.valueOf(damageValue));
/*     */   }
/*     */   
/*     */   public int getDamageValue() {
/*  55 */     return this.dataWatcher.getWatchableObjectInt(2);
/*     */   }
/*     */   
/*     */   protected void onImpact(MovingObjectPosition p_70184_1_)
/*     */   {
/*  60 */     if (!this.worldObj.isRemote) {
/*  61 */       switch (this.damageValue) {
/*     */       case 0: 
/*  63 */         nauseaEffect(p_70184_1_);
/*  64 */         break;
/*     */       case 1: 
/*  66 */         spawnWeb(p_70184_1_);
/*     */       }
/*     */       
/*     */     }
/*  70 */     setDead();
/*  71 */     setDead();
/*     */   }
/*     */   
/*     */   private static boolean setBlockIfNotSolid(World world, int x, int y, int z, Block block) {
/*  75 */     return setBlockIfNotSolid(world, x, y, z, block, 0);
/*     */   }
/*     */   
/*     */   private static boolean setBlockIfNotSolid(World world, int x, int y, int z, Block block, int metadata) {
/*  79 */     if ((world.getBlock(x, y, z).isAir(world, x, y, z)) || (world.getBlock(x, y, z) == PaladiumRegister.customWeb)) {
/*  80 */       world.setBlock(x, y, z, block, metadata, 3);
/*  81 */       return true;
/*     */     }
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   private void spawnWeb(MovingObjectPosition mop) {
/*  87 */     switch (mop.typeOfHit) {
/*     */     case ENTITY: 
/*  89 */       this.worldObj.setBlock((int)mop.entityHit.posX, (int)mop.entityHit.posY, (int)mop.entityHit.posZ, Blocks.web);
/*     */       
/*  91 */       break;
/*     */     case BLOCK: 
/*  93 */       if (this.worldObj.getBlock(mop.blockX, mop.blockY, mop.blockZ) == Blocks.snow) {
/*  94 */         mop.blockY -= 1;
/*  95 */         mop.sideHit = 1;
/*     */       }
/*  97 */       switch (mop.sideHit) {
/*     */       case 0: 
/*  99 */         setBlockIfNotSolid(this.worldObj, mop.blockX, mop.blockY - 1, mop.blockZ, PaladiumRegister.customWeb);
/* 100 */         break;
/*     */       case 1: 
/* 102 */         setBlockIfNotSolid(this.worldObj, mop.blockX, mop.blockY + 1, mop.blockZ, PaladiumRegister.customWeb);
/* 103 */         break;
/*     */       case 2: 
/* 105 */         setBlockIfNotSolid(this.worldObj, mop.blockX - 1, mop.blockY, mop.blockZ, PaladiumRegister.customWeb);
/* 106 */         break;
/*     */       case 3: 
/* 108 */         setBlockIfNotSolid(this.worldObj, mop.blockX + 1, mop.blockY, mop.blockZ, PaladiumRegister.customWeb);
/* 109 */         break;
/*     */       case 4: 
/* 111 */         setBlockIfNotSolid(this.worldObj, mop.blockX, mop.blockY, mop.blockZ - 1, PaladiumRegister.customWeb);
/* 112 */         break;
/*     */       case 5: 
/* 114 */         setBlockIfNotSolid(this.worldObj, mop.blockX, mop.blockY, mop.blockZ + 1, PaladiumRegister.customWeb);
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   protected float getGravityVelocity()
/*     */   {
/* 122 */     if (this.isGun)
/* 123 */       return 0.01F;
/* 124 */     return super.getGravityVelocity();
/*     */   }
/*     */   
/*     */   protected float func_70182_d()
/*     */   {
/* 129 */     if (this.isGun)
/* 130 */       return 2.0F;
/* 131 */     return super.func_70182_d();
/*     */   }
/*     */   
/*     */   protected float func_70183_g()
/*     */   {
/* 136 */     if (this.isGun)
/* 137 */       return 2.0F;
/* 138 */     return super.func_70183_g();
/*     */   }
/*     */   
/*     */   public void nauseaEffect(MovingObjectPosition p_70184_1_) {
/* 142 */     AxisAlignedBB axisalignedbb = this.boundingBox.expand(4.0D, 2.0D, 4.0D);
/* 143 */     List list1 = this.worldObj.getEntitiesWithinAABB(EntityPlayer.class, axisalignedbb);
/*     */     
/* 145 */     if ((list1 != null) && (!list1.isEmpty())) {
/* 146 */       Iterator iterator = list1.iterator();
/*     */       
/* 148 */       while (iterator.hasNext()) {
/* 149 */         EntityPlayer entitylivingbase = (EntityPlayer)iterator.next();
/* 150 */         double d0 = getDistanceSqToEntity(entitylivingbase);
/*     */         
/* 152 */         if (d0 < 16.0D) {
/* 153 */           double d1 = 1.0D - Math.sqrt(d0) / 4.0D;
/*     */           
/* 155 */           if (entitylivingbase == p_70184_1_.entityHit) {
/* 156 */             d1 = 1.0D;
/*     */           }
/* 158 */           entitylivingbase.addPotionEffect(new net.minecraft.potion.PotionEffect(Potion.confusion.id, 400, 100));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 164 */     this.worldObj.playAuxSFX(2002, (int)Math.round(this.posX), (int)Math.round(this.posY), 
/* 165 */       (int)Math.round(this.posZ), 4);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\projectiles\EntitySplashPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */