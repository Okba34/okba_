/*     */ package fr.paladium.palamod.entities.projectiles;
/*     */ 
/*     */ import fr.paladium.palamod.util.BowHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityArrow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class EntityCustomArrow
/*     */   extends EntityArrow
/*     */ {
/*     */   public static final int POISON = 0;
/*     */   public static final int WITHER = 1;
/*     */   public static final int SLOWNESS = 2;
/*     */   public static final int SWITCH = 3;
/*     */   EntityPlayer player;
/*     */   int type;
/*     */   private boolean inGround;
/*  28 */   private int field_145791_d = -1;
/*  29 */   private int field_145792_e = -1;
/*  30 */   private int field_145789_f = -1;
/*     */   
/*     */   private Block field_145790_g;
/*     */   
/*     */   private int inData;
/*     */   
/*     */   private boolean canBePickedUp;
/*     */   
/*     */   public int arrowShake;
/*     */   public Entity shootingEntity;
/*     */   private int ticksInGround;
/*     */   private int ticksInAir;
/*  42 */   private double damage = 2.0D;
/*     */   private int knockbackStrength;
/*     */   
/*     */   public EntityCustomArrow(World world)
/*     */   {
/*  47 */     super(world);
/*     */   }
/*     */   
/*     */   public EntityCustomArrow(World world, int type, EntityPlayer player) {
/*  51 */     super(world);
/*  52 */     this.type = type;
/*  53 */     this.player = player;
/*     */   }
/*     */   
/*     */   public EntityCustomArrow(World world, EntityLivingBase entity, float power, int type, boolean infiniteAmmo) {
/*  57 */     super(world, entity, power);
/*  58 */     this.type = type;
/*  59 */     this.player = ((EntityPlayer)entity);
/*  60 */     this.canBePickedUp = infiniteAmmo;
/*     */   }
/*     */   
/*     */   public void readEntityFromNBT(NBTTagCompound nbt) {
/*  64 */     super.readEntityFromNBT(nbt);
/*     */     
/*  66 */     this.canBePickedUp = nbt.getBoolean("canBePickedUp");
/*  67 */     if (nbt.hasKey("typearrow")) {
/*  68 */       setType(nbt.getInteger("typearrow"));
/*     */     }
/*     */   }
/*     */   
/*     */   public EntityPlayer getPlayer() {
/*  73 */     return this.player;
/*     */   }
/*     */   
/*     */   public void writeEntityToNBT(NBTTagCompound nbt) {
/*  77 */     super.writeEntityToNBT(nbt);
/*     */     
/*  79 */     nbt.setBoolean("canBePickedUp", this.canBePickedUp);
/*  80 */     nbt.setInteger("typearrow", getType());
/*     */   }
/*     */   
/*     */   public int getType() {
/*  84 */     return this.type;
/*     */   }
/*     */   
/*     */   public void onEntityUpdate()
/*     */   {
/*  89 */     if (this.ticksExisted >= 2000) {
/*  90 */       setDead();
/*     */     }
/*  92 */     Vec3 vec3d = Vec3.createVectorHelper(this.posX, this.posY, this.posZ);
/*  93 */     Vec3 vec3d1 = Vec3.createVectorHelper(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
/*     */     
/*  95 */     MovingObjectPosition movingobjectposition = this.worldObj.func_147447_a(vec3d, vec3d1, false, true, false);
/*     */     
/*     */ 
/*  98 */     List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox
/*  99 */       .addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0D, 1.0D, 1.0D));
/* 100 */     double d = 0.0D;
/* 101 */     Entity entity = null;
/* 102 */     for (int l = 0; l < list.size(); l++) {
/* 103 */       Entity entity1 = (Entity)list.get(l);
/* 104 */       if ((entity1.canBeCollidedWith()) && ((entity1 != this.shootingEntity) || (this.ticksInAir >= 5)))
/*     */       {
/*     */ 
/* 107 */         float f4 = 0.3F;
/* 108 */         AxisAlignedBB axisalignedbb1 = entity1.boundingBox.expand(f4, f4, f4);
/* 109 */         MovingObjectPosition movingobjectposition1 = axisalignedbb1.calculateIntercept(vec3d, vec3d1);
/* 110 */         if (movingobjectposition1 != null)
/*     */         {
/*     */ 
/* 113 */           double d1 = vec3d.distanceTo(movingobjectposition1.hitVec);
/* 114 */           if ((d1 < d) || (d == 0.0D)) {
/* 115 */             entity = entity1;
/* 116 */             d = d1;
/*     */           }
/*     */         }
/*     */       } }
/* 120 */     if (entity != null) {
/* 121 */       movingobjectposition = new MovingObjectPosition(entity);
/*     */     }
/*     */     
/* 124 */     if ((movingobjectposition != null) && 
/* 125 */       (movingobjectposition.entityHit == null)) {
/* 126 */       this.inGround = true;
/*     */     }
/*     */     
/* 129 */     super.onEntityUpdate();
/*     */   }
/*     */   
/*     */   public void setType(int type) {
/* 133 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */   public EntityItem entityDropItem(ItemStack p_70099_1_, float p_70099_2_)
/*     */   {
/* 139 */     return super.entityDropItem(p_70099_1_, p_70099_2_);
/*     */   }
/*     */   
/*     */   public void onCollideWithPlayer(EntityPlayer player) {
/* 143 */     if (!this.canBePickedUp)
/* 144 */       return;
/* 145 */     if (this.inGround) {
/* 146 */       if (BowHelper.getItem(this.type) == null) {
/* 147 */         return;
/*     */       }
/* 149 */       EntityItem arrow = new EntityItem(player.worldObj, player.posX, player.posY, player.posZ, new ItemStack(BowHelper.getItem(this.type)));
/* 150 */       if (!player.worldObj.isRemote)
/* 151 */         player.worldObj.spawnEntityInWorld(arrow);
/* 152 */       setDead();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\projectiles\EntityCustomArrow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */