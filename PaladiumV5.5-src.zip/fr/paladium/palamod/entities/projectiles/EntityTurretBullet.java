/*    */ package fr.paladium.palamod.entities.projectiles;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*    */ import fr.paladium.palamod.tiles.TileEntityTurret;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.boss.EntityWither;
/*    */ import net.minecraft.entity.projectile.EntityThrowable;
/*    */ import net.minecraft.util.DamageSource;
/*    */ import net.minecraft.util.MovingObjectPosition;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class EntityTurretBullet
/*    */   extends EntityThrowable
/*    */ {
/*    */   static final float damage = 5.0F;
/*    */   
/*    */   public EntityTurretBullet(World world)
/*    */   {
/* 19 */     super(world);
/*    */   }
/*    */   
/*    */   protected void onImpact(MovingObjectPosition object)
/*    */   {
/* 24 */     if (!this.worldObj.isRemote) {
/* 25 */       if ((this.worldObj.getTileEntity(object.blockX, object.blockY, object.blockZ) instanceof TileEntityTurret)) {
/* 26 */         return;
/*    */       }
/* 28 */       setDead();
/* 29 */       Entity entity = object.entityHit;
/* 30 */       if (entity == null) {
/* 31 */         return;
/*    */       }
/* 33 */       if (((entity instanceof EntityWither)) || ((entity instanceof EntityCustomWither))) {
/* 34 */         entity.attackEntityFrom(DamageSource.magic, 5.0F);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected float getGravityVelocity() {
/* 40 */     return 0.0F;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\entities\projectiles\EntityTurretBullet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */