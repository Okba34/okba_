/*    */ package fr.paladium.palamod;
/*    */ 
/*    */ import cpw.mods.fml.common.Mod;
/*    */ import cpw.mods.fml.common.Mod.EventHandler;
/*    */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*    */ import cpw.mods.fml.common.event.FMLServerStartingEvent;
/*    */ import cpw.mods.fml.common.event.FMLServerStoppingEvent;
/*    */ import fr.paladium.palamod.common.commands.CommandFactions;
/*    */ import fr.paladium.palamod.common.commands.CommandFurnace;
/*    */ import fr.paladium.palamod.common.commands.CommandSetXpJobs;
/*    */ import fr.paladium.palamod.job.ModJobs;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ @Mod(modid="palamod", version="5.5", name="PalaMod", dependencies="required-after:Forge@[10.13.4.1448,)", acceptedMinecraftVersions="[1.7.10]")
/*    */ public class PalaMod
/*    */ {
/* 22 */   public static final Logger logger = LogManager.getLogger("PalaMod");
/*    */   
/*    */   public static final int modLoaded = 1;
/* 25 */   public static boolean charger = false;
/*    */   
/*    */   public static byte[] music;
/*    */   public static net.minecraft.world.World world;
/* 29 */   public static String MODID = "palamod";
/*    */   
/*    */   @cpw.mods.fml.common.Mod.Instance("palamod")
/*    */   public static PalaMod instance;
/*    */   @cpw.mods.fml.common.SidedProxy(clientSide="fr.paladium.palamod.proxy.ClientProxy", serverSide="fr.paladium.palamod.proxy.CommonProxy")
/*    */   public static CommonProxy proxy;
/*    */   
/*    */   public PalaMod()
/*    */   {
/* 38 */     logger.info("Paladium best server?");
/*    */   }
/*    */   
/*    */   @Mod.EventHandler
/*    */   public void preInit(FMLPreInitializationEvent event) {
/* 43 */     logger.info("PalaMod (5.5) -- Preparing for launch.");
/* 44 */     logger.info("Entering preinitialization phase.");
/*    */     
/* 46 */     proxy.preInit(event);
/*    */   }
/*    */   
/*    */   @Mod.EventHandler
/*    */   public void init(FMLInitializationEvent event) throws Exception {
/* 51 */     logger.info("Entering initialization phase.");
/*    */     
/* 53 */     proxy.init(event);
/*    */   }
/*    */   
/*    */   @Mod.EventHandler
/*    */   public void postInit(FMLPostInitializationEvent event) {
/* 58 */     logger.info("Entering postinitialization phase.");
/*    */     
/* 60 */     proxy.postInit(event);
/*    */   }
/*    */   
/*    */   @Mod.EventHandler
/*    */   public void serverLoad(FMLServerStartingEvent event) {
/* 65 */     event.registerServerCommand(new fr.paladium.palamod.common.commands.CommandSendMessage());
/* 66 */     event.registerServerCommand(new fr.paladium.palamod.common.commands.CommandAnnounceBoss());
/* 67 */     event.registerServerCommand(new fr.paladium.palamod.common.commands.CommandStopBoss());
/* 68 */     event.registerServerCommand(new CommandFurnace());
/* 69 */     event.registerServerCommand(new fr.paladium.palamod.common.commands.CommandFurnaceInfo());
/* 70 */     event.registerServerCommand(new CommandFactions());
/* 71 */     event.registerServerCommand(new CommandSetXpJobs());
/*    */     
/*    */ 
/* 74 */     ModJobs.autoSave();
/* 75 */     world = event.getServer().getEntityWorld();
/*    */   }
/*    */   
/*    */   @Mod.EventHandler
/*    */   public void serverStop(FMLServerStoppingEvent event) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\PalaMod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */