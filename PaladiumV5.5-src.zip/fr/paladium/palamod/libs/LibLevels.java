/*   */ package fr.paladium.palamod.libs;
/*   */ 
/*   */ public class LibLevels
/*   */ {
/* 5 */   public static int MAX_LEVEL = 80;
/*   */   public static final int CAPACITY_SPEED = 0;
/*   */   public static final int CAPACITY_DAMAGE = 1;
/*   */   public static final int CAPACITY_EXPLOSION = 2;
/*   */   public static final int CAPACITY_LIFE = 3;
/*   */   public static final int CAPACITY_JUMP = 4;
/*   */   public static final int MAX_CAPACITY_SPEED = 30;
/*   */   public static final int MAX_CAPACITY_DAMAGE = 10;
/*   */   public static final int MAX_CAPACITY_EXPLOSION = 100;
/*   */   public static final int MAX_CAPACITY_LIFE = 6;
/*   */   public static final int MAX_CAPACITY_JUMP = 20;
/*   */   public static final float DEFAULT_PLAYER_SPEED = 0.1F;
/*   */   public static final int MAX_CAPACITY_POINT = 100;
/*   */   public static final int CAPACITY_POINT_PER_LEVEL = 5;
/*   */   public static final int SPELL_BATUM = 0;
/*   */   public static final int SPELL_AERUM = 1;
/*   */   public static final int SPELL_INERTIUM = 2;
/*   */   public static final int SPELL_MENTALIS = 3;
/*   */   public static final int SPELL_REPULSION = 4;
/*   */   public static final int SPELL_EXPLODE = 5;
/*   */   public static final int SPELL_PERCEPTION = 6;
/*   */   public static final int SPELL_OMNISCIENCE = 7;
/*   */   public static final int SPELL_OBSERVATUS = 8;
/*   */   public static final int SPELL_POINT_PER_LEVEL = 1;
/*   */   public static final int SPELL_INERTIUM_TIME_1 = 10;
/*   */   public static final int SPELL_INERTIUM_TIME_2 = 30;
/*   */   public static final int SPELL_INERTIUM_TIME_3 = 60;
/*   */   public static final int SPELL_PERCEPTION_RADIUS_1 = 12;
/*   */   public static final int SPELL_PERCEPTION_RADIUS_2 = 24;
/*   */   public static final int SPELL_PERCEPTION_RADIUS_3 = 32;
/*   */   public static final int SPELL_OBSERVATUS_RADIUS_1 = 12;
/*   */   public static final int SPELL_OBSERVATUS_RADIUS_2 = 24;
/*   */   public static final int SPELL_OBSERVATUS_RADIUS_3 = 32;
/*   */   public static final int SPELL_MENTALIS_TIME_1 = 20;
/*   */   public static final int SPELL_MENTALIS_TIME_2 = 40;
/*   */   public static final int SPELL_MENTALIS_TIME_3 = 60;
/*   */   public static final int SPELL_OMNISCIENCE_TIME = 10;
/*   */   public static final int SPELL_REPULSION_RANGE_1 = 2;
/*   */   public static final int SPELL_REPULSION_RANGE_2 = 3;
/*   */   public static final int SPELL_REPULSION_RANGE_3 = 4;
/*   */   public static final int SPELL_REPULSION_POWER_1 = 3;
/*   */   public static final int SPELL_REPULSION_POWER_2 = 4;
/*   */   public static final int SPELL_REPULSION_POWER_3 = 5;
/*   */   public static final int HEIGHT_SPELL_LIST_ELEMENT = 32;
/*   */   public static final int X_OFFSET_SPELL_LIST_ELEMENT = 2;
/*   */   public static final int WIDTH_SPELL_LIST = 146;
/*   */   public static final int HEIGHT_SPELL_LIST = 127;
/*   */   public static final int WIDTH_SPELL_IMAGE = 97;
/*   */   public static final int HEIGHT_SPELL_IMAGE = 50;
/*   */   public static final int WIDTH_SPELL_DESC = 93;
/*   */   public static final int HEIGHT_SPELL_DESC = 60;
/*   */   public static final int Y_OFFSET_SPELL_IMAGE = 6;
/*   */   public static final int X_OFFSET_SPELL_IMAGE = 0;
/*   */   public static final int X_OFFSET_SPELL_LIST = 6;
/*   */   public static final int Y_OFFSET_SPELL_LIST = 26;
/*   */   public static final int X_OFFSET_SPELL_TEXT = 3;
/*   */   public static final int Y_OFFSET_SPELL_TEXT = 5;
/*   */   public static final int Y_OFFSET_SPELL_NAME = 60;
/*   */   public static final int X_OFFSET_SPELL_NAME = 5;
/*   */   public static final int Y_OFFSET_SPELL_LIST_LEVEL = 15;
/*   */   public static final int Y_OFFSET_SPELL_LEVELS = 142;
/*   */   public static final int X_OFFSET_SPELL_LEVELS = 249;
/*   */   public static final int X_DISTANCE_SPELL_LEVELS = 2;
/*   */   public static final int Y_OFFSET_SPELL_TITLE = 7;
/*   */   public static final int Y_OFFSET_SPELL_POINTS = 30;
/*   */   public static final int X_OFFSET_SPELL_POINTS = 30;
/*   */   public static final int X_MARGIN_SPELL_POINTS = 3;
/*   */   public static final int Y_OFFSET_SPELL_DESC = 24;
/*   */   public static final int X_OFFSET_SPELL_DESC = 4;
/*   */   public static final int Y_OFFSET_DESC_BETWEEN = 8;
/*   */   public static final int Y_OFFSET_BETWEEN_CAPACITY = 13;
/*   */   public static final int Y_OFFSET_CAPACITY = 40;
/*   */   public static final int X_OFFSET_CAPACITY = -18;
/*   */   public static final int X_OFFSET_CAPACITY_BUTTONS = 10;
/*   */   public static final int Y_OFFSET_CAPACITY_POINTS = 115;
/*   */   public static final int Y_OFFSET_CAPACITY_POINTS_TOTAL = 143;
/*   */   public static final int X_OFFSET_CAPACITY_POINTS_TOTAL = 113;
/*   */   public static final int HUD_SPELL_RADIUS = 70;
/*   */   public static final float HUD_SPELL_ALPHA = 0.3F;
/*   */   public static final float HUD_SPELL_AMMOUNT = 6.0F;
/*   */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibLevels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */