package fr.paladium.palamod.libs;

public class LibMisc
{
  public static final String MOD_ID = "palamod";
  public static final String MOD_NAME = "palamod";
  public static final String VERSION = "1.0";
  public static final String PROXY_SERVER = "fr.paladium.common.core.proxy.CommonProxy";
  public static final String PROXY_CLIENT = "fr.paladium.common.core.proxy.ClientProxy";
  public static final String SERVER_MOD_ID = "paladiumservertools";
  public static final String NETWORK_CHANNEL = "palamod";
  public static final int INSTRUCTION_SETHOME = 0;
  public static final int INSTRUCTION_HOME = 1;
  public static final int INSTRUCTION_ADDCAP = 2;
  public static final int INSTRUCTION_ADDSPELL = 3;
  public static final int INSTRUCTION_SENDSPELL = 4;
  public static final int INSTRUCTION_ADD_GOLEM_UPGRADE = 5;
  public static final int INSTRUCTION_HEAD_ROTATION = 6;
  public static final int INSTRUCTION_REQUEST_PACKAGES = 7;
  public static final int INSTRUCTION_REQUEST_TRADE_OFFERS = 8;
  public static final int INSTRUCTION_REQUEST_MONEY = 9;
  public static final int INSTRUCTION_REQUEST_PLAYER_OFFERS = 10;
  public static final int INSTRUCTION_CREATE_OFFER = 11;
  public static final int INSTRUCTION_CHEAT = 12;
  public static final int GEM_EARTH = 0;
  public static final int GEM_WATER = 1;
  public static final int GEM_AIR = 2;
  public static final int GEM_FIRE = 3;
  public static final int SPEED_I = 0;
  public static final int SPEED_II = 1;
  public static final int FORCE_I = 2;
  public static final int NO_FALL = 3;
  public static final int VITALITY_1 = 4;
  public static final int VITALITY_2 = 5;
  public static final int VITALITY_3 = 6;
  public static final int DAMAGE_MOB = 7;
  public static final int FIRE_PROTECTION_1 = 8;
  public static final int FIRE_PROTECTION_2 = 9;
  public static final int FIRE_PROTECTION_3 = 10;
  public static final int JUMP_1 = 11;
  public static final int JUMP_2 = 12;
  public static final int MALUS_SPEED = 0;
  public static final int MALUS_FORCE = 1;
  public static final int MALUS_VITALITY = 2;
  public static final int MALUS_KNOCKBACK = 3;
  public static final int MALUS_NIGHT_VISION = 4;
  public static final int MALUS_HASTE = 5;
  public static final int DELAY_NOTIFICATION_HUD = 2000;
  public static final int DELAY_NOTIFICATION_DECAY = 500;
  public static final int CLICK_INTERVAL = 250;
  public static final int MARKET_CACHE_TIME = 5;
  public static final int MAX_DISTANCE_INTERACT = 10;
  public static final String NAME_GUARDIAN_KEEPER_DATA = "palamod_guardianKeeper";
  public static final int ARMOR_COMPRESSOR_TIME = 100;
  public static final String RUNE_BONUS = "bonusType";
  public static final String RUNE_MALUS = "malusType";
  public static final String RUNE_LIST = "runes";
  public static final String DECORATION = "tabDecoration";
  public static final int EGGPLANT = 0;
  public static final int CHERVIL = 1;
  public static final int KIWANO = 2;
  public static final int ORANGEBLUE = 3;
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibMisc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */