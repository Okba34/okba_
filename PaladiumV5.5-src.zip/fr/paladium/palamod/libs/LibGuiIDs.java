package fr.paladium.palamod.libs;

public class LibGuiIDs
{
  public static final int INVENTORY_UNIFIED = 40;
  public static final int FACTION_UNIFIED = 41;
  public static final int LEVEL_UNIFIED = 42;
  public static final int SPELL_UNIFIED = 43;
  public static final int JOB_UNIFIED = 44;
  public static final int COSMETIC_UNIFIED = 45;
  public static final int PROMPT = 46;
  public static final int GUARDIAN_GOLEM = 7;
  public static final int GUARDIAN_GOLEM_TREE = 8;
  public static final int GUARDIAN_KEEPER = 9;
  public static final int PALADIUM_MACHINE = 10;
  public static final int PALADIUM_FURNACE = 11;
  public static final int PALADIUM_GRINDER = 12;
  public static final int VOIDSTONE = 13;
  public static final int CHEST_EXPLORER = 14;
  public static final int BACKPACK = 15;
  public static final int STUFF_SWITCHER = 16;
  public static final int BOW_MACHINE = 17;
  public static final int ONLINE_DETECTOR = 18;
  public static final int COMPRESSOR = 19;
  public static final int OBSIDIAN_UPGRADE = 20;
  public static final int PALADIUM_CHEST = 21;
  public static final int MAGICAL_ANVIL = 22;
  public static final int IN_GAME_SHOP = 23;
  public static final int IN_GAME_EXCHANGE = 24;
  public static final int FORGE = 25;
  public static final int COBBLEBREAKER = 26;
  public static final int FRIDGE = 27;
  public static final int BARBECUE = 28;
  public static final int UNCLAIMFINDERBLUE = 29;
  public static final int WOODMACHINE = 30;
  public static final int IN_GAME_OFFERS = 31;
  public static final int INVENTORY_DEFAULT = 32;
  public static final int GUI_TWEAKED_ENDER_CHEST = 33;
  public static final int DISPLAY_INFO = 34;
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibGuiIDs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */