/*   */ package fr.paladium.palamod.libs;
/*   */ 
/*   */ import fr.paladium.palamod.PalaMod;
/*   */ 
/*   */ public class LibJobs
/*   */ {
/* 7 */   public static final String JOB_EXTENDED_PROPERTY = PalaMod.MODID + "_JobsData";
/*   */   public static final int ALCHIMISTE = 1;
/*   */   public static final int FARMER = 2;
/*   */   public static final int MINER = 3;
/*   */   public static final int LUMBERJACK = 4;
/*   */   public static final int HUNTER = 5;
/*   */   public static final int MAX_LEVEL = 20;
/*   */   public static final int MAX_JOBS = 5;
/*   */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibJobs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */