/*     */ package fr.paladium.palamod.libs;
/*     */ 
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LibRessources
/*     */ {
/*   9 */   public static final String GUARDIAN_GOLEM = PalaMod.MODID + ":textures/entity/guardian_golem.png";
/*  10 */   public static final String SPECTRUM = PalaMod.MODID + ":textures/entity/spectrum.png";
/*  11 */   public static final String SPECTRUM_LAYER = PalaMod.MODID + ":textures/entity/spectrum_layer.png";
/*     */   
/*     */ 
/*     */ 
/*  15 */   public static String GUI_ELEMENTS = PalaMod.MODID + ":textures/gui/gui_elements.png";
/*  16 */   public static String GUI_UNIFIED_BAR = PalaMod.MODID + ":textures/gui/gui_bar.png";
/*     */   
/*     */ 
/*     */ 
/*  20 */   public static String ARMOR_COMPRESSOR_GUI = PalaMod.MODID + ":textures/gui/armorCompressor.png";
/*  21 */   public static String MAGICAL_ANVIL_GUI = PalaMod.MODID + ":textures/gui/magicalAnvil.png";
/*  22 */   public static String GUARDIAN_GOLEM_GUI = PalaMod.MODID + ":textures/gui/guardian_golem.png";
/*  23 */   public static String GUARDIAN_GOLEM_GUI_TREE = PalaMod.MODID + ":textures/gui/guardian_tree.png";
/*  24 */   public static String GUARDIAN_KEEPER_GUI = PalaMod.MODID + ":textures/gui/guardian_keeper.png";
/*  25 */   public static String INVENTORY_UNIFIED = PalaMod.MODID + ":textures/gui/inventory_unified.png";
/*  26 */   public static String LEVEL_UNIFIED = PalaMod.MODID + ":textures/gui/level_unified.png";
/*  27 */   public static String SPELL_UNIFIED = PalaMod.MODID + ":textures/gui/spell_unified.png";
/*  28 */   public static String FACTION_UNIFIED = PalaMod.MODID + ":textures/gui/spell_unified.png";
/*  29 */   public static String JOB_UNIFIED = PalaMod.MODID + ":textures/gui/jobs_unified.png";
/*  30 */   public static String COSMETIC_UNIFIED = PalaMod.MODID + ":textures/gui/spell_unified.png";
/*  31 */   public static String BACKGROUND_SHOP = PalaMod.MODID + ":textures/gui/background_shop.png";
/*     */   
/*  33 */   public static int[] INVENTORY_UNIFIED_ICON = { 64, 44 };
/*  34 */   public static int[] FACTION_UNIFIED_ICON = { 80, 44 };
/*  35 */   public static int[] LEVEL_UNIFIED_ICON = { 48, 44 };
/*  36 */   public static int[] SPELL_UNIFIED_ICON = { 16, 44 };
/*  37 */   public static int[] JOB_UNIFIED_ICON = { 0, 44 };
/*  38 */   public static int[] COSMETIC_UNIFIED_ICON = { 32, 44 };
/*  39 */   public static int[] DISABLED_SLOT = { 53, 0 };
/*  40 */   public static int[] OPEN_CHEST_ICON = { 97, 44 };
/*  41 */   public static int[] PALACOIN_ICON = { 0, 60 };
/*     */   
/*     */ 
/*     */ 
/*  45 */   public static String FISHERMAN_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  46 */   public static String HUNTER_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  47 */   public static String ASSASIN_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  48 */   public static String FARMER_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  49 */   public static String MINER_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  50 */   public static String ENCHANTER_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  51 */   public static String LUMBERJACK_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  52 */   public static String JOAILLIER_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*  53 */   public static String ALCHIMISTE_LOGO = PalaMod.MODID + ":textures/gui/job_icons.png";
/*     */   
/*  55 */   public static int[] FISHERMAN_LOGO_COORDS = { 0, 60 };
/*  56 */   public static int[] HUNTER_LOGO_COORDS = { 0, 80 };
/*  57 */   public static int[] ASSASIN_LOGO_COORDS = { 0, 0 };
/*  58 */   public static int[] FARMER_LOGO_COORDS = { 0, 40 };
/*  59 */   public static int[] MINER_LOGO_COORDS = { 0, 140 };
/*  60 */   public static int[] ENCHANTER_LOGO_COORDS = { 0, 20 };
/*  61 */   public static int[] LUMBERJACK_LOGO_COORDS = { 0, 120 };
/*  62 */   public static int[] JOAILLIER_LOGO_COORDS = { 0, 100 };
/*  63 */   public static int[] ALCHIMISTE_LOGO_COORDS = { 0, 0 };
/*     */   
/*     */ 
/*     */ 
/*  67 */   public static String BATUM_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  68 */   public static String AERUM_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  69 */   public static String INERTIUM_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  70 */   public static String MENTALIS_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  71 */   public static String REPULSION_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  72 */   public static String EXPLODE_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  73 */   public static String PERCEPTION_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  74 */   public static String OMNISCIENCE_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*  75 */   public static String OBSERVATUS_LOGO = PalaMod.MODID + ":textures/gui/spell_icons.png";
/*     */   
/*  77 */   public static int[] BATUM_LOGO_COORDS = { 196, 0 };
/*  78 */   public static int[] AERUM_LOGO_COORDS = { 224, 0 };
/*  79 */   public static int[] INERTIUM_LOGO_COORDS = { 168, 0 };
/*  80 */   public static int[] MENTALIS_LOGO_COORDS = { 140, 0 };
/*  81 */   public static int[] REPULSION_LOGO_COORDS = { 28, 0 };
/*  82 */   public static int[] EXPLODE_LOGO_COORDS = { 0, 0 };
/*  83 */   public static int[] PERCEPTION_LOGO_COORDS = { 56, 0 };
/*  84 */   public static int[] OMNISCIENCE_LOGO_COORDS = { 84, 0 };
/*  85 */   public static int[] OBSERVATUS_LOGO_COORDS = { 112, 0 };
/*     */   
/*  87 */   public static String BATUM_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  88 */   public static String AERUM_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  89 */   public static String INERTIUM_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  90 */   public static String MENTALIS_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  91 */   public static String REPULSION_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  92 */   public static String EXPLODE_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  93 */   public static String PERCEPTION_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  94 */   public static String OMNISCIENCE_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*  95 */   public static String OBSERVATUS_IMAGE = PalaMod.MODID + ":textures/gui/spell_images.png";
/*     */   
/*  97 */   public static int[] BATUM_IMAGE_COORDS = { 0, 0 };
/*  98 */   public static int[] AERUM_IMAGE_COORDS = { 97, 100 };
/*  99 */   public static int[] INERTIUM_IMAGE_COORDS = { 97, 50 };
/* 100 */   public static int[] MENTALIS_IMAGE_COORDS = { 97, 0 };
/* 101 */   public static int[] REPULSION_IMAGE_COORDS = { 0, 150 };
/* 102 */   public static int[] EXPLODE_IMAGE_COORDS = { 0, 102 };
/* 103 */   public static int[] PERCEPTION_IMAGE_COORDS = { 0, 200 };
/* 104 */   public static int[] OMNISCIENCE_IMAGE_COORDS = { 0, 50 };
/* 105 */   public static int[] OBSERVATUS_IMAGE_COORDS = { 97, 150 };
/*     */   
/* 107 */   public static int SPELL_LOGO_SIZE = 28;
/*     */   
/*     */ 
/*     */ 
/* 111 */   public static int X_UNIFIED_BUTTON_1 = 0;
/* 112 */   public static int Y_UNIFIED_BUTTON_1 = 0;
/* 113 */   public static int UNIFIED_BAR_MAGENTA = 0;
/* 114 */   public static int UNIFIED_BAR_GREEN = 9;
/* 115 */   public static int UNIFIED_BAR_GREY = 18;
/* 116 */   public static int UNIFIED_BAR_RED = 27;
/*     */   
/* 118 */   public static int[] BUTTON_PLUS_COORDS = { 44, 0 };
/* 119 */   public static int[] BUTTON_DIGIT_COORDS = { 44, 18 };
/*     */   
/* 121 */   public static int X_OFFSET_SHOP_DISPLAYER = 5;
/*     */   
/*     */ 
/*     */ 
/* 125 */   public static int HEIGHT_UNIFIED_BAR = 9;
/* 126 */   public static int WIDTH_BUTTON_PLUS = 9;
/* 127 */   public static int WIDTH_BUTTON_DIGIT = 9;
/* 128 */   public static int WIDTH_GUARDIAN_GOLEM_GUI = 238;
/* 129 */   public static int HEIGHT_GUARDUAN_GOLEM_GUI = 227;
/* 130 */   public static int WIDTH_GUARDIAN_KEEPER_GUI = 175;
/* 131 */   public static int HEIGHT_GUARDUAN_KEEPER_GUI = 120;
/* 132 */   public static int WIDTH_BACKGROUND_SHOP = 512;
/* 133 */   public static int HEIGHT_BACKGROUND_SHOP = 512;
/* 134 */   public static int WIDTH_ICON_BUTTON_SHOP = 16;
/* 135 */   public static int HEIGHT_ICON_BUTTON_SHOP = 16;
/* 136 */   public static int WIDTH_SHOP_ENTRY = 300;
/* 137 */   public static int HEIGHT_SHOP_ENTRY = 50;
/* 138 */   public static int WIDTH_ICON_SHOP = 30;
/* 139 */   public static int HEIGHT_ICON_SHOP = 30;
/* 140 */   public static int SHOP_LIST_WIDTH = 300;
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibRessources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */