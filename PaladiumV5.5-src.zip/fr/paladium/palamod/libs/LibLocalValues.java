package fr.paladium.palamod.libs;

public class LibLocalValues
{
  public static final String LOCAL_MONEY = "localMoney";
  public static final String LOCAL_HOMES = "localHomes";
  public static final String LOCAL_JOBS = "localJobs";
  public static final String LOCAL_LEVELS = "localLevels";
  public static final String LOCAL_LEVEL = "localLevel";
  public static final String LOCAL_XP = "localXP";
  public static final String LOCAL_CAPACITY_POINTS = "capacityPoints";
  public static final String LOCAL_SPELLS = "spell";
  public static final String LOCAL_SPELL_POINTS = "spellPoints";
  public static final String LOCAL_GOLEM = "golemData";
  public static final String LOCAL_GOLEM_ID = "golemID";
  public static final String LOCAL_SHOP_PACKAGES = "shopPackages";
  public static final String LOCAL_EXCHANGE_OFFERS = "exchangeOffers";
  public static final String LOCAL_BALANCES = "moneyBalance";
  public static final String LOCAL_EXCHANGE_OFFERS_PLAYER = "exchangePlayer";
  public static final String IS_MENTALISED = "isMentalised";
  public static final String SERVER = "server";
  public static final int DEFAULT_LOCAL_VALUE_INT = 0;
  public static final String DEFAULT_LOCAL_VALUE_STRING = "";
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\libs\LibLocalValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */