/*    */ package fr.paladium.palamod.client.particles;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.particle.EntityFX;
/*    */ import net.minecraft.client.renderer.RenderHelper;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ExplosionParticles extends EntityFX
/*    */ {
/* 14 */   private static final ResourceLocation field_110127_a = new ResourceLocation("textures/entity/explosion.png");
/*    */   
/*    */   private int field_70581_a;
/*    */   private int field_70584_aq;
/*    */   private TextureManager theRenderEngine;
/*    */   private float field_70582_as;
/*    */   private static final String __OBFID = "CL_00000910";
/*    */   
/*    */   public ExplosionParticles(TextureManager p_i1213_1_, World p_i1213_2_, double p_i1213_3_, double p_i1213_5_, double p_i1213_7_, double p_i1213_9_, double p_i1213_11_, double p_i1213_13_)
/*    */   {
/* 24 */     super(p_i1213_2_, p_i1213_3_, p_i1213_5_, p_i1213_7_, 0.0D, 0.0D, 0.0D);
/* 25 */     this.theRenderEngine = p_i1213_1_;
/* 26 */     this.field_70584_aq = (6 + this.rand.nextInt(4));
/* 27 */     this.particleRed = (this.particleGreen = this.particleBlue = this.rand.nextFloat() * 0.6F + 0.4F);
/* 28 */     this.field_70582_as = (1.0F - (float)p_i1213_9_ * 0.5F);
/*    */   }
/*    */   
/*    */   public void renderParticle(Tessellator p_70539_1_, float p_70539_2_, float p_70539_3_, float p_70539_4_, float p_70539_5_, float p_70539_6_, float p_70539_7_)
/*    */   {
/* 33 */     int i = (int)((this.field_70581_a + p_70539_2_) * 15.0F / this.field_70584_aq);
/*    */     
/* 35 */     if (i <= 15) {
/* 36 */       this.theRenderEngine.bindTexture(field_110127_a);
/* 37 */       float f6 = i % 4 / 4.0F;
/* 38 */       float f7 = f6 + 0.24975F;
/* 39 */       float f8 = i / 4 / 4.0F;
/* 40 */       float f9 = f8 + 0.24975F;
/* 41 */       float f10 = 2.0F * this.field_70582_as;
/* 42 */       float f11 = (float)(this.prevPosX + (this.posX - this.prevPosX) * p_70539_2_ - interpPosX);
/* 43 */       float f12 = (float)(this.prevPosY + (this.posY - this.prevPosY) * p_70539_2_ - interpPosY);
/* 44 */       float f13 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * p_70539_2_ - interpPosZ);
/* 45 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 46 */       GL11.glDisable(2896);
/* 47 */       RenderHelper.disableStandardItemLighting();
/* 48 */       p_70539_1_.startDrawingQuads();
/* 49 */       p_70539_1_.setColorRGBA_F(this.particleRed, this.particleGreen, this.particleBlue, 1.0F);
/* 50 */       p_70539_1_.setNormal(0.0F, 1.0F, 0.0F);
/* 51 */       p_70539_1_.setBrightness(240);
/* 52 */       p_70539_1_.addVertexWithUV(f11 - p_70539_3_ * f10 - p_70539_6_ * f10, f12 - p_70539_4_ * f10, f13 - p_70539_5_ * f10 - p_70539_7_ * f10, f7, f9);
/*    */       
/*    */ 
/* 55 */       p_70539_1_.addVertexWithUV(f11 - p_70539_3_ * f10 + p_70539_6_ * f10, f12 + p_70539_4_ * f10, f13 - p_70539_5_ * f10 + p_70539_7_ * f10, f7, f8);
/*    */       
/*    */ 
/* 58 */       p_70539_1_.addVertexWithUV(f11 + p_70539_3_ * f10 + p_70539_6_ * f10, f12 + p_70539_4_ * f10, f13 + p_70539_5_ * f10 + p_70539_7_ * f10, f6, f8);
/*    */       
/*    */ 
/* 61 */       p_70539_1_.addVertexWithUV(f11 + p_70539_3_ * f10 - p_70539_6_ * f10, f12 - p_70539_4_ * f10, f13 + p_70539_5_ * f10 - p_70539_7_ * f10, f6, f9);
/*    */       
/*    */ 
/* 64 */       p_70539_1_.draw();
/* 65 */       GL11.glPolygonOffset(0.0F, 0.0F);
/* 66 */       GL11.glEnable(2896);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getBrightnessForRender(float p_70070_1_) {
/* 71 */     return 61680;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void onUpdate()
/*    */   {
/* 78 */     this.prevPosX = this.posX;
/* 79 */     this.prevPosY = this.posY;
/* 80 */     this.prevPosZ = this.posZ;
/* 81 */     this.field_70581_a += 1;
/*    */     
/* 83 */     if (this.field_70581_a == this.field_70584_aq) {
/* 84 */       setDead();
/*    */     }
/*    */   }
/*    */   
/*    */   public int getFXLayer() {
/* 89 */     return 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\particles\ExplosionParticles.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */