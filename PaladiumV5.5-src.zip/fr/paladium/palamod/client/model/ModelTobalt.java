/*     */ package fr.paladium.palamod.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ public class ModelTobalt extends net.minecraft.client.model.ModelBase
/*     */ {
/*     */   ModelRenderer head;
/*     */   ModelRenderer body;
/*     */   ModelRenderer rightarm11;
/*     */   ModelRenderer rightleg;
/*     */   ModelRenderer leftleg;
/*     */   ModelRenderer head2;
/*     */   ModelRenderer head3;
/*     */   ModelRenderer head4;
/*     */   ModelRenderer head5;
/*     */   ModelRenderer head6;
/*     */   ModelRenderer head7;
/*     */   ModelRenderer head8;
/*     */   ModelRenderer head9;
/*     */   ModelRenderer head10;
/*     */   ModelRenderer head11;
/*     */   ModelRenderer head12;
/*     */   ModelRenderer leftarm2;
/*     */   ModelRenderer rightarm10;
/*     */   ModelRenderer rightarm8;
/*     */   ModelRenderer rightarm9;
/*     */   ModelRenderer leftarm6;
/*     */   ModelRenderer leftarm7;
/*     */   ModelRenderer leftarm8;
/*     */   ModelRenderer leftarm9;
/*     */   ModelRenderer connect;
/*     */   ModelRenderer rightarm;
/*     */   ModelRenderer connect2;
/*     */   ModelRenderer rightarm2;
/*     */   ModelRenderer leftarm10;
/*     */   ModelRenderer rightarm3;
/*     */   ModelRenderer leftarm11;
/*     */   ModelRenderer rightarm4;
/*     */   ModelRenderer rightarm5;
/*     */   ModelRenderer leftarm12;
/*     */   ModelRenderer leftarm13;
/*     */   ModelRenderer leftarm14;
/*     */   ModelRenderer rightarm6;
/*     */   ModelRenderer leftarm15;
/*     */   ModelRenderer rightarm7;
/*     */   ModelRenderer head13;
/*     */   ModelRenderer head14;
/*     */   
/*     */   public ModelTobalt()
/*     */   {
/*  52 */     this.textureWidth = 128;
/*  53 */     this.textureHeight = 64;
/*     */     
/*  55 */     this.head = new ModelRenderer(this, 50, 0);
/*  56 */     this.head.addBox(-6.0F, 4.0F, -7.0F, 12, 4, 1);
/*  57 */     this.head.setRotationPoint(0.0F, -6.0F, 5.0F);
/*  58 */     this.head.setTextureSize(128, 64);
/*  59 */     this.head.mirror = true;
/*  60 */     setRotation(this.head, 0.0F, 0.0F, 0.0F);
/*     */     
/*  62 */     this.body = new ModelRenderer(this, 78, 1);
/*  63 */     this.body.addBox(-9.0F, 0.0F, -2.0F, 18, 20, 6);
/*  64 */     this.body.setRotationPoint(0.0F, -9.0F, 7.0F);
/*  65 */     this.body.setTextureSize(128, 64);
/*  66 */     this.body.mirror = true;
/*  67 */     setRotation(this.body, 0.0F, 0.0F, 0.0F);
/*     */     
/*  69 */     this.rightarm11 = new ModelRenderer(this, 40, 16);
/*  70 */     this.rightarm11.addBox(-8.0F, -8.0F, -1.0F, 2, 4, 2);
/*  71 */     this.rightarm11.setRotationPoint(-10.0F, -6.0F, 8.0F);
/*  72 */     this.rightarm11.setTextureSize(128, 64);
/*  73 */     this.rightarm11.mirror = true;
/*  74 */     setRotation(this.rightarm11, 0.0F, 0.0F, 0.0F);
/*     */     
/*  76 */     this.rightleg = new ModelRenderer(this, 0, 16);
/*  77 */     this.rightleg.addBox(-3.0F, 0.0F, -3.0F, 6, 13, 6);
/*  78 */     this.rightleg.setRotationPoint(-6.0F, 11.0F, 8.0F);
/*  79 */     this.rightleg.setTextureSize(128, 64);
/*  80 */     this.rightleg.mirror = true;
/*  81 */     setRotation(this.rightleg, 0.0F, 0.0F, 0.0F);
/*     */     
/*  83 */     this.leftleg = new ModelRenderer(this, 0, 16);
/*  84 */     this.leftleg.addBox(-3.0F, 0.0F, -3.0F, 6, 13, 6);
/*  85 */     this.leftleg.setRotationPoint(6.0F, 11.0F, 8.0F);
/*  86 */     this.leftleg.setTextureSize(128, 64);
/*  87 */     this.leftleg.mirror = true;
/*  88 */     setRotation(this.leftleg, 0.0F, 0.0F, 0.0F);
/*     */     
/*  90 */     this.head2 = new ModelRenderer(this, 0, 0);
/*  91 */     this.head2.addBox(-5.0F, -5.0F, -6.0F, 10, 10, 6);
/*  92 */     this.head2.setRotationPoint(0.0F, -6.0F, 5.0F);
/*  93 */     this.head2.setTextureSize(128, 64);
/*  94 */     this.head2.mirror = true;
/*  95 */     setRotation(this.head2, 0.0F, 0.0F, 0.0F);
/*     */     
/*  97 */     this.head3 = new ModelRenderer(this, 50, 0);
/*  98 */     this.head3.addBox(-6.0F, -1.0F, -7.0F, 12, 2, 1);
/*  99 */     this.head3.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 100 */     this.head3.setTextureSize(128, 64);
/* 101 */     this.head3.mirror = true;
/* 102 */     setRotation(this.head3, 0.0F, 0.0F, 0.0F);
/*     */     
/* 104 */     this.head4 = new ModelRenderer(this, 62, 7);
/* 105 */     this.head4.addBox(-2.0F, -13.0F, -7.0F, 4, 6, 1);
/* 106 */     this.head4.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 107 */     this.head4.setTextureSize(128, 64);
/* 108 */     this.head4.mirror = true;
/* 109 */     setRotation(this.head4, 0.0F, 0.0F, 0.0F);
/*     */     
/* 111 */     this.head5 = new ModelRenderer(this, 35, 0);
/* 112 */     this.head5.addBox(-2.0F, -3.0F, -7.0F, 4, 2, 1);
/* 113 */     this.head5.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 114 */     this.head5.setTextureSize(128, 64);
/* 115 */     this.head5.mirror = true;
/* 116 */     setRotation(this.head5, 0.0F, 0.0F, 0.0F);
/*     */     
/* 118 */     this.head6 = new ModelRenderer(this, 35, 0);
/* 119 */     this.head6.addBox(-6.0F, 1.0F, -7.0F, 2, 3, 1);
/* 120 */     this.head6.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 121 */     this.head6.setTextureSize(128, 64);
/* 122 */     this.head6.mirror = true;
/* 123 */     setRotation(this.head6, 0.0F, 0.0F, 0.0F);
/*     */     
/* 125 */     this.head7 = new ModelRenderer(this, 35, 0);
/* 126 */     this.head7.addBox(-6.0F, -3.0F, -7.0F, 2, 2, 1);
/* 127 */     this.head7.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 128 */     this.head7.setTextureSize(128, 64);
/* 129 */     this.head7.mirror = true;
/* 130 */     setRotation(this.head7, 0.0F, 0.0F, 0.0F);
/*     */     
/* 132 */     this.head8 = new ModelRenderer(this, 35, 0);
/* 133 */     this.head8.addBox(4.0F, 1.0F, -7.0F, 2, 3, 1);
/* 134 */     this.head8.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 135 */     this.head8.setTextureSize(128, 64);
/* 136 */     this.head8.mirror = true;
/* 137 */     setRotation(this.head8, 0.0F, 0.0F, 0.0F);
/*     */     
/* 139 */     this.head9 = new ModelRenderer(this, 35, 0);
/* 140 */     this.head9.addBox(4.0F, -3.0F, -7.0F, 2, 2, 1);
/* 141 */     this.head9.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 142 */     this.head9.setTextureSize(128, 64);
/* 143 */     this.head9.mirror = true;
/* 144 */     setRotation(this.head9, 0.0F, 0.0F, 0.0F);
/*     */     
/* 146 */     this.head10 = new ModelRenderer(this, 50, 0);
/* 147 */     this.head10.addBox(2.0F, -3.0F, -7.0F, 1, 1, 1);
/* 148 */     this.head10.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 149 */     this.head10.setTextureSize(128, 64);
/* 150 */     this.head10.mirror = true;
/* 151 */     setRotation(this.head10, 0.0F, 0.0F, 0.0F);
/*     */     
/* 153 */     this.head11 = new ModelRenderer(this, 50, 7);
/* 154 */     this.head11.addBox(-6.0F, -11.0F, -7.0F, 3, 4, 1);
/* 155 */     this.head11.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 156 */     this.head11.setTextureSize(128, 64);
/* 157 */     this.head11.mirror = true;
/* 158 */     setRotation(this.head11, 0.0F, 0.0F, 0.0F);
/*     */     
/* 160 */     this.head12 = new ModelRenderer(this, 50, 7);
/* 161 */     this.head12.addBox(3.0F, -11.0F, -7.0F, 3, 4, 1);
/* 162 */     this.head12.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 163 */     this.head12.setTextureSize(128, 64);
/* 164 */     this.head12.mirror = true;
/* 165 */     setRotation(this.head12, 0.0F, 0.0F, 0.0F);
/*     */     
/* 167 */     this.leftarm2 = new ModelRenderer(this, 63, 45);
/* 168 */     this.leftarm2.addBox(-1.0F, 9.0F, -26.0F, 8, 8, 2);
/* 169 */     this.leftarm2.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 170 */     this.leftarm2.setTextureSize(128, 64);
/* 171 */     this.leftarm2.mirror = true;
/* 172 */     setRotation(this.leftarm2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 174 */     this.rightarm10 = new ModelRenderer(this, 13, 38);
/* 175 */     this.rightarm10.addBox(-8.0F, -4.0F, -5.0F, 2, 16, 10);
/* 176 */     this.rightarm10.setRotationPoint(-10.0F, -6.0F, 8.0F);
/* 177 */     this.rightarm10.setTextureSize(128, 64);
/* 178 */     this.rightarm10.mirror = true;
/* 179 */     setRotation(this.rightarm10, 0.0F, 0.0F, 0.0F);
/*     */     
/* 181 */     this.rightarm8 = new ModelRenderer(this, 40, 26);
/* 182 */     this.rightarm8.addBox(-8.0F, -6.0F, -5.0F, 2, 2, 2);
/* 183 */     this.rightarm8.setRotationPoint(-10.0F, -6.0F, 8.0F);
/* 184 */     this.rightarm8.setTextureSize(128, 64);
/* 185 */     this.rightarm8.mirror = true;
/* 186 */     setRotation(this.rightarm8, 0.0F, 0.0F, 0.0F);
/*     */     
/* 188 */     this.rightarm9 = new ModelRenderer(this, 40, 26);
/* 189 */     this.rightarm9.addBox(-8.0F, -6.0F, 3.0F, 2, 2, 2);
/* 190 */     this.rightarm9.setRotationPoint(-10.0F, -6.0F, 8.0F);
/* 191 */     this.rightarm9.setTextureSize(128, 64);
/* 192 */     this.rightarm9.mirror = true;
/* 193 */     setRotation(this.rightarm9, 0.0F, 0.0F, 0.0F);
/*     */     
/* 195 */     this.leftarm6 = new ModelRenderer(this, 40, 16);
/* 196 */     this.leftarm6.addBox(6.0F, -8.0F, -1.0F, 2, 4, 2);
/* 197 */     this.leftarm6.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 198 */     this.leftarm6.setTextureSize(128, 64);
/* 199 */     this.leftarm6.mirror = true;
/* 200 */     setRotation(this.leftarm6, 0.0F, 0.0F, 0.0F);
/*     */     
/* 202 */     this.leftarm7 = new ModelRenderer(this, 40, 26);
/* 203 */     this.leftarm7.addBox(6.0F, -6.0F, -5.0F, 2, 2, 2);
/* 204 */     this.leftarm7.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 205 */     this.leftarm7.setTextureSize(128, 64);
/* 206 */     this.leftarm7.mirror = true;
/* 207 */     setRotation(this.leftarm7, 0.0F, 0.0F, 0.0F);
/*     */     
/* 209 */     this.leftarm8 = new ModelRenderer(this, 40, 26);
/* 210 */     this.leftarm8.addBox(6.0F, -6.0F, 3.0F, 2, 2, 2);
/* 211 */     this.leftarm8.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 212 */     this.leftarm8.setTextureSize(128, 64);
/* 213 */     this.leftarm8.mirror = true;
/* 214 */     setRotation(this.leftarm8, 0.0F, 0.0F, 0.0F);
/*     */     
/* 216 */     this.leftarm9 = new ModelRenderer(this, 38, 38);
/* 217 */     this.leftarm9.addBox(6.0F, -4.0F, -5.0F, 2, 16, 10);
/* 218 */     this.leftarm9.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 219 */     this.leftarm9.setTextureSize(128, 64);
/* 220 */     this.leftarm9.mirror = true;
/* 221 */     setRotation(this.leftarm9, 0.0F, 0.0F, 0.0F);
/*     */     
/* 223 */     this.connect = new ModelRenderer(this, 81, 29);
/* 224 */     this.connect.addBox(-6.0F, -2.0F, -2.0F, 5, 4, 3);
/* 225 */     this.connect.setRotationPoint(12.0F, -4.0F, 8.0F);
/* 226 */     this.connect.setTextureSize(128, 64);
/* 227 */     this.connect.mirror = true;
/* 228 */     setRotation(this.connect, 0.0F, 0.0F, 0.5235988F);
/*     */     
/* 230 */     this.rightarm = new ModelRenderer(this, 63, 45);
/* 231 */     this.rightarm.addBox(-7.0F, 9.0F, -26.0F, 8, 8, 2);
/* 232 */     this.rightarm.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 233 */     this.rightarm.setTextureSize(128, 64);
/* 234 */     this.rightarm.mirror = true;
/* 235 */     setRotation(this.rightarm, 0.0F, 0.0F, 0.0F);
/*     */     
/* 237 */     this.connect2 = new ModelRenderer(this, 81, 29);
/* 238 */     this.connect2.addBox(-6.0F, -2.0F, -2.0F, 5, 4, 3);
/* 239 */     this.connect2.setRotationPoint(-7.0F, -7.0F, 8.0F);
/* 240 */     this.connect2.setTextureSize(128, 64);
/* 241 */     this.connect2.mirror = true;
/* 242 */     setRotation(this.connect2, 0.0F, 0.0F, -0.5235988F);
/*     */     
/* 244 */     this.rightarm2 = new ModelRenderer(this, 102, 30);
/* 245 */     this.rightarm2.addBox(-6.0F, -2.0F, -3.0F, 6, 18, 6);
/* 246 */     this.rightarm2.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 247 */     this.rightarm2.setTextureSize(128, 64);
/* 248 */     this.rightarm2.mirror = true;
/* 249 */     setRotation(this.rightarm2, 0.0F, 0.0F, 0.0F);
/*     */     
/* 251 */     this.leftarm10 = new ModelRenderer(this, 102, 30);
/* 252 */     this.leftarm10.addBox(0.0F, -2.0F, -3.0F, 6, 18, 6);
/* 253 */     this.leftarm10.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 254 */     this.leftarm10.setTextureSize(128, 64);
/* 255 */     this.leftarm10.mirror = true;
/* 256 */     setRotation(this.leftarm10, 0.0F, 0.0F, 0.0F);
/*     */     
/* 258 */     this.rightarm3 = new ModelRenderer(this, 63, 45);
/* 259 */     this.rightarm3.addBox(-5.0F, 11.0F, -16.0F, 4, 4, 14);
/* 260 */     this.rightarm3.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 261 */     this.rightarm3.setTextureSize(128, 64);
/* 262 */     this.rightarm3.mirror = true;
/* 263 */     setRotation(this.rightarm3, 0.0F, 0.0F, 0.0F);
/*     */     
/* 265 */     this.leftarm11 = new ModelRenderer(this, 63, 45);
/* 266 */     this.leftarm11.addBox(1.0F, 11.0F, -16.0F, 4, 4, 14);
/* 267 */     this.leftarm11.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 268 */     this.leftarm11.setTextureSize(128, 64);
/* 269 */     this.leftarm11.mirror = true;
/* 270 */     setRotation(this.leftarm11, 0.0F, 0.0F, 0.0F);
/*     */     
/* 272 */     this.rightarm4 = new ModelRenderer(this, 63, 53);
/* 273 */     this.rightarm4.addBox(-5.0F, 11.0F, -24.0F, 4, 4, 2);
/* 274 */     this.rightarm4.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 275 */     this.rightarm4.setTextureSize(128, 64);
/* 276 */     this.rightarm4.mirror = true;
/* 277 */     setRotation(this.rightarm4, 0.0F, 0.0F, 0.0F);
/*     */     
/* 279 */     this.rightarm5 = new ModelRenderer(this, 63, 45);
/* 280 */     this.rightarm5.addBox(-7.0F, 9.0F, -22.0F, 8, 8, 2);
/* 281 */     this.rightarm5.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 282 */     this.rightarm5.setTextureSize(128, 64);
/* 283 */     this.rightarm5.mirror = true;
/* 284 */     setRotation(this.rightarm5, 0.0F, 0.0F, 0.0F);
/*     */     
/* 286 */     this.leftarm12 = new ModelRenderer(this, 63, 45);
/* 287 */     this.leftarm12.addBox(-1.0F, 9.0F, -22.0F, 8, 8, 2);
/* 288 */     this.leftarm12.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 289 */     this.leftarm12.setTextureSize(128, 64);
/* 290 */     this.leftarm12.mirror = true;
/* 291 */     setRotation(this.leftarm12, 0.0F, 0.0F, 0.0F);
/*     */     
/* 293 */     this.leftarm13 = new ModelRenderer(this, 63, 53);
/* 294 */     this.leftarm13.addBox(1.0F, 11.0F, -24.0F, 4, 4, 2);
/* 295 */     this.leftarm13.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 296 */     this.leftarm13.setTextureSize(128, 64);
/* 297 */     this.leftarm13.mirror = true;
/* 298 */     setRotation(this.leftarm13, 0.0F, 0.0F, 0.0F);
/*     */     
/* 300 */     this.leftarm14 = new ModelRenderer(this, 63, 45);
/* 301 */     this.leftarm14.addBox(-1.0F, 9.0F, -18.0F, 8, 8, 2);
/* 302 */     this.leftarm14.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 303 */     this.leftarm14.setTextureSize(128, 64);
/* 304 */     this.leftarm14.mirror = true;
/* 305 */     setRotation(this.leftarm14, 0.0F, 0.0F, 0.0F);
/*     */     
/* 307 */     this.rightarm6 = new ModelRenderer(this, 63, 45);
/* 308 */     this.rightarm6.addBox(-7.0F, 9.0F, -18.0F, 8, 8, 2);
/* 309 */     this.rightarm6.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 310 */     this.rightarm6.setTextureSize(128, 64);
/* 311 */     this.rightarm6.mirror = true;
/* 312 */     setRotation(this.rightarm6, 0.0F, 0.0F, 0.0F);
/*     */     
/* 314 */     this.leftarm15 = new ModelRenderer(this, 63, 53);
/* 315 */     this.leftarm15.addBox(1.0F, 11.0F, -20.0F, 4, 4, 2);
/* 316 */     this.leftarm15.setRotationPoint(10.0F, -6.0F, 8.0F);
/* 317 */     this.leftarm15.setTextureSize(128, 64);
/* 318 */     this.leftarm15.mirror = true;
/* 319 */     setRotation(this.leftarm15, 0.0F, 0.0F, 0.0F);
/*     */     
/* 321 */     this.rightarm7 = new ModelRenderer(this, 63, 53);
/* 322 */     this.rightarm7.addBox(-5.0F, 11.0F, -20.0F, 4, 4, 2);
/* 323 */     this.rightarm7.setRotationPoint(-10.0F, -6.0F, 7.0F);
/* 324 */     this.rightarm7.setTextureSize(128, 64);
/* 325 */     this.rightarm7.mirror = true;
/* 326 */     setRotation(this.rightarm7, 0.0F, 0.0F, 0.0F);
/*     */     
/* 328 */     this.head13 = new ModelRenderer(this, 50, 0);
/* 329 */     this.head13.addBox(-6.0F, -7.0F, -7.0F, 12, 4, 1);
/* 330 */     this.head13.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 331 */     this.head13.setTextureSize(128, 64);
/* 332 */     this.head13.mirror = true;
/* 333 */     setRotation(this.head13, 0.0F, 0.0F, 0.0F);
/*     */     
/* 335 */     this.head14 = new ModelRenderer(this, 50, 0);
/* 336 */     this.head14.addBox(-3.0F, -3.0F, -7.0F, 1, 1, 1);
/* 337 */     this.head14.setRotationPoint(0.0F, -6.0F, 5.0F);
/* 338 */     this.head14.setTextureSize(128, 64);
/* 339 */     this.head14.mirror = true;
/* 340 */     setRotation(this.head14, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */   
/*     */   public void render(net.minecraft.entity.Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 344 */     setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
/* 345 */     this.head.render(par7);
/* 346 */     this.body.render(par7);
/* 347 */     this.rightarm11.render(par7);
/* 348 */     this.rightleg.render(par7);
/* 349 */     this.leftleg.render(par7);
/* 350 */     this.head2.render(par7);
/* 351 */     this.head3.render(par7);
/* 352 */     this.head4.render(par7);
/* 353 */     this.head5.render(par7);
/* 354 */     this.head6.render(par7);
/* 355 */     this.head7.render(par7);
/* 356 */     this.head8.render(par7);
/* 357 */     this.head9.render(par7);
/* 358 */     this.head10.render(par7);
/* 359 */     this.head11.render(par7);
/* 360 */     this.head12.render(par7);
/* 361 */     this.leftarm2.render(par7);
/* 362 */     this.rightarm10.render(par7);
/* 363 */     this.rightarm8.render(par7);
/* 364 */     this.rightarm9.render(par7);
/* 365 */     this.leftarm6.render(par7);
/* 366 */     this.leftarm7.render(par7);
/* 367 */     this.leftarm8.render(par7);
/* 368 */     this.leftarm9.render(par7);
/* 369 */     this.connect.render(par7);
/* 370 */     this.rightarm.render(par7);
/* 371 */     this.connect2.render(par7);
/* 372 */     this.rightarm2.render(par7);
/* 373 */     this.leftarm10.render(par7);
/* 374 */     this.rightarm3.render(par7);
/* 375 */     this.leftarm11.render(par7);
/* 376 */     this.rightarm4.render(par7);
/* 377 */     this.rightarm5.render(par7);
/* 378 */     this.leftarm12.render(par7);
/* 379 */     this.leftarm13.render(par7);
/* 380 */     this.leftarm14.render(par7);
/* 381 */     this.rightarm6.render(par7);
/* 382 */     this.leftarm15.render(par7);
/* 383 */     this.rightarm7.render(par7);
/* 384 */     this.head13.render(par7);
/* 385 */     this.head14.render(par7);
/*     */   }
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 389 */     model.rotateAngleX = x;
/* 390 */     model.rotateAngleY = y;
/* 391 */     model.rotateAngleZ = z;
/*     */   }
/*     */   
/*     */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, net.minecraft.entity.Entity par7Entity)
/*     */   {
/* 396 */     this.rightarm.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 397 */     this.rightarm.rotateAngleZ = 0.0F;
/*     */     
/* 399 */     this.rightarm2.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 400 */     this.rightarm2.rotateAngleZ = 0.0F;
/*     */     
/* 402 */     this.rightarm3.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 403 */     this.rightarm3.rotateAngleZ = 0.0F;
/*     */     
/* 405 */     this.rightarm4.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 406 */     this.rightarm4.rotateAngleZ = 0.0F;
/*     */     
/* 408 */     this.rightarm5.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 409 */     this.rightarm5.rotateAngleZ = 0.0F;
/*     */     
/* 411 */     this.rightarm6.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 412 */     this.rightarm6.rotateAngleZ = 0.0F;
/*     */     
/* 414 */     this.rightarm7.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 415 */     this.rightarm7.rotateAngleZ = 0.0F;
/*     */     
/* 417 */     this.rightarm8.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 418 */     this.rightarm8.rotateAngleZ = 0.0F;
/*     */     
/* 420 */     this.rightarm9.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 421 */     this.rightarm9.rotateAngleZ = 0.0F;
/*     */     
/* 423 */     this.rightarm10.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 424 */     this.rightarm10.rotateAngleZ = 0.0F;
/*     */     
/* 426 */     this.rightarm11.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F);
/* 427 */     this.rightarm11.rotateAngleZ = 0.0F;
/*     */     
/* 429 */     this.leftarm6.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 430 */     this.leftarm6.rotateAngleZ = 0.0F;
/*     */     
/* 432 */     this.leftarm2.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 433 */     this.leftarm2.rotateAngleZ = 0.0F;
/*     */     
/* 435 */     this.leftarm7.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 436 */     this.leftarm7.rotateAngleZ = 0.0F;
/*     */     
/* 438 */     this.leftarm8.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 439 */     this.leftarm8.rotateAngleZ = 0.0F;
/*     */     
/* 441 */     this.leftarm9.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 442 */     this.leftarm9.rotateAngleZ = 0.0F;
/*     */     
/* 444 */     this.leftarm10.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 445 */     this.leftarm10.rotateAngleZ = 0.0F;
/*     */     
/* 447 */     this.leftarm11.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 448 */     this.leftarm11.rotateAngleZ = 0.0F;
/*     */     
/* 450 */     this.leftarm12.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 451 */     this.leftarm12.rotateAngleZ = 0.0F;
/*     */     
/* 453 */     this.leftarm13.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 454 */     this.leftarm13.rotateAngleZ = 0.0F;
/*     */     
/* 456 */     this.leftarm14.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 457 */     this.leftarm14.rotateAngleZ = 0.0F;
/*     */     
/* 459 */     this.leftarm15.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F);
/* 460 */     this.leftarm15.rotateAngleZ = 0.0F;
/*     */     
/* 462 */     this.rightleg.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 1.4F * par2);
/* 463 */     this.rightleg.rotateAngleY = 0.0F;
/*     */     
/* 465 */     this.leftleg.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelTobalt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */