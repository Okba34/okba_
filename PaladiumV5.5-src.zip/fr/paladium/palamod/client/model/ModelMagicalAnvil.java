/*     */ package fr.paladium.palamod.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ 
/*     */ 
/*     */ public class ModelMagicalAnvil
/*     */   extends ModelBase
/*     */ {
/*     */   public ModelRenderer Elem19;
/*     */   public ModelRenderer Elem18;
/*     */   public ModelRenderer Elem17;
/*     */   public ModelRenderer Elem16;
/*     */   public ModelRenderer Elem15;
/*     */   public ModelRenderer Elem14;
/*     */   public ModelRenderer Elem24;
/*     */   public ModelRenderer Elem13;
/*     */   public ModelRenderer Elem23;
/*     */   public ModelRenderer Elem12;
/*     */   public ModelRenderer Elem22;
/*     */   public ModelRenderer Elem11;
/*     */   public ModelRenderer Elem21;
/*     */   public ModelRenderer Elem10;
/*     */   public ModelRenderer Elem20;
/*     */   public ModelRenderer Elem9;
/*     */   public ModelRenderer Elem7;
/*     */   public ModelRenderer Elem8;
/*     */   public ModelRenderer Elem5;
/*     */   public ModelRenderer Elem6;
/*     */   public ModelRenderer Elem4;
/*     */   
/*     */   public ModelMagicalAnvil()
/*     */   {
/*  35 */     this.textureWidth = 64;
/*  36 */     this.textureHeight = 64;
/*  37 */     this.Elem13 = new ModelRenderer(this, 26, 15);
/*  38 */     this.Elem13.setRotationPoint(-2.5F, 20.5F, -4.0F);
/*  39 */     this.Elem13.addBox(0.0F, 0.0F, 0.0F, 5, 4, 8, 0.0F);
/*  40 */     this.Elem24 = new ModelRenderer(this, 0, 0);
/*  41 */     this.Elem24.setRotationPoint(-1.0F, 22.0F, 5.0F);
/*  42 */     this.Elem24.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
/*  43 */     this.Elem12 = new ModelRenderer(this, 14, 4);
/*  44 */     this.Elem12.setRotationPoint(-5.0F, 11.5F, 7.0F);
/*  45 */     this.Elem12.addBox(0.0F, 0.0F, 0.0F, 10, 2, 1, 0.0F);
/*  46 */     this.Elem16 = new ModelRenderer(this, 51, 2);
/*  47 */     this.Elem16.setRotationPoint(-2.0F, 21.5F, -5.0F);
/*  48 */     this.Elem16.addBox(0.0F, 0.0F, 0.0F, 4, 3, 1, 0.0F);
/*  49 */     this.Elem18 = new ModelRenderer(this, 46, 0);
/*  50 */     this.Elem18.setRotationPoint(-2.0F, 11.0F, -2.5F);
/*  51 */     this.Elem18.addBox(0.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
/*  52 */     this.Elem15 = new ModelRenderer(this, 0, 3);
/*  53 */     this.Elem15.setRotationPoint(-2.5F, 11.0F, -2.0F);
/*  54 */     this.Elem15.addBox(0.0F, 0.0F, 0.0F, 5, 1, 4, 0.0F);
/*  55 */     this.Elem14 = new ModelRenderer(this, 0, 8);
/*  56 */     this.Elem14.setRotationPoint(-2.5F, 13.5F, -4.0F);
/*  57 */     this.Elem14.addBox(0.0F, 0.0F, 0.0F, 5, 1, 8, 0.0F);
/*  58 */     this.Elem5 = new ModelRenderer(this, 32, 30);
/*  59 */     this.Elem5.setRotationPoint(-7.5F, 11.5F, -6.0F);
/*  60 */     this.Elem5.addBox(0.0F, 0.0F, 0.0F, 15, 2, 1, 0.0F);
/*  61 */     this.Elem9 = new ModelRenderer(this, 0, 23);
/*  62 */     this.Elem9.setRotationPoint(-6.0F, 11.5F, -7.5F);
/*  63 */     this.Elem9.addBox(0.0F, 0.0F, 0.0F, 12, 2, 1, 0.0F);
/*  64 */     this.Elem7 = new ModelRenderer(this, 28, 27);
/*  65 */     this.Elem7.setRotationPoint(-6.5F, 11.5F, -6.5F);
/*  66 */     this.Elem7.addBox(0.0F, 0.0F, 0.0F, 13, 2, 1, 0.0F);
/*  67 */     this.Elem23 = new ModelRenderer(this, 6, 0);
/*  68 */     this.Elem23.setRotationPoint(-1.0F, 23.0F, 5.0F);
/*  69 */     this.Elem23.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
/*  70 */     this.Elem10 = new ModelRenderer(this, 0, 20);
/*  71 */     this.Elem10.setRotationPoint(-6.0F, 11.5F, 6.5F);
/*  72 */     this.Elem10.addBox(0.0F, 0.0F, 0.0F, 12, 2, 1, 0.0F);
/*  73 */     this.Elem19 = new ModelRenderer(this, 36, 0);
/*  74 */     this.Elem19.setRotationPoint(-2.0F, 11.0F, 1.5F);
/*  75 */     this.Elem19.addBox(0.0F, 0.0F, 0.0F, 4, 1, 1, 0.0F);
/*  76 */     this.Elem21 = new ModelRenderer(this, 18, 0);
/*  77 */     this.Elem21.setRotationPoint(-1.0F, 23.0F, -6.0F);
/*  78 */     this.Elem21.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
/*  79 */     this.Elem8 = new ModelRenderer(this, 0, 27);
/*  80 */     this.Elem8.setRotationPoint(-6.5F, 11.5F, 5.5F);
/*  81 */     this.Elem8.addBox(0.0F, 0.0F, 0.0F, 13, 2, 1, 0.0F);
/*  82 */     this.Elem17 = new ModelRenderer(this, 36, 2);
/*  83 */     this.Elem17.setRotationPoint(-2.0F, 14.5F, -3.5F);
/*  84 */     this.Elem17.addBox(0.0F, 0.0F, 0.0F, 4, 6, 7, 0.0F);
/*  85 */     this.Elem11 = new ModelRenderer(this, 0, 17);
/*  86 */     this.Elem11.setRotationPoint(-5.0F, 11.5F, -8.0F);
/*  87 */     this.Elem11.addBox(0.0F, 0.0F, 0.0F, 10, 2, 1, 0.0F);
/*  88 */     this.Elem6 = new ModelRenderer(this, 0, 30);
/*  89 */     this.Elem6.setRotationPoint(-7.5F, 11.5F, 5.0F);
/*  90 */     this.Elem6.addBox(0.0F, 0.0F, 0.0F, 15, 2, 1, 0.0F);
/*  91 */     this.Elem4 = new ModelRenderer(this, 0, 33);
/*  92 */     this.Elem4.setRotationPoint(-8.0F, 11.5F, -5.0F);
/*  93 */     this.Elem4.addBox(0.0F, 0.0F, 0.0F, 16, 2, 10, 0.0F);
/*  94 */     this.Elem22 = new ModelRenderer(this, 12, 0);
/*  95 */     this.Elem22.setRotationPoint(-1.0F, 22.0F, -6.0F);
/*  96 */     this.Elem22.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
/*  97 */     this.Elem20 = new ModelRenderer(this, 26, 0);
/*  98 */     this.Elem20.setRotationPoint(-2.0F, 21.5F, 4.0F);
/*  99 */     this.Elem20.addBox(0.0F, 0.0F, 0.0F, 4, 3, 1, 0.0F);
/*     */   }
/*     */   
/*     */   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
/*     */   {
/* 104 */     this.Elem13.render(f5);
/* 105 */     this.Elem24.render(f5);
/* 106 */     this.Elem12.render(f5);
/* 107 */     this.Elem16.render(f5);
/* 108 */     this.Elem18.render(f5);
/* 109 */     this.Elem15.render(f5);
/* 110 */     this.Elem14.render(f5);
/* 111 */     this.Elem5.render(f5);
/* 112 */     this.Elem9.render(f5);
/* 113 */     this.Elem7.render(f5);
/* 114 */     this.Elem23.render(f5);
/* 115 */     this.Elem10.render(f5);
/* 116 */     this.Elem19.render(f5);
/* 117 */     this.Elem21.render(f5);
/* 118 */     this.Elem8.render(f5);
/* 119 */     this.Elem17.render(f5);
/* 120 */     this.Elem11.render(f5);
/* 121 */     this.Elem6.render(f5);
/* 122 */     this.Elem4.render(f5);
/* 123 */     this.Elem22.render(f5);
/* 124 */     this.Elem20.render(f5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z)
/*     */   {
/* 131 */     modelRenderer.rotateAngleX = x;
/* 132 */     modelRenderer.rotateAngleY = y;
/* 133 */     modelRenderer.rotateAngleZ = z;
/*     */   }
/*     */   
/*     */   public void renderModel(float f5) {
/* 137 */     this.Elem24.render(f5);
/* 138 */     this.Elem23.render(f5);
/* 139 */     this.Elem22.render(f5);
/* 140 */     this.Elem21.render(f5);
/* 141 */     this.Elem20.render(f5);
/* 142 */     this.Elem19.render(f5);
/* 143 */     this.Elem18.render(f5);
/* 144 */     this.Elem17.render(f5);
/* 145 */     this.Elem16.render(f5);
/* 146 */     this.Elem15.render(f5);
/* 147 */     this.Elem14.render(f5);
/* 148 */     this.Elem13.render(f5);
/* 149 */     this.Elem12.render(f5);
/* 150 */     this.Elem11.render(f5);
/* 151 */     this.Elem10.render(f5);
/* 152 */     this.Elem9.render(f5);
/* 153 */     this.Elem8.render(f5);
/* 154 */     this.Elem7.render(f5);
/* 155 */     this.Elem6.render(f5);
/* 156 */     this.Elem5.render(f5);
/* 157 */     this.Elem4.render(f5);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelMagicalAnvil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */