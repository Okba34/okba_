/*     */ package fr.paladium.palamod.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelBase;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ModelTurret
/*     */   extends ModelBase
/*     */ {
/*     */   ModelRenderer foot43;
/*     */   ModelRenderer foot13;
/*     */   ModelRenderer foot42;
/*     */   ModelRenderer foot41;
/*     */   ModelRenderer foot33;
/*     */   ModelRenderer foot32;
/*     */   ModelRenderer foot31;
/*     */   ModelRenderer foot23;
/*     */   ModelRenderer foot22;
/*     */   ModelRenderer foot21;
/*     */   ModelRenderer foot11;
/*     */   ModelRenderer foot12;
/*     */   ModelRenderer body1;
/*     */   ModelRenderer body24;
/*     */   ModelRenderer body3;
/*     */   ModelRenderer body25;
/*     */   ModelRenderer body22;
/*     */   ModelRenderer body23;
/*     */   ModelRenderer body21;
/*     */   ModelRenderer head1;
/*     */   ModelRenderer head2;
/*     */   ModelRenderer head5;
/*     */   ModelRenderer canon;
/*     */   ModelRenderer head4;
/*     */   ModelRenderer head3;
/*     */   ModelRenderer head;
/*     */   
/*     */   public ModelTurret()
/*     */   {
/*  40 */     this.textureWidth = 64;
/*  41 */     this.textureHeight = 32;
/*     */     
/*  43 */     this.foot43 = new ModelRenderer(this, 26, 28);
/*  44 */     this.foot43.addBox(0.0F, 0.0F, 0.0F, 3, 1, 3);
/*  45 */     this.foot43.setRotationPoint(1.0F, 20.0F, -4.0F);
/*  46 */     this.foot43.setTextureSize(64, 32);
/*  47 */     this.foot43.mirror = true;
/*  48 */     setRotation(this.foot43, 0.0F, 0.0F, 0.0F);
/*  49 */     this.foot13 = new ModelRenderer(this, 26, 16);
/*  50 */     this.foot13.addBox(0.0F, 0.0F, 0.0F, 3, 1, 3);
/*  51 */     this.foot13.setRotationPoint(-4.0F, 20.0F, -4.0F);
/*  52 */     this.foot13.setTextureSize(64, 32);
/*  53 */     this.foot13.mirror = true;
/*  54 */     setRotation(this.foot13, 0.0F, 0.0F, 0.0F);
/*  55 */     this.foot42 = new ModelRenderer(this, 17, 24);
/*  56 */     this.foot42.addBox(0.0F, 0.0F, 0.0F, 2, 2, 2);
/*  57 */     this.foot42.setRotationPoint(3.0F, 21.0F, -5.0F);
/*  58 */     this.foot42.setTextureSize(64, 32);
/*  59 */     this.foot42.mirror = true;
/*  60 */     setRotation(this.foot42, 0.0F, 0.0F, 0.0F);
/*  61 */     this.foot41 = new ModelRenderer(this, 0, 27);
/*  62 */     this.foot41.addBox(0.0F, 0.0F, 0.0F, 4, 1, 4);
/*  63 */     this.foot41.setRotationPoint(2.0F, 23.0F, -6.0F);
/*  64 */     this.foot41.setTextureSize(64, 32);
/*  65 */     this.foot41.mirror = true;
/*  66 */     setRotation(this.foot41, 0.0F, 0.0F, 0.0F);
/*  67 */     this.foot33 = new ModelRenderer(this, 26, 24);
/*  68 */     this.foot33.addBox(0.0F, 0.0F, 0.0F, 3, 1, 3);
/*  69 */     this.foot33.setRotationPoint(1.0F, 20.0F, 1.0F);
/*  70 */     this.foot33.setTextureSize(64, 32);
/*  71 */     this.foot33.mirror = true;
/*  72 */     setRotation(this.foot33, 0.0F, 0.0F, 0.0F);
/*  73 */     this.foot32 = new ModelRenderer(this, 17, 20);
/*  74 */     this.foot32.addBox(0.0F, 0.0F, 0.0F, 2, 2, 2);
/*  75 */     this.foot32.setRotationPoint(3.0F, 21.0F, 3.0F);
/*  76 */     this.foot32.setTextureSize(64, 32);
/*  77 */     this.foot32.mirror = true;
/*  78 */     setRotation(this.foot32, 0.0F, 0.0F, 0.0F);
/*  79 */     this.foot31 = new ModelRenderer(this, 0, 22);
/*  80 */     this.foot31.addBox(0.0F, 0.0F, 0.0F, 4, 1, 4);
/*  81 */     this.foot31.setRotationPoint(2.0F, 23.0F, 2.0F);
/*  82 */     this.foot31.setTextureSize(64, 32);
/*  83 */     this.foot31.mirror = true;
/*  84 */     setRotation(this.foot31, 0.0F, 0.0F, 0.0F);
/*  85 */     this.foot23 = new ModelRenderer(this, 26, 20);
/*  86 */     this.foot23.addBox(0.0F, 0.0F, 0.0F, 3, 1, 3);
/*  87 */     this.foot23.setRotationPoint(-4.0F, 20.0F, 1.0F);
/*  88 */     this.foot23.setTextureSize(64, 32);
/*  89 */     this.foot23.mirror = true;
/*  90 */     setRotation(this.foot23, 0.0F, 0.0F, 0.0F);
/*  91 */     this.foot22 = new ModelRenderer(this, 17, 16);
/*  92 */     this.foot22.addBox(0.0F, 0.0F, 0.0F, 2, 2, 2);
/*  93 */     this.foot22.setRotationPoint(-5.0F, 21.0F, 3.0F);
/*  94 */     this.foot22.setTextureSize(64, 32);
/*  95 */     this.foot22.mirror = true;
/*  96 */     setRotation(this.foot22, 0.0F, 0.0F, 0.0F);
/*  97 */     this.foot21 = new ModelRenderer(this, 0, 17);
/*  98 */     this.foot21.addBox(0.0F, 0.0F, 0.0F, 4, 1, 4);
/*  99 */     this.foot21.setRotationPoint(-6.0F, 23.0F, 2.0F);
/* 100 */     this.foot21.setTextureSize(64, 32);
/* 101 */     this.foot21.mirror = true;
/* 102 */     setRotation(this.foot21, 0.0F, 0.0F, 0.0F);
/* 103 */     this.foot11 = new ModelRenderer(this, 0, 12);
/* 104 */     this.foot11.addBox(0.0F, 0.0F, 0.0F, 4, 1, 4);
/* 105 */     this.foot11.setRotationPoint(-6.0F, 23.0F, -6.0F);
/* 106 */     this.foot11.setTextureSize(64, 32);
/* 107 */     this.foot11.mirror = true;
/* 108 */     setRotation(this.foot11, 0.0F, 0.0F, 0.0F);
/* 109 */     this.foot12 = new ModelRenderer(this, 17, 28);
/* 110 */     this.foot12.addBox(0.0F, 0.0F, 0.0F, 2, 2, 2);
/* 111 */     this.foot12.setRotationPoint(-5.0F, 21.0F, -5.0F);
/* 112 */     this.foot12.setTextureSize(64, 32);
/* 113 */     this.foot12.mirror = true;
/* 114 */     setRotation(this.foot12, 0.0F, 0.0F, 0.0F);
/* 115 */     this.body1 = new ModelRenderer(this, 0, 0);
/* 116 */     this.body1.addBox(0.0F, 0.0F, 0.0F, 6, 1, 6);
/* 117 */     this.body1.setRotationPoint(-3.0F, 19.0F, -3.0F);
/* 118 */     this.body1.setTextureSize(64, 32);
/* 119 */     this.body1.mirror = true;
/* 120 */     setRotation(this.body1, 0.0F, 0.0F, 0.0F);
/* 121 */     this.body24 = new ModelRenderer(this, 0, 0);
/* 122 */     this.body24.addBox(0.0F, 0.0F, 0.0F, 1, 4, 4);
/* 123 */     this.body24.setRotationPoint(1.0F, 15.0F, -2.0F);
/* 124 */     this.body24.setTextureSize(64, 32);
/* 125 */     this.body24.mirror = true;
/* 126 */     setRotation(this.body24, 0.0F, 0.0F, 0.0F);
/* 127 */     this.body3 = new ModelRenderer(this, 0, 0);
/* 128 */     this.body3.addBox(0.0F, 0.0F, 0.0F, 2, 3, 2);
/* 129 */     this.body3.setRotationPoint(-1.0F, 12.0F, -1.0F);
/* 130 */     this.body3.setTextureSize(64, 32);
/* 131 */     this.body3.mirror = true;
/* 132 */     setRotation(this.body3, 0.0F, 0.0F, 0.0F);
/* 133 */     this.body25 = new ModelRenderer(this, 0, 0);
/* 134 */     this.body25.addBox(0.0F, 0.0F, 0.0F, 1, 4, 2);
/* 135 */     this.body25.setRotationPoint(2.0F, 15.0F, -1.0F);
/* 136 */     this.body25.setTextureSize(64, 32);
/* 137 */     this.body25.mirror = true;
/* 138 */     setRotation(this.body25, 0.0F, 0.0F, 0.0F);
/* 139 */     this.body22 = new ModelRenderer(this, 0, 0);
/* 140 */     this.body22.addBox(0.0F, 0.0F, 0.0F, 1, 4, 4);
/* 141 */     this.body22.setRotationPoint(-2.0F, 15.0F, -2.0F);
/* 142 */     this.body22.setTextureSize(64, 32);
/* 143 */     this.body22.mirror = true;
/* 144 */     setRotation(this.body22, 0.0F, 0.0F, 0.0F);
/* 145 */     this.body23 = new ModelRenderer(this, 0, 0);
/* 146 */     this.body23.addBox(0.0F, 0.0F, 0.0F, 1, 4, 2);
/* 147 */     this.body23.setRotationPoint(-3.0F, 15.0F, -1.0F);
/* 148 */     this.body23.setTextureSize(64, 32);
/* 149 */     this.body23.mirror = true;
/* 150 */     setRotation(this.body23, 0.0F, 0.0F, 0.0F);
/* 151 */     this.body21 = new ModelRenderer(this, 0, 0);
/* 152 */     this.body21.addBox(0.0F, 0.0F, 0.0F, 2, 4, 6);
/* 153 */     this.body21.setRotationPoint(-1.0F, 15.0F, -3.0F);
/* 154 */     this.body21.setTextureSize(64, 32);
/* 155 */     this.body21.mirror = true;
/* 156 */     setRotation(this.body21, 0.0F, 0.0F, 0.0F);
/*     */     
/* 158 */     this.head1 = new ModelRenderer(this, 30, 0);
/* 159 */     this.head1.addBox(0.0F, 0.0F, 0.0F, 4, 5, 6);
/* 160 */     this.head1.setRotationPoint(-2.0F, 9.0F, -3.0F);
/* 161 */     this.head1.setTextureSize(64, 32);
/* 162 */     this.head1.mirror = true;
/* 163 */     setRotation(this.head1, 0.0F, 0.0F, 0.0F);
/* 164 */     this.head2 = new ModelRenderer(this, 50, 0);
/* 165 */     this.head2.addBox(0.0F, 0.0F, 0.0F, 1, 3, 6);
/* 166 */     this.head2.setRotationPoint(-3.0F, 10.0F, -3.0F);
/* 167 */     this.head2.setTextureSize(64, 32);
/* 168 */     this.head2.mirror = true;
/* 169 */     setRotation(this.head2, 0.0F, 0.0F, 0.0F);
/* 170 */     this.head5 = new ModelRenderer(this, 54, 23);
/* 171 */     this.head5.addBox(0.0F, 0.0F, 0.0F, 4, 3, 1);
/* 172 */     this.head5.setRotationPoint(-2.0F, 10.0F, 3.0F);
/* 173 */     this.head5.setTextureSize(64, 32);
/* 174 */     this.head5.mirror = true;
/* 175 */     setRotation(this.head5, 0.0F, 0.0F, 0.0F);
/* 176 */     this.canon = new ModelRenderer(this, 54, 27);
/* 177 */     this.canon.addBox(0.0F, 0.0F, 0.0F, 2, 2, 3);
/* 178 */     this.canon.setRotationPoint(-1.0F, 10.0F, -7.0F);
/* 179 */     this.canon.setTextureSize(64, 32);
/* 180 */     this.canon.mirror = true;
/* 181 */     setRotation(this.canon, 0.0F, 0.0F, 0.0F);
/* 182 */     this.head4 = new ModelRenderer(this, 54, 18);
/* 183 */     this.head4.addBox(0.0F, 0.0F, 0.0F, 4, 4, 1);
/* 184 */     this.head4.setRotationPoint(-2.0F, 9.0F, -4.0F);
/* 185 */     this.head4.setTextureSize(64, 32);
/* 186 */     this.head4.mirror = true;
/* 187 */     setRotation(this.head4, 0.0F, 0.0F, 0.0F);
/* 188 */     this.head3 = new ModelRenderer(this, 50, 9);
/* 189 */     this.head3.addBox(0.0F, 0.0F, 0.0F, 1, 3, 6);
/* 190 */     this.head3.setRotationPoint(2.0F, 10.0F, -3.0F);
/* 191 */     this.head3.setTextureSize(64, 32);
/* 192 */     this.head3.mirror = true;
/* 193 */     setRotation(this.head3, 0.0F, 0.0F, 0.0F);
/*     */     
/* 195 */     this.head = new ModelRenderer(this, 0, 0);
/* 196 */     this.head.addChild(this.head1);
/* 197 */     this.head.addChild(this.head2);
/* 198 */     this.head.addChild(this.head3);
/* 199 */     this.head.addChild(this.head4);
/* 200 */     this.head.addChild(this.head5);
/* 201 */     this.head.addChild(this.canon);
/*     */   }
/*     */   
/*     */   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5)
/*     */   {
/* 206 */     super.render(entity, f, f1, f2, f3, f4, f5);
/* 207 */     setRotationAngles(f, f1, f2, f3, f4, f5, entity);
/* 208 */     this.foot43.render(f5);
/* 209 */     this.foot13.render(f5);
/* 210 */     this.foot42.render(f5);
/* 211 */     this.foot41.render(f5);
/* 212 */     this.foot33.render(f5);
/* 213 */     this.foot32.render(f5);
/* 214 */     this.foot31.render(f5);
/* 215 */     this.foot23.render(f5);
/* 216 */     this.foot22.render(f5);
/* 217 */     this.foot21.render(f5);
/* 218 */     this.foot11.render(f5);
/* 219 */     this.foot12.render(f5);
/* 220 */     this.body1.render(f5);
/* 221 */     this.body24.render(f5);
/* 222 */     this.body3.render(f5);
/* 223 */     this.body25.render(f5);
/* 224 */     this.body22.render(f5);
/* 225 */     this.body23.render(f5);
/* 226 */     this.body21.render(f5);
/* 227 */     this.head1.render(f5);
/* 228 */     this.head2.render(f5);
/* 229 */     this.head5.render(f5);
/* 230 */     this.canon.render(f5);
/* 231 */     this.head4.render(f5);
/* 232 */     this.head3.render(f5);
/*     */   }
/*     */   
/*     */   public void render(float f5, float pitch, float yaw) {
/* 236 */     this.foot43.render(f5);
/* 237 */     this.foot13.render(f5);
/* 238 */     this.foot42.render(f5);
/* 239 */     this.foot41.render(f5);
/* 240 */     this.foot33.render(f5);
/* 241 */     this.foot32.render(f5);
/* 242 */     this.foot31.render(f5);
/* 243 */     this.foot23.render(f5);
/* 244 */     this.foot22.render(f5);
/* 245 */     this.foot21.render(f5);
/* 246 */     this.foot11.render(f5);
/* 247 */     this.foot12.render(f5);
/* 248 */     this.body1.render(f5);
/* 249 */     this.body24.render(f5);
/* 250 */     this.body3.render(f5);
/* 251 */     this.body25.render(f5);
/* 252 */     this.body22.render(f5);
/* 253 */     this.body23.render(f5);
/* 254 */     this.body21.render(f5);
/*     */     
/* 256 */     this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
/*     */     
/* 258 */     float yawDeg = yaw * 180.0F / 3.1415927F + 180.0F;
/*     */     
/*     */ 
/* 261 */     GL11.glPushMatrix();
/*     */     
/* 263 */     GL11.glTranslatef(0.0F, 0.8F, 0.0F);
/* 264 */     GL11.glRotatef(pitch, 1.0F, 0.0F, 0.0F);
/* 265 */     GL11.glTranslatef(0.0F, -0.8F, 0.0F);
/*     */     
/* 267 */     GL11.glRotatef(yawDeg, 0.0F, 1.0F, 0.0F);
/* 268 */     this.head.render(f5);
/*     */     
/* 270 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 274 */     model.rotateAngleX = x;
/* 275 */     model.rotateAngleY = y;
/* 276 */     model.rotateAngleZ = z;
/*     */   }
/*     */   
/*     */   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
/* 280 */     super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelTurret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */