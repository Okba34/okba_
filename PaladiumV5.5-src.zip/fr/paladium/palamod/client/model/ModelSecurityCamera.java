/*    */ package fr.paladium.palamod.client.model;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelSecurityCamera
/*    */   extends ModelBase
/*    */ {
/*    */   public ModelRenderer shape1;
/*    */   public ModelRenderer shape2;
/*    */   public ModelRenderer cameraRotationPoint;
/*    */   public ModelRenderer shape3;
/*    */   public ModelRenderer cameraBody;
/*    */   public ModelRenderer cameraLensRight;
/*    */   public ModelRenderer cameraLensLeft;
/*    */   public ModelRenderer cameraLensTop;
/* 22 */   public boolean reverseCameraRotation = false;
/*    */   
/*    */   public ModelSecurityCamera()
/*    */   {
/* 26 */     this.textureWidth = 128;
/* 27 */     this.textureHeight = 64;
/* 28 */     this.cameraRotationPoint = new ModelRenderer(this, 0, 25);
/* 29 */     this.cameraRotationPoint.setRotationPoint(0.0F, 14.0F, 3.0F);
/* 30 */     this.cameraRotationPoint.addBox(0.0F, 0.0F, 0.0F, 1, 1, 1, 0.0F);
/* 31 */     setRotateAngle(this.cameraRotationPoint, 0.2617994F, 0.0F, 0.0F);
/* 32 */     this.cameraLensRight = new ModelRenderer(this, 10, 40);
/* 33 */     this.cameraLensRight.setRotationPoint(3.0F, 0.0F, -3.0F);
/* 34 */     this.cameraLensRight.addBox(-2.0F, 0.0F, 0.0F, 1, 3, 1, 0.0F);
/* 35 */     this.shape3 = new ModelRenderer(this, 1, 12);
/* 36 */     this.shape3.setRotationPoint(0.0F, 1.0F, 0.0F);
/* 37 */     this.shape3.addBox(0.0F, 0.0F, 0.0F, 2, 1, 7, 0.0F);
/* 38 */     this.cameraLensLeft = new ModelRenderer(this, 0, 40);
/* 39 */     this.cameraLensLeft.setRotationPoint(-2.0F, 0.0F, -3.0F);
/* 40 */     this.cameraLensLeft.addBox(0.0F, 0.0F, 0.0F, 1, 3, 1, 0.0F);
/* 41 */     this.cameraBody = new ModelRenderer(this, 0, 25);
/* 42 */     this.cameraBody.setRotationPoint(0.0F, 0.0F, -5.0F);
/* 43 */     this.cameraBody.addBox(-2.0F, 0.0F, -2.0F, 4, 3, 8, 0.0F);
/* 44 */     setRotateAngle(this.cameraBody, 0.2617994F, 0.0F, 0.0F);
/* 45 */     this.shape1 = new ModelRenderer(this, 0, 0);
/* 46 */     this.shape1.setRotationPoint(-3.0F, 13.0F, 7.0F);
/* 47 */     this.shape1.addBox(0.0F, 0.0F, 0.0F, 6, 6, 1, 0.0F);
/* 48 */     this.cameraLensTop = new ModelRenderer(this, 20, 40);
/* 49 */     this.cameraLensTop.setRotationPoint(-1.0F, 0.0F, -3.0F);
/* 50 */     this.cameraLensTop.addBox(0.0F, 0.0F, 0.0F, 2, 1, 1, 0.0F);
/* 51 */     this.shape2 = new ModelRenderer(this, 2, 12);
/* 52 */     this.shape2.setRotationPoint(-1.0F, 13.75F, 2.25F);
/* 53 */     this.shape2.addBox(0.0F, 0.0F, 0.0F, 2, 1, 6, 0.0F);
/* 54 */     setRotateAngle(this.shape2, -0.5235988F, 0.0F, 0.0F);
/* 55 */     this.cameraBody.addChild(this.cameraLensRight);
/* 56 */     this.shape2.addChild(this.shape3);
/* 57 */     this.cameraBody.addChild(this.cameraLensLeft);
/* 58 */     this.cameraRotationPoint.addChild(this.cameraBody);
/* 59 */     this.cameraBody.addChild(this.cameraLensTop);
/*    */   }
/*    */   
/*    */   public void renderAll()
/*    */   {
/* 64 */     this.cameraRotationPoint.render(0.0625F);
/* 65 */     this.shape1.render(0.0625F);
/* 66 */     this.shape2.render(0.0625F);
/*    */   }
/*    */   
/*    */   public void setCameraRotation(float rotation)
/*    */   {
/* 71 */     this.cameraRotationPoint.rotateAngleY = rotation;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z)
/*    */   {
/* 79 */     modelRenderer.rotateAngleX = x;
/* 80 */     modelRenderer.rotateAngleY = y;
/* 81 */     modelRenderer.rotateAngleZ = z;
/*    */   }
/*    */   
/*    */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity)
/*    */   {
/* 86 */     super.setRotationAngles(par1, par2, par3, par4, par5, par6, par7Entity);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelSecurityCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */