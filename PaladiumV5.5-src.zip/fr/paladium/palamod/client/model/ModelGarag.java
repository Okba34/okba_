/*     */ package fr.paladium.palamod.client.model;
/*     */ 
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ public class ModelGarag extends net.minecraft.client.model.ModelBase
/*     */ {
/*     */   ModelRenderer head;
/*     */   ModelRenderer body;
/*     */   ModelRenderer rightarm;
/*     */   ModelRenderer leftarm;
/*     */   ModelRenderer rightleg;
/*     */   ModelRenderer leftleg;
/*     */   ModelRenderer rightarm2;
/*     */   ModelRenderer leftarm2;
/*     */   ModelRenderer body2;
/*     */   ModelRenderer rightarm3;
/*     */   ModelRenderer leftarm3;
/*     */   ModelRenderer body3;
/*     */   ModelRenderer body4;
/*     */   ModelRenderer body5;
/*     */   ModelRenderer body6;
/*     */   ModelRenderer body7;
/*     */   ModelRenderer body8;
/*     */   
/*     */   public ModelGarag()
/*     */   {
/*  28 */     this.textureWidth = 256;
/*  29 */     this.textureHeight = 32;
/*  30 */     this.head = new ModelRenderer(this, 0, 0);
/*  31 */     this.head.addBox(-6.0F, -8.0F, -4.0F, 12, 8, 8);
/*  32 */     this.head.setRotationPoint(0.0F, 0.0F, -9.0F);
/*  33 */     this.head.setTextureSize(256, 32);
/*  34 */     this.head.mirror = true;
/*  35 */     setRotation(this.head, 0.0F, 0.0F, 0.0F);
/*  36 */     this.body = new ModelRenderer(this, 55, 7);
/*  37 */     this.body.addBox(3.0F, -12.0F, 8.0F, 3, 12, 6);
/*  38 */     this.body.setRotationPoint(0.0F, 5.0F, 4.0F);
/*  39 */     this.body.setTextureSize(256, 32);
/*  40 */     this.body.mirror = true;
/*  41 */     setRotation(this.body, -0.7853982F, 0.0F, 0.0F);
/*  42 */     this.rightarm = new ModelRenderer(this, 218, 13);
/*  43 */     this.rightarm.addBox(-4.0F, 14.0F, -6.0F, 8, 10, 8);
/*  44 */     this.rightarm.setRotationPoint(-12.0F, 0.0F, -6.0F);
/*  45 */     this.rightarm.setTextureSize(256, 32);
/*  46 */     this.rightarm.mirror = true;
/*  47 */     setRotation(this.rightarm, 0.0F, 0.0F, 0.0F);
/*  48 */     this.leftarm = new ModelRenderer(this, 218, 13);
/*  49 */     this.leftarm.addBox(-2.0F, 14.0F, -6.0F, 8, 10, 8);
/*  50 */     this.leftarm.setRotationPoint(10.0F, 0.0F, -6.0F);
/*  51 */     this.leftarm.setTextureSize(256, 32);
/*  52 */     this.leftarm.mirror = true;
/*  53 */     setRotation(this.leftarm, 0.0F, 0.0F, 0.0F);
/*  54 */     this.rightleg = new ModelRenderer(this, 189, 13);
/*  55 */     this.rightleg.addBox(-2.0F, 0.0F, -2.0F, 6, 12, 6);
/*  56 */     this.rightleg.setRotationPoint(-8.0F, 12.0F, 14.0F);
/*  57 */     this.rightleg.setTextureSize(256, 32);
/*  58 */     this.rightleg.mirror = true;
/*  59 */     setRotation(this.rightleg, 0.0F, 0.0F, 0.0F);
/*  60 */     this.leftleg = new ModelRenderer(this, 189, 13);
/*  61 */     this.leftleg.addBox(-2.0F, 0.0F, -2.0F, 6, 12, 6);
/*  62 */     this.leftleg.setRotationPoint(6.0F, 12.0F, 14.0F);
/*  63 */     this.leftleg.setTextureSize(256, 32);
/*  64 */     this.leftleg.mirror = true;
/*  65 */     setRotation(this.leftleg, 0.0F, 0.0F, 0.0F);
/*  66 */     this.rightarm2 = new ModelRenderer(this, 162, 0);
/*  67 */     this.rightarm2.addBox(-3.0F, -2.0F, -2.0F, 6, 22, 6);
/*  68 */     this.rightarm2.setRotationPoint(-10.0F, 4.0F, 4.0F);
/*  69 */     this.rightarm2.setTextureSize(256, 32);
/*  70 */     this.rightarm2.mirror = true;
/*  71 */     setRotation(this.rightarm2, 0.0F, 0.0F, 0.0F);
/*  72 */     this.leftarm2 = new ModelRenderer(this, 162, 0);
/*  73 */     this.leftarm2.addBox(-1.0F, -2.0F, -2.0F, 6, 22, 6);
/*  74 */     this.leftarm2.setRotationPoint(8.0F, 4.0F, 4.0F);
/*  75 */     this.leftarm2.setTextureSize(256, 32);
/*  76 */     this.leftarm2.mirror = true;
/*  77 */     setRotation(this.leftarm2, 0.0F, 0.0F, 0.0F);
/*  78 */     this.body2 = new ModelRenderer(this, 93, 0);
/*  79 */     this.body2.addBox(-7.0F, 0.0F, -2.0F, 14, 16, 6);
/*  80 */     this.body2.setRotationPoint(0.0F, 5.0F, 4.0F);
/*  81 */     this.body2.setTextureSize(256, 32);
/*  82 */     this.body2.mirror = true;
/*  83 */     setRotation(this.body2, 1.047198F, 0.0F, 0.0F);
/*  84 */     this.rightarm3 = new ModelRenderer(this, 135, 0);
/*  85 */     this.rightarm3.addBox(-3.0F, -2.0F, -2.0F, 6, 26, 6);
/*  86 */     this.rightarm3.setRotationPoint(-12.0F, 0.0F, -6.0F);
/*  87 */     this.rightarm3.setTextureSize(256, 32);
/*  88 */     this.rightarm3.mirror = true;
/*  89 */     setRotation(this.rightarm3, 0.0F, 0.0F, 0.0F);
/*  90 */     this.leftarm3 = new ModelRenderer(this, 135, 0);
/*  91 */     this.leftarm3.addBox(-1.0F, -2.0F, -2.0F, 6, 26, 6);
/*  92 */     this.leftarm3.setRotationPoint(10.0F, 0.0F, -6.0F);
/*  93 */     this.leftarm3.setTextureSize(256, 32);
/*  94 */     this.leftarm3.mirror = true;
/*  95 */     setRotation(this.leftarm3, 0.0F, 0.0F, 0.0F);
/*  96 */     this.body3 = new ModelRenderer(this, 85, 0);
/*  97 */     this.body3.addBox(-9.0F, -12.0F, -2.0F, 18, 12, 6);
/*  98 */     this.body3.setRotationPoint(0.0F, 5.0F, 4.0F);
/*  99 */     this.body3.setTextureSize(256, 32);
/* 100 */     this.body3.mirror = true;
/* 101 */     setRotation(this.body3, 1.047198F, 0.0F, 0.0F);
/* 102 */     this.body4 = new ModelRenderer(this, 55, 7);
/* 103 */     this.body4.addBox(-6.0F, -12.0F, 8.0F, 3, 12, 6);
/* 104 */     this.body4.setRotationPoint(0.0F, 5.0F, 4.0F);
/* 105 */     this.body4.setTextureSize(256, 32);
/* 106 */     this.body4.mirror = true;
/* 107 */     setRotation(this.body4, -0.7853982F, 0.0F, 0.0F);
/* 108 */     this.body5 = new ModelRenderer(this, 55, 7);
/* 109 */     this.body5.addBox(-8.0F, -12.0F, -11.0F, 3, 12, 6);
/* 110 */     this.body5.setRotationPoint(0.0F, 5.0F, 4.0F);
/* 111 */     this.body5.setTextureSize(256, 32);
/* 112 */     this.body5.mirror = true;
/* 113 */     setRotation(this.body5, -0.7853982F, 0.0F, 0.0F);
/* 114 */     this.body6 = new ModelRenderer(this, 55, 7);
/* 115 */     this.body6.addBox(5.0F, -12.0F, -11.0F, 3, 12, 6);
/* 116 */     this.body6.setRotationPoint(0.0F, 5.0F, 4.0F);
/* 117 */     this.body6.setTextureSize(256, 32);
/* 118 */     this.body6.mirror = true;
/* 119 */     setRotation(this.body6, -0.7853982F, 0.0F, 0.0F);
/* 120 */     this.body7 = new ModelRenderer(this, 55, 7);
/* 121 */     this.body7.addBox(-6.0F, -12.0F, 0.0F, 3, 12, 6);
/* 122 */     this.body7.setRotationPoint(0.0F, 5.0F, 4.0F);
/* 123 */     this.body7.setTextureSize(256, 32);
/* 124 */     this.body7.mirror = true;
/* 125 */     setRotation(this.body7, -0.7853982F, 0.0F, 0.0F);
/* 126 */     this.body8 = new ModelRenderer(this, 55, 7);
/* 127 */     this.body8.addBox(3.0F, -12.0F, 0.0F, 3, 12, 6);
/* 128 */     this.body8.setRotationPoint(0.0F, 5.0F, 4.0F);
/* 129 */     this.body8.setTextureSize(256, 32);
/* 130 */     this.body8.mirror = true;
/* 131 */     setRotation(this.body8, -0.7853982F, 0.0F, 0.0F);
/*     */   }
/*     */   
/*     */   public void render(net.minecraft.entity.Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
/* 135 */     setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
/* 136 */     this.head.render(par7);
/* 137 */     this.body.render(par7);
/* 138 */     this.rightarm.render(par7);
/* 139 */     this.leftarm.render(par7);
/* 140 */     this.rightleg.render(par7);
/* 141 */     this.leftleg.render(par7);
/* 142 */     this.rightarm2.render(par7);
/* 143 */     this.leftarm2.render(par7);
/* 144 */     this.body2.render(par7);
/* 145 */     this.rightarm3.render(par7);
/* 146 */     this.leftarm3.render(par7);
/* 147 */     this.body3.render(par7);
/* 148 */     this.body4.render(par7);
/* 149 */     this.body5.render(par7);
/* 150 */     this.body6.render(par7);
/* 151 */     this.body7.render(par7);
/* 152 */     this.body8.render(par7);
/*     */   }
/*     */   
/*     */   private void setRotation(ModelRenderer model, float x, float y, float z) {
/* 156 */     model.rotateAngleX = x;
/* 157 */     model.rotateAngleY = y;
/* 158 */     model.rotateAngleZ = z;
/*     */   }
/*     */   
/*     */   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, net.minecraft.entity.Entity par7Entity)
/*     */   {
/* 163 */     this.rightarm.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 1.4F * par2);
/* 164 */     this.rightarm.rotateAngleY = 0.0F;
/* 165 */     this.rightarm2.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 1.4F * par2);
/* 166 */     this.rightarm2.rotateAngleY = 0.0F;
/* 167 */     this.leftarm.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 1.4F * par2);
/* 168 */     this.leftarm.rotateAngleY = 0.0F;
/* 169 */     this.leftarm2.rotateAngleX = (MathHelper.cos(par1 * 0.6662F) * 1.4F * par2);
/* 170 */     this.leftarm2.rotateAngleY = 0.0F;
/* 171 */     this.leftleg.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2);
/* 172 */     this.rightleg.rotateAngleX = (MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelGarag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */