/*    */ package fr.paladium.palamod.client.model;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*    */ import net.minecraft.client.model.ModelRenderer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ 
/*    */ public class ModelCustomWither extends net.minecraft.client.model.ModelBase
/*    */ {
/*    */   private ModelRenderer[] field_82905_a;
/*    */   private ModelRenderer[] field_82904_b;
/*    */   
/*    */   public ModelCustomWither()
/*    */   {
/* 15 */     this.textureWidth = 64;
/* 16 */     this.textureHeight = 64;
/* 17 */     this.field_82905_a = new ModelRenderer[3];
/* 18 */     this.field_82905_a[0] = new ModelRenderer(this, 0, 16);
/* 19 */     this.field_82905_a[0].addBox(-10.0F, 3.9F, -0.5F, 20, 3, 3);
/* 20 */     this.field_82905_a[1] = new ModelRenderer(this).setTextureSize(this.textureWidth, this.textureHeight);
/* 21 */     this.field_82905_a[1].setRotationPoint(-2.0F, 6.9F, -0.5F);
/* 22 */     this.field_82905_a[1].setTextureOffset(0, 22).addBox(0.0F, 0.0F, 0.0F, 3, 10, 3);
/* 23 */     this.field_82905_a[1].setTextureOffset(24, 22).addBox(-4.0F, 1.5F, 0.5F, 11, 2, 2);
/* 24 */     this.field_82905_a[1].setTextureOffset(24, 22).addBox(-4.0F, 4.0F, 0.5F, 11, 2, 2);
/* 25 */     this.field_82905_a[1].setTextureOffset(24, 22).addBox(-4.0F, 6.5F, 0.5F, 11, 2, 2);
/* 26 */     this.field_82905_a[2] = new ModelRenderer(this, 12, 22);
/* 27 */     this.field_82905_a[2].addBox(0.0F, 0.0F, 0.0F, 3, 6, 3);
/* 28 */     this.field_82904_b = new ModelRenderer[3];
/* 29 */     this.field_82904_b[0] = new ModelRenderer(this, 0, 0);
/* 30 */     this.field_82904_b[0].addBox(-4.0F, -4.0F, -4.0F, 8, 8, 8);
/* 31 */     this.field_82904_b[1] = new ModelRenderer(this, 32, 0);
/* 32 */     this.field_82904_b[1].addBox(-4.0F, -4.0F, -4.0F, 6, 6, 6);
/* 33 */     this.field_82904_b[1].rotationPointX = -8.0F;
/* 34 */     this.field_82904_b[1].rotationPointY = 4.0F;
/* 35 */     this.field_82904_b[2] = new ModelRenderer(this, 32, 0);
/* 36 */     this.field_82904_b[2].addBox(-4.0F, -4.0F, -4.0F, 6, 6, 6);
/* 37 */     this.field_82904_b[2].rotationPointX = 10.0F;
/* 38 */     this.field_82904_b[2].rotationPointY = 4.0F;
/*    */   }
/*    */   
/*    */   public int func_82903_a() {
/* 42 */     return 32;
/*    */   }
/*    */   
/*    */   public void render(Entity p_render_1_, float p_render_2_, float p_render_3_, float p_render_4_, float p_render_5_, float p_render_6_, float p_render_7_) {
/* 46 */     setRotationAngles(p_render_2_, p_render_3_, p_render_4_, p_render_5_, p_render_6_, p_render_7_, p_render_1_);
/* 47 */     ModelRenderer[] var8 = this.field_82904_b;
/* 48 */     int var9 = var8.length;
/*    */     
/*    */ 
/*    */ 
/* 52 */     for (int var10 = 0; var10 < var9; var10++) {
/* 53 */       ModelRenderer var11 = var8[var10];
/* 54 */       var11.render(p_render_7_);
/*    */     }
/*    */     
/* 57 */     var8 = this.field_82905_a;
/* 58 */     var9 = var8.length;
/*    */     
/* 60 */     for (var10 = 0; var10 < var9; var10++) {
/* 61 */       ModelRenderer var11 = var8[var10];
/* 62 */       var11.render(p_render_7_);
/*    */     }
/*    */   }
/*    */   
/*    */   public void setRotationAngles(float p_setRotationAngles_1_, float p_setRotationAngles_2_, float p_setRotationAngles_3_, float p_setRotationAngles_4_, float p_setRotationAngles_5_, float p_setRotationAngles_6_, Entity p_setRotationAngles_7_)
/*    */   {
/* 68 */     float var8 = net.minecraft.util.MathHelper.cos(p_setRotationAngles_3_ * 0.1F);
/* 69 */     this.field_82905_a[1].rotateAngleX = ((0.065F + 0.05F * var8) * 3.1415927F);
/* 70 */     this.field_82905_a[2].setRotationPoint(-2.0F, 6.9F + net.minecraft.util.MathHelper.cos(this.field_82905_a[1].rotateAngleX) * 10.0F, -0.5F + net.minecraft.util.MathHelper.sin(this.field_82905_a[1].rotateAngleX) * 10.0F);
/* 71 */     this.field_82905_a[2].rotateAngleX = ((0.265F + 0.1F * var8) * 3.1415927F);
/* 72 */     this.field_82904_b[0].rotateAngleY = (p_setRotationAngles_4_ / 57.295776F);
/* 73 */     this.field_82904_b[0].rotateAngleX = (p_setRotationAngles_5_ / 57.295776F);
/*    */   }
/*    */   
/*    */   public void setLivingAnimations(EntityLivingBase p_setLivingAnimations_1_, float p_setLivingAnimations_2_, float p_setLivingAnimations_3_, float p_setLivingAnimations_4_) {
/* 77 */     EntityCustomWither var5 = (EntityCustomWither)p_setLivingAnimations_1_;
/*    */     
/* 79 */     for (int var6 = 1; var6 < 3; var6++) {
/* 80 */       this.field_82904_b[var6].rotateAngleY = ((var5.func_82207_a(var6 - 1) - p_setLivingAnimations_1_.renderYawOffset) / 57.295776F);
/* 81 */       this.field_82904_b[var6].rotateAngleX = (var5.func_82210_r(var6 - 1) / 57.295776F);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\model\ModelCustomWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */