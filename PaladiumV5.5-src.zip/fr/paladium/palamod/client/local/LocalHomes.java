/*    */ package fr.paladium.palamod.client.local;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONObject;
/*    */ import org.json.simple.parser.JSONParser;
/*    */ import org.json.simple.parser.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalHomes
/*    */ {
/*    */   static int maxHomes;
/* 15 */   static HashMap<String, String> homes = new HashMap();
/*    */   
/*    */   public static void pretify(String jsonDoc) {
/* 18 */     JSONParser parser = new JSONParser();
/* 19 */     if ((jsonDoc == null) || (jsonDoc.equals("")))
/* 20 */       return;
/*    */     try {
/* 22 */       JSONObject json = (JSONObject)parser.parse(jsonDoc);
/*    */       
/* 24 */       maxHomes = new Integer(((Long)json.get("maxhomes")).intValue()).intValue();
/* 25 */       if (json.containsKey("homes")) {
/* 26 */         JSONArray array = (JSONArray)json.get("homes");
/* 27 */         Iterator i = array.iterator();
/* 28 */         while (i.hasNext()) {
/* 29 */           JSONObject obj = (JSONObject)i.next();
/* 30 */           homes.put((String)obj.get("name"), (String)obj.get("levelName"));
/*    */         }
/*    */       }
/*    */     } catch (ParseException e) {
/* 34 */       e.printStackTrace();
/* 35 */       return;
/*    */     }
/*    */   }
/*    */   
/*    */   public static int getMaxHomes() {
/* 40 */     return maxHomes;
/*    */   }
/*    */   
/*    */   public static void setMaxHomes(int maxHomes) {
/* 44 */     maxHomes = maxHomes;
/*    */   }
/*    */   
/*    */   public static HashMap<String, String> getHomes() {
/* 48 */     return homes;
/*    */   }
/*    */   
/*    */   public static void setHomes(HashMap<String, String> homes) {
/* 52 */     homes = homes;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\local\LocalHomes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */