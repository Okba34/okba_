/*     */ package fr.paladium.palamod.client.local;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.client.gui.tools.prompt.PromptAction;
/*     */ import fr.paladium.palamod.util.ParseHelper;
/*     */ import fr.paladium.servertools.market.MarketOffer;
/*     */ import fr.paladium.servertools.shop.ShopEntry;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ import org.json.simple.parser.ParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class LocalValues
/*     */ {
/*     */   static PromptAction promptAction;
/*     */   static String guiName;
/*     */   static String buttonName;
/*     */   static String[] promptParams;
/*  28 */   static HashMap<String, String> localValuesString = new HashMap();
/*  29 */   static HashMap<String, Integer> localValuesInt = new HashMap();
/*  30 */   static HashMap<Integer, Integer> localJobs = new HashMap();
/*  31 */   static HashMap<Integer, Integer> localCaps = new HashMap();
/*  32 */   static HashMap<Integer, Integer> localSpells = new HashMap();
/*  33 */   static HashMap<Integer, Integer> localGolem = new HashMap();
/*     */   
/*     */   static HashMap<Integer, ShopEntry> localShopEntries;
/*     */   static HashMap<UUID, MarketOffer> localMarketOffers;
/*     */   static HashMap<UUID, MarketOffer> playerMarketOffers;
/*  38 */   public static ArrayList<String> notification = new ArrayList();
/*     */   
/*     */   public static void setValue(String key, String value) {
/*  41 */     localValuesString.put(key, value);
/*     */   }
/*     */   
/*     */   public static void setValue(String key, int value) {
/*  45 */     localValuesInt.put(key, Integer.valueOf(value));
/*     */   }
/*     */   
/*     */   public static String getString(String key) {
/*  49 */     if (localValuesString.containsKey(key))
/*  50 */       return (String)localValuesString.get(key);
/*  51 */     return "";
/*     */   }
/*     */   
/*     */   public static int getInteger(String key) {
/*  55 */     if (localValuesInt.containsKey(key))
/*  56 */       return ((Integer)localValuesInt.get(key)).intValue();
/*  57 */     return 0;
/*     */   }
/*     */   
/*     */   public static void setPromptAction(PromptAction action) {
/*  61 */     promptAction = action;
/*     */   }
/*     */   
/*     */   public static PromptAction getPromptAction() {
/*  65 */     return promptAction;
/*     */   }
/*     */   
/*     */   public static void setPromptParams(String[] params) {
/*  69 */     promptParams = params;
/*     */   }
/*     */   
/*     */   public static String[] getPromptParams() {
/*  73 */     return promptParams;
/*     */   }
/*     */   
/*     */   public static String getGuiName() {
/*  77 */     return guiName;
/*     */   }
/*     */   
/*     */   public static void setGuiName(String guiName) {
/*  81 */     guiName = guiName;
/*     */   }
/*     */   
/*     */   public static String getButtonName() {
/*  85 */     return buttonName;
/*     */   }
/*     */   
/*     */   public static void setButtonName(String buttonName) {
/*  89 */     buttonName = buttonName;
/*     */   }
/*     */   
/*     */   public static void setPromptGui(String guiName, String buttonName, String[] params, PromptAction action) {
/*  93 */     setGuiName(guiName);
/*  94 */     setButtonName(buttonName);
/*  95 */     setPromptAction(action);
/*  96 */     setPromptParams(params);
/*     */   }
/*     */   
/*     */   public static void initJobs() {
/* 100 */     String localJobsString = (String)localValuesString.get("localJobs");
/*     */     
/* 102 */     JSONParser parser = new JSONParser();
/* 103 */     if ((localJobs == null) || (localJobs.equals(""))) {
/* 104 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 108 */       object = (JSONObject)parser.parse(localJobsString);
/*     */     } catch (ParseException e) { JSONObject object;
/*     */       return;
/*     */     }
/*     */     JSONObject object;
/* 113 */     JSONArray array = (JSONArray)object.get("jobs");
/* 114 */     if (array == null)
/* 115 */       return;
/* 116 */     for (int i = 0; i < array.size(); i++) {
/* 117 */       JSONObject subObj = (JSONObject)array.get(i);
/* 118 */       int id = ((Long)subObj.get("id")).intValue();
/* 119 */       int xp = ((Long)subObj.get("xp")).intValue();
/*     */       
/* 121 */       localJobs.put(Integer.valueOf(id), Integer.valueOf(xp));
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getXPJob(int jobId)
/*     */   {
/*     */     
/* 128 */     if (!localJobs.containsKey(Integer.valueOf(jobId))) {
/* 129 */       return 0;
/*     */     }
/* 131 */     return ((Integer)localJobs.get(Integer.valueOf(jobId))).intValue();
/*     */   }
/*     */   
/*     */   public static void addNotification(String message) {
/* 135 */     String[] coumpoundMessage = message.split("/");
/* 136 */     String finalMessage = "";
/* 137 */     for (String m : coumpoundMessage) {
/* 138 */       if ((m.length() > 2) && (m.charAt(0) == '%') && (m.charAt(m.length() - 1) == '%')) {
/* 139 */         finalMessage = finalMessage + I18n.format(m.substring(1, m.length() - 1), new Object[0]);
/*     */       } else
/* 141 */         finalMessage = finalMessage + m;
/*     */     }
/* 143 */     notification.add(finalMessage);
/*     */   }
/*     */   
/*     */   public static boolean initLevels() {
/* 147 */     localCaps = new HashMap();
/* 148 */     String localLevelsString = (String)localValuesString.get("localLevels");
/*     */     
/* 150 */     JSONParser parser = new JSONParser();
/* 151 */     if ((localLevelsString == null) || (localLevelsString.equals(""))) {
/* 152 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 156 */       object = (JSONObject)parser.parse(localLevelsString);
/*     */     } catch (ParseException e) { JSONObject object;
/* 158 */       return false;
/*     */     }
/*     */     JSONObject object;
/* 161 */     localValuesInt.put("localLevel", Integer.valueOf(((Long)object.get("level")).intValue()));
/* 162 */     localValuesInt.put("localXP", Integer.valueOf(((Long)object.get("xp")).intValue()));
/* 163 */     localValuesInt.put("capacityPoints", 
/* 164 */       Integer.valueOf(((Long)object.get("capacityPoints")).intValue()));
/*     */     
/* 166 */     JSONArray array = (JSONArray)object.get("cap");
/* 167 */     if (array == null)
/* 168 */       return true;
/* 169 */     for (int i = 0; i < array.size(); i++) {
/* 170 */       JSONObject subObj = (JSONObject)array.get(i);
/* 171 */       int id = ((Long)subObj.get("id")).intValue();
/* 172 */       int ammount = ((Long)subObj.get("ammount")).intValue();
/*     */       
/* 174 */       localCaps.put(Integer.valueOf(id), Integer.valueOf(ammount));
/*     */     }
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   public static int getCap(int cap) {
/* 180 */     if (localCaps.containsKey(Integer.valueOf(cap))) {
/* 181 */       return ((Integer)localCaps.get(Integer.valueOf(cap))).intValue();
/*     */     }
/* 183 */     return 0;
/*     */   }
/*     */   
/*     */   public static boolean initSpells() {
/* 187 */     localSpells = new HashMap();
/* 188 */     String localSpellsString = (String)localValuesString.get("spell");
/*     */     
/* 190 */     JSONParser parser = new JSONParser();
/* 191 */     if ((localSpellsString == null) || (localSpellsString.equals(""))) {
/* 192 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 196 */       object = (JSONObject)parser.parse(localSpellsString);
/*     */     } catch (ParseException e) { JSONObject object;
/* 198 */       return false;
/*     */     }
/*     */     JSONObject object;
/* 201 */     localValuesInt.put("spellPoints", Integer.valueOf(((Long)object.get("spellPoints")).intValue()));
/* 202 */     localValuesInt.put("localLevel", Integer.valueOf(((Long)object.get("level")).intValue()));
/*     */     
/* 204 */     JSONArray array = (JSONArray)object.get("spells");
/* 205 */     if (array == null)
/* 206 */       return true;
/* 207 */     for (int i = 0; i < array.size(); i++) {
/* 208 */       JSONObject subObj = (JSONObject)array.get(i);
/* 209 */       int id = ((Long)subObj.get("id")).intValue();
/* 210 */       int ammount = ((Long)subObj.get("ammount")).intValue();
/*     */       
/* 212 */       localSpells.put(Integer.valueOf(id), Integer.valueOf(ammount));
/*     */     }
/*     */     
/* 215 */     return true;
/*     */   }
/*     */   
/*     */   public static int getSpell(int spell) {
/* 219 */     if (localSpells.containsKey(Integer.valueOf(spell))) {
/* 220 */       return ((Integer)localSpells.get(Integer.valueOf(spell))).intValue();
/*     */     }
/* 222 */     return 0;
/*     */   }
/*     */   
/*     */   public static void clearSpells() {
/* 226 */     localSpells.clear();
/* 227 */     localValuesString.put("spell", "");
/*     */   }
/*     */   
/*     */   public static String getNotification(int notif) {
/* 231 */     if (notif < 0) {
/* 232 */       return null;
/*     */     }
/* 234 */     String result = (String)notification.get(notif);
/* 235 */     notification.remove(notif);
/* 236 */     return result;
/*     */   }
/*     */   
/*     */   public static void initGuardian()
/*     */   {
/* 241 */     String localJobsString = (String)localValuesString.get("golemData");
/*     */     
/* 243 */     JSONParser parser = new JSONParser();
/* 244 */     if ((localJobs == null) || (localJobs.equals(""))) {
/* 245 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 249 */       object = (JSONObject)parser.parse(localJobsString);
/*     */     } catch (ParseException e) { JSONObject object;
/*     */       return;
/*     */     }
/*     */     JSONObject object;
/* 254 */     JSONArray array = (JSONArray)object.get("upgrades");
/* 255 */     if (array == null)
/* 256 */       return;
/* 257 */     for (int i = 0; i < array.size(); i++) {
/* 258 */       JSONObject subObj = (JSONObject)array.get(i);
/* 259 */       int id = ((Long)subObj.get("id")).intValue();
/* 260 */       int xp = ((Long)subObj.get("level")).intValue();
/*     */       
/* 262 */       localGolem.put(Integer.valueOf(id), Integer.valueOf(xp));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int getUpgrade(int id)
/*     */   {
/* 270 */     return ((Integer)localGolem.getOrDefault(Integer.valueOf(id), Integer.valueOf(0))).intValue();
/*     */   }
/*     */   
/*     */   public static void clearGolem() {
/* 274 */     localGolem.clear();
/*     */   }
/*     */   
/*     */   public static boolean initShopEntries() {
/* 278 */     if (localShopEntries != null)
/* 279 */       return true;
/* 280 */     if (getString("shopPackages").equals("")) {
/* 281 */       return false;
/*     */     }
/* 283 */     JSONParser parser = new JSONParser();
/*     */     
/*     */     try
/*     */     {
/* 287 */       jsonEntries = (JSONObject)parser.parse(getString("shopPackages"));
/*     */     } catch (ParseException e) { JSONObject jsonEntries;
/* 289 */       return false;
/*     */     }
/*     */     JSONObject jsonEntries;
/* 292 */     localShopEntries = new HashMap();
/* 293 */     System.out.println("Loading packages...");
/*     */     try
/*     */     {
/* 296 */       JSONArray array = (JSONArray)jsonEntries.get("shopPackages");
/* 297 */       for (int i = 0; i < array.size(); i++) {
/* 298 */         JSONObject e = (JSONObject)array.get(i);
/* 299 */         int id = ((Long)e.get("id")).intValue();
/* 300 */         String displayName = (String)e.get("displayName");
/* 301 */         String image = (String)e.get("image");
/* 302 */         int price = ((Long)e.get("price")).intValue();
/* 303 */         JSONArray commands = (JSONArray)e.get("toExecute");
/* 304 */         ArrayList<String> toExecute = new ArrayList();
/* 305 */         for (int j = 0; j < commands.size(); j++) {
/* 306 */           toExecute.add((String)commands.get(j));
/*     */         }
/* 308 */         ShopEntry entry = new ShopEntry(id, displayName, price, image, toExecute);
/* 309 */         localShopEntries.put(Integer.valueOf(id), entry);
/* 310 */         System.out.println("Registering package with id " + id + " - " + displayName);
/*     */       }
/*     */     } catch (ClassCastException e) {
/* 313 */       System.out.println("Failed to load packages...");
/* 314 */       e.printStackTrace();
/* 315 */       return false;
/*     */     }
/* 317 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean initExchangeEntries() {
/* 321 */     if (getString("exchangeOffers").equals("")) {
/* 322 */       return false;
/*     */     }
/* 324 */     HashMap<UUID, MarketOffer> result = ParseHelper.getMarketOfferFromJson(getString("exchangeOffers"));
/*     */     
/* 326 */     if (result == null) {
/* 327 */       localMarketOffers = new HashMap();
/* 328 */       return false;
/*     */     }
/*     */     
/* 331 */     localMarketOffers = result;
/* 332 */     return true;
/*     */   }
/*     */   
/*     */   public static double getBalance() {
/* 336 */     if (getString("moneyBalance").equals("")) {
/* 337 */       return 0.0D;
/*     */     }
/* 339 */     JSONParser parser = new JSONParser();
/*     */     
/*     */     try
/*     */     {
/* 343 */       jsonEntries = (JSONObject)parser.parse(getString("moneyBalance"));
/*     */     } catch (ParseException e) { JSONObject jsonEntries;
/* 345 */       return 0.0D;
/*     */     }
/*     */     try {
/*     */       JSONObject jsonEntries;
/* 349 */       return ((Double)jsonEntries.getOrDefault("cashBalance", Double.valueOf(0.0D))).doubleValue();
/*     */     } catch (ClassCastException e) {}
/* 351 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static double getPalacoinBalance()
/*     */   {
/* 356 */     if (getString("moneyBalance").equals("")) {
/* 357 */       return 0.0D;
/*     */     }
/* 359 */     JSONParser parser = new JSONParser();
/*     */     
/*     */     try
/*     */     {
/* 363 */       jsonEntries = (JSONObject)parser.parse(getString("moneyBalance"));
/*     */     } catch (ParseException e) { JSONObject jsonEntries;
/* 365 */       return 0.0D;
/*     */     }
/*     */     try {
/*     */       JSONObject jsonEntries;
/* 369 */       return ((Double)jsonEntries.getOrDefault("palacoinBalance", Double.valueOf(0.0D))).doubleValue();
/*     */     } catch (ClassCastException e) {}
/* 371 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static HashMap<UUID, MarketOffer> getOfferFromPlayer()
/*     */   {
/* 376 */     if (getString("exchangePlayer").equals("")) {
/* 377 */       return new HashMap();
/*     */     }
/* 379 */     playerMarketOffers = ParseHelper.getMarketOfferFromJson(getString("exchangePlayer"));
/* 380 */     return playerMarketOffers;
/*     */   }
/*     */   
/*     */   public static HashMap<Integer, ShopEntry> getShopEntries() {
/* 384 */     return localShopEntries;
/*     */   }
/*     */   
/*     */   public static HashMap<UUID, MarketOffer> getMarketOffers() {
/* 388 */     return localMarketOffers;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\local\LocalValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */