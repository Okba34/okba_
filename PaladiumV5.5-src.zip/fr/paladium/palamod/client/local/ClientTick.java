package fr.paladium.palamod.client.local;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent.PlayerTickEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.io.InputStream;

public class ClientTick
{
  static InputStream is;
  
  @SideOnly(Side.CLIENT)
  @SubscribeEvent
  public void tick(TickEvent.PlayerTickEvent event) {}
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\local\ClientTick.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */