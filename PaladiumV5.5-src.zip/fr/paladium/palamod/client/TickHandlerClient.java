/*     */ package fr.paladium.palamod.client;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent.Phase;
/*     */ import cpw.mods.fml.common.gameevent.TickEvent.RenderTickEvent;
/*     */ import cpw.mods.fml.relauncher.ReflectionHelper;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.items.armors.RepairableArmor;
/*     */ import fr.paladium.palamod.util.LibObfuscation;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */ public class TickHandlerClient
/*     */ {
/*  30 */   public static int cheatCheck = 0;
/*  31 */   public static float partialTicks = 0.0F;
/*  32 */   public static float ticksInGame = 0.0F;
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onRenderTick(TickEvent.RenderTickEvent event)
/*     */   {
/*  37 */     render();
/*     */     
/*  39 */     if ((event.phase == TickEvent.Phase.END) && (
/*  40 */       (Minecraft.getMinecraft().currentScreen == null) || (!Minecraft.getMinecraft().currentScreen.doesGuiPauseGame()))) {
/*  41 */       ticksInGame += 1.0F;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void render()
/*     */   {
/*  48 */     Minecraft mc = Minecraft.getMinecraft();
/*  49 */     GuiScreen gui = mc.currentScreen;
/*  50 */     if ((gui != null) && ((gui instanceof GuiContainer)) && (mc.thePlayer != null) && (mc.thePlayer.inventory.getItemStack() == null))
/*     */     {
/*  52 */       GuiContainer container = (GuiContainer)gui;
/*  53 */       Slot slot = (Slot)ReflectionHelper.getPrivateValue(GuiContainer.class, container, LibObfuscation.THE_SLOT);
/*  54 */       if ((slot != null) && (slot.getHasStack()))
/*     */       {
/*  56 */         ItemStack stack = slot.getStack();
/*  57 */         if (stack != null)
/*     */         {
/*  59 */           ScaledResolution res = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
/*  60 */           FontRenderer font = mc.fontRenderer;
/*  61 */           int mouseX = Mouse.getX() * res.getScaledWidth() / mc.displayWidth;
/*  62 */           int mouseY = res.getScaledHeight() - Mouse.getY() * res.getScaledHeight() / mc.displayHeight;
/*     */           
/*     */           List<String> tooltip;
/*     */           try
/*     */           {
/*  67 */             tooltip = stack.getTooltip(mc.thePlayer, mc.gameSettings.advancedItemTooltips);
/*     */           }
/*     */           catch (Exception e) {
/*     */             List<String> tooltip;
/*  71 */             tooltip = new ArrayList();
/*     */           }
/*  73 */           int width = 0;
/*  74 */           for (String s : tooltip)
/*  75 */             width = Math.max(width, font.getStringWidth(s) + 2);
/*  76 */           int tooltipHeight = (tooltip.size() - 1) * 10 + 5;
/*     */           
/*  78 */           int height = 3;
/*  79 */           int offx = 11;
/*  80 */           int offy = 17;
/*     */           
/*  82 */           boolean offscreen = mouseX + width + 19 >= res.getScaledWidth();
/*     */           
/*  84 */           int fixY = res.getScaledHeight() - (mouseY + tooltipHeight);
/*  85 */           if (fixY < 0)
/*  86 */             offy -= fixY;
/*  87 */           if (offscreen) {
/*  88 */             offx = -13 - width;
/*     */           }
/*  90 */           else if ((stack.getItem() instanceof RepairableArmor)) {
/*  91 */             drawBar(stack, (RepairableArmor)stack.getItem(), mouseX, mouseY, offx, offy, width, height);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void drawBar(ItemStack stack, RepairableArmor display, int mouseX, int mouseY, int offx, int offy, int width, int height) {
/*  99 */     float fraction = RepairableArmor.getFraction(stack);
/* 100 */     int manaBarWidth = (int)Math.ceil(width * fraction);
/*     */     
/* 102 */     GL11.glDisable(2929);
/* 103 */     Gui.drawRect(mouseX + offx - 1, mouseY - offy - height - 1, mouseX + offx + width + 1, mouseY - offy, -16777216);
/* 104 */     Gui.drawRect(mouseX + offx, mouseY - offy - height, mouseX + offx + manaBarWidth, mouseY - offy, Color.HSBtoRGB(21.55F, 1.0F, 80.78F));
/* 105 */     Gui.drawRect(mouseX + offx + manaBarWidth, mouseY - offy - height, mouseX + offx + width, mouseY - offy, 268435455);
/* 106 */     Gui.drawRect(mouseX + offx + manaBarWidth, mouseY - offy - height, mouseX + offx + width, mouseY - offy, -11184811);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\TickHandlerClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */