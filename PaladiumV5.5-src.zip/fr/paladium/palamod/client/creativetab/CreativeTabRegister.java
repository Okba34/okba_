/*    */ package fr.paladium.palamod.client.creativetab;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.material.MaterialRegister;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ 
/*    */ public class CreativeTabRegister
/*    */ {
/* 10 */   public static final CreativeTabs PALADIUM = new CreativeTabs("paladium") {
/*    */     @SideOnly(Side.CLIENT)
/*    */     public net.minecraft.item.Item getTabIconItem() {
/* 13 */       return MaterialRegister.PALADIUM_INGOT;
/*    */     }
/*    */   };
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\creativetab\CreativeTabRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */