/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.CustomBossStatus;
/*    */ import fr.paladium.palamod.util.DisplayHelper;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class OverlayBoss
/*    */ {
/* 23 */   Minecraft mc = Minecraft.getMinecraft();
/* 24 */   private ResourceLocation boss = new ResourceLocation("palamod:textures/gui/bossBar.png");
/*    */   
/*    */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*    */   public void onRender(RenderGameOverlayEvent.Pre event) {
/* 28 */     if (event.type == RenderGameOverlayEvent.ElementType.BOSSHEALTH) {
/* 29 */       if (CustomBossStatus.bossName == null)
/* 30 */         return;
/* 31 */       CustomBossStatus.update();
/* 32 */       event.setCanceled(true);
/* 33 */       FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/* 34 */       ScaledResolution scaledresolution = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
/*    */       
/* 36 */       int i = scaledresolution.getScaledWidth();
/* 37 */       short short1 = 182;
/* 38 */       int k = (int)(CustomBossStatus.healthScale * (short1 + 1));
/* 39 */       byte b0 = 12;
/*    */       
/* 41 */       String s = CustomBossStatus.bossName;
/* 42 */       fr.drawStringWithShadow(s, i / 2 - fr.getStringWidth(s) / 2, b0 + 7, 16777215);
/* 43 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 44 */       this.mc.getTextureManager().bindTexture(Gui.icons);
/*    */       
/* 46 */       this.mc.getTextureManager().bindTexture(this.boss);
/*    */       
/* 48 */       DisplayHelper.drawTexturedModalRect(i / 2 - 92, 3, 1.0F, 0, 0, 185, 15);
/* 49 */       DisplayHelper.drawTexturedModalRect(i / 2 - 90, 7, 2.0F, 0, 15, k, 7);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */