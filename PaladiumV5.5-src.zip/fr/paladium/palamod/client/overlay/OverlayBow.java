/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ 
/*    */ 
/*    */ public class OverlayBow
/*    */   extends Gui
/*    */ {
/*    */   Minecraft mc;
/* 15 */   final ResourceLocation tex = new ResourceLocation("palamod", "textures/overlay/Crosshair_0.png");
/*    */   
/*    */   public OverlayBow() {
/* 18 */     this.mc = Minecraft.getMinecraft();
/*    */   }
/*    */   
/*    */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*    */   public void onRender(RenderGameOverlayEvent.Pre event) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayBow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */