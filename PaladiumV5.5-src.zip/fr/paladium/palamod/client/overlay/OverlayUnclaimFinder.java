/*     */ package fr.paladium.palamod.client.overlay;
/*     */ 
/*     */ import com.sun.corba.se.impl.io.TypeMismatchException;
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.paladium.item.ItemUnclaimFinder;
/*     */ import fr.paladium.palamod.tiles.TileHarpagophytumFlower;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.chunk.Chunk;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class OverlayUnclaimFinder extends Gui
/*     */ {
/*     */   private Minecraft mc;
/*     */   private String show;
/*  33 */   private final ResourceLocation bg = new ResourceLocation("palamod", "textures/overlay/UnclaimFinder.png");
/*     */   private FontRenderer fontRender;
/*  35 */   private RenderItem itemRenderer = new RenderItem();
/*     */   
/*     */   public OverlayUnclaimFinder() {
/*  38 */     this.mc = Minecraft.getMinecraft();
/*  39 */     this.show = "0%";
/*  40 */     this.fontRender = this.mc.fontRenderer;
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*     */   public void onRender(RenderGameOverlayEvent.Post event) {
/*  45 */     if (event.type != RenderGameOverlayEvent.ElementType.HOTBAR) {
/*  46 */       return;
/*     */     }
/*     */     
/*  49 */     if ((this.mc.thePlayer.getHeldItem() != null) && ((this.mc.thePlayer.getHeldItem().getItem() instanceof ItemUnclaimFinder)) && (this.mc.theWorld.isRemote)) {
/*  50 */       this.mc.renderEngine.bindTexture(this.bg);
/*     */       
/*  52 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  53 */       GL11.glDisable(2896);
/*  54 */       GL11.glEnable(3042);
/*  55 */       GL11.glBlendFunc(770, 771);
/*     */       
/*  57 */       fr.paladium.palamod.util.DisplayHelper.drawTexturedQuadFit(5.0D, 5.0D, 32.0D, 32.0D, 0.0D);
/*     */       
/*  59 */       int amountTiles = this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ + 0).chunkTileEntityMap.values().size();
/*  60 */       amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ + 1).chunkTileEntityMap.values().size();
/*  61 */       amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ - 1).chunkTileEntityMap.values().size();
/*  62 */       amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 1, this.mc.thePlayer.chunkCoordZ).chunkTileEntityMap.values().size();
/*  63 */       amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX - 1, this.mc.thePlayer.chunkCoordZ).chunkTileEntityMap.values().size();
/*     */       
/*  65 */       int amountHarpago = 0;
/*     */       
/*  67 */       for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ + 0).chunkTileEntityMap.values()) {
/*  68 */         if ((tileEntity instanceof TileHarpagophytumFlower)) {
/*  69 */           amountHarpago += 2;
/*     */         }
/*     */       }
/*  72 */       for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ + 1).chunkTileEntityMap.values()) {
/*  73 */         if ((tileEntity instanceof TileHarpagophytumFlower)) {
/*  74 */           amountHarpago += 2;
/*     */         }
/*     */       }
/*  77 */       for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 0, this.mc.thePlayer.chunkCoordZ - 1).chunkTileEntityMap.values()) {
/*  78 */         if ((tileEntity instanceof TileHarpagophytumFlower)) {
/*  79 */           amountHarpago += 2;
/*     */         }
/*     */       }
/*  82 */       for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + 1, this.mc.thePlayer.chunkCoordZ).chunkTileEntityMap.values()) {
/*  83 */         if ((tileEntity instanceof TileHarpagophytumFlower)) {
/*  84 */           amountHarpago += 2;
/*     */         }
/*     */       }
/*  87 */       for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX - 1, this.mc.thePlayer.chunkCoordZ).chunkTileEntityMap.values()) {
/*  88 */         if ((tileEntity instanceof TileHarpagophytumFlower)) {
/*  89 */           amountHarpago += 2;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  94 */       if (this.mc.thePlayer.getHeldItem().getItemDamage() >= 1) {
/*  95 */         int[] y = { -2, -1, 0, 1, 2, -2, 2, -2, 2, -2, 2, -2, -1, 0, 1, 2 };
/*  96 */         int[] x = { -2, -2, -2, -2, -2, -1, -1, 0, 0, 1, 1, 2, 2, 2, 2, 2 };
/*  97 */         for (int i = 0; i < y.length; i++) {
/*  98 */           amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + x[i], this.mc.thePlayer.chunkCoordZ + y[i]).chunkTileEntityMap.values().size();
/*     */           
/* 100 */           for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + x[i], this.mc.thePlayer.chunkCoordZ + y[i]).chunkTileEntityMap.values()) {
/* 101 */             if ((tileEntity instanceof TileHarpagophytumFlower)) {
/* 102 */               amountHarpago += 2;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 108 */       if (this.mc.thePlayer.getHeldItem().getItemDamage() >= 2) {
/* 109 */         int[] y = { -3, -2, -1, 0, 1, 2, 0, 3, -3, 3, -3, 3, -3, 3, -3, 3, -3, -2, -1, 0, 1, 2, 3 };
/* 110 */         int[] x = { -3, -3, -3, -3, -3, -3, -5, -2, -1, -1, 0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 3, 3, 3 };
/* 111 */         for (int i = 0; i < y.length; i++) {
/* 112 */           amountTiles += this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + x[i], this.mc.thePlayer.chunkCoordZ + y[i]).chunkTileEntityMap.values().size();
/*     */           
/* 114 */           for (Object tileEntity : this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + x[i], this.mc.thePlayer.chunkCoordZ + y[i]).chunkTileEntityMap.values()) {
/* 115 */             if ((tileEntity instanceof TileHarpagophytumFlower)) {
/* 116 */               amountHarpago += 2;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 122 */       if (this.mc.thePlayer.getHeldItem().getItemDamage() >= 3) {
/* 123 */         int chests = 0;
/* 124 */         int moddedChests = 0;
/*     */         
/* 126 */         for (int x = -3; x < 3; x++) {
/* 127 */           for (int z = -3; z < 3; z++) {
/* 128 */             Map<?, ?> tileMap = this.mc.theWorld.getChunkFromChunkCoords(this.mc.thePlayer.chunkCoordX + x, this.mc.thePlayer.chunkCoordZ + z).chunkTileEntityMap;
/* 129 */             Iterator<?> entries = tileMap.entrySet().iterator();
/* 130 */             while (entries.hasNext()) {
/*     */               try {
/* 132 */                 Map.Entry<?, ?> e = (Map.Entry)entries.next();
/* 133 */                 TileEntity te = (TileEntity)e.getValue();
/* 134 */                 if (te != null)
/*     */                 {
/*     */ 
/* 137 */                   if (te.getClass().toString().contains("net.minecraft.tileentity.TileEntityChest")) {
/* 138 */                     chests++;
/*     */                   }
/* 140 */                   else if ((te.getClass().toString().contains("Chest")) || (te.getClass().toString().contains("chest"))) {
/* 141 */                     moddedChests++;
/*     */                   }
/*     */                 }
/*     */               } catch (TypeMismatchException e) {
/* 145 */                 fr.paladium.palamod.PalaMod.logger.error("Trouble in the operation of the unchaim finder!");
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 151 */         ItemStack stackChest = new ItemStack(net.minecraft.init.Blocks.chest);
/* 152 */         ItemStack stackModdedChests = new ItemStack(PaladiumRegister.PALADIUM_CHEST);
/* 153 */         GL11.glPushMatrix();
/* 154 */         GL11.glEnable(2929);
/* 155 */         GL11.glScaled(1.5D, 1.5D, 1.5D);
/*     */         
/* 157 */         this.itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, stackChest, 30, 5);
/* 158 */         this.itemRenderer.renderItemAndEffectIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, stackModdedChests, 50, 5);
/*     */         
/* 160 */         GL11.glDisable(2929);
/* 161 */         GL11.glDisable(2896);
/* 162 */         GL11.glPopMatrix();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 167 */         int xChests = 53;
/* 168 */         int xModdedChests = 83;
/*     */         
/* 170 */         if (chests > 100) {
/* 171 */           chests = 100;
/*     */         }
/*     */         
/* 174 */         if ((amountHarpago > 5) && (chests != 0)) {
/* 175 */           if (chests - 5 < 0) {
/* 176 */             chests = 1;
/*     */           } else {
/* 178 */             chests -= 5;
/*     */           }
/* 180 */         } else if ((amountHarpago > 0) && (chests != 0)) {
/* 181 */           if (chests - amountHarpago < 0) {
/* 182 */             chests = 1;
/*     */           } else {
/* 184 */             chests -= amountHarpago;
/*     */           }
/*     */         }
/*     */         
/* 188 */         if (moddedChests > 100) {
/* 189 */           moddedChests = 100;
/*     */         }
/*     */         
/* 192 */         if ((amountHarpago > 5) && (moddedChests != 0)) {
/* 193 */           if (moddedChests - 5 < 0) {
/* 194 */             moddedChests = 1;
/*     */           } else {
/* 196 */             moddedChests -= 5;
/*     */           }
/* 198 */         } else if ((amountHarpago > 0) && (moddedChests != 0)) {
/* 199 */           if (moddedChests - amountHarpago < 0) {
/* 200 */             moddedChests = 1;
/*     */           } else {
/* 202 */             moddedChests -= amountHarpago;
/*     */           }
/*     */         }
/*     */         
/* 206 */         String showChests = chests + "%";
/* 207 */         String showModdedChests = moddedChests + "%";
/*     */         
/* 209 */         if (chests > 9) {
/* 210 */           xChests -= 3;
/*     */         }
/* 212 */         if (moddedChests > 9) {
/* 213 */           xModdedChests -= 3;
/*     */         }
/*     */         
/* 216 */         this.fontRender.drawStringWithShadow(showChests, xChests, 37, -1);
/* 217 */         this.fontRender.drawStringWithShadow(showModdedChests, xModdedChests, 37, -1);
/*     */       }
/*     */       
/* 220 */       if (amountTiles > 100) {
/* 221 */         amountTiles = 100;
/*     */       }
/*     */       
/* 224 */       if ((amountHarpago > 10) && (amountTiles != 0)) {
/* 225 */         if (amountTiles - 10 < 0) {
/* 226 */           amountTiles = 1;
/*     */         } else {
/* 228 */           amountTiles -= 10;
/*     */         }
/* 230 */       } else if ((amountHarpago > 0) && (amountTiles != 0)) {
/* 231 */         if (amountTiles - amountHarpago < 0) {
/* 232 */           amountTiles = 1;
/*     */         } else {
/* 234 */           amountTiles -= amountHarpago;
/*     */         }
/*     */       }
/*     */       
/* 238 */       this.show = (amountTiles + "%");
/*     */       
/* 240 */       int x = 0;
/*     */       
/* 242 */       if (amountTiles > 9) {
/* 243 */         x = 12;
/*     */       }
/*     */       else {
/* 246 */         x = 15;
/*     */       }
/*     */       
/* 249 */       this.fontRender.drawStringWithShadow(this.show, x, 37, -1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayUnclaimFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */