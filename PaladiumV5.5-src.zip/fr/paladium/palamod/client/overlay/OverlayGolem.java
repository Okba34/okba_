/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.items.ItemGuardianWand;
/*    */ import fr.paladium.palamod.util.DisplayHelper;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.OpenGlHelper;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class OverlayGolem
/*    */ {
/* 27 */   Minecraft mc = Minecraft.getMinecraft();
/* 28 */   FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/* 29 */   ResourceLocation background = new ResourceLocation("palamod:textures/gui/GolemOverlay.png");
/*    */   
/*    */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*    */   public void onRender(RenderGameOverlayEvent.Pre event) {
/* 33 */     if (event.type == RenderGameOverlayEvent.ElementType.HOTBAR) {
/* 34 */       if ((this.mc.thePlayer.getHeldItem() == null) || 
/* 35 */         (!(this.mc.thePlayer.getHeldItem().getItem() instanceof ItemGuardianWand)))
/* 36 */         return;
/* 37 */       ItemStack wand = this.mc.thePlayer.getHeldItem();
/*    */       
/* 39 */       if (!ItemGuardianWand.isGolemLoaded(wand, this.mc.thePlayer.worldObj)) {
/* 40 */         return;
/*    */       }
/* 42 */       ScaledResolution res = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
/* 43 */       int width = res.getScaledWidth();
/*    */       
/*    */ 
/* 46 */       int x = width - 45;
/* 47 */       int y = 60;
/* 48 */       int size = 20;
/* 49 */       float rotX = 20.0F;
/* 50 */       float rotY = 0.0F;
/* 51 */       GL11.glPushMatrix();
/* 52 */       GL11.glTranslatef(x, y, 50.0F);
/* 53 */       EntityGuardianGolem golem = ItemGuardianWand.getGolem(wand, this.mc.theWorld);
/* 54 */       renderGolem(0, 0, size, rotX, rotY, golem);
/* 55 */       GL11.glScaled(0.6D, 0.6D, 0.0D);
/* 56 */       this.fr.drawStringWithShadow(golem.getName(), -35, 10, 16777215);
/* 57 */       GL11.glScaled(1.6666666666666667D, 1.6666666666666667D, 0.0D);
/* 58 */       this.mc.renderEngine.bindTexture(this.background);
/* 59 */       GL11.glScalef(0.85F, 0.85F, 0.0F);
/* 60 */       GL11.glEnable(3042);
/* 61 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
/* 62 */       DisplayHelper.drawTexturedModalRect(-35, -66, 0.0F, 0, 21, 71, 90);
/* 63 */       GL11.glPopMatrix();
/*    */     }
/*    */   }
/*    */   
/*    */   public void renderGolem(int x, int y, int size, float rotX, float rotY, EntityGuardianGolem golem) {
/* 68 */     GL11.glEnable(2903);
/* 69 */     GL11.glPushMatrix();
/* 70 */     GL11.glTranslatef(x, y, 50.0F);
/* 71 */     GL11.glScalef(-size, size, size);
/* 72 */     GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/* 73 */     float f2 = golem.renderYawOffset;
/* 74 */     float f3 = golem.rotationYaw;
/* 75 */     float f4 = golem.rotationPitch;
/* 76 */     float f5 = golem.prevRotationYawHead;
/* 77 */     float f6 = golem.rotationYawHead;
/* 78 */     GL11.glRotatef(135.0F, 0.0F, 1.0F, 0.0F);
/* 79 */     GL11.glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
/* 80 */     GL11.glRotatef(-(float)Math.atan(rotX / 40.0F) * 20.0F, 1.0F, 0.0F, 0.0F);
/* 81 */     golem.renderYawOffset = ((float)Math.atan(rotX / 40.0F) * 20.0F);
/* 82 */     golem.rotationYaw = ((float)Math.atan(rotY / 40.0F) * 40.0F);
/* 83 */     golem.rotationPitch = (-(float)Math.atan(rotY / 40.0F) * 20.0F);
/* 84 */     golem.rotationYawHead = golem.rotationYaw;
/* 85 */     golem.prevRotationYawHead = golem.rotationYaw;
/* 86 */     GL11.glTranslatef(0.0F, golem.yOffset, 0.0F);
/* 87 */     RenderManager.instance.playerViewY = 180.0F;
/* 88 */     RenderManager.instance.renderEntityWithPosYaw(golem, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
/* 89 */     golem.renderYawOffset = f2;
/* 90 */     golem.rotationYaw = f3;
/* 91 */     golem.rotationPitch = f4;
/* 92 */     golem.prevRotationYawHead = f5;
/* 93 */     golem.rotationYawHead = f6;
/* 94 */     GL11.glPopMatrix();
/* 95 */     GL11.glDisable(32826);
/* 96 */     OpenGlHelper.setActiveTexture(OpenGlHelper.lightmapTexUnit);
/* 97 */     GL11.glDisable(3553);
/* 98 */     OpenGlHelper.setActiveTexture(OpenGlHelper.defaultTexUnit);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */