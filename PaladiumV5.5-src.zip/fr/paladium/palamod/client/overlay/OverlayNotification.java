/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import fr.paladium.palamod.client.local.LocalValues;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ 
/*    */ 
/*    */ public class OverlayNotification
/*    */ {
/* 15 */   Minecraft mc = Minecraft.getMinecraft();
/* 16 */   FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/*    */   String lastItem;
/* 18 */   long lastItemTime = System.currentTimeMillis();
/*    */   double transparency;
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRender(RenderGameOverlayEvent.Pre e) {
/* 23 */     if (this.mc == null) {
/* 24 */       return;
/*    */     }
/*    */     
/* 27 */     if (e.type == RenderGameOverlayEvent.ElementType.HOTBAR) {
/* 28 */       ScaledResolution res = new ScaledResolution(this.mc, this.mc.displayWidth, this.mc.displayHeight);
/*    */       
/* 30 */       if (this.lastItemTime < System.currentTimeMillis()) {
/* 31 */         this.lastItem = LocalValues.getNotification(LocalValues.notification.size() - 1);
/* 32 */         if (this.lastItem != null) {
/* 33 */           this.lastItemTime = (System.currentTimeMillis() + 2000L);
/*    */         }
/*    */       }
/*    */       
/* 37 */       if (this.lastItem != null) {
/* 38 */         String display = this.lastItem;
/*    */         
/* 40 */         if (System.currentTimeMillis() > this.lastItemTime - 500L) {
/* 41 */           this.transparency = ((this.lastItemTime - System.currentTimeMillis()) / 500.0D);
/*    */         }
/* 43 */         else if (System.currentTimeMillis() < this.lastItemTime - 2000L + 500L)
/*    */         {
/* 45 */           this.transparency = ((System.currentTimeMillis() - (this.lastItemTime - 2000L)) / 500.0D);
/*    */         }
/*    */         else
/*    */         {
/* 49 */           this.transparency = 1.0D;
/*    */         }
/*    */         
/* 52 */         int alpha = (int)(this.transparency * 255.0D);
/* 53 */         if (alpha < 10) {
/* 54 */           alpha = 10;
/*    */         }
/* 56 */         this.fr.drawString(display, res
/* 57 */           .getScaledWidth() - this.fr.getStringWidth(display) - 5, 5, 16777215 + (alpha << 24));
/*    */       }
/*    */       else {
/* 60 */         this.transparency = 0.0D;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayNotification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */