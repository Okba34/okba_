/*     */ package fr.paladium.palamod.client.overlay;
/*     */ 
/*     */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*     */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCamera;
/*     */ import fr.paladium.palamod.tiles.TileEntityCamera;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class OverlayCamera extends Gui
/*     */ {
/*     */   private FontRenderer fontRender;
/*     */   private Minecraft mc;
/*  25 */   private int fire = 20;
/*     */   
/*     */   public OverlayCamera() {
/*  28 */     this.mc = Minecraft.getMinecraft();
/*  29 */     this.fontRender = this.mc.fontRenderer;
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*     */   public void onRender(RenderGameOverlayEvent.Pre event) {
/*  34 */     if (event.type != net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType.HOTBAR) {
/*  35 */       return;
/*     */     }
/*     */     
/*  38 */     ItemStack stack = this.mc.thePlayer.getHeldItem();
/*  39 */     if ((stack != null) && ((stack.getItem() instanceof fr.paladium.palamod.items.ItemCameraTablet)) && (this.mc.theWorld.isRemote) && (!this.mc.thePlayer.isSneaking())) {
/*  40 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  41 */       GL11.glDisable(2896);
/*  42 */       GL11.glEnable(3042);
/*  43 */       GL11.glBlendFunc(770, 771);
/*     */       
/*  45 */       NBTTagCompound compound = stack.getTagCompound();
/*  46 */       if (compound != null) {
/*  47 */         boolean flag = false;
/*  48 */         int x = 0;int y = 0;int z = 0;
/*     */         
/*  50 */         int index = compound.getInteger("Index");
/*     */         
/*  52 */         if (index == 0) {
/*  53 */           if (compound.getBoolean("cam1")) {
/*  54 */             x = compound.getInteger("cam1X");
/*  55 */             y = compound.getInteger("cam1Y");
/*  56 */             z = compound.getInteger("cam1Z");
/*  57 */             flag = false;
/*     */           }
/*     */           else {
/*  60 */             compound.setInteger("Index", 1);
/*  61 */             index = 1;
/*  62 */             flag = true;
/*     */           }
/*     */         }
/*     */         
/*  66 */         if (index == 1) {
/*  67 */           if (compound.getBoolean("cam2")) {
/*  68 */             x = compound.getInteger("cam2X");
/*  69 */             y = compound.getInteger("cam2Y");
/*  70 */             z = compound.getInteger("cam2Z");
/*  71 */             flag = false;
/*     */           }
/*     */           else {
/*  74 */             compound.setInteger("Index", 2);
/*  75 */             index = 2;
/*  76 */             flag = true;
/*     */           }
/*     */         }
/*     */         
/*  80 */         if (index == 2) {
/*  81 */           if (compound.getBoolean("cam3")) {
/*  82 */             x = compound.getInteger("cam3X");
/*  83 */             y = compound.getInteger("cam3Y");
/*  84 */             z = compound.getInteger("cam3Z");
/*  85 */             flag = false;
/*     */           }
/*     */           else {
/*  88 */             compound.setInteger("Index", 0);
/*  89 */             index = 0;
/*  90 */             flag = true;
/*     */           }
/*     */         }
/*     */         
/*  94 */         flag = (index != 0) && (index != 1) && (index != 2);
/*     */         
/*  96 */         if (flag) {
/*  97 */           EntityCamera.destroyCamera();
/*  98 */           return;
/*     */         }
/*     */         
/* 101 */         this.mc.thePlayer.worldObj.getChunkProvider().loadChunk(x, z);
/* 102 */         if ((this.mc.thePlayer.worldObj.getBlock(x, y, z) instanceof fr.paladium.palamod.paladium.block.BlockCamera)) {
/* 103 */           Calendar calendar = Calendar.getInstance();
/* 104 */           calendar.setTime(new Date());
/* 105 */           String hour = dbl(calendar.get(11)) + ":" + dbl(calendar.get(12)) + ":" + dbl(calendar.get(13));
/* 106 */           String date = dbl(calendar.get(5)) + "/" + dbl(calendar.get(2) + 1) + "/" + calendar.get(1);
/* 107 */           String time = hour + " - " + date;
/*     */           
/* 109 */           if (this.fire <= 10) {
/* 110 */             this.fontRender.drawString("Recording â€¢", 10, 10, 16711680);
/*     */           }
/*     */           else {
/* 113 */             this.fontRender.drawString("Recording", 10, 10, 16711680);
/*     */           }
/*     */           
/* 116 */           this.fire -= 1;
/* 117 */           if (this.fire <= 0) {
/* 118 */             this.fire = 20;
/*     */           }
/*     */           
/* 121 */           this.fontRender.drawString(time, event.resolution.getScaledWidth() - 10 - this.fontRender.getStringWidth(time), 10, 16711680);
/*     */           
/* 123 */           float rotation = 0.0F;
/*     */           
/* 125 */           switch (Minecraft.getMinecraft().theWorld.getBlockMetadata(x, y - 2, z)) {
/*     */           case 0: 
/* 127 */             rotation = 0.0F;
/* 128 */             break;
/*     */           case 1: 
/* 130 */             rotation = 0.0F;
/* 131 */             break;
/*     */           case 2: 
/* 133 */             rotation = 0.0F;
/* 134 */             break;
/*     */           case 3: 
/* 136 */             rotation = 0.0F;
/*     */           }
/*     */           
/* 139 */           net.minecraft.tileentity.TileEntity tile = Minecraft.getMinecraft().theWorld.getTileEntity(x, y, z);
/*     */           
/* 141 */           x = (int)(x + 1.5D);
/* 142 */           z = (int)(z + 1.5D);
/*     */           
/* 144 */           if ((tile == null) || (!(tile instanceof TileEntityCamera))) {
/* 145 */             EntityCamera.destroyCamera();
/*     */           }
/*     */           else {
/* 148 */             EntityCamera.createCamera(x, y, z, (TileEntityCamera)tile, 40.0F, rotation * 90.0F);
/*     */           }
/* 150 */           event.setCanceled(true);
/*     */           
/* 152 */           return;
/*     */         }
/* 154 */         switch (index) {
/*     */         case 0: 
/* 156 */           compound.setBoolean("cam1", false);
/* 157 */           break;
/*     */         
/*     */         case 1: 
/* 160 */           compound.setBoolean("cam2", false);
/* 161 */           break;
/*     */         
/*     */         case 2: 
/* 164 */           compound.setBoolean("cam3", false);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/* 169 */     EntityCamera.destroyCamera();
/*     */   }
/*     */   
/*     */   private String dbl(int a) {
/* 173 */     return "" + a;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */