/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.command.CommandHideBoss;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class OverlayMessageBoss
/*    */ {
/* 17 */   public static int currentTime = 0;
/*    */   public static long ms;
/*    */   public static int x;
/*    */   public static int z;
/* 21 */   FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/* 22 */   Minecraft mc = Minecraft.getMinecraft();
/*    */   
/*    */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*    */   public void display(RenderGameOverlayEvent.Pre event) {
/* 26 */     if (event.type != RenderGameOverlayEvent.ElementType.HOTBAR)
/* 27 */       return;
/* 28 */     if (currentTime == 0) {
/* 29 */       return;
/*    */     }
/* 31 */     if (System.currentTimeMillis() >= ms + 1000L) {
/* 32 */       currentTime -= 1;
/* 33 */       ms = System.currentTimeMillis();
/*    */     }
/*    */     
/* 36 */     if (CommandHideBoss.hide) {
/* 37 */       return;
/*    */     }
/* 39 */     GL11.glPushMatrix();
/* 40 */     this.fr.drawStringWithShadow("Prochain Boss dans ", 5, 5, 16777215);
/* 41 */     this.fr.drawStringWithShadow(getMinutes(currentTime) + ":" + getSeconds(currentTime), 109, 5, 1028394);
/* 42 */     this.fr.drawStringWithShadow("En x:" + x + " z:" + z, 5, 17, 16777215);
/* 43 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public static void startCd(int x, int z, int time) {
/* 47 */     currentTime = time;
/* 48 */     x = x;
/* 49 */     z = z;
/*    */   }
/*    */   
/*    */   public int getMinutes(int time) {
/* 53 */     return time / 60;
/*    */   }
/*    */   
/*    */   public int getSeconds(int time) {
/* 57 */     return time % 60;
/*    */   }
/*    */   
/*    */   public static void reset() {
/* 61 */     currentTime = 0;
/* 62 */     ms = 0L;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayMessageBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */