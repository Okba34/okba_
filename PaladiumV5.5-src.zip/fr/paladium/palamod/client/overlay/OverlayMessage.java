/*    */ package fr.paladium.palamod.client.overlay;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.EventPriority;
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.DisplayMessage;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ 
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class OverlayMessage
/*    */ {
/*    */   public static long time;
/* 22 */   public static ArrayList<DisplayMessage> messages = new ArrayList();
/* 23 */   public static Minecraft mc = Minecraft.getMinecraft();
/* 24 */   public static FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/*    */   
/*    */   public static void addMessageToQueue(DisplayMessage message) {
/* 27 */     messages.add(message);
/*    */   }
/*    */   
/*    */   public static void removeLast() {
/* 31 */     if (messages.size() < 1)
/* 32 */       return;
/* 33 */     messages.remove(messages.size() - 1);
/*    */   }
/*    */   
/*    */   public static DisplayMessage getLast() {
/* 37 */     if (messages.size() < 1)
/* 38 */       return null;
/* 39 */     return (DisplayMessage)messages.get(messages.size() - 1);
/*    */   }
/*    */   
/*    */   public static void reset() {
/* 43 */     time = 0L;
/* 44 */     removeLast();
/*    */   }
/*    */   
/*    */   @SubscribeEvent(priority=EventPriority.NORMAL)
/*    */   public void onMessage(RenderGameOverlayEvent.Pre event) {
/* 49 */     if (event.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS)
/* 50 */       return;
/* 51 */     if (messages.isEmpty()) {
/* 52 */       return;
/*    */     }
/* 54 */     DisplayMessage message = getLast();
/* 55 */     if (time == 0L) {
/* 56 */       time = System.currentTimeMillis() + message.time * 1000;
/*    */     }
/* 58 */     event.setCanceled(true);
/*    */     
/* 60 */     String title = message.title;
/* 61 */     String subTitle = message.subTitle;
/*    */     
/* 63 */     title = title.replaceAll("&", "§").replaceAll("_", " ");
/* 64 */     subTitle = subTitle.replaceAll("&", "§").replaceAll("_", " ");
/*    */     
/* 66 */     ScaledResolution scaledresolution = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
/* 67 */     int i = scaledresolution.getScaledWidth();
/* 68 */     int j = scaledresolution.getScaledHeight();
/*    */     
/* 70 */     int x1 = (i - fr.getStringWidth(title) * 3) / 2;
/* 71 */     int y1 = (j - 35) / 2;
/*    */     
/* 73 */     GL11.glPushMatrix();
/* 74 */     GL11.glTranslated(x1, y1, 0.0D);
/* 75 */     GL11.glScaled(3.0D, 3.0D, 3.0D);
/* 76 */     fr.drawStringWithShadow(title, 0, 0, 16777215);
/* 77 */     GL11.glPopMatrix();
/*    */     
/* 79 */     int x2 = (i - fr.getStringWidth(subTitle)) / 2;
/* 80 */     int y2 = (int)(j / 1.8D);
/*    */     
/* 82 */     GL11.glPushMatrix();
/* 83 */     GL11.glTranslated(x2, y2, 0.0D);
/* 84 */     fr.drawStringWithShadow(subTitle, 0, 0, 16777215);
/* 85 */     GL11.glPopMatrix();
/*    */     
/* 87 */     if (System.currentTimeMillis() >= time) {
/* 88 */       reset();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\overlay\OverlayMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */