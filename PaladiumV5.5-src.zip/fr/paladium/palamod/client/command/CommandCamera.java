/*    */ package fr.paladium.palamod.client.command;
/*    */ 
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandCamera
/*    */   extends CommandBase
/*    */ {
/*    */   public String getCommandName()
/*    */   {
/* 20 */     return "camera";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 25 */     return "/camera [create/list/switch/remove/back]";
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] args) {}
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\command\CommandCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */