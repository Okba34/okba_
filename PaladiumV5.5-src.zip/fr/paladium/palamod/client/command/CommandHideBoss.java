/*    */ package fr.paladium.palamod.client.command;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.util.ChatComponentTranslation;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class CommandHideBoss
/*    */   implements ICommand
/*    */ {
/* 14 */   public static boolean hide = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int compareTo(Object arg0)
/*    */   {
/* 22 */     return 0;
/*    */   }
/*    */   
/*    */   public String getCommandName()
/*    */   {
/* 27 */     return "hideboss";
/*    */   }
/*    */   
/*    */   public String getCommandUsage(ICommandSender sender)
/*    */   {
/* 32 */     return "/hideboss";
/*    */   }
/*    */   
/*    */   public List getCommandAliases()
/*    */   {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public void processCommand(ICommandSender sender, String[] command)
/*    */   {
/* 42 */     if (hide) {
/* 43 */       hide = false;
/* 44 */       sender.addChatMessage(new ChatComponentTranslation("Annonce de boss affichï¿½e !", new Object[0]));
/*    */     }
/*    */     else {
/* 47 */       hide = true;
/* 48 */       sender.addChatMessage(new ChatComponentTranslation("Annonce de boss cachï¿½e !", new Object[0]));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canCommandSenderUseCommand(ICommandSender sender)
/*    */   {
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public List addTabCompletionOptions(ICommandSender p_71516_1_, String[] p_71516_2_)
/*    */   {
/* 59 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isUsernameIndex(String[] p_82358_1_, int p_82358_2_)
/*    */   {
/* 64 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\command\CommandHideBoss.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */