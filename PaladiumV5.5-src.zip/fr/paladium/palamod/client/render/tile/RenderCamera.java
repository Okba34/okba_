/*    */ package fr.paladium.palamod.client.render.tile;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelSecurityCamera;
/*    */ import fr.paladium.palamod.tiles.TileEntityCamera;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.multiplayer.WorldClient;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderCamera extends TileEntitySpecialRenderer
/*    */ {
/* 14 */   public static ModelSecurityCamera model = new ModelSecurityCamera();
/* 15 */   public static ResourceLocation texture = new ResourceLocation("palamod", "textures/blocks/securityCamera.png");
/*    */   
/*    */   public void renderTileEntityAt(TileEntity tile, double x, double y, double z, float partialRenderTick)
/*    */   {
/* 19 */     renderTileEntityCameraAt((TileEntityCamera)tile, x, y, z, partialRenderTick);
/*    */   }
/*    */   
/*    */   private void renderTileEntityCameraAt(TileEntityCamera tile, double x, double y, double z, float partialRenderTick)
/*    */   {
/* 24 */     GL11.glPushMatrix();
/* 25 */     GL11.glTranslated(x + 0.5D, y + 1.5D, z + 0.5D);
/* 26 */     GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*    */     
/* 28 */     int rotation = 0;
/* 29 */     switch (Minecraft.getMinecraft().theWorld.getBlockMetadata(tile.xCoord, tile.yCoord, tile.zCoord))
/*    */     {
/*    */     case 0: 
/* 32 */       rotation = 0;
/* 33 */       break;
/*    */     case 1: 
/* 35 */       rotation = -2;
/* 36 */       break;
/*    */     case 2: 
/* 38 */       rotation = 4;
/* 39 */       break;
/*    */     case 3: 
/* 41 */       rotation = 2;
/*    */     }
/*    */     
/*    */     
/* 45 */     GL11.glRotatef(rotation * -45, 0.0F, 1.0F, 0.0F);
/*    */     
/* 47 */     float rot = tile.getRotation();
/*    */     
/* 49 */     model.setCameraRotation(rot);
/*    */     
/* 51 */     Minecraft.getMinecraft().renderEngine.bindTexture(texture);
/* 52 */     model.renderAll();
/* 53 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\tile\RenderCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */