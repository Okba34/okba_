/*     */ package fr.paladium.palamod.client.render.item;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.util.BowHelper;
/*     */ import fr.paladium.palamod.util.DisplayHelper;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.client.IItemRenderer;
/*     */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*     */ import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class ItemBowRenderer implements IItemRenderer
/*     */ {
/*  25 */   private final RenderItem renderItem = new RenderItem();
/*  26 */   private final ResourceLocation speed = new ResourceLocation("palamod:textures/items/upgrade_speed.png");
/*  27 */   private final ResourceLocation range = new ResourceLocation("palamod:textures/items/upgrade_range.png");
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean handleRenderType(ItemStack stack, IItemRenderer.ItemRenderType type)
/*     */   {
/*  33 */     return type == IItemRenderer.ItemRenderType.INVENTORY;
/*     */   }
/*     */   
/*     */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack stack, IItemRenderer.ItemRendererHelper helper)
/*     */   {
/*  38 */     return false;
/*     */   }
/*     */   
/*     */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack stack, Object... data)
/*     */   {
/*  43 */     TextureManager textureManager = Minecraft.getMinecraft().getTextureManager();
/*  44 */     ResourceLocation resource = textureManager.getResourceLocation(stack.getItemSpriteNumber());
/*     */     
/*  46 */     EntityPlayer player = Minecraft.getMinecraft().thePlayer;
/*  47 */     ItemStack usingItem = player.getItemInUse();
/*  48 */     int useRemaining = player.getItemInUseCount();
/*     */     
/*  50 */     ItemBow bow = (ItemBow)stack.getItem();
/*     */     
/*  52 */     IIcon icon = bow.getIcon(stack, 0);
/*  53 */     int pulling1 = 18;
/*  54 */     int pulling2 = 13;
/*  55 */     if (!BowHelper.canApply(stack, 1)) {
/*  56 */       pulling1 = 8;
/*  57 */       pulling2 = 7;
/*     */     }
/*  59 */     if ((usingItem != null) && (usingItem == stack)) {
/*  60 */       int charge = stack.getMaxItemUseDuration() - useRemaining;
/*  61 */       if (charge >= pulling1) {
/*  62 */         icon = bow.getItemIconForUseDuration(2);
/*  63 */       } else if (charge > pulling2) {
/*  64 */         icon = bow.getItemIconForUseDuration(1);
/*  65 */       } else if (charge > 0)
/*  66 */         icon = bow.getItemIconForUseDuration(0);
/*     */     }
/*  68 */     if (icon == null) {
/*  69 */       icon = ((TextureMap)textureManager.getTexture(resource)).getAtlasSprite("missingno");
/*     */     }
/*  71 */     GL11.glPushMatrix();
/*     */     
/*  73 */     textureManager.bindTexture(resource);
/*     */     
/*  75 */     GL11.glDisable(2896);
/*  76 */     GL11.glEnable(3008);
/*  77 */     GL11.glEnable(3042);
/*  78 */     OpenGlHelper.glBlendFunc(770, 771, 1, 0);
/*     */     
/*  80 */     this.renderItem.renderIcon(0, 0, icon, 16, 16);
/*     */     
/*  82 */     GL11.glDisable(3042);
/*  83 */     GL11.glDisable(3008);
/*     */     
/*  85 */     if (stack.hasEffect(0)) {
/*  86 */       this.renderItem.renderEffect(textureManager, 0, 0);
/*     */     }
/*  88 */     GL11.glPopMatrix();
/*     */     
/*  90 */     GL11.glPushMatrix();
/*     */     
/*  92 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  93 */     GL11.glDisable(2896);
/*  94 */     GL11.glEnable(3042);
/*  95 */     GL11.glBlendFunc(770, 771);
/*     */     
/*  97 */     if (!BowHelper.canApply(stack, 1)) {
/*  98 */       textureManager.bindTexture(this.speed);
/*  99 */       DisplayHelper.drawTexturedQuadFit(0.0D, 0.0D, 16.0D, 16.0D, 0.0D);
/*     */     }
/*     */     
/* 102 */     if (!BowHelper.canApply(stack, 0)) {
/* 103 */       textureManager.bindTexture(this.range);
/* 104 */       DisplayHelper.drawTexturedQuadFit(0.0D, 0.0D, 16.0D, 16.0D, 0.0D);
/*     */     }
/*     */     
/* 107 */     GL11.glDisable(3042);
/* 108 */     GL11.glDisable(3008);
/*     */     
/* 110 */     GL11.glPopMatrix();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\item\ItemBowRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */