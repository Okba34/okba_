/*    */ package fr.paladium.palamod.client.render.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelSecurityCamera;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderItemCamera implements net.minecraftforge.client.IItemRenderer
/*    */ {
/*    */   private ModelSecurityCamera model;
/*    */   private TileEntitySpecialRenderer render;
/*    */   private TileEntity entity;
/*    */   
/*    */   public RenderItemCamera(TileEntitySpecialRenderer render, TileEntity entity)
/*    */   {
/* 19 */     this.render = render;
/* 20 */     this.entity = entity;
/* 21 */     this.model = new ModelSecurityCamera();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper)
/*    */   {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data)
/*    */   {
/* 39 */     if (type == IItemRenderer.ItemRenderType.ENTITY)
/* 40 */       GL11.glTranslatef(-0.5F, 0.0F, -0.5F);
/* 41 */     if (type == IItemRenderer.ItemRenderType.INVENTORY)
/* 42 */       GL11.glTranslated(0.0D, -0.8D, 0.0D);
/* 43 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED)
/*    */     {
/* 45 */       GL11.glScaled(1.5D, 1.5D, 1.5D);
/* 46 */       GL11.glTranslated(0.6D, 0.0D, 0.8D);
/*    */     }
/* 48 */     GL11.glRotated(180.0D, 0.0D, 1.0D, 0.0D);
/* 49 */     this.render.renderTileEntityAt(this.entity, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\item\RenderItemCamera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */