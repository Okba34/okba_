/*    */ package fr.paladium.palamod.client.render.item;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelCompressor;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderItemCompressor implements net.minecraftforge.client.IItemRenderer
/*    */ {
/*    */   private ModelCompressor model;
/*    */   private TileEntitySpecialRenderer render;
/*    */   private TileEntity entity;
/*    */   
/*    */   public RenderItemCompressor(TileEntitySpecialRenderer render, TileEntity entity)
/*    */   {
/* 18 */     this.render = render;
/* 19 */     this.entity = entity;
/* 20 */     this.model = new ModelCompressor();
/*    */   }
/*    */   
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, net.minecraftforge.client.IItemRenderer.ItemRendererHelper helper)
/*    */   {
/* 31 */     return true;
/*    */   }
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data)
/*    */   {
/* 36 */     if (type == IItemRenderer.ItemRenderType.ENTITY)
/* 37 */       GL11.glTranslatef(-0.5F, 0.0F, -0.5F);
/* 38 */     if (type == IItemRenderer.ItemRenderType.INVENTORY)
/* 39 */       GL11.glTranslated(0.0D, -0.8D, 0.0D);
/* 40 */     if (type == IItemRenderer.ItemRenderType.EQUIPPED) {
/* 41 */       GL11.glScaled(1.5D, 1.5D, 1.5D);
/* 42 */       GL11.glTranslated(0.6D, 0.0D, 0.8D);
/*    */     }
/* 44 */     GL11.glRotated(180.0D, 0.0D, 1.0D, 0.0D);
/* 45 */     this.render.renderTileEntityAt(this.entity, 0.0D, 0.0D, 0.0D, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\item\RenderItemCompressor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */