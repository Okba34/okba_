/*    */ package fr.paladium.palamod.client.render.item;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.client.IItemRenderer;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRenderType;
/*    */ import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
/*    */ import net.minecraftforge.client.model.IModelCustom;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ItemRenderGuardianWand implements IItemRenderer
/*    */ {
/* 15 */   private ResourceLocation guardianWandTewture = new ResourceLocation("palamodtextures/models/GuardianWand.png");
/* 16 */   private ResourceLocation guardianWandModel = new ResourceLocation("palamod", "models/GuardianWand.obj");
/* 17 */   public IModelCustom model = net.minecraftforge.client.model.AdvancedModelLoader.loadModel(this.guardianWandModel);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean handleRenderType(ItemStack item, IItemRenderer.ItemRenderType type)
/*    */   {
/* 25 */     return true;
/*    */   }
/*    */   
/*    */   public boolean shouldUseRenderHelper(IItemRenderer.ItemRenderType type, ItemStack item, IItemRenderer.ItemRendererHelper helper)
/*    */   {
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public void renderItem(IItemRenderer.ItemRenderType type, ItemStack item, Object... data)
/*    */   {
/* 35 */     GL11.glPushMatrix();
/* 36 */     float scale = 1.2F;
/* 37 */     GL11.glScalef(scale, scale, scale);
/* 38 */     GL11.glRotatef(210.0F, 0.0F, 0.0F, 1.0F);
/* 39 */     GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 40 */     GL11.glRotatef(270.0F, 0.0F, 0.0F, 1.0F);
/* 41 */     GL11.glRotatef(0.0F, 0.0F, 1.0F, 0.0F);
/* 42 */     Minecraft.getMinecraft().renderEngine.bindTexture(this.guardianWandTewture);
/* 43 */     this.model.renderAll();
/* 44 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\item\ItemRenderGuardianWand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */