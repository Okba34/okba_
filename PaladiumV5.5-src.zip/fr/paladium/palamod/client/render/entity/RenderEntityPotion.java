/*    */ package fr.paladium.palamod.client.render.entity;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.entities.projectiles.EntitySplashPotion;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.projectile.EntityThrowable;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderEntityPotion extends Render
/*    */ {
/* 17 */   private static ResourceLocation nausea = new ResourceLocation("palamod:textures/entity/SicknessPotion.png");
/* 18 */   private static ResourceLocation web = new ResourceLocation("palamod:textures/entity/WebPotion.png");
/* 19 */   private float scale = 1.0F;
/*    */   
/*    */ 
/*    */   public void renderProjectile(EntityThrowable projectile, double x, double y, double z)
/*    */   {
/* 24 */     GL11.glPushMatrix();
/* 25 */     bindEntityTexture(projectile);
/* 26 */     GL11.glTranslatef((float)x, (float)y, (float)z);
/* 27 */     GL11.glEnable(32826);
/* 28 */     GL11.glScalef(this.scale * 0.5F, this.scale * 0.5F, this.scale * 0.5F);
/* 29 */     Tessellator tessellator = Tessellator.instance;
/* 30 */     float minU = 0.0F;
/* 31 */     float maxU = 1.0F;
/* 32 */     float minV = 0.0F;
/* 33 */     float maxV = 1.0F;
/* 34 */     float f7 = 1.0F;
/* 35 */     float f8 = 0.5F;
/* 36 */     float f9 = 0.25F;
/* 37 */     GL11.glRotatef(180.0F - this.renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
/* 38 */     GL11.glRotatef(-this.renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
/* 39 */     tessellator.startDrawingQuads();
/* 40 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/* 41 */     tessellator.addVertexWithUV(0.0F - f8, 0.0F - f9, 0.0D, minU, maxV);
/* 42 */     tessellator.addVertexWithUV(f7 - f8, 0.0F - f9, 0.0D, maxU, maxV);
/* 43 */     tessellator.addVertexWithUV(f7 - f8, 1.0F - f9, 0.0D, maxU, minV);
/* 44 */     tessellator.addVertexWithUV(0.0F - f8, 1.0F - f9, 0.0D, minU, minV);
/* 45 */     tessellator.draw();
/* 46 */     GL11.glDisable(32826);
/* 47 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9)
/*    */   {
/* 52 */     renderProjectile((EntityThrowable)par1Entity, par2, par4, par6);
/*    */   }
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity)
/*    */   {
/* 57 */     EntitySplashPotion e = (EntitySplashPotion)entity;
/* 58 */     switch (e.getDamageValue()) {
/*    */     case 0: 
/* 60 */       return nausea;
/*    */     case 1: 
/* 62 */       return web;
/*    */     }
/* 64 */     return nausea;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\entity\RenderEntityPotion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */