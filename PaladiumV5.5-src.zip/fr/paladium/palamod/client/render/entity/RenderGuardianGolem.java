/*     */ package fr.paladium.palamod.client.render.entity;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.client.model.ModelGuardianGolem;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import net.minecraft.client.model.ModelRenderer;
/*     */ import net.minecraft.client.renderer.ItemRenderer;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderLiving;
/*     */ import net.minecraft.client.renderer.entity.RenderManager;
/*     */ import net.minecraft.client.renderer.texture.TextureMap;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */ public class RenderGuardianGolem extends RenderLiving
/*     */ {
/*  22 */   private static final ResourceLocation ironGolemTextures = new ResourceLocation("palamod:textures/entity/PaladiumGuardian.png");
/*     */   private final ModelGuardianGolem ironGolemModel;
/*     */   
/*     */   public RenderGuardianGolem() {
/*  26 */     super(new ModelGuardianGolem(), 0.5F);
/*  27 */     this.ironGolemModel = ((ModelGuardianGolem)this.mainModel);
/*     */   }
/*     */   
/*     */   public void doRender(EntityGuardianGolem p_76986_1_, double p_76986_2_, double p_76986_4_, double p_76986_6_, float p_76986_8_, float p_76986_9_)
/*     */   {
/*  32 */     super.doRender(p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
/*     */   }
/*     */   
/*     */   protected ResourceLocation getEntityTexture(EntityGuardianGolem p_110775_1_) {
/*  36 */     return ironGolemTextures;
/*     */   }
/*     */   
/*     */   protected void rotateCorpse(EntityGuardianGolem p_77043_1_, float p_77043_2_, float p_77043_3_, float p_77043_4_) {
/*  40 */     super.rotateCorpse(p_77043_1_, p_77043_2_, p_77043_3_, p_77043_4_);
/*     */     
/*  42 */     if (p_77043_1_.limbSwingAmount >= 0.01D) {
/*  43 */       float f3 = 13.0F;
/*  44 */       float f4 = p_77043_1_.limbSwing - p_77043_1_.limbSwingAmount * (1.0F - p_77043_4_) + 6.0F;
/*  45 */       float f5 = (Math.abs(f4 % f3 - f3 * 0.5F) - f3 * 0.25F) / (f3 * 0.25F);
/*  46 */       GL11.glRotatef(6.5F * f5, 0.0F, 0.0F, 1.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   public void doRender(EntityLiving p_76986_1_, double p_76986_2_, double p_76986_4_, double p_76986_6_, float p_76986_8_, float p_76986_9_)
/*     */   {
/*  52 */     doRender((EntityGuardianGolem)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
/*     */   }
/*     */   
/*     */   protected void rotateCorpse(EntityLivingBase p_77043_1_, float p_77043_2_, float p_77043_3_, float p_77043_4_) {
/*  56 */     rotateCorpse((EntityGuardianGolem)p_77043_1_, p_77043_2_, p_77043_3_, p_77043_4_);
/*     */   }
/*     */   
/*     */   public void doRender(EntityLivingBase p_76986_1_, double p_76986_2_, double p_76986_4_, double p_76986_6_, float p_76986_8_, float p_76986_9_)
/*     */   {
/*  61 */     doRender(p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
/*     */   }
/*     */   
/*     */   protected ResourceLocation getEntityTexture(Entity p_110775_1_) {
/*  65 */     return getEntityTexture((EntityGuardianGolem)p_110775_1_);
/*     */   }
/*     */   
/*     */   public void doRender(Entity p_76986_1_, double p_76986_2_, double p_76986_4_, double p_76986_6_, float p_76986_8_, float p_76986_9_)
/*     */   {
/*  70 */     doRender((EntityGuardianGolem)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
/*     */   }
/*     */   
/*     */   protected void bindEntityTexture(Entity p_110777_1_)
/*     */   {
/*  75 */     super.bindEntityTexture(p_110777_1_);
/*     */   }
/*     */   
/*     */   protected void renderEquippedItems(EntityLivingBase p_77029_1_, float p_77029_2_)
/*     */   {
/*  80 */     renderEquippedItems((EntityGuardianGolem)p_77029_1_, p_77029_2_);
/*     */   }
/*     */   
/*     */   protected void renderEquippedItems(EntityGuardianGolem p_77029_1_, float p_77029_2_) {
/*  84 */     super.renderEquippedItems(p_77029_1_, p_77029_2_);
/*  85 */     ItemStack itemstack = p_77029_1_.getWeapon();
/*  86 */     if (itemstack == null)
/*  87 */       return;
/*  88 */     GL11.glEnable(32826);
/*  89 */     GL11.glPushMatrix();
/*  90 */     GL11.glRotatef(5.0F + 180.0F * this.ironGolemModel.ironGolemRightArm.rotateAngleX / 3.1415927F, 1.0F, 0.0F, 0.0F);
/*     */     
/*  92 */     GL11.glTranslatef(-0.6275F, 1.0F, -0.1F);
/*  93 */     GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*  94 */     GL11.glRotatef(39.0F, 0.0F, 1.0F, 0.0F);
/*  95 */     float f1 = 0.8F;
/*  96 */     GL11.glScalef(f1, -f1, f1);
/*  97 */     int i = p_77029_1_.getBrightnessForRender(p_77029_2_);
/*  98 */     int j = i % 65536;
/*  99 */     int k = i / 65536;
/* 100 */     OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, j / 1.0F, k / 1.0F);
/* 101 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 102 */     bindTexture(TextureMap.locationBlocksTexture);
/* 103 */     i = itemstack.getItem().getColorFromItemStack(itemstack, 0);
/* 104 */     float f4 = (i >> 16 & 0xFF) / 255.0F;
/* 105 */     float f5 = (i >> 8 & 0xFF) / 255.0F;
/* 106 */     float f2 = (i & 0xFF) / 255.0F;
/* 107 */     GL11.glColor4f(f4, f5, f2, 1.0F);
/* 108 */     this.renderManager.itemRenderer.renderItem(p_77029_1_, itemstack, 0);
/* 109 */     GL11.glPopMatrix();
/* 110 */     GL11.glDisable(32826);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\entity\RenderGuardianGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */