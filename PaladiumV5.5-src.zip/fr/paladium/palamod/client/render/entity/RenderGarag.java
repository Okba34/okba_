/*    */ package fr.paladium.palamod.client.render.entity;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.client.model.ModelGarag;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGarag;
/*    */ import net.minecraft.client.model.ModelBase;
/*    */ import net.minecraft.client.renderer.entity.RenderLiving;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ @SideOnly(Side.CLIENT)
/*    */ public class RenderGarag
/*    */   extends RenderLiving
/*    */ {
/* 19 */   private static final ResourceLocation EntityTexture = new ResourceLocation("palamod:textures/entity/Garag.png");
/*    */   protected ModelGarag model;
/*    */   
/*    */   public RenderGarag(ModelBase par1ModelBase, float par2)
/*    */   {
/* 24 */     super(par1ModelBase, par2);
/* 25 */     this.model = ((ModelGarag)this.mainModel);
/*    */   }
/*    */   
/*    */   protected void preRenderCallback(ModelGarag par1EntityLivingBase, float par2)
/*    */   {
/* 30 */     preRenderCallback(par1EntityLivingBase, par2);
/*    */   }
/*    */   
/*    */   public void renderGarag(EntityGarag var1, double var2, double var4, double var6, float var8, float var9) {
/* 34 */     super.doRender(var1, var2, var4, var6, var8, var9);
/*    */   }
/*    */   
/*    */   public void doRender(EntityLiving var1, double var2, double var4, double var6, float var8, float var9) {
/* 38 */     renderGarag((EntityGarag)var1, var2, var4, var6, var8, var9);
/*    */   }
/*    */   
/*    */   public void doRender(Entity var1, double var2, double var4, double var6, float var8, float var9) {
/* 42 */     renderGarag((EntityGarag)var1, var2, var4, var6, var8, var9);
/*    */   }
/*    */   
/*    */   protected void preRenderCallback(EntityLivingBase entity, float f) {
/* 46 */     GL11.glScalef(1.6F, 1.6F, 1.6F);
/*    */   }
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 50 */     return EntityTexture;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\entity\RenderGarag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */