/*     */ package fr.paladium.palamod.client.render.entity;
/*     */ 
/*     */ import fr.paladium.palamod.client.model.ModelCustomWither;
/*     */ import fr.paladium.palamod.entities.mobs.EntityCustomWither;
/*     */ import net.minecraft.client.renderer.entity.RenderLiving;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.boss.BossStatus;
/*     */ import net.minecraft.entity.boss.EntityWither;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class RenderCustomWither
/*     */   extends RenderLiving
/*     */ {
/*  18 */   private static final ResourceLocation invulnerableWitherTextures = new ResourceLocation("textures/entity/wither/wither_invulnerable.png");
/*     */   
/*  20 */   private static final ResourceLocation witherTextures = new ResourceLocation("textures/entity/wither/wither.png");
/*     */   private int field_82419_a;
/*     */   
/*     */   public RenderCustomWither() {
/*  24 */     super(new ModelCustomWither(), 1.0F);
/*  25 */     this.field_82419_a = ((ModelCustomWither)this.mainModel).func_82903_a();
/*     */   }
/*     */   
/*     */   protected ResourceLocation getEntityTexture(Entity entity)
/*     */   {
/*  30 */     return getEntityTexturew((EntityCustomWither)entity);
/*     */   }
/*     */   
/*     */   public void doRender(EntityCustomWither p_doRender_1_, double p_doRender_2_, double p_doRender_4_, double p_doRender_6_, float p_doRender_8_, float p_doRender_9_)
/*     */   {
/*  35 */     BossStatus.setBossStatus(p_doRender_1_, true);
/*  36 */     int var10 = ((ModelCustomWither)this.mainModel).func_82903_a();
/*  37 */     if (var10 != this.field_82419_a) {
/*  38 */       this.field_82419_a = var10;
/*  39 */       this.mainModel = new ModelCustomWither();
/*     */     }
/*     */     
/*  42 */     super.doRender(p_doRender_1_, p_doRender_2_, p_doRender_4_, p_doRender_6_, p_doRender_8_, p_doRender_9_);
/*     */   }
/*     */   
/*     */   protected ResourceLocation getEntityTexturew(EntityCustomWither wither) {
/*  46 */     int var2 = wither.func_82212_n();
/*  47 */     return (var2 > 0) && ((var2 > 80) || (var2 / 5 % 2 != 1)) ? invulnerableWitherTextures : witherTextures;
/*     */   }
/*     */   
/*     */   protected void preRenderCallback(EntityLivingBase p_77041_1_, float p_77041_2_)
/*     */   {
/*  52 */     preRenderCallback((EntityWither)p_77041_1_, p_77041_2_);
/*     */   }
/*     */   
/*     */   protected void preRenderCallback(EntityWither p_77041_1_, float p_77041_2_)
/*     */   {
/*  57 */     int i = p_77041_1_.func_82212_n();
/*     */     
/*  59 */     if (i > 0) {
/*  60 */       float f1 = 2.0F - (i - p_77041_2_) / 220.0F * 0.5F;
/*  61 */       GL11.glScalef(f1, f1, f1);
/*     */     } else {
/*  63 */       GL11.glScalef(2.0F, 2.0F, 2.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int shouldRenderPass(EntityCustomWither p_shouldRenderPass_1_, int p_shouldRenderPass_2_, float p_shouldRenderPass_3_)
/*     */   {
/*  69 */     if (p_shouldRenderPass_1_.isArmored()) {
/*  70 */       if (p_shouldRenderPass_1_.isInvisible()) {
/*  71 */         GL11.glDepthMask(false);
/*     */       } else {
/*  73 */         GL11.glDepthMask(true);
/*     */       }
/*     */       
/*  76 */       if (p_shouldRenderPass_2_ == 1) {
/*  77 */         float var4 = p_shouldRenderPass_1_.ticksExisted + p_shouldRenderPass_3_;
/*  78 */         bindTexture(invulnerableWitherTextures);
/*  79 */         GL11.glMatrixMode(5890);
/*  80 */         GL11.glLoadIdentity();
/*  81 */         float var5 = MathHelper.cos(var4 * 0.02F) * 3.0F;
/*  82 */         float var6 = var4 * 0.01F;
/*  83 */         GL11.glTranslatef(var5, var6, 0.0F);
/*  84 */         setRenderPassModel(this.mainModel);
/*  85 */         GL11.glMatrixMode(5888);
/*  86 */         GL11.glEnable(3042);
/*  87 */         float var7 = 0.5F;
/*  88 */         GL11.glColor4f(var7, var7, var7, 1.0F);
/*  89 */         GL11.glDisable(2896);
/*  90 */         GL11.glBlendFunc(1, 1);
/*  91 */         GL11.glTranslatef(0.0F, -0.01F, 0.0F);
/*  92 */         GL11.glScalef(1.1F, 1.1F, 1.1F);
/*  93 */         return 1;
/*     */       }
/*     */       
/*  96 */       if (p_shouldRenderPass_2_ == 2) {
/*  97 */         GL11.glMatrixMode(5890);
/*  98 */         GL11.glLoadIdentity();
/*  99 */         GL11.glMatrixMode(5888);
/* 100 */         GL11.glEnable(2896);
/* 101 */         GL11.glDisable(3042);
/*     */       }
/*     */     }
/*     */     
/* 105 */     return -1;
/*     */   }
/*     */   
/*     */   protected int inheritRenderPass(EntityCustomWither p_inheritRenderPass_1_, int p_inheritRenderPass_2_, float p_inheritRenderPass_3_)
/*     */   {
/* 110 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\entity\RenderCustomWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */