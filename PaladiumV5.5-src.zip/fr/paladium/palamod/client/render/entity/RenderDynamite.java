/*    */ package fr.paladium.palamod.client.render.entity;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.entitie.projectile.DynamiteEntity;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderDynamite
/*    */   extends Render
/*    */ {
/* 14 */   private static final ResourceLocation textureDynamite = new ResourceLocation("palamod:textures/entity/Dynamite.png");
/* 15 */   private static final ResourceLocation textureNinja = new ResourceLocation("palamod:textures/entity/DynamiteNinja.png");
/*    */   
/*    */   public static final int DEFAULT = 0;
/*    */   public static final int NINJA = 1;
/*    */   public int type;
/*    */   
/*    */   public RenderDynamite(int type)
/*    */   {
/* 23 */     this.type = type;
/*    */   }
/*    */   
/*    */   public void renderDynamite(DynamiteEntity e, double d, double d1, double d2, float f, float f1) {
/* 27 */     GL11.glPushMatrix();
/* 28 */     bindEntityTexture(e);
/*    */     
/* 30 */     GL11.glTranslatef((float)d, (float)d1, (float)d2);
/* 31 */     GL11.glRotatef(e.rotationYaw + 90.0F, 0.0F, 1.0F, 0.0F);
/* 32 */     GL11.glRotatef(e.prevRotationPitch + (e.rotationPitch - e.prevRotationPitch) * f1, 0.0F, 0.0F, 1.0F);
/*    */     
/* 34 */     Tessellator tessellator = Tessellator.instance;
/* 35 */     int i = 0;
/* 36 */     float f2 = 0.0F;
/* 37 */     float f3 = 0.5F;
/* 38 */     float f4 = (0 + i * 10) / 32.0F;
/* 39 */     float f5 = (5 + i * 10) / 32.0F;
/* 40 */     float f6 = 0.0F;
/* 41 */     float f7 = 0.15625F;
/* 42 */     float f8 = (5 + i * 10) / 32.0F;
/* 43 */     float f9 = (10 + i * 10) / 32.0F;
/* 44 */     float f10 = 0.05625F;
/* 45 */     GL11.glEnable(32826);
/* 46 */     float f11 = -f1;
/* 47 */     if (f11 > 0.0F) {
/* 48 */       float f12 = -MathHelper.sin(f11 * 3.0F) * f11;
/* 49 */       GL11.glRotatef(f12, 0.0F, 0.0F, 1.0F);
/*    */     }
/* 51 */     GL11.glRotatef(45.0F, 1.0F, 0.0F, 0.0F);
/* 52 */     GL11.glScalef(f10, f10, f10);
/* 53 */     GL11.glTranslatef(-4.0F, 0.0F, 0.0F);
/* 54 */     GL11.glNormal3f(f10, 0.0F, 0.0F);
/* 55 */     tessellator.startDrawingQuads();
/* 56 */     tessellator.addVertexWithUV(-7.0D, -2.0D, -2.0D, f6, f8);
/* 57 */     tessellator.addVertexWithUV(-7.0D, -2.0D, 2.0D, f7, f8);
/* 58 */     tessellator.addVertexWithUV(-7.0D, 2.0D, 2.0D, f7, f9);
/* 59 */     tessellator.addVertexWithUV(-7.0D, 2.0D, -2.0D, f6, f9);
/* 60 */     tessellator.draw();
/* 61 */     GL11.glNormal3f(-f10, 0.0F, 0.0F);
/* 62 */     tessellator.startDrawingQuads();
/* 63 */     tessellator.addVertexWithUV(-7.0D, 2.0D, -2.0D, f6, f8);
/* 64 */     tessellator.addVertexWithUV(-7.0D, 2.0D, 2.0D, f7, f8);
/* 65 */     tessellator.addVertexWithUV(-7.0D, -2.0D, 2.0D, f7, f9);
/* 66 */     tessellator.addVertexWithUV(-7.0D, -2.0D, -2.0D, f6, f9);
/* 67 */     tessellator.draw();
/* 68 */     for (int j = 0; j < 4; j++) {
/* 69 */       GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/* 70 */       GL11.glNormal3f(0.0F, 0.0F, f10);
/* 71 */       tessellator.startDrawingQuads();
/* 72 */       tessellator.addVertexWithUV(-8.0D, -2.0D, 0.0D, f2, f4);
/* 73 */       tessellator.addVertexWithUV(8.0D, -2.0D, 0.0D, f3, f4);
/* 74 */       tessellator.addVertexWithUV(8.0D, 2.0D, 0.0D, f3, f5);
/* 75 */       tessellator.addVertexWithUV(-8.0D, 2.0D, 0.0D, f2, f5);
/* 76 */       tessellator.draw();
/*    */     }
/*    */     
/* 79 */     GL11.glDisable(32826);
/* 80 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/* 83 */   public float pitch = 40.0F;
/*    */   
/*    */   public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
/* 86 */     renderDynamite((DynamiteEntity)entity, d, d1, d2, f, f1);
/*    */   }
/*    */   
/*    */   protected ResourceLocation getEntityTexture(Entity entity) {
/* 90 */     if (this.type == 1) {
/* 91 */       return textureNinja;
/*    */     }
/* 93 */     return textureDynamite;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\entity\RenderDynamite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */