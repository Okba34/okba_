/*    */ package fr.paladium.palamod.client.render.effects;
/*    */ 
/*    */ import net.minecraft.client.particle.EntityReddustFX;
/*    */ 
/*    */ public class FindiumOreFX extends EntityReddustFX
/*    */ {
/*    */   public FindiumOreFX(net.minecraft.world.World w, double x, double y, double z, float r, float g, float b) {
/*  8 */     super(w, x, y, z, 1.0F, 0.88F, 0.03F);
/*    */   }
/*    */   
/*    */   public int getBrightnessForRender(float par1)
/*    */   {
/* 13 */     int j1 = super.getBrightnessForRender(par1);
/* 14 */     j1 = Math.max(j1 >> 20, j1 >> 4);
/* 15 */     j1 += 3;
/*    */     
/* 17 */     if (j1 > 15) {
/* 18 */       j1 = 15;
/*    */     }
/*    */     
/* 21 */     return j1 << 20 | j1 << 4;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\effects\FindiumOreFX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */