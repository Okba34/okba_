/*     */ package fr.paladium.palamod.client.render.block;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.proxy.ClientProxy;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(cpw.mods.fml.relauncher.Side.CLIENT)
/*     */ public class RenderBlockSpike implements ISimpleBlockRenderingHandler
/*     */ {
/*     */   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer)
/*     */   {
/*  19 */     GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/*  20 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/*  21 */     renderSpikeBlock(Minecraft.getMinecraft().theWorld, 0, 0, 0, 1, 0, block, renderer, -1);
/*  22 */     GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/*  23 */     GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/*     */   }
/*     */   
/*     */   public boolean renderSpikeBlock(IBlockAccess world, int x, int y, int z, int side, int type, Block block, RenderBlocks renderer, int brightness)
/*     */   {
/*  28 */     float ax = 0.0F;
/*  29 */     float ay = 0.0F;
/*  30 */     float az = 0.0F;
/*  31 */     float bx = 1.0F;
/*  32 */     float by = 0.0F;
/*  33 */     float bz = 0.0F;
/*  34 */     float cx = 0.0F;
/*  35 */     float cy = 0.0F;
/*  36 */     float cz = 1.0F;
/*  37 */     float dx = 1.0F;
/*  38 */     float dy = 0.0F;
/*  39 */     float dz = 1.0F;
/*  40 */     float ex = 0.0F;
/*  41 */     float ey = 1.0F;
/*  42 */     float ez = 0.0F;
/*  43 */     float fx = 1.0F;
/*  44 */     float fy = 1.0F;
/*  45 */     float fz = 0.0F;
/*  46 */     float gx = 0.0F;
/*  47 */     float gy = 1.0F;
/*  48 */     float gz = 1.0F;
/*  49 */     float hx = 1.0F;
/*  50 */     float hy = 1.0F;
/*  51 */     float hz = 1.0F;
/*  52 */     switch (side) {
/*     */     case 0: 
/*  54 */       ax = az = bx = bz = cx = cz = dx = dz = 0.5F;
/*  55 */       break;
/*     */     case 1: 
/*  57 */       ex = ez = fx = fz = gx = gz = hx = hz = 0.5F;
/*  58 */       break;
/*     */     case 2: 
/*  60 */       ay = by = ey = fy = ax = bx = ex = fx = 0.5F;
/*  61 */       break;
/*     */     case 3: 
/*  63 */       cy = dy = gy = hy = cx = dx = gx = hx = 0.5F;
/*  64 */       break;
/*     */     case 4: 
/*  66 */       ay = cy = ey = gy = az = cz = ez = gz = 0.5F;
/*  67 */       break;
/*     */     case 5: 
/*  69 */       by = dy = fy = hy = bz = dz = fz = hz = 0.5F;
/*  70 */       break;
/*     */     default: 
/*  72 */       return false;
/*     */     }
/*  74 */     IIcon texture = block.getIcon(side, type);
/*  75 */     if (renderer.hasOverrideBlockTexture()) {
/*  76 */       texture = renderer.overrideBlockTexture;
/*     */     }
/*  78 */     Tessellator tessellator = Tessellator.instance;
/*  79 */     if (brightness >= 0) {
/*  80 */       tessellator.setBrightness(brightness);
/*     */     }
/*  82 */     boolean inventory = brightness < 0;
/*  83 */     if (brightness >= 0) {
/*  84 */       tessellator.setColorOpaque_F(0.5F, 0.5F, 0.5F);
/*     */     }
/*  86 */     if (!renderer.hasOverrideBlockTexture()) {
/*  87 */       texture = block.getIcon(0, side + type * 6);
/*     */     }
/*  89 */     if (inventory) {
/*  90 */       tessellator.startDrawingQuads();
/*  91 */       tessellator.setNormal(0.0F, -1.0F, 0.0F);
/*     */     }
/*  93 */     if (side != 0) {
/*  94 */       float[] u = { ax, bx, dx, cx };
/*  95 */       float[] v = { az, bz, dz, cz };
/*  96 */       int rotation = calcRotation(0, side);
/*  97 */       tessellator.addVertexWithUV(x + ax, y + ay, z + az, getU(0, texture, rotation, u, v), 
/*  98 */         getV(0, texture, rotation, u, v));
/*  99 */       tessellator.addVertexWithUV(x + bx, y + by, z + bz, getU(1, texture, rotation, u, v), 
/* 100 */         getV(1, texture, rotation, u, v));
/* 101 */       tessellator.addVertexWithUV(x + dx, y + dy, z + dz, getU(2, texture, rotation, u, v), 
/* 102 */         getV(2, texture, rotation, u, v));
/* 103 */       tessellator.addVertexWithUV(x + cx, y + cy, z + cz, getU(3, texture, rotation, u, v), 
/* 104 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 106 */     if (inventory) {
/* 107 */       tessellator.draw();
/*     */     }
/* 109 */     if (inventory) {
/* 110 */       tessellator.startDrawingQuads();
/* 111 */       tessellator.setNormal(0.0F, 1.0F, 0.0F);
/*     */     }
/* 113 */     if (brightness >= 0) {
/* 114 */       tessellator.setColorOpaque_F(1.0F, 1.0F, 1.0F);
/*     */     }
/* 116 */     if (!renderer.hasOverrideBlockTexture()) {
/* 117 */       texture = block.getIcon(1, side + type * 6);
/*     */     }
/* 119 */     if (side != 1) {
/* 120 */       float[] u = { ex, gx, hx, fx };
/* 121 */       float[] v = { ez, gz, hz, fz };
/* 122 */       int rotation = calcRotation(1, side);
/* 123 */       tessellator.addVertexWithUV(x + ex, y + ey, z + ez, getU(0, texture, rotation, u, v), 
/* 124 */         getV(0, texture, rotation, u, v));
/* 125 */       tessellator.addVertexWithUV(x + gx, y + gy, z + gz, getU(1, texture, rotation, u, v), 
/* 126 */         getV(1, texture, rotation, u, v));
/* 127 */       tessellator.addVertexWithUV(x + hx, y + hy, z + hz, getU(2, texture, rotation, u, v), 
/* 128 */         getV(2, texture, rotation, u, v));
/* 129 */       tessellator.addVertexWithUV(x + fx, y + fy, z + fz, getU(3, texture, rotation, u, v), 
/* 130 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 132 */     if (inventory) {
/* 133 */       tessellator.draw();
/*     */     }
/* 135 */     if (brightness >= 0) {
/* 136 */       if (side == 0) {
/* 137 */         tessellator.setColorOpaque_F(0.65F, 0.65F, 0.65F);
/* 138 */       } else if (side == 1) {
/* 139 */         tessellator.setColorOpaque_F(0.9F, 0.9F, 0.9F);
/*     */       } else {
/* 141 */         tessellator.setColorOpaque_F(0.8F, 0.8F, 0.8F);
/*     */       }
/*     */     }
/* 144 */     if (!renderer.hasOverrideBlockTexture()) {
/* 145 */       texture = block.getIcon(2, side + type * 6);
/*     */     }
/* 147 */     if (inventory) {
/* 148 */       tessellator.startDrawingQuads();
/* 149 */       tessellator.setNormal(0.0F, 0.445F, 0.894F);
/*     */     }
/* 151 */     if (side != 2) {
/* 152 */       float[] u = { 1.0F - ax, 1.0F - ex, 1.0F - fx, 1.0F - bx };
/* 153 */       float[] v = { 1.0F - ay, 1.0F - ey, 1.0F - fy, 1.0F - by };
/* 154 */       int rotation = calcRotation(2, side);
/* 155 */       tessellator.addVertexWithUV(x + ax, y + ay, z + az, getU(0, texture, rotation, u, v), 
/* 156 */         getV(0, texture, rotation, u, v));
/* 157 */       tessellator.addVertexWithUV(x + ex, y + ey, z + ez, getU(1, texture, rotation, u, v), 
/* 158 */         getV(1, texture, rotation, u, v));
/* 159 */       tessellator.addVertexWithUV(x + fx, y + fy, z + fz, getU(2, texture, rotation, u, v), 
/* 160 */         getV(2, texture, rotation, u, v));
/* 161 */       tessellator.addVertexWithUV(x + bx, y + by, z + bz, getU(3, texture, rotation, u, v), 
/* 162 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 164 */     if (inventory) {
/* 165 */       tessellator.draw();
/*     */     }
/* 167 */     if (brightness >= 0) {
/* 168 */       if (side == 0) {
/* 169 */         tessellator.setColorOpaque_F(0.65F, 0.65F, 0.65F);
/* 170 */       } else if (side == 1) {
/* 171 */         tessellator.setColorOpaque_F(0.9F, 0.9F, 0.9F);
/*     */       } else {
/* 173 */         tessellator.setColorOpaque_F(0.8F, 0.8F, 0.8F);
/*     */       }
/*     */     }
/* 176 */     if (!renderer.hasOverrideBlockTexture()) {
/* 177 */       texture = block.getIcon(3, side + type * 6);
/*     */     }
/* 179 */     if (inventory) {
/* 180 */       tessellator.startDrawingQuads();
/* 181 */       tessellator.setNormal(0.0F, 0.445F, -0.894F);
/*     */     }
/* 183 */     if (side != 3) {
/* 184 */       float[] u = { dx, hx, gx, cx };
/* 185 */       float[] v = { 1.0F - dy, 1.0F - hy, 1.0F - gy, 1.0F - cy };
/* 186 */       int rotation = calcRotation(3, side);
/* 187 */       tessellator.addVertexWithUV(x + dx, y + dy, z + dz, getU(0, texture, rotation, u, v), 
/* 188 */         getV(0, texture, rotation, u, v));
/* 189 */       tessellator.addVertexWithUV(x + hx, y + hy, z + hz, getU(1, texture, rotation, u, v), 
/* 190 */         getV(1, texture, rotation, u, v));
/* 191 */       tessellator.addVertexWithUV(x + gx, y + gy, z + gz, getU(2, texture, rotation, u, v), 
/* 192 */         getV(2, texture, rotation, u, v));
/* 193 */       tessellator.addVertexWithUV(x + cx, y + cy, z + cz, getU(3, texture, rotation, u, v), 
/* 194 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 196 */     if (inventory) {
/* 197 */       tessellator.draw();
/*     */     }
/* 199 */     if (brightness >= 0) {
/* 200 */       if (side == 0) {
/* 201 */         tessellator.setColorOpaque_F(0.55F, 0.55F, 0.55F);
/* 202 */       } else if (side == 1) {
/* 203 */         tessellator.setColorOpaque_F(0.7F, 0.7F, 0.7F);
/*     */       } else {
/* 205 */         tessellator.setColorOpaque_F(0.6F, 0.6F, 0.6F);
/*     */       }
/*     */     }
/* 208 */     if (!renderer.hasOverrideBlockTexture()) {
/* 209 */       texture = block.getIcon(4, side + type * 6);
/*     */     }
/* 211 */     if (inventory) {
/* 212 */       tessellator.startDrawingQuads();
/* 213 */       tessellator.setNormal(0.894F, 0.445F, 0.0F);
/*     */     }
/* 215 */     if (side != 4) {
/* 216 */       float[] u = { cz, gz, ez, az };
/* 217 */       float[] v = { 1.0F - cy, 1.0F - gy, 1.0F - ey, 1.0F - ay };
/* 218 */       int rotation = calcRotation(4, side);
/* 219 */       tessellator.addVertexWithUV(x + cx, y + cy, z + cz, getU(0, texture, rotation, u, v), 
/* 220 */         getV(0, texture, rotation, u, v));
/* 221 */       tessellator.addVertexWithUV(x + gx, y + gy, z + gz, getU(1, texture, rotation, u, v), 
/* 222 */         getV(1, texture, rotation, u, v));
/* 223 */       tessellator.addVertexWithUV(x + ex, y + ey, z + ez, getU(2, texture, rotation, u, v), 
/* 224 */         getV(2, texture, rotation, u, v));
/* 225 */       tessellator.addVertexWithUV(x + ax, y + ay, z + az, getU(3, texture, rotation, u, v), 
/* 226 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 228 */     if (inventory) {
/* 229 */       tessellator.draw();
/*     */     }
/* 231 */     if (brightness >= 0) {
/* 232 */       if (side == 0) {
/* 233 */         tessellator.setColorOpaque_F(0.55F, 0.55F, 0.55F);
/* 234 */       } else if (side == 1) {
/* 235 */         tessellator.setColorOpaque_F(0.7F, 0.7F, 0.7F);
/*     */       } else {
/* 237 */         tessellator.setColorOpaque_F(0.6F, 0.6F, 0.6F);
/*     */       }
/*     */     }
/* 240 */     if (!renderer.hasOverrideBlockTexture()) {
/* 241 */       texture = block.getIcon(5, side + type * 6);
/*     */     }
/* 243 */     if (inventory) {
/* 244 */       tessellator.startDrawingQuads();
/* 245 */       tessellator.setNormal(-0.894F, 0.445F, 0.0F);
/*     */     }
/* 247 */     if (side != 5) {
/* 248 */       float[] u = { 1.0F - bz, 1.0F - fz, 1.0F - hz, 1.0F - dz };
/* 249 */       float[] v = { 1.0F - by, 1.0F - fy, 1.0F - hy, 1.0F - dy };
/* 250 */       int rotation = calcRotation(5, side);
/* 251 */       tessellator.addVertexWithUV(x + bx, y + by, z + bz, getU(0, texture, rotation, u, v), 
/* 252 */         getV(0, texture, rotation, u, v));
/* 253 */       tessellator.addVertexWithUV(x + fx, y + fy, z + fz, getU(1, texture, rotation, u, v), 
/* 254 */         getV(1, texture, rotation, u, v));
/* 255 */       tessellator.addVertexWithUV(x + hx, y + hy, z + hz, getU(2, texture, rotation, u, v), 
/* 256 */         getV(2, texture, rotation, u, v));
/* 257 */       tessellator.addVertexWithUV(x + dx, y + dy, z + dz, getU(3, texture, rotation, u, v), 
/* 258 */         getV(3, texture, rotation, u, v));
/*     */     }
/* 260 */     if (inventory) {
/* 261 */       tessellator.draw();
/*     */     }
/* 263 */     return true;
/*     */   }
/*     */   
/*     */   public float getU(int i, IIcon texture, int rotation, float[] u, float[] v) {
/* 267 */     switch (rotation % 4) {
/*     */     case 0: 
/* 269 */       return texture.getInterpolatedU(u[(i % 4)] * 16.0F);
/*     */     case 1: 
/* 271 */       return texture.getInterpolatedU(v[(i % 4)] * 16.0F);
/*     */     case 2: 
/* 273 */       return texture.getInterpolatedU(16.0F - u[(i % 4)] * 16.0F);
/*     */     case 3: 
/* 275 */       return texture.getInterpolatedU(16.0F - v[(i % 4)] * 16.0F);
/*     */     }
/* 277 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float getV(int i, IIcon texture, int rotation, float[] u, float[] v) {
/* 281 */     switch (rotation % 4) {
/*     */     case 0: 
/* 283 */       return texture.getInterpolatedV(v[(i % 4)] * 16.0F);
/*     */     case 1: 
/* 285 */       return texture.getInterpolatedV(16.0F - u[(i % 4)] * 16.0F);
/*     */     case 2: 
/* 287 */       return texture.getInterpolatedV(16.0F - v[(i % 4)] * 16.0F);
/*     */     case 3: 
/* 289 */       return texture.getInterpolatedV(u[(i % 4)] * 16.0F);
/*     */     }
/* 291 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public int calcRotation(int side, int direction) {
/* 295 */     if (side == direction) {
/* 296 */       return 0;
/*     */     }
/* 298 */     if (side == net.minecraft.util.Facing.oppositeSide[direction]) {
/* 299 */       return 0;
/*     */     }
/* 301 */     if (direction == 1) {
/* 302 */       return 0;
/*     */     }
/* 304 */     if (direction == 0) {
/* 305 */       return 2;
/*     */     }
/* 307 */     if ((side == 0) || (side == 1)) {
/* 308 */       return new int[] { 0, 2, 3, 1 }[(direction - 2)];
/*     */     }
/* 310 */     return 1 + (side + direction + direction / 2) % 2 * 2;
/*     */   }
/*     */   
/*     */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer)
/*     */   {
/* 315 */     int side = world.getBlockMetadata(x, y, z) % 6;
/* 316 */     int type = (world.getBlockMetadata(x, y, z) - side) / 6;
/* 317 */     int brightness = block.getMixedBrightnessForBlock(world, x, y, z);
/* 318 */     return renderSpikeBlock(world, x, y, z, side, type, block, renderer, brightness);
/*     */   }
/*     */   
/*     */   public boolean shouldRender3DInInventory(int modelId) {
/* 322 */     return true;
/*     */   }
/*     */   
/*     */   public int getRenderId()
/*     */   {
/* 327 */     return ClientProxy.renderBlockSpikeId;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\block\RenderBlockSpike.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */