/*     */ package fr.paladium.palamod.client.render.block;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.model.ModelSkeletonHead;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class RenderSkullUpgrade
/*     */   extends TileEntitySpecialRenderer
/*     */   implements ISimpleBlockRenderingHandler
/*     */ {
/*  19 */   private static final ResourceLocation wither = new ResourceLocation("textures/entity/skeleton/wither_skeleton.png");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ModelSkeletonHead modelskeletonhead;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RenderSkullUpgrade()
/*     */   {
/*  31 */     this.modelskeletonhead = new ModelSkeletonHead();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void renderTileEntityAt(TileEntity tileEntity, double v, double v1, double v2, float v3) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void renderInventoryBlock(Block block, int i, int i1, RenderBlocks renderBlocks) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean renderWorldBlock(IBlockAccess iBlockAccess, int i, int i1, int i2, Block block, int i3, RenderBlocks renderBlocks)
/*     */   {
/*     */     try
/*     */     {
/*  74 */       bindTexture(wither);
/*  75 */       float rotation = iBlockAccess.getBlockMetadata(i, i1, i2) * 45.0F;
/*  76 */       GL11.glTranslatef(i + 0.5F, i1, i2 + 0.5F);
/*  77 */       GL11.glEnable(32826);
/*  78 */       GL11.glScalef(-1.0F, -1.0F, 1.0F);
/*  79 */       GL11.glEnable(3008);
/*     */       try {
/*  81 */         this.modelskeletonhead.render((Entity)null, 0.0F, 0.0F, 0.0F, rotation, 0.0F, 0.0625F);
/*     */       } catch (Exception e) {
/*  83 */         e.printStackTrace();
/*     */       }
/*  85 */       GL11.glPopMatrix();
/*  86 */       return true;
/*     */     } catch (Exception e) {
/*  88 */       e.printStackTrace();
/*     */     }
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   public boolean shouldRender3DInInventory(int i)
/*     */   {
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   public int getRenderId()
/*     */   {
/* 100 */     return 45;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\block\RenderSkullUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */