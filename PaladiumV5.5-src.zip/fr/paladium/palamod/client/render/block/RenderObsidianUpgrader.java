/*     */ package fr.paladium.palamod.client.render.block;
/*     */ 
/*     */ import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
/*     */ import fr.paladium.palamod.proxy.ClientProxy;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.renderer.RenderBlocks;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class RenderObsidianUpgrader
/*     */   implements ISimpleBlockRenderingHandler
/*     */ {
/*     */   public void renderInventoryBlock(Block block, int metadata, int modelId, RenderBlocks renderer)
/*     */   {
/*  20 */     renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/*  21 */     renderInInventory(Tessellator.instance, renderer, block, metadata);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer)
/*     */   {
/*  27 */     TileEntity tile = world.getTileEntity(x, y, z);
/*  28 */     if ((tile instanceof TileEntityObsidianUpgrader))
/*     */     {
/*  30 */       TileEntityObsidianUpgrader te = (TileEntityObsidianUpgrader)tile;
/*  31 */       if (te.hasMaster())
/*     */       {
/*  33 */         TileEntityObsidianUpgrader master = (TileEntityObsidianUpgrader)world.getTileEntity(te.getMasterX(), te.getMasterY(), te.getMasterZ());
/*  34 */         boolean flag = isSame(x + 1, y, z, te);boolean flag1 = isSame(x, y, z + 1, te);boolean flag2 = isSame(x - 1, y, z, te);boolean flag3 = isSame(x, y, z - 1, te);
/*  35 */         if ((flag) && (flag1))
/*     */         {
/*  37 */           renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 0.10000000149011612D, 1.0D);
/*  38 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  40 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.0D, 0.10000000149011612D, 1.0D, 1.0D);
/*  41 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  43 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.0D, 1.0D, 1.0D, 0.10000000149011612D);
/*  44 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  46 */           renderer.setRenderBounds(0.10000000149011612D, 0.10000000149011612D, 0.10000000149011612D, 1.0D, master.getObsidian() / 64.0F, 1.0D);
/*  47 */           renderer.renderStandardBlock(block, x, y, z);
/*  48 */           return true;
/*     */         }
/*  50 */         if ((flag2) && (flag1))
/*     */         {
/*  52 */           renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 0.10000000149011612D, 1.0D);
/*  53 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  55 */           renderer.setRenderBounds(0.8999999761581421D, 0.10000000149011612D, 0.0D, 1.0D, 1.0D, 1.0D);
/*  56 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  58 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.0D, 1.0D, 1.0D, 0.10000000149011612D);
/*  59 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  61 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.10000000149011612D, 0.8999999761581421D, master.getObsidian() / 64.0F, 1.0D);
/*  62 */           renderer.renderStandardBlock(block, x, y, z);
/*  63 */           return true;
/*     */         }
/*  65 */         if ((flag) && (flag3))
/*     */         {
/*  67 */           renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 0.10000000149011612D, 1.0D);
/*  68 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  70 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.0D, 0.10000000149011612D, 1.0D, 1.0D);
/*  71 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  73 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.8999999761581421D, 1.0D, 1.0D, 1.0D);
/*  74 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  76 */           renderer.setRenderBounds(0.10000000149011612D, 0.10000000149011612D, 0.0D, 1.0D, master.getObsidian() / 64.0F, 0.8999999761581421D);
/*  77 */           renderer.renderStandardBlock(block, x, y, z);
/*  78 */           return true;
/*     */         }
/*  80 */         if ((flag2) && (flag3))
/*     */         {
/*  82 */           renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 0.10000000149011612D, 1.0D);
/*  83 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  85 */           renderer.setRenderBounds(0.8999999761581421D, 0.10000000149011612D, 0.0D, 1.0D, 1.0D, 1.0D);
/*  86 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  88 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.8999999761581421D, 1.0D, 1.0D, 1.0D);
/*  89 */           renderer.renderStandardBlock(block, x, y, z);
/*     */           
/*  91 */           renderer.setRenderBounds(0.0D, 0.10000000149011612D, 0.0D, 0.8999999761581421D, master.getObsidian() / 64.0F, 0.8999999761581421D);
/*  92 */           renderer.renderStandardBlock(block, x, y, z);
/*  93 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*  97 */     renderer.setRenderBounds(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/*  98 */     renderer.renderStandardBlock(block, x, y, z);
/*  99 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean shouldRender3DInInventory(int modelId)
/*     */   {
/* 105 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRenderId()
/*     */   {
/* 111 */     return ClientProxy.renderObsidianUpgraderId;
/*     */   }
/*     */   
/*     */   private void renderInInventory(Tessellator tessellator, RenderBlocks renderer, Block block, int metadata)
/*     */   {
/* 116 */     GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
/* 117 */     tessellator.startDrawingQuads();
/* 118 */     tessellator.setNormal(0.0F, -1.0F, 0.0F);
/* 119 */     renderer.renderFaceYNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(0, metadata));
/* 120 */     tessellator.draw();
/* 121 */     tessellator.startDrawingQuads();
/* 122 */     tessellator.setNormal(0.0F, 1.0F, 0.0F);
/* 123 */     renderer.renderFaceYPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(1, metadata));
/* 124 */     tessellator.draw();
/* 125 */     tessellator.startDrawingQuads();
/* 126 */     tessellator.setNormal(0.0F, 0.0F, -1.0F);
/* 127 */     renderer.renderFaceZNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(2, metadata));
/* 128 */     tessellator.draw();
/* 129 */     tessellator.startDrawingQuads();
/* 130 */     tessellator.setNormal(0.0F, 0.0F, 1.0F);
/* 131 */     renderer.renderFaceZPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(3, metadata));
/* 132 */     tessellator.draw();
/* 133 */     tessellator.startDrawingQuads();
/* 134 */     tessellator.setNormal(-1.0F, 0.0F, 0.0F);
/* 135 */     renderer.renderFaceXNeg(block, 0.0D, 0.0D, 0.0D, block.getIcon(4, metadata));
/* 136 */     tessellator.draw();
/* 137 */     tessellator.startDrawingQuads();
/* 138 */     tessellator.setNormal(1.0F, 0.0F, 0.0F);
/* 139 */     renderer.renderFaceXPos(block, 0.0D, 0.0D, 0.0D, block.getIcon(5, metadata));
/* 140 */     tessellator.draw();
/* 141 */     GL11.glTranslatef(0.5F, 0.5F, 0.5F);
/*     */   }
/*     */   
/*     */   private boolean isSame(int x, int y, int z, TileEntityObsidianUpgrader te)
/*     */   {
/* 146 */     World world = te.getWorldObj();
/* 147 */     TileEntity tile = world.getTileEntity(x, y, z);
/* 148 */     if ((tile instanceof TileEntityObsidianUpgrader))
/*     */     {
/* 150 */       TileEntityObsidianUpgrader te2 = (TileEntityObsidianUpgrader)tile;
/* 151 */       return (te.getMasterX() == te2.getMasterX()) && (te.getMasterY() == te2.getMasterY()) && (te.getMasterZ() == te2.getMasterZ());
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\block\RenderObsidianUpgrader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */