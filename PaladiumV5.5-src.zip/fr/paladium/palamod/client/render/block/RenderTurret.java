/*    */ package fr.paladium.palamod.client.render.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.model.ModelTurret;
/*    */ import fr.paladium.palamod.tiles.TileEntityTurret;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class RenderTurret
/*    */   extends TileEntitySpecialRenderer
/*    */ {
/*    */   private final ModelTurret model;
/*    */   private final ResourceLocation textureActivate;
/*    */   private final ResourceLocation textureDesactivate;
/*    */   
/*    */   public RenderTurret()
/*    */   {
/* 19 */     this.model = new ModelTurret();
/* 20 */     this.textureActivate = new ResourceLocation("palamod:textures/models/Turret.png");
/* 21 */     this.textureDesactivate = new ResourceLocation("palamod:textures/models/TurretDesactivate.png");
/*    */   }
/*    */   
/*    */ 
/*    */   public void renderTileEntityAt(TileEntity tile, double x, double y, double z, float f)
/*    */   {
/* 27 */     GL11.glPushMatrix();
/* 28 */     GL11.glTranslatef((float)x + 0.5F, (float)y + 1.5F, (float)z + 0.5F);
/*    */     
/* 30 */     TileEntityTurret tileTurret = (TileEntityTurret)tile;
/*    */     
/* 32 */     if (tileTurret.activate) {
/* 33 */       bindTexture(this.textureActivate);
/*    */     } else {
/* 35 */       bindTexture(this.textureDesactivate);
/*    */     }
/*    */     
/* 38 */     GL11.glPushMatrix();
/* 39 */     GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
/*    */     
/* 41 */     if (tileTurret.activate) {
/* 42 */       float yaw = (float)-Math.atan2(tileTurret.targetOffX, tileTurret.targetOffZ);
/* 43 */       this.model.render(0.0625F, 0.0F, yaw);
/*    */     } else {
/* 45 */       this.model.render(0.0625F, -45.0F, 0.0F);
/*    */     }
/* 47 */     GL11.glPopMatrix();
/* 48 */     GL11.glPopMatrix();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\render\block\RenderTurret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */