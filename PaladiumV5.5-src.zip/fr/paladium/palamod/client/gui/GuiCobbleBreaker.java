/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerCobbleBreaker;
/*    */ import fr.paladium.palamod.job.logic.TileCobbleBreaker;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiCobbleBreaker extends GuiContainer
/*    */ {
/* 14 */   ResourceLocation background = new ResourceLocation("palamod", "textures/gui/cobbleBreaker.png");
/*    */   
/*    */   private TileCobbleBreaker tileCobbleBreaker;
/*    */   
/*    */   public GuiCobbleBreaker(TileCobbleBreaker tile, InventoryPlayer inventory, EntityPlayer player)
/*    */   {
/* 20 */     super(new ContainerCobbleBreaker(tile, inventory, player));
/* 21 */     this.xSize = 189;
/* 22 */     this.ySize = 178;
/*    */     
/* 24 */     this.allowUserInput = false;
/* 25 */     this.tileCobbleBreaker = tile;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 31 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 32 */     this.mc.getTextureManager().bindTexture(this.background);
/* 33 */     int k = (this.width - this.xSize) / 2;
/* 34 */     int l = (this.height - this.ySize) / 2;
/* 35 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 37 */     double d = 15 * this.tileCobbleBreaker.getWork() / 400;
/* 38 */     int i = (int)d;
/* 39 */     drawTexturedModalRect(k + 94, l + 30, 1, 241, 8, i);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiCobbleBreaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */