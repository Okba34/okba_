/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerChestExplorer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiChestExplorer extends GuiContainer
/*    */ {
/*    */   TileEntity tile;
/* 14 */   ResourceLocation bg = new ResourceLocation("palamod:textures/gui/ChestExplorer.png");
/*    */   
/*    */   public GuiChestExplorer(TileEntity te) {
/* 17 */     super(new ContainerChestExplorer(te));
/* 18 */     this.xSize = 256;
/* 19 */     this.ySize = 177;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 24 */     this.mc.renderEngine.bindTexture(this.bg);
/*    */     
/* 26 */     drawDefaultBackground();
/* 27 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 28 */     int x = (this.width - this.xSize) / 2;
/* 29 */     int y = (this.height - this.ySize) / 2;
/* 30 */     drawTexturedModalRect(x, y, 0, 0, 256, 256);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiChestExplorer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */