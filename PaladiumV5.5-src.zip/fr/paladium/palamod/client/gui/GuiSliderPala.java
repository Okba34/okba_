/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import cpw.mods.fml.client.config.GuiSlider;
/*    */ import cpw.mods.fml.client.config.GuiSlider.ISlider;
/*    */ import fr.paladium.palamod.util.GuiDrawer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiSliderPala extends GuiSlider
/*    */ {
/* 13 */   private static ResourceLocation button = new ResourceLocation("palamod:textures/gui/sldr.png");
/*    */   
/*    */   public GuiSliderPala(int id, int xPos, int yPos, String displayStr, double minVal, double maxVal, double currentVal, GuiSlider.ISlider par)
/*    */   {
/* 17 */     super(id, xPos, yPos, displayStr, minVal, maxVal, currentVal, par);
/*    */   }
/*    */   
/*    */   public GuiSliderPala(int id, int xPos, int yPos, int width, int height, String prefix, String suf, double minVal, double maxVal, double currentVal, boolean showDec, boolean drawStr, GuiSlider.ISlider par)
/*    */   {
/* 22 */     super(id, xPos, yPos, width, height, prefix, suf, minVal, maxVal, currentVal, showDec, drawStr, par);
/*    */   }
/*    */   
/*    */ 
/*    */   public GuiSliderPala(int id, int xPos, int yPos, int width, int height, String prefix, String suf, double minVal, double maxVal, double currentVal, boolean showDec, boolean drawStr)
/*    */   {
/* 28 */     super(id, xPos, yPos, width, height, prefix, suf, minVal, maxVal, currentVal, showDec, drawStr);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void mouseDragged(Minecraft par1Minecraft, int par2, int par3)
/*    */   {
/* 34 */     if (this.visible)
/*    */     {
/* 36 */       if (this.dragging)
/*    */       {
/* 38 */         this.sliderValue = ((par2 - (this.xPosition + 4)) / (this.width - 8));
/* 39 */         updateSlider();
/*    */       }
/*    */       
/* 42 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 43 */       Minecraft.getMinecraft().getTextureManager().bindTexture(button);
/* 44 */       GuiDrawer.drawTexturedQuadFit(this.xPosition + (int)(getValueInt() * (this.width - 8)), this.yPosition, 120.0D, 100.0D, 0.0D);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiSliderPala.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */