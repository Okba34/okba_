/*    */ package fr.paladium.palamod.client.gui.tools.prompt;
/*    */ 
/*    */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.GuiTextField;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.inventory.Container;
/*    */ 
/*    */ public class GuiPromptInfo extends GuiContainer
/*    */ {
/*    */   String guiName;
/*    */   String buttonName;
/*    */   int parentGui;
/*    */   PromptAction action;
/*    */   String[] params;
/*    */   GuiTextField input;
/*    */   
/*    */   public GuiPromptInfo(Container container, String guiName, String buttonName, String[] params, PromptAction action)
/*    */   {
/* 22 */     this(container, guiName, buttonName, -1, params, action);
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 27 */     super.initGui();
/* 28 */     int x = (this.width - this.xSize) / 2;
/* 29 */     int y = (this.height - this.ySize) / 2;
/* 30 */     this.input = new GuiTextField(this.fontRendererObj, x, y, 200, 20);
/* 31 */     this.input.setFocused(false);
/* 32 */     this.input.setCanLoseFocus(true);
/* 33 */     this.buttonList.add(new GuiButton(0, x, y + 50, "Sethome"));
/*    */   }
/*    */   
/*    */   public GuiPromptInfo(Container container, String guiName, String buttonName, int guiID, String[] params, PromptAction action) {
/* 37 */     super(container);
/* 38 */     this.guiName = guiName;
/* 39 */     this.buttonName = buttonName;
/* 40 */     this.parentGui = guiID;
/* 41 */     this.action = action;
/* 42 */     this.params = params;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY)
/*    */   {
/* 47 */     this.input.drawTextBox();
/*    */   }
/*    */   
/*    */   protected void mouseClicked(int par1, int par2, int par3)
/*    */   {
/* 52 */     super.mouseClicked(par1, par2, par3);
/* 53 */     this.input.mouseClicked(par1, par2, par3);
/*    */   }
/*    */   
/*    */   public void onGuiClosed()
/*    */   {
/* 58 */     org.lwjgl.input.Keyboard.enableRepeatEvents(false);
/*    */   }
/*    */   
/*    */   protected void keyTyped(char par1, int pressedKey)
/*    */   {
/* 63 */     if ((pressedKey == 1) || ((!this.input.isFocused()) && 
/* 64 */       (pressedKey == this.mc.gameSettings.keyBindInventory.getKeyCode()))) {
/* 65 */       this.mc.thePlayer.closeScreen();
/*    */     }
/* 67 */     this.input.textboxKeyTyped(par1, pressedKey);
/*    */   }
/*    */   
/*    */   public void updateScreen()
/*    */   {
/* 72 */     super.updateScreen();
/* 73 */     this.input.updateCursorCounter();
/*    */   }
/*    */   
/*    */   protected void actionPerformed(GuiButton button)
/*    */   {
/* 78 */     super.actionPerformed(button);
/*    */     
/* 80 */     if (button.id == 0) {
/* 81 */       String[] tempParams = new String[this.params.length + 1];
/* 82 */       tempParams[0] = this.input.getText();
/* 83 */       int i = 1;
/* 84 */       for (String s : this.params) {
/* 85 */         tempParams[(i++)] = s;
/*    */       }
/* 87 */       this.action.onAction(tempParams);
/* 88 */       if (this.parentGui != -1) {}
/*    */       
/* 90 */       PacketOpenGui packet = new PacketOpenGui();
/* 91 */       packet.setInformations((byte)this.parentGui);
/* 92 */       fr.paladium.palamod.proxy.CommonProxy.packetPipeline.sendToServer(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\prompt\GuiPromptInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */