package fr.paladium.palamod.client.gui.tools.prompt;

public abstract interface PromptAction
{
  public abstract void onAction(String[] paramArrayOfString);
}


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\prompt\PromptAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */