/*   */ package fr.paladium.palamod.client.gui.tools.prompt;
/*   */ 
/*   */ public class PromptActionSethome
/*   */   implements PromptAction
/*   */ {
/*   */   public void onAction(String[] params)
/*   */   {
/* 8 */     if (params[0].equals("")) {}
/*   */   }
/*   */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\prompt\PromptActionSethome.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */