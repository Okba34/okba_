/*    */ package fr.paladium.palamod.client.gui.tools.buttons;
/*    */ 
/*    */ import fr.paladium.palamod.libs.LibRessources;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiButtonDigit extends GuiButton
/*    */ {
/*    */   ResourceLocation background;
/*    */   FontRenderer fr;
/*    */   int level;
/*    */   public boolean disabled;
/*    */   
/*    */   public GuiButtonDigit(int buttonId, int x, int y, int level, boolean disabled)
/*    */   {
/* 19 */     super(buttonId, x, y, "");
/* 20 */     this.width = LibRessources.WIDTH_BUTTON_PLUS;
/* 21 */     this.height = LibRessources.WIDTH_BUTTON_PLUS;
/* 22 */     this.background = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/* 23 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 24 */     this.level = level;
/* 25 */     this.disabled = disabled;
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*    */   {
/* 30 */     if (this.visible) {
/* 31 */       FontRenderer fontrenderer = mc.fontRenderer;
/* 32 */       mc.getTextureManager().bindTexture(this.background);
/* 33 */       fr.paladium.palamod.client.gui.GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 34 */       this.field_146123_n = ((mouseX >= this.xPosition) && (mouseY >= this.yPosition) && (mouseX < this.xPosition + this.width) && (mouseY < this.yPosition + this.height));
/*    */       
/* 36 */       int textX = LibRessources.BUTTON_DIGIT_COORDS[0];
/* 37 */       int textY = LibRessources.BUTTON_DIGIT_COORDS[1];
/*    */       
/* 39 */       if (this.disabled) {
/* 40 */         textY += LibRessources.WIDTH_BUTTON_DIGIT;
/*    */       }
/* 42 */       drawTexturedModalRect(this.xPosition, this.yPosition, textX, textY, LibRessources.WIDTH_BUTTON_PLUS, LibRessources.WIDTH_BUTTON_PLUS);
/*    */       
/* 44 */       int color = 13673256;
/* 45 */       if (this.field_146123_n) {
/* 46 */         color = 13683240;
/*    */       }
/* 48 */       GL11.glPushMatrix();
/* 49 */       GL11.glTranslated(this.xPosition + 2, this.yPosition + 1, 0.0D);
/* 50 */       GL11.glScaled(0.8D, 0.8D, 0.0D);
/* 51 */       this.fr.drawString("" + this.level, 0, 0, color);
/* 52 */       GL11.glPopMatrix();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\buttons\GuiButtonDigit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */