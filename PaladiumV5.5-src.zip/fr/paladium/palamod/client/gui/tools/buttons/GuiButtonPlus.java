/*    */ package fr.paladium.palamod.client.gui.tools.buttons;
/*    */ 
/*    */ import fr.paladium.palamod.libs.LibRessources;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class GuiButtonPlus extends GuiButton
/*    */ {
/*    */   ResourceLocation background;
/*    */   
/*    */   public GuiButtonPlus(int buttonId, int x, int y, String buttonText)
/*    */   {
/* 15 */     super(buttonId, x, y, buttonText);
/* 16 */     this.width = LibRessources.WIDTH_BUTTON_PLUS;
/* 17 */     this.height = LibRessources.WIDTH_BUTTON_PLUS;
/* 18 */     this.background = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*    */   {
/* 23 */     if (this.visible) {
/* 24 */       FontRenderer fontrenderer = mc.fontRenderer;
/* 25 */       mc.getTextureManager().bindTexture(this.background);
/* 26 */       fr.paladium.palamod.client.gui.GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 27 */       this.field_146123_n = ((mouseX >= this.xPosition) && (mouseY >= this.yPosition) && (mouseX < this.xPosition + this.width) && (mouseY < this.yPosition + this.height));
/*    */       
/* 29 */       int textX = LibRessources.BUTTON_PLUS_COORDS[0];
/* 30 */       int textY = LibRessources.BUTTON_PLUS_COORDS[1];
/*    */       
/* 32 */       if (this.field_146123_n) {
/* 33 */         textY += LibRessources.WIDTH_BUTTON_PLUS;
/*    */       }
/* 35 */       drawTexturedModalRect(this.xPosition, this.yPosition, textX, textY, LibRessources.WIDTH_BUTTON_PLUS, LibRessources.WIDTH_BUTTON_PLUS);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\buttons\GuiButtonPlus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */