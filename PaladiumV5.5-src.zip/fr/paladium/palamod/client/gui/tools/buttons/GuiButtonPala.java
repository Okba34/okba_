/*    */ package fr.paladium.palamod.client.gui.tools.buttons;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import sun.font.TrueTypeFont;
/*    */ 
/*    */ public class GuiButtonPala extends GuiButton
/*    */ {
/*    */   private TrueTypeFont font;
/* 13 */   private boolean antiAlias = true;
/* 14 */   protected boolean red = false;
/* 15 */   protected static final ResourceLocation buttonTextures = new ResourceLocation(PalaMod.MODID + ":textures/gui/btn.png");
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, String s)
/*    */   {
/* 19 */     this(i, j, k, 120, 20, s);
/*    */   }
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, int l, int i1, String s)
/*    */   {
/* 24 */     super(i, j, k, l, i1, s);
/* 25 */     if (s.equals("PALADIUM")) {
/* 26 */       this.red = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, int l, int i1, String s, boolean red) {
/* 31 */     super(i, j, k, l, i1, s);
/* 32 */     this.red = red;
/*    */   }
/*    */   
/*    */   public int getHoverState(boolean flag)
/*    */   {
/* 37 */     byte byte0 = 1;
/* 38 */     if (!this.enabled)
/*    */     {
/* 40 */       byte0 = 0;
/*    */     }
/* 42 */     else if (flag)
/*    */     {
/* 44 */       byte0 = 2;
/*    */     }
/* 46 */     return byte0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void drawButton(Minecraft mc, int mx, int my)
/*    */   {
/* 53 */     if (this.visible)
/*    */     {
/* 55 */       FontRenderer fontrenderer = mc.fontRenderer;
/* 56 */       int l = 14737632;
/*    */       
/* 58 */       int x = this.xPosition + this.width / 2;
/* 59 */       int y = this.yPosition + (this.height - 8) / 2;
/*    */       
/* 61 */       Boolean check = Boolean.valueOf((mx >= this.xPosition) && (my >= this.yPosition) && (mx < this.xPosition + this.width) && (my < this.yPosition + this.height));
/*    */       
/* 63 */       if (check.booleanValue()) {
/* 64 */         if ((this.displayString.equalsIgnoreCase("Discord")) || (this.displayString.equalsIgnoreCase("Twitter"))) {
/* 65 */           drawCenteredString(fontrenderer, "Â§b" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/* 66 */         } else if ((this.displayString.equalsIgnoreCase("Options")) || (this.displayString.equalsIgnoreCase("Site Web")) || (this.displayString.equalsIgnoreCase("Teamspeak")) || (this.displayString.equalsIgnoreCase("Quit Game"))) {
/* 67 */           drawCenteredString(fontrenderer, "Â§6" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */         } else {
/* 69 */           drawCenteredString(fontrenderer, "Â§c" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */         }
/*    */       }
/* 72 */       else if ((this.displayString.equalsIgnoreCase("Discord")) || (this.displayString.equalsIgnoreCase("Twitter"))) {
/* 73 */         drawCenteredString(fontrenderer, "Â§3" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/* 74 */       } else if ((this.displayString.equalsIgnoreCase("Options")) || (this.displayString.equalsIgnoreCase("Site Web")) || (this.displayString.equalsIgnoreCase("Teamspeak")) || (this.displayString.equalsIgnoreCase("Quit Game"))) {
/* 75 */         drawCenteredString(fontrenderer, "Â§f" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */       } else {
/* 77 */         drawCenteredString(fontrenderer, "Â§6" + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\buttons\GuiButtonPala.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */