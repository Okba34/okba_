/*     */ package fr.paladium.palamod.client.gui.tools.buttons;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.GlStateManager;
/*     */ import fr.paladium.palamod.client.gui.GlStateManager.DestFactor;
/*     */ import fr.paladium.palamod.client.gui.GlStateManager.SourceFactor;
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiButtonTab
/*     */   extends GuiButton
/*     */ {
/*     */   int style;
/*     */   ItemStack item;
/*  25 */   ResourceLocation guiElement = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/*  26 */   RenderItem itemRenderer = new RenderItem();
/*     */   FontRenderer fr;
/*     */   String name;
/*     */   
/*     */   public GuiButtonTab(int buttonId, int x, int y, ItemStack item, String name) {
/*  31 */     this(buttonId, x, y, 0, item, name);
/*     */   }
/*     */   
/*     */   public GuiButtonTab(int buttonId, int x, int y, int style, ItemStack item, String name) {
/*  35 */     super(buttonId, x, y, 22, 22, "");
/*  36 */     this.style = style;
/*  37 */     this.item = item;
/*  38 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*  39 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*     */   {
/*  44 */     if (this.visible) {
/*  45 */       FontRenderer fontrenderer = mc.fontRenderer;
/*  46 */       mc.getTextureManager().bindTexture(this.guiElement);
/*  47 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/*  48 */       this.field_146123_n = ((mouseX >= this.xPosition) && (mouseY >= this.yPosition) && (mouseX < this.xPosition + this.width) && (mouseY < this.yPosition + this.height));
/*     */       
/*  50 */       int i = getHoverState(this.field_146123_n);
/*  51 */       GlStateManager.enableBlend();
/*  52 */       GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*     */       
/*     */ 
/*  55 */       GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*     */       
/*  57 */       if (!this.field_146123_n) {
/*  58 */         drawTexturedModalRect(this.xPosition, this.yPosition, LibRessources.X_UNIFIED_BUTTON_1, LibRessources.Y_UNIFIED_BUTTON_1, 22, 22);
/*     */       }
/*     */       else
/*     */       {
/*  62 */         drawTexturedModalRect(this.xPosition, this.yPosition, LibRessources.X_UNIFIED_BUTTON_1, LibRessources.Y_UNIFIED_BUTTON_1 + 22, 22, 22);
/*     */       }
/*     */       
/*  65 */       GL11.glPushMatrix();
/*  66 */       GL11.glDisable(2896);
/*  67 */       GL11.glTranslated(this.xPosition, this.yPosition, 10.0D);
/*  68 */       GL11.glPushMatrix();
/*  69 */       GL11.glTranslated(5.0D, 4.0D, 0.0D);
/*  70 */       GL11.glScaled(0.8D, 0.8D, 1.0D);
/*  71 */       GL11.glEnable(3553);
/*  72 */       this.itemRenderer.renderItemAndEffectIntoGUI(this.fr, Minecraft.getMinecraft().getTextureManager(), this.item, 0, 0);
/*  73 */       GL11.glPopMatrix();
/*  74 */       GL11.glPopMatrix();
/*     */       
/*  76 */       mouseDragged(mc, mouseX, mouseY);
/*  77 */       int j = 14737632;
/*     */       
/*  79 */       if (this.packedFGColour != 0) {
/*  80 */         j = this.packedFGColour;
/*  81 */       } else if (!this.enabled) {
/*  82 */         j = 10526880;
/*  83 */       } else if (this.field_146123_n) {
/*  84 */         j = 16777120;
/*     */       }
/*     */       
/*  87 */       drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, j);
/*     */     }
/*     */     
/*  90 */     if ((this.field_146123_n) && 
/*  91 */       (this.field_146123_n)) {
/*  92 */       ArrayList<String> list = new ArrayList();
/*  93 */       list.add(this.name);
/*  94 */       drawHoveringText(list, mouseX, mouseY, this.fr);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean getHovered()
/*     */   {
/* 100 */     return this.field_146123_n;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawHoveringText(List p_146283_1_, int p_146283_2_, int p_146283_3_, FontRenderer font)
/*     */   {
/* 106 */     if (!p_146283_1_.isEmpty())
/*     */     {
/* 108 */       GL11.glDisable(32826);
/* 109 */       RenderHelper.disableStandardItemLighting();
/* 110 */       GL11.glDisable(2896);
/* 111 */       GL11.glDisable(2929);
/* 112 */       int k = 0;
/* 113 */       Iterator iterator = p_146283_1_.iterator();
/*     */       
/* 115 */       while (iterator.hasNext())
/*     */       {
/* 117 */         String s = (String)iterator.next();
/* 118 */         int l = font.getStringWidth(s);
/*     */         
/* 120 */         if (l > k)
/*     */         {
/* 122 */           k = l;
/*     */         }
/*     */       }
/*     */       
/* 126 */       int j2 = p_146283_2_ + 12;
/* 127 */       int k2 = p_146283_3_ - 12;
/* 128 */       int i1 = 8;
/*     */       
/* 130 */       if (p_146283_1_.size() > 1)
/*     */       {
/* 132 */         i1 += 2 + (p_146283_1_.size() - 1) * 10;
/*     */       }
/*     */       
/* 135 */       if (j2 + k > this.width)
/*     */       {
/* 137 */         j2 -= 28 + k;
/*     */       }
/*     */       
/* 140 */       if (k2 + i1 + 6 > this.height)
/*     */       {
/* 142 */         k2 = this.height - i1 - 6;
/*     */       }
/*     */       
/* 145 */       this.zLevel = 300.0F;
/* 146 */       this.itemRenderer.zLevel = 300.0F;
/* 147 */       int j1 = -267386864;
/* 148 */       drawGradientRect(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j1, j1);
/* 149 */       drawGradientRect(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j1, j1);
/* 150 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j1, j1);
/* 151 */       drawGradientRect(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j1, j1);
/* 152 */       drawGradientRect(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j1, j1);
/* 153 */       int k1 = 1347420415;
/* 154 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 155 */       drawGradientRect(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k1, l1);
/* 156 */       drawGradientRect(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k1, l1);
/* 157 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k1, k1);
/* 158 */       drawGradientRect(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l1, l1);
/*     */       
/* 160 */       for (int i2 = 0; i2 < p_146283_1_.size(); i2++)
/*     */       {
/* 162 */         String s1 = (String)p_146283_1_.get(i2);
/* 163 */         font.drawStringWithShadow(s1, j2, k2, -1);
/*     */         
/* 165 */         if (i2 == 0)
/*     */         {
/* 167 */           k2 += 2;
/*     */         }
/*     */         
/* 170 */         k2 += 10;
/*     */       }
/*     */       
/* 173 */       this.zLevel = 0.0F;
/* 174 */       this.itemRenderer.zLevel = 0.0F;
/* 175 */       GL11.glEnable(2896);
/* 176 */       GL11.glEnable(2929);
/* 177 */       RenderHelper.enableStandardItemLighting();
/* 178 */       GL11.glEnable(32826);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\buttons\GuiButtonTab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */