/*    */ package fr.paladium.palamod.client.gui.tools.buttons;
/*    */ 
/*    */ import fr.paladium.palamod.libs.LibRessources;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiButtonShop extends GuiButton
/*    */ {
/* 12 */   static FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
/*    */   int xPadding;
/*    */   int yPadding;
/*    */   ResourceLocation icon;
/*    */   int iconX;
/*    */   int iconY;
/*    */   boolean isVisible;
/*    */   boolean isCentered;
/*    */   
/*    */   public GuiButtonShop(int buttonId, int x, int y, String buttonText, ResourceLocation icon, int widthPadding, int heightPadding, int iconX, int iconY)
/*    */   {
/* 23 */     super(buttonId, x, y, LibRessources.WIDTH_ICON_BUTTON_SHOP + widthPadding * 4 + fr.getStringWidth(buttonText), LibRessources.HEIGHT_ICON_BUTTON_SHOP + heightPadding * 2, buttonText);
/*    */     
/* 25 */     this.xPadding = widthPadding;
/* 26 */     this.yPadding = heightPadding;
/* 27 */     this.icon = icon;
/*    */     
/* 29 */     this.iconX = iconX;
/* 30 */     this.iconY = iconY;
/* 31 */     this.isVisible = true;
/*    */   }
/*    */   
/*    */   public GuiButtonShop(int buttonId, int x, int y, String buttonText, ResourceLocation icon, int widthPadding, int heightPadding, int iconX, int iconY, boolean centered)
/*    */   {
/* 36 */     this(buttonId, x, y, buttonText, icon, widthPadding, heightPadding, iconX, iconY);
/* 37 */     this.isCentered = centered;
/* 38 */     this.width = widthPadding;
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*    */   {
/* 43 */     if (!this.isVisible) {
/* 44 */       return;
/*    */     }
/* 46 */     super.drawButton(mc, mouseX, mouseY);
/*    */     
/* 48 */     drawColorRectagle(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, 0.0F, 0.08F, 0.11F, 1.0F);
/* 49 */     Minecraft.getMinecraft().getTextureManager().bindTexture(this.icon);
/* 50 */     GL11.glPushMatrix();
/* 51 */     GL11.glTranslated(0.0D, 0.0D, 2.0D);
/* 52 */     if (!this.isCentered) {
/* 53 */       drawTexturedModalRect(this.xPosition + this.xPadding, this.yPosition + this.yPadding, this.iconX, this.iconY, LibRessources.WIDTH_ICON_BUTTON_SHOP, LibRessources.HEIGHT_ICON_BUTTON_SHOP);
/*    */       
/* 55 */       fr.drawStringWithShadow(this.displayString, this.xPosition + 3 * this.xPadding + LibRessources.WIDTH_ICON_BUTTON_SHOP, this.yPosition + this.yPadding + (LibRessources.HEIGHT_ICON_BUTTON_SHOP - 8) / 2, 16777215);
/*    */     }
/*    */     else {
/* 58 */       drawTexturedModalRect(this.xPosition + 
/* 59 */         (this.xPadding - 5 - fr.getStringWidth(this.displayString) - LibRessources.WIDTH_ICON_BUTTON_SHOP) / 2, this.yPosition + this.yPadding, this.iconX, this.iconY, LibRessources.WIDTH_ICON_BUTTON_SHOP, LibRessources.HEIGHT_ICON_BUTTON_SHOP);
/*    */       
/*    */ 
/*    */ 
/* 63 */       fr.drawStringWithShadow(this.displayString, this.xPosition + 
/* 64 */         (this.xPadding - fr.getStringWidth(this.displayString) - LibRessources.WIDTH_ICON_BUTTON_SHOP) / 2 + LibRessources.WIDTH_ICON_BUTTON_SHOP + 5, this.yPosition + this.yPadding + (LibRessources.HEIGHT_ICON_BUTTON_SHOP - 8) / 2, 16777215);
/*    */     }
/*    */     
/*    */ 
/* 68 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   public void setVisible(boolean b) {
/* 72 */     this.isVisible = b;
/*    */   }
/*    */   
/*    */   public void drawColorRectagle(int x, int y, int x1, int y1, float red, float green, float blue, float t) {
/* 76 */     GL11.glPushAttrib(8);
/* 77 */     GL11.glPolygonMode(2886, 6914);
/* 78 */     GL11.glColor4f(red, green, blue, t);
/* 79 */     GL11.glRecti(x, y, x1, y1);
/* 80 */     GL11.glPopAttrib();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\buttons\GuiButtonShop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */