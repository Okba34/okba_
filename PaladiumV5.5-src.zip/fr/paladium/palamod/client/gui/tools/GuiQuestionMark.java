/*     */ package fr.paladium.palamod.client.gui.tools;
/*     */ 
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiQuestionMark extends Gui
/*     */ {
/*     */   int posX;
/*     */   int posY;
/*     */   String desc;
/*     */   ResourceLocation elements;
/*     */   boolean hovered;
/*  23 */   Minecraft mc = Minecraft.getMinecraft();
/*     */   FontRenderer fr;
/*     */   int width;
/*     */   int height;
/*  27 */   RenderItem itemRenderer = new RenderItem();
/*     */   
/*     */   public GuiQuestionMark(int posX, int posY, String desc) {
/*  30 */     this.posX = posX;
/*  31 */     this.posY = posY;
/*  32 */     this.desc = desc;
/*  33 */     this.elements = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/*  34 */     this.fr = this.mc.fontRenderer;
/*  35 */     this.width = Minecraft.getMinecraft().currentScreen.width;
/*  36 */     this.height = Minecraft.getMinecraft().currentScreen.height;
/*     */   }
/*     */   
/*     */   public void draw(int mouseX, int mouseY) {
/*  40 */     boolean hovered = (mouseX > this.posX) && (mouseX < this.posX + 9) && (mouseY > this.posY) && (mouseY < this.posY + 9);
/*  41 */     Minecraft.getMinecraft().renderEngine.bindTexture(this.elements);
/*  42 */     drawTexturedModalRect(this.posX, this.posY, 71, 0, 80, 9);
/*  43 */     if ((hovered) && 
/*  44 */       (hovered)) {
/*  45 */       ArrayList<String> list = new ArrayList();
/*  46 */       list.add(this.desc);
/*  47 */       drawHoveringText(list, mouseX - 20 - this.fr.getStringWidth(this.desc), mouseY, this.fr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawHoveringText(List p_146283_1_, int p_146283_2_, int p_146283_3_, FontRenderer font)
/*     */   {
/*  54 */     if (!p_146283_1_.isEmpty())
/*     */     {
/*  56 */       GL11.glDisable(32826);
/*  57 */       RenderHelper.disableStandardItemLighting();
/*  58 */       GL11.glDisable(2896);
/*  59 */       GL11.glDisable(2929);
/*  60 */       int k = 0;
/*  61 */       Iterator iterator = p_146283_1_.iterator();
/*     */       
/*  63 */       while (iterator.hasNext())
/*     */       {
/*  65 */         String s = (String)iterator.next();
/*  66 */         int l = font.getStringWidth(s);
/*     */         
/*  68 */         if (l > k)
/*     */         {
/*  70 */           k = l;
/*     */         }
/*     */       }
/*     */       
/*  74 */       int j2 = p_146283_2_ + 12;
/*  75 */       int k2 = p_146283_3_ - 12;
/*  76 */       int i1 = 8;
/*     */       
/*  78 */       if (p_146283_1_.size() > 1)
/*     */       {
/*  80 */         i1 += 2 + (p_146283_1_.size() - 1) * 10;
/*     */       }
/*     */       
/*  83 */       if (j2 + k > this.width)
/*     */       {
/*  85 */         j2 -= 28 + k;
/*     */       }
/*     */       
/*  88 */       if (k2 + i1 + 6 > this.height)
/*     */       {
/*  90 */         k2 = this.height - i1 - 6;
/*     */       }
/*     */       
/*  93 */       this.zLevel = 300.0F;
/*  94 */       this.itemRenderer.zLevel = 300.0F;
/*  95 */       int j1 = -267386864;
/*  96 */       drawGradientRect(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j1, j1);
/*  97 */       drawGradientRect(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j1, j1);
/*  98 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j1, j1);
/*  99 */       drawGradientRect(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j1, j1);
/* 100 */       drawGradientRect(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j1, j1);
/* 101 */       int k1 = 1347420415;
/* 102 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 103 */       drawGradientRect(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k1, l1);
/* 104 */       drawGradientRect(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k1, l1);
/* 105 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k1, k1);
/* 106 */       drawGradientRect(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l1, l1);
/*     */       
/* 108 */       for (int i2 = 0; i2 < p_146283_1_.size(); i2++)
/*     */       {
/* 110 */         String s1 = (String)p_146283_1_.get(i2);
/* 111 */         font.drawStringWithShadow(s1, j2, k2, -1);
/*     */         
/* 113 */         if (i2 == 0)
/*     */         {
/* 115 */           k2 += 2;
/*     */         }
/*     */         
/* 118 */         k2 += 10;
/*     */       }
/*     */       
/* 121 */       this.zLevel = 0.0F;
/* 122 */       this.itemRenderer.zLevel = 0.0F;
/* 123 */       GL11.glEnable(2896);
/* 124 */       GL11.glEnable(2929);
/* 125 */       RenderHelper.enableStandardItemLighting();
/* 126 */       GL11.glEnable(32826);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\GuiQuestionMark.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */