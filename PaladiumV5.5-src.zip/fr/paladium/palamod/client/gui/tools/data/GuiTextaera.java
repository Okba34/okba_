/*    */ package fr.paladium.palamod.client.gui.tools.data;
/*    */ 
/*    */ import fr.paladium.palamod.client.gui.tools.list.GuiScrollable;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiTextaera extends GuiScrollable
/*    */ {
/*    */   String content;
/*    */   String[] lines;
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiTextaera(int posX, int posY, int width, int height, String content)
/*    */   {
/* 16 */     super(posX, posY, width, height);
/* 17 */     this.content = content;
/* 18 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 19 */     this.lines = content.split("</br>");
/* 20 */     int totalY = 0;
/* 21 */     for (String s : this.lines) {
/* 22 */       totalY += 8;
/*    */     }
/* 24 */     setTotalY(totalY);
/*    */   }
/*    */   
/*    */   public void drawContent(int x, int y, int mouseX, int mouseY)
/*    */   {
/* 29 */     int currentY = 0;
/* 30 */     for (String s : this.lines) {
/* 31 */       GL11.glPushMatrix();
/* 32 */       GL11.glTranslated(x, y + currentY - this.scrolledAmmount * getScaledSlide(), 0.0D);
/* 33 */       GL11.glScaled(0.8D, 0.8D, 1.0D);
/* 34 */       this.fr.drawString(s, 0, 0, 16777215);
/* 35 */       GL11.glPopMatrix();
/* 36 */       currentY += 8;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\data\GuiTextaera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */