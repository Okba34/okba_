/*     */ package fr.paladium.palamod.client.gui.tools.bar;
/*     */ 
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiBarUnified extends Gui
/*     */ {
/*  19 */   protected static RenderItem itemRender = new RenderItem();
/*     */   
/*     */   int type;
/*     */   
/*     */   int xPos;
/*     */   
/*     */   int yPos;
/*     */   int xOffset;
/*     */   int yOffset;
/*     */   boolean shouldHover;
/*     */   int width;
/*     */   int height;
/*     */   int scaledValue;
/*     */   int scaledMax;
/*     */   double size;
/*     */   boolean hover;
/*     */   Minecraft mc;
/*     */   FontRenderer fr;
/*     */   ResourceLocation location;
/*     */   
/*     */   public GuiBarUnified(int x, int y, int width, int type, double size, int xOffset, int yOffset)
/*     */   {
/*  41 */     this(x, y, width, type, size);
/*  42 */     this.shouldHover = true;
/*  43 */     this.xOffset = xOffset;
/*  44 */     this.yOffset = yOffset;
/*  45 */     this.height = Minecraft.getMinecraft().currentScreen.height;
/*     */   }
/*     */   
/*     */   public GuiBarUnified(int x, int y, int width, int type, double size)
/*     */   {
/*  50 */     this.xPos = x;
/*  51 */     this.yPos = y;
/*  52 */     this.width = width;
/*  53 */     this.type = type;
/*  54 */     this.size = size;
/*  55 */     this.height = Minecraft.getMinecraft().currentScreen.height;
/*  56 */     this.mc = Minecraft.getMinecraft();
/*  57 */     this.fr = this.mc.fontRenderer;
/*  58 */     this.location = new ResourceLocation(LibRessources.GUI_UNIFIED_BAR);
/*     */   }
/*     */   
/*     */   public void setScaledBar(int value, int max) {
/*  62 */     this.scaledValue = value;
/*  63 */     this.scaledMax = max;
/*     */   }
/*     */   
/*     */   public void setPosition(int x, int y) {
/*  67 */     this.xPos = x;
/*  68 */     this.yPos = y;
/*     */   }
/*     */   
/*     */   public void setType(int type) {
/*  72 */     this.type = type;
/*     */   }
/*     */   
/*     */   public void drawBar() {
/*  76 */     this.mc.renderEngine.bindTexture(this.location);
/*     */     
/*  78 */     GL11.glPushMatrix();
/*  79 */     GL11.glScaled(this.size, this.size, 0.0D);
/*  80 */     drawTexturedModalRect(this.xPos, this.yPos, 0, this.type, 1, LibRessources.HEIGHT_UNIFIED_BAR);
/*     */     
/*  82 */     for (int i = 0; i < this.width - 2; i++) {
/*  83 */       drawTexturedModalRect(this.xPos + 1 + i, this.yPos, 1, this.type, 2, LibRessources.HEIGHT_UNIFIED_BAR);
/*     */     }
/*     */     
/*  86 */     drawTexturedModalRect(this.xPos + this.width - 1, this.yPos, 0, this.type, 1, LibRessources.HEIGHT_UNIFIED_BAR);
/*     */     
/*  88 */     for (int i = 0; i < this.scaledValue / this.scaledMax * (this.width - 2); i++) {
/*  89 */       drawTexturedModalRect(this.xPos + 1 + i, this.yPos + 1, 2, this.type, 3, LibRessources.HEIGHT_UNIFIED_BAR);
/*     */     }
/*  91 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public double getSize() {
/*  95 */     return this.size;
/*     */   }
/*     */   
/*     */   public void drawHover(int mouseX, int mouseY, int centerX, int centerY) {
/*  99 */     int x = this.xPos + centerX + this.xOffset;
/* 100 */     int y = this.yPos + centerY + this.yOffset;
/* 101 */     this.hover = ((mouseX > x) && (mouseX < x + this.size * this.width) && (mouseY > y) && (mouseY < y + this.size * LibRessources.HEIGHT_UNIFIED_BAR));
/*     */     
/* 103 */     if (!this.shouldHover)
/* 104 */       return;
/* 105 */     if (this.hover) {
/* 106 */       ArrayList<String> list = new ArrayList();
/* 107 */       list.add(this.scaledValue + "/" + this.scaledMax);
/* 108 */       drawHoveringText(list, mouseX, mouseY, this.fr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawHoveringText(List p_146283_1_, int p_146283_2_, int p_146283_3_, FontRenderer font)
/*     */   {
/* 115 */     if (!p_146283_1_.isEmpty())
/*     */     {
/* 117 */       GL11.glDisable(32826);
/* 118 */       RenderHelper.disableStandardItemLighting();
/* 119 */       GL11.glDisable(2896);
/* 120 */       GL11.glDisable(2929);
/* 121 */       int k = 0;
/* 122 */       Iterator iterator = p_146283_1_.iterator();
/*     */       
/* 124 */       while (iterator.hasNext())
/*     */       {
/* 126 */         String s = (String)iterator.next();
/* 127 */         int l = font.getStringWidth(s);
/*     */         
/* 129 */         if (l > k)
/*     */         {
/* 131 */           k = l;
/*     */         }
/*     */       }
/*     */       
/* 135 */       int j2 = p_146283_2_ + 12;
/* 136 */       int k2 = p_146283_3_ - 12;
/* 137 */       int i1 = 8;
/*     */       
/* 139 */       if (p_146283_1_.size() > 1)
/*     */       {
/* 141 */         i1 += 2 + (p_146283_1_.size() - 1) * 10;
/*     */       }
/*     */       
/* 144 */       if (j2 + k > this.width)
/*     */       {
/* 146 */         j2 -= 28 + k;
/*     */       }
/*     */       
/* 149 */       if (k2 + i1 + 6 > this.height)
/*     */       {
/* 151 */         k2 = this.height - i1 - 6;
/*     */       }
/*     */       
/* 154 */       this.zLevel = 300.0F;
/* 155 */       itemRender.zLevel = 300.0F;
/* 156 */       int j1 = -267386864;
/* 157 */       drawGradientRect(j2 - 3, k2 - 4, j2 + k + 3, k2 - 3, j1, j1);
/* 158 */       drawGradientRect(j2 - 3, k2 + i1 + 3, j2 + k + 3, k2 + i1 + 4, j1, j1);
/* 159 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 + i1 + 3, j1, j1);
/* 160 */       drawGradientRect(j2 - 4, k2 - 3, j2 - 3, k2 + i1 + 3, j1, j1);
/* 161 */       drawGradientRect(j2 + k + 3, k2 - 3, j2 + k + 4, k2 + i1 + 3, j1, j1);
/* 162 */       int k1 = 1347420415;
/* 163 */       int l1 = (k1 & 0xFEFEFE) >> 1 | k1 & 0xFF000000;
/* 164 */       drawGradientRect(j2 - 3, k2 - 3 + 1, j2 - 3 + 1, k2 + i1 + 3 - 1, k1, l1);
/* 165 */       drawGradientRect(j2 + k + 2, k2 - 3 + 1, j2 + k + 3, k2 + i1 + 3 - 1, k1, l1);
/* 166 */       drawGradientRect(j2 - 3, k2 - 3, j2 + k + 3, k2 - 3 + 1, k1, k1);
/* 167 */       drawGradientRect(j2 - 3, k2 + i1 + 2, j2 + k + 3, k2 + i1 + 3, l1, l1);
/*     */       
/* 169 */       for (int i2 = 0; i2 < p_146283_1_.size(); i2++)
/*     */       {
/* 171 */         String s1 = (String)p_146283_1_.get(i2);
/* 172 */         font.drawStringWithShadow(s1, j2, k2, -1);
/*     */         
/* 174 */         if (i2 == 0)
/*     */         {
/* 176 */           k2 += 2;
/*     */         }
/*     */         
/* 179 */         k2 += 10;
/*     */       }
/*     */       
/* 182 */       this.zLevel = 0.0F;
/* 183 */       itemRender.zLevel = 0.0F;
/* 184 */       GL11.glEnable(2896);
/* 185 */       GL11.glEnable(2929);
/* 186 */       RenderHelper.enableStandardItemLighting();
/* 187 */       GL11.glEnable(32826);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\bar\GuiBarUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */