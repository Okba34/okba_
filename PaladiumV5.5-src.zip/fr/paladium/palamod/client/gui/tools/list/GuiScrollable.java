/*     */ package fr.paladium.palamod.client.gui.tools.list;
/*     */ 
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import org.lwjgl.input.Mouse;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public abstract class GuiScrollable
/*     */   extends Gui
/*     */ {
/*     */   int posX;
/*     */   int posY;
/*     */   public int width;
/*     */   public int height;
/*     */   protected int scrolledAmmount;
/*     */   int totalY;
/*     */   boolean scrolling;
/*     */   int lastMouseY;
/*     */   
/*     */   public GuiScrollable(int posX, int posY, int width, int height)
/*     */   {
/*  24 */     this.posX = posX;
/*  25 */     this.posY = posY;
/*  26 */     this.width = width;
/*  27 */     this.height = height;
/*     */   }
/*     */   
/*     */   public void draw(int mouseX, int mouseY) {
/*  31 */     int x = this.posX;
/*  32 */     int y = this.posY;
/*  33 */     boolean inScrollable = (mouseX > this.posX) && (mouseX < this.posX + this.width) && (mouseY > this.posY) && (mouseY < this.posY + this.height) && (this.totalY > this.height);
/*     */     
/*     */ 
/*  36 */     if ((inScrollable | this.scrolling)) {
/*  37 */       if (Mouse.isButtonDown(0)) {
/*  38 */         if (this.scrolling) {
/*  39 */           if (mouseX < this.posX + this.width - 5) {
/*  40 */             this.scrolledAmmount -= mouseY - this.lastMouseY;
/*     */           } else
/*  42 */             this.scrolledAmmount += mouseY - this.lastMouseY;
/*  43 */           if (this.scrolledAmmount > (this.totalY - this.height) / getScaledSlide() + 2.0D) {
/*  44 */             this.scrolledAmmount = ((int)((this.totalY - this.height) / getScaledSlide() + 2.0D));
/*  45 */           } else if (this.scrolledAmmount < 0) {
/*  46 */             this.scrolledAmmount = 0;
/*     */           }
/*     */         } else {
/*  49 */           this.scrolling = true; }
/*  50 */         this.lastMouseY = mouseY;
/*     */       } else {
/*  52 */         this.scrolling = false;
/*     */       }
/*     */     }
/*  55 */     if ((inScrollable) && (Mouse.hasWheel())) {
/*  56 */       this.scrolledAmmount -= Mouse.getDWheel() / 20;
/*  57 */       if (this.scrolledAmmount > (this.totalY - this.height) / getScaledSlide() + 2.0D) {
/*  58 */         this.scrolledAmmount = ((int)((this.totalY - this.height) / getScaledSlide() + 2.0D));
/*  59 */       } else if (this.scrolledAmmount < 0) {
/*  60 */         this.scrolledAmmount = 0;
/*     */       }
/*     */     }
/*  63 */     GL11.glPushMatrix();
/*     */     
/*  65 */     Minecraft mc = Minecraft.getMinecraft();
/*  66 */     ScaledResolution res = new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
/*  67 */     double scaleW = mc.displayWidth / res.getScaledWidth_double();
/*  68 */     double scaleH = mc.displayHeight / res.getScaledHeight_double();
/*     */     
/*  70 */     GL11.glEnable(3089);
/*  71 */     GL11.glScissor((int)(this.posX * scaleW), (int)(mc.displayHeight - (this.posY + this.height) * scaleH), (int)(this.width * scaleW), (int)(this.height * scaleH));
/*     */     
/*     */ 
/*  74 */     drawContent(x, y, mouseX, mouseY);
/*     */     
/*  76 */     GL11.glDisable(3089);
/*  77 */     GL11.glPopMatrix();
/*     */     
/*  79 */     double size = this.height / getScaledSlide();
/*  80 */     int left = this.posX + this.width - 5;
/*  81 */     int top = this.posY + this.scrolledAmmount;
/*  82 */     int right = this.posX + this.width;
/*  83 */     int bottom = this.posY + this.scrolledAmmount + (int)size;
/*     */     
/*  85 */     if (top < this.posY)
/*  86 */       top = this.posY;
/*  87 */     if (bottom < this.posY + size)
/*  88 */       bottom = this.posY + (int)size;
/*  89 */     if (bottom > this.posY + this.height)
/*  90 */       bottom = this.posY + this.height;
/*  91 */     if (top > this.posY + this.height - (int)size) {
/*  92 */       top = this.posY + this.height - (int)size;
/*     */     }
/*  94 */     GL11.glPushMatrix();
/*  95 */     GL11.glTranslated(0.0D, 0.0D, 3.0D);
/*  96 */     if (this.totalY > this.height)
/*  97 */       drawRect(left, top, right, bottom, 1426063360);
/*  98 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public double getScaledSlide() {
/* 102 */     double scaledSlide = this.totalY / this.height;
/* 103 */     if (scaledSlide < 1.0D)
/* 104 */       scaledSlide = 1.0D;
/* 105 */     return scaledSlide;
/*     */   }
/*     */   
/*     */   public void setTotalY(int totalY) {
/* 109 */     this.totalY = totalY;
/*     */   }
/*     */   
/*     */   public abstract void drawContent(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiScrollable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */