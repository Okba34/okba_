/*    */ package fr.paladium.palamod.client.gui.tools.list;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.Gui;
/*    */ import org.lwjgl.input.Mouse;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GuiListElement
/*    */   extends Gui
/*    */ {
/*    */   int width;
/*    */   int height;
/*    */   boolean selected;
/*    */   long lastClick;
/*    */   boolean mouseButtonDown;
/*    */   FontRenderer fr;
/*    */   List<String> content;
/*    */   GuiList list;
/*    */   
/*    */   public GuiListElement(int width, int height, List<String> content, GuiList list)
/*    */   {
/* 27 */     this.width = width;
/* 28 */     this.height = height;
/* 29 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 30 */     this.content = content;
/* 31 */     this.list = list;
/*    */   }
/*    */   
/*    */   public void draw(int posX, int posY, int x, int y) {
/* 35 */     int currentY = posY;
/*    */     
/* 37 */     if ((Mouse.isButtonDown(0)) && (!this.mouseButtonDown)) {
/* 38 */       if ((x > posX) && (x < posX + this.width) && (y > posY) && (y < posY + this.height) && (x < this.list.posX + this.list.width - 5) && (x > this.list.posX) && (y > this.list.posY) && (y < this.list.posY + this.list.height))
/*    */       {
/*    */ 
/*    */ 
/* 42 */         if (this.lastClick + 250L > System.currentTimeMillis()) {
/* 43 */           doAction();
/*    */         }
/* 45 */         this.lastClick = System.currentTimeMillis();
/* 46 */         this.selected = true;
/* 47 */         this.list.setSelected(this);
/* 48 */       } else if (this.selected) {
/* 49 */         this.selected = false;
/*    */       }
/*    */     }
/*    */     
/* 53 */     this.mouseButtonDown = Mouse.isButtonDown(0);
/*    */     
/* 55 */     if (this.selected) {
/* 56 */       drawSelected(posX, posY, x, y);
/*    */     }
/* 58 */     drawContent(posX, posY, x, y);
/*    */   }
/*    */   
/*    */   public abstract void doAction();
/*    */   
/*    */   public abstract void drawContent(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public abstract void drawSelected(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public int getWidth() {
/* 68 */     return this.width;
/*    */   }
/*    */   
/*    */   public void setWidth(int width) {
/* 72 */     this.width = width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 76 */     return this.height;
/*    */   }
/*    */   
/*    */   public void setHeight(int height) {
/* 80 */     this.height = height;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiListElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */