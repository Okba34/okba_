/*    */ package fr.paladium.palamod.client.gui.tools.list;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class GuiList extends GuiScrollable
/*    */ {
/*    */   ArrayList<GuiListElement> list;
/*    */   GuiListElement focused;
/*    */   
/*    */   public GuiList(int posX, int posY, int width, int height) {
/* 11 */     super(posX, posY, width, height);
/*    */     
/* 13 */     this.list = new ArrayList();
/*    */   }
/*    */   
/*    */   public void addGuiListElement(GuiListElement e) {
/* 17 */     this.list.add(e);
/*    */     
/* 19 */     this.totalY = 0;
/* 20 */     for (GuiListElement element : this.list)
/* 21 */       this.totalY += element.height;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 25 */     this.list.clear();
/*    */   }
/*    */   
/*    */   public GuiListElement getSelected() {
/* 29 */     return this.focused;
/*    */   }
/*    */   
/*    */   public void setSelected(GuiListElement guiListElement) {
/* 33 */     this.focused = guiListElement;
/*    */   }
/*    */   
/*    */   public void drawContent(int x, int y, int mouseX, int mouseY)
/*    */   {
/* 38 */     for (GuiListElement e : this.list) {
/* 39 */       e.draw(x, (int)(y - this.scrolledAmmount * getScaledSlide()), mouseX, mouseY);
/* 40 */       y += e.height;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */