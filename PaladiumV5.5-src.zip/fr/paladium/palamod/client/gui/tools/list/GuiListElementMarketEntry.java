/*    */ package fr.paladium.palamod.client.gui.tools.list;
/*    */ 
/*    */ import fr.paladium.servertools.market.MarketOffer;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiListElementMarketEntry
/*    */   extends GuiListElement
/*    */ {
/*    */   public static final int COLOR_BUY = 397848;
/*    */   public static final int COLOR_SELL = 661792;
/*    */   int color;
/*    */   MarketOffer offer;
/*    */   FontRenderer fr;
/*    */   boolean hovered;
/*    */   
/*    */   public GuiListElementMarketEntry(int width, int height, List<String> content, GuiList list, MarketOffer offer)
/*    */   {
/* 21 */     super(width, height, content, list);
/* 22 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 23 */     this.offer = offer;
/* 24 */     this.color = (offer.getType() == 1 ? 397848 : 661792);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void doAction() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void drawContent(int posX, int posY, int mouseX, int mouseY)
/*    */   {
/* 35 */     if (getColor() == 661792) {
/* 36 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.04F, 0.1F, 0.13F, 1.0F);
/* 37 */     } else if (getColor() == 1776399) {
/* 38 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.11F, 0.11F, 0.06F, 1.0F);
/*    */     } else {
/* 40 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.02F, 0.07F, 0.09F, 1.0F);
/*    */     }
/* 42 */     GL11.glPushMatrix();
/* 43 */     GL11.glTranslated(0.0D, 0.0D, 10.0D);
/* 44 */     this.fr.drawStringWithShadow(this.offer.getPlayerName(), posX + 10, posY + 6, 16777215);
/* 45 */     this.fr.drawStringWithShadow("" + this.offer.getAmmount(), posX + 220, posY + 6, 16777215);
/* 46 */     this.fr.drawStringWithShadow("" + this.offer.getBid(), posX + 320, posY + 6, 16777215);
/* 47 */     this.fr.drawStringWithShadow(this.offer.getType() == 1 ? "Achat" : "Vente", posX + 390, posY + 6, 16777215);
/* 48 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */ 
/*    */   public void drawSelected(int posX, int posY, int mouseX, int mouseY) {}
/*    */   
/*    */ 
/*    */   public int getColor()
/*    */   {
/* 57 */     if (this.selected)
/* 58 */       return 1776399;
/* 59 */     return this.color;
/*    */   }
/*    */   
/*    */   public void drawColorRectagle(int x, int y, int x1, int y1, float red, float green, float blue, float t) {
/* 63 */     GL11.glPushAttrib(8);
/* 64 */     GL11.glPolygonMode(2886, 6914);
/* 65 */     GL11.glColor4f(red, green, blue, t);
/* 66 */     GL11.glRecti(x, y, x1, y1);
/* 67 */     GL11.glPopAttrib();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiListElementMarketEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */