/*     */ package fr.paladium.palamod.client.gui.tools.list;
/*     */ 
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import fr.paladium.servertools.shop.ShopEntry;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiListElementShopEntry extends GuiListElement
/*     */ {
/*     */   public static final int COLOR_1 = 397848;
/*     */   public static final int COLOR_2 = 661792;
/*     */   int color;
/*     */   ShopEntry entry;
/*     */   FontRenderer fr;
/*     */   ResourceLocation image;
/*     */   ResourceLocation elements;
/*     */   
/*     */   public GuiListElementShopEntry(int width, int height, List<String> content, GuiList list, ShopEntry entry)
/*     */   {
/*  25 */     super(width, height, content, list);
/*  26 */     this.entry = entry;
/*  27 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*  28 */     this.color = (entry.getId() % 2 == 0 ? 397848 : 661792);
/*  29 */     this.image = new ResourceLocation(PalaMod.MODID + ":" + entry.getImage());
/*  30 */     this.elements = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doAction() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void drawContent(int posX, int posY, int mouseX, int mouseY)
/*     */   {
/*  41 */     if (getColor() == 661792) {
/*  42 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.04F, 0.1F, 0.13F, 1.0F);
/*  43 */     } else if (getColor() == 1776399) {
/*  44 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.11F, 0.11F, 0.06F, 1.0F);
/*     */     } else {
/*  46 */       drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.02F, 0.07F, 0.09F, 1.0F);
/*     */     }
/*  48 */     GL11.glPushMatrix();
/*  49 */     GL11.glTranslated(0.0D, 0.0D, 2.0D);
/*  50 */     int offset = 4;
/*  51 */     GL11.glPushMatrix();
/*  52 */     GL11.glTranslated(posX + offset + this.height - 2 * offset, posY + offset + 5, 0.0D);
/*  53 */     GL11.glScaled(1.2D, 1.2D, 1.0D);
/*  54 */     this.fr.drawStringWithShadow(this.entry.getDisplayName(), 0, 0, 16777215);
/*  55 */     GL11.glPopMatrix();
/*     */     
/*  57 */     drawColorRectagle(posX, posY, posX + this.width, posY + this.height, 0.0F, 0.0F, 0.0F, 0.2F);
/*  58 */     Minecraft.getMinecraft().renderEngine.bindTexture(this.image);
/*  59 */     drawTexturedModalRect(posX + offset + (this.height - offset * 2 - LibRessources.WIDTH_ICON_SHOP) / 2, posY + offset + (this.height - offset * 2 - LibRessources.HEIGHT_ICON_SHOP) / 2, 0, 0, LibRessources.WIDTH_ICON_BUTTON_SHOP, LibRessources.HEIGHT_ICON_SHOP);
/*     */     
/*     */ 
/*     */ 
/*  63 */     float iconModifier = 0.5F;
/*     */     
/*  65 */     GL11.glPushMatrix();
/*     */     
/*  67 */     GL11.glTranslated(this.width - this.fr.getStringWidth("" + this.entry.getPrice()) - 16.0F * iconModifier - this.height, 29.0D, 0.0D);
/*     */     
/*     */ 
/*     */ 
/*  71 */     GL11.glPushMatrix();
/*  72 */     GL11.glTranslated(posX + offset + this.height - 2 * offset, posY + offset + 5, 0.0D);
/*  73 */     GL11.glScaled(1.0D, 1.0D, 1.0D);
/*  74 */     this.fr.drawStringWithShadow("" + this.entry.getPrice(), 0, 0, 16777215);
/*  75 */     GL11.glPopMatrix();
/*     */     
/*     */ 
/*     */ 
/*  79 */     GL11.glPushMatrix();
/*  80 */     GL11.glTranslated(posX + offset + this.height - 2 * offset + this.fr.getStringWidth("" + this.entry.getPrice()), posY + offset + 5, 0.0D);
/*     */     
/*  82 */     GL11.glScaled(iconModifier, iconModifier, 1.0D);
/*  83 */     Minecraft.getMinecraft().getTextureManager().bindTexture(this.elements);
/*  84 */     drawTexturedModalRect(0, 0, LibRessources.PALACOIN_ICON[0], LibRessources.PALACOIN_ICON[1], 16, 16);
/*  85 */     GL11.glPopMatrix();
/*     */     
/*     */ 
/*  88 */     GL11.glPopMatrix();
/*     */     
/*     */ 
/*  91 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawSelected(int posX, int posY, int mouseX, int mouseY) {}
/*     */   
/*     */ 
/*     */   public int getColor()
/*     */   {
/* 100 */     if (this.selected)
/* 101 */       return 1776399;
/* 102 */     return this.color;
/*     */   }
/*     */   
/*     */   public ShopEntry getEntry() {
/* 106 */     return this.entry;
/*     */   }
/*     */   
/*     */   public void drawColorRectagle(int x, int y, int x1, int y1, float red, float green, float blue, float t) {
/* 110 */     GL11.glPushAttrib(8);
/* 111 */     GL11.glPolygonMode(2886, 6914);
/* 112 */     GL11.glColor4f(red, green, blue, t);
/* 113 */     GL11.glRecti(x, y, x1, y1);
/* 114 */     GL11.glPopAttrib();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiListElementShopEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */