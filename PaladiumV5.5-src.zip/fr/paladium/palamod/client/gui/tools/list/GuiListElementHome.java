/*    */ package fr.paladium.palamod.client.gui.tools.list;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiListElementHome extends GuiListElement
/*    */ {
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiListElementHome(int width, int height, List<String> content, GuiList list)
/*    */   {
/* 15 */     super(width, height, content, list);
/* 16 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*    */   }
/*    */   
/*    */   public void doAction()
/*    */   {
/* 21 */     String[] params = { (String)this.content.get(0) };
/*    */     
/* 23 */     Minecraft.getMinecraft().thePlayer.closeScreen();
/*    */   }
/*    */   
/*    */   public void drawContent(int posX, int posY, int mouseX, int mouseY)
/*    */   {
/* 28 */     int currentY = 0;
/* 29 */     for (String s : this.content) {
/* 30 */       if (currentY != 0) {
/* 31 */         GL11.glPushMatrix();
/* 32 */         GL11.glTranslated(posX + 3, posY + currentY + 3, 1.0D);
/*    */         
/* 34 */         GL11.glScaled(0.7D, 0.7D, 0.7D);
/* 35 */         this.fr.drawStringWithShadow(s, 0, 0, 16777215);
/* 36 */         GL11.glPopMatrix();
/*    */       } else {
/* 38 */         GL11.glPushMatrix();
/* 39 */         GL11.glTranslated(posX + 3, posY + currentY + 3, 1.0D);
/*    */         
/* 41 */         GL11.glScaled(1.0D, 1.0D, 1.0D);
/* 42 */         this.fr.drawString(s, 0, 0, 4456465);
/* 43 */         GL11.glPopMatrix();
/*    */       }
/* 45 */       currentY += 10;
/*    */     }
/*    */   }
/*    */   
/*    */   public void drawSelected(int posX, int posY, int mouseX, int mouseY)
/*    */   {
/* 51 */     drawRect(posX, posY, posX + this.width - 5, posY + this.height, 1426063360);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\tools\list\GuiListElementHome.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */