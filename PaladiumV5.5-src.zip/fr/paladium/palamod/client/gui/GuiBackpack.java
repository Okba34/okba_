/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerBackpack;
/*    */ import fr.paladium.palamod.common.inventory.InventoryBackpack;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiBackpack
/*    */   extends GuiContainer
/*    */ {
/* 16 */   ResourceLocation background = new ResourceLocation("palamod", "textures/gui/Backpack.png");
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiBackpack(InventoryPlayer inventory, InventoryBackpack inventoryBackpack) {
/* 20 */     super(new ContainerBackpack(inventory, inventoryBackpack));
/* 21 */     this.xSize = 176;
/* 22 */     this.ySize = 221;
/* 23 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 29 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 30 */     this.mc.getTextureManager().bindTexture(this.background);
/* 31 */     int k = (this.width - this.xSize) / 2;
/* 32 */     int l = (this.height - this.ySize) / 2;
/* 33 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/* 34 */     this.fr.drawStringWithShadow("Backpack", k + 7, l + 5, 16777215);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiBackpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */