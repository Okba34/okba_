/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerStuffSwitcher;
/*    */ import fr.paladium.palamod.common.inventory.InventoryStuffSwitcher;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiStuffSwitcher extends GuiContainer
/*    */ {
/* 14 */   ResourceLocation background = new ResourceLocation("palamod", "textures/gui/StuffSwitcher.png");
/*    */   
/*    */   public GuiStuffSwitcher(InventoryPlayer inventory, InventoryStuffSwitcher inventoryStuff) {
/* 17 */     super(new ContainerStuffSwitcher(inventory, inventoryStuff));
/* 18 */     this.xSize = 176;
/* 19 */     this.ySize = 117;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 25 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 26 */     this.mc.getTextureManager().bindTexture(this.background);
/* 27 */     int k = (this.width - this.xSize) / 2;
/* 28 */     int l = (this.height - this.ySize) / 2;
/* 29 */     drawTexturedModalRect(k, l, 0, 1, this.xSize, this.ySize);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiStuffSwitcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */