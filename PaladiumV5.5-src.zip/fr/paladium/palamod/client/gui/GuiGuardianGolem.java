/*     */ package fr.paladium.palamod.client.gui;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.button.ButtonGuardianChest;
/*     */ import fr.paladium.palamod.client.gui.button.ButtonGuardianUpgrade;
/*     */ import fr.paladium.palamod.common.gui.ContainerGuardianGolem;
/*     */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import fr.paladium.palamod.util.DisplayHelper;
/*     */ import fr.paladium.palamod.util.GuardianHelper;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiGuardianGolem
/*     */   extends GuiContainer
/*     */ {
/*  25 */   static int CHEST = 0;
/*  26 */   static int UPGRADE = 1;
/*     */   
/*     */   private EntityGuardianGolem golem;
/*  29 */   private final ResourceLocation background = new ResourceLocation("palamod:textures/gui/GuardianGolem.png");
/*     */   private FontRenderer fr;
/*     */   public float xSizeFloat;
/*     */   public float ySizeFloat;
/*     */   
/*     */   public GuiGuardianGolem(EntityGuardianGolem entity, InventoryPlayer inventory) {
/*  35 */     super(new ContainerGuardianGolem(entity, inventory));
/*  36 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*  37 */     this.golem = entity;
/*  38 */     this.xSize = 238;
/*  39 */     this.ySize = 227;
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  44 */     super.initGui();
/*  45 */     int x = (this.width - this.xSize) / 2;
/*  46 */     int y = (this.height - this.ySize) / 2;
/*     */     
/*  48 */     this.buttonList.add(new ButtonGuardianChest(CHEST, x + 210, y + 202, "", this.golem));
/*  49 */     this.buttonList.add(new ButtonGuardianUpgrade(UPGRADE, x + 140, y + 53, "", this.golem));
/*     */   }
/*     */   
/*     */   public void drawScreen(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
/*  53 */     super.drawScreen(p_73863_1_, p_73863_2_, p_73863_3_);
/*  54 */     this.xSizeFloat = p_73863_1_;
/*  55 */     this.ySizeFloat = p_73863_2_;
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*     */   {
/*  60 */     this.mc.renderEngine.bindTexture(this.background);
/*  61 */     drawDefaultBackground();
/*  62 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  63 */     int x = (this.width - this.xSize) / 2;
/*  64 */     int y = (this.height - this.ySize) / 2;
/*  65 */     drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
/*  66 */     float scaledXp = 240.0F * (this.golem.getSubLevel() / this.golem.getRequiredXP());
/*  67 */     drawTexturedModalRect(x + 9, y + 20, 0, 227, (int)scaledXp, 11);
/*  68 */     DisplayHelper.renderEntity(x + 42, y + 130, 30, x + 51 - this.xSizeFloat, y + 75 - 50 - this.ySizeFloat, this.golem, false);
/*     */     
/*     */ 
/*  71 */     this.fr.drawStringWithShadow(this.golem.getGuardianName(), x + (this.xSize / 2 - this.fr.getStringWidth(this.golem.getGuardianName()) / 2), y + 7, 182844);
/*     */     
/*  73 */     this.fr.drawStringWithShadow("Ameliorations", x + 83, y + 40, 16777215);
/*     */     
/*  75 */     this.fr.drawStringWithShadow("Ameliorations Cosmetiques", x + 83, y + 76, 16777215);
/*     */     
/*  77 */     this.fr.drawStringWithShadow("Whitelist", x + 177, y + 40, 16777215);
/*     */     
/*  79 */     this.fr.drawString("Niveau " + this.golem.getLevel(), x + (this.xSize / 2 - this.fr
/*  80 */       .getStringWidth("Niveau " + this.golem.getLevel()) / 2), y + 21, 16777215, true);
/*  81 */     this.fr.drawString(this.golem.getSubLevel() + "/" + (int)this.golem.getRequiredXP(), x + 11, y + 38, 16777215, true);
/*     */     
/*  83 */     this.fr.drawString("" + this.golem.getSpeed(), x + 103, y + 120, 16777215, true);
/*     */     
/*  85 */     this.fr.drawString("" + this.golem.getDamages(), x + 151, y + 120, 16777215, true);
/*     */     
/*  87 */     this.fr.drawString("" + this.golem.getLife(), x + 195, y + 120, 16777215, true);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/*  93 */     super.actionPerformed(button);
/*  94 */     if ((GuardianHelper.hasUpgrade(this.golem, 5)) && (button.id == CHEST)) {
/*  95 */       PacketOpenGui packet = new PacketOpenGui();
/*  96 */       packet.setInformations((byte)24, this.golem.getEntityId(), 0, 0);
/*  97 */       CommonProxy.packetPipeline.sendToServer(packet);
/*     */     }
/*     */     
/* 100 */     if ((GuardianHelper.hasUpgrade(this.golem, 6)) && (button.id == UPGRADE)) {
/* 101 */       PacketOpenGui packet = new PacketOpenGui();
/* 102 */       packet.setInformations((byte)25, this.golem.getEntityId(), 0, 0);
/* 103 */       CommonProxy.packetPipeline.sendToServer(packet);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiGuardianGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */