/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.OpenGlHelper;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import sun.font.TrueTypeFont;
/*    */ 
/*    */ public class GuiButtonPala
/*    */   extends GuiButton
/*    */ {
/*    */   private TrueTypeFont font;
/* 17 */   private boolean antiAlias = true;
/* 18 */   protected boolean red = false;
/* 19 */   protected static final ResourceLocation buttonTextures = new ResourceLocation("palamod:textures/gui/btn.png");
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, String s)
/*    */   {
/* 23 */     this(i, j, k, 120, 20, s);
/*    */   }
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, int l, int i1, String s)
/*    */   {
/* 28 */     super(i, j, k, l, i1, s);
/* 29 */     if (s.equals("PALADIUM")) {
/* 30 */       this.red = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public GuiButtonPala(int i, int j, int k, int l, int i1, String s, boolean red) {
/* 35 */     super(i, j, k, l, i1, s);
/* 36 */     this.red = red;
/*    */   }
/*    */   
/*    */   public int getHoverState(boolean flag)
/*    */   {
/* 41 */     byte byte0 = 1;
/* 42 */     if (!this.enabled)
/*    */     {
/* 44 */       byte0 = 0;
/*    */     }
/* 46 */     else if (flag)
/*    */     {
/* 48 */       byte0 = 2;
/*    */     }
/* 50 */     return byte0;
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mx, int my)
/*    */   {
/* 55 */     if (this.visible)
/*    */     {
/* 57 */       FontRenderer fontrenderer = mc.fontRenderer;
/* 58 */       fontrenderer.setUnicodeFlag(false);
/* 59 */       fontrenderer.FONT_HEIGHT = 60;
/* 60 */       mc.getTextureManager().bindTexture(buttonTextures);
/* 61 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 62 */       this.field_146123_n = ((mx >= this.xPosition) && (my >= this.yPosition) && (mx < this.xPosition + this.width) && (my < this.yPosition + this.height));
/* 63 */       int k = getHoverState(this.field_146123_n);
/* 64 */       GL11.glEnable(3042);
/* 65 */       OpenGlHelper.glBlendFunc(770, 771, 1, 0);
/* 66 */       GL11.glBlendFunc(770, 771);
/* 67 */       drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + k * 20, this.width / 2, this.height);
/* 68 */       drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + k * 20, this.width / 2, this.height);
/* 69 */       mouseDragged(mc, mx, my);
/* 70 */       int l = 14737632;
/*    */       
/* 72 */       if (this.red)
/*    */       {
/* 74 */         l = 14486056;
/*    */       }
/* 76 */       if (!this.enabled)
/*    */       {
/* 78 */         l = 10526880;
/*    */       }
/* 80 */       else if (this.field_146123_n)
/*    */       {
/* 82 */         l = 16777120;
/*    */       }
/*    */       
/* 85 */       drawCenteredString(fontrenderer, EnumChatFormatting.BOLD.toString() + this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiButtonPala.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */