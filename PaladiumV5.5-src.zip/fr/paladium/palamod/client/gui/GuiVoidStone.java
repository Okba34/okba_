/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerVoidStone;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiVoidStone
/*    */   extends GuiContainer
/*    */ {
/* 15 */   ResourceLocation background = new ResourceLocation("palamod", "textures/gui/VoidStone.png");
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiVoidStone(InventoryPlayer invetory) {
/* 19 */     super(new ContainerVoidStone(invetory));
/* 20 */     this.xSize = 176;
/* 21 */     this.ySize = 122;
/* 22 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 27 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 28 */     this.mc.getTextureManager().bindTexture(this.background);
/* 29 */     int k = (this.width - this.xSize) / 2;
/* 30 */     int l = (this.height - this.ySize) / 2;
/* 31 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/* 32 */     this.fr.drawStringWithShadow("Void Stone", k + 5, l + 5, 16777215);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiVoidStone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */