/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerEmpty;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketGuardianRadius;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import fr.paladium.palamod.tiles.TileEntityGuardianAnchor;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiTextField;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class GuiGuardianAnchor extends GuiContainer
/*    */ {
/*    */   GuiTextField radiusInput;
/*    */   TileEntityGuardianAnchor te;
/* 20 */   final ResourceLocation background = new ResourceLocation("palamod:textures/gui/GuardianRadius.png");
/*    */   
/*    */   public GuiGuardianAnchor(TileEntityGuardianAnchor te)
/*    */   {
/* 24 */     super(new ContainerEmpty());
/* 25 */     this.te = te;
/* 26 */     this.xSize = 161;
/* 27 */     this.ySize = 70;
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 32 */     super.initGui();
/* 33 */     int x = (this.width - this.xSize) / 2;
/* 34 */     int y = (this.height - this.ySize) / 2;
/* 35 */     this.radiusInput = new GuiTextField(this.fontRendererObj, x + 5, y + 20, 150, 15);
/* 36 */     this.radiusInput.setFocused(false);
/* 37 */     this.radiusInput.setCanLoseFocus(true);
/* 38 */     this.radiusInput.setText("" + this.te.getRadius());
/*    */   }
/*    */   
/*    */ 
/*    */   public void onGuiClosed()
/*    */   {
/* 44 */     org.lwjgl.input.Keyboard.enableRepeatEvents(false);
/* 45 */     this.radiusInput.setFocused(false);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void mouseClicked(int par1, int par2, int par3)
/*    */   {
/* 51 */     super.mouseClicked(par1, par2, par3);
/* 52 */     this.radiusInput.mouseClicked(par1, par2, par3);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void keyTyped(char par1, int pressedKey)
/*    */   {
/* 59 */     if ((pressedKey == 1) || ((!this.radiusInput.isFocused()) && 
/* 60 */       (pressedKey == this.mc.gameSettings.keyBindInventory.getKeyCode())))
/*    */     {
/*    */       try {
/* 63 */         radius = Integer.parseInt(this.radiusInput.getText());
/*    */       } catch (NumberFormatException e) { int radius;
/*    */         return; }
/*    */       int radius;
/* 67 */       PacketGuardianRadius packet = new PacketGuardianRadius();
/* 68 */       packet.addInformations(radius, this.te);
/* 69 */       CommonProxy.packetPipeline.sendToServer(packet);
/* 70 */       this.mc.thePlayer.closeScreen();
/*    */     }
/* 72 */     this.radiusInput.textboxKeyTyped(par1, pressedKey);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerBackgroundLayer(float par1, int x, int y)
/*    */   {
/* 78 */     this.mc.renderEngine.bindTexture(this.background);
/* 79 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 80 */     int k = (this.width - this.xSize) / 2;
/* 81 */     int l = (this.height - this.ySize) / 2;
/* 82 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/* 83 */     this.radiusInput.drawTextBox();
/* 84 */     this.fontRendererObj.drawStringWithShadow("Detecting: ", k + (this.xSize / 2 - this.fontRendererObj.getStringWidth("Detecting: ") / 2), l + 44, 16777215);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerForegroundLayer(int x, int y)
/*    */   {
/* 90 */     String title = "Guardian Anchor";
/* 91 */     this.fontRendererObj.drawString(title, (this.xSize - this.fontRendererObj.getStringWidth(title)) / 2, 5, 4210752);
/*    */   }
/*    */   
/*    */ 
/*    */   public void updateScreen()
/*    */   {
/* 97 */     super.updateScreen();
/* 98 */     this.radiusInput.updateCursorCounter();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiGuardianAnchor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */