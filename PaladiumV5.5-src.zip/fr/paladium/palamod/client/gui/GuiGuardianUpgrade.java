/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerGuardianUpgrade;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiGuardianUpgrade
/*    */   extends GuiContainer
/*    */ {
/*    */   private EntityGuardianGolem golem;
/* 18 */   private final ResourceLocation background = new ResourceLocation("palamod:textures/gui/GuardianUpgrade.png");
/*    */   private FontRenderer fr;
/*    */   public float xSizeFloat;
/*    */   public float ySizeFloat;
/*    */   
/*    */   public GuiGuardianUpgrade(EntityGuardianGolem entity, InventoryPlayer inventory) {
/* 24 */     super(new ContainerGuardianUpgrade(entity, inventory));
/* 25 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 26 */     this.golem = entity;
/* 27 */     this.xSize = 238;
/* 28 */     this.ySize = 153;
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 33 */     super.initGui();
/* 34 */     int x = (this.width - this.xSize) / 2;
/* 35 */     int y = (this.height - this.ySize) / 2;
/*    */   }
/*    */   
/*    */   public void drawScreen(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
/* 39 */     super.drawScreen(p_73863_1_, p_73863_2_, p_73863_3_);
/* 40 */     this.xSizeFloat = p_73863_1_;
/* 41 */     this.ySizeFloat = p_73863_2_;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 46 */     this.mc.renderEngine.bindTexture(this.background);
/* 47 */     drawDefaultBackground();
/* 48 */     GL11.glPushMatrix();
/* 49 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 50 */     int x = (this.width - this.xSize) / 2;
/* 51 */     int y = (this.height - this.ySize) / 2;
/* 52 */     drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
/* 53 */     float scaledXp = 240.0F * (this.golem.getSubLevel() / this.golem.getRequiredXP());
/* 54 */     drawTexturedModalRect(x + 9, y + 20, 0, 227, (int)scaledXp, 11);
/* 55 */     this.fr.drawStringWithShadow(this.golem.getGuardianName(), x + (this.xSize / 2 - this.fr.getStringWidth(this.golem.getGuardianName()) / 2), y + 7, 182844);
/*    */     
/* 57 */     this.fr.drawString("Niveau " + this.golem.getLevel(), x + (this.xSize / 2 - this.fr
/* 58 */       .getStringWidth("Niveau " + this.golem.getLevel()) / 2), y + 21, 16777215, true);
/* 59 */     this.fr.drawString("AmÃ©liorations", x + (this.xSize / 2 - this.fr
/* 60 */       .getStringWidth("AmÃ©liorations") / 2), y + 37, 16777215, true);
/* 61 */     GL11.glPopMatrix();
/*    */   }
/*    */   
/*    */   protected void actionPerformed(GuiButton button)
/*    */   {
/* 66 */     super.actionPerformed(button);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiGuardianUpgrade.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */