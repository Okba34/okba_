/*     */ package fr.paladium.palamod.client.gui;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.util.GuiDrawer;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.client.settings.GameSettings.Options;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ @SideOnly(Side.CLIENT)
/*     */ public class GuiOptionSliderPala extends GuiButtonPala
/*     */ {
/*     */   private float field_146134_p;
/*     */   public boolean field_146135_o;
/*     */   private GameSettings.Options field_146133_q;
/*     */   private final float field_146132_r;
/*     */   private final float field_146131_s;
/*     */   private static final String __OBFID = "CL_00000680";
/*  22 */   private static ResourceLocation button = new ResourceLocation("palamod:textures/gui/sldr.png");
/*     */   
/*     */   public GuiOptionSliderPala(int id, int x, int y, GameSettings.Options options)
/*     */   {
/*  26 */     this(id, x, y, options, 0.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public GuiOptionSliderPala(int id, int x, int y, GameSettings.Options options, boolean red)
/*     */   {
/*  31 */     this(id, x, y, options, 0.0F, 1.0F);
/*  32 */     this.red = red;
/*     */   }
/*     */   
/*     */   public GuiOptionSliderPala(int id, int x, int y, GameSettings.Options options, float par5, float par6)
/*     */   {
/*  37 */     super(id, x, y, 150, 20, "");
/*  38 */     this.field_146134_p = 1.0F;
/*  39 */     this.field_146133_q = options;
/*  40 */     this.field_146132_r = par5;
/*  41 */     this.field_146131_s = par6;
/*     */     
/*  43 */     Minecraft minecraft = Minecraft.getMinecraft();
/*  44 */     this.field_146134_p = options.normalizeValue(minecraft.gameSettings.getOptionFloatValue(options));
/*  45 */     this.displayString = minecraft.gameSettings.getKeyBinding(options);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHoverState(boolean p_146114_1_)
/*     */   {
/*  54 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void mouseDragged(Minecraft p_146119_1_, int p_146119_2_, int p_146119_3_)
/*     */   {
/*  62 */     if (this.visible)
/*     */     {
/*  64 */       if (this.field_146135_o)
/*     */       {
/*  66 */         this.field_146134_p = ((p_146119_2_ - (this.xPosition + 4)) / (this.width - 8));
/*     */         
/*  68 */         if (this.field_146134_p < 0.0F)
/*     */         {
/*  70 */           this.field_146134_p = 0.0F;
/*     */         }
/*     */         
/*  73 */         if (this.field_146134_p > 1.0F)
/*     */         {
/*  75 */           this.field_146134_p = 1.0F;
/*     */         }
/*     */         
/*  78 */         float f = this.field_146133_q.denormalizeValue(this.field_146134_p);
/*  79 */         p_146119_1_.gameSettings.setOptionFloatValue(this.field_146133_q, f);
/*  80 */         this.field_146134_p = this.field_146133_q.normalizeValue(f);
/*  81 */         this.displayString = p_146119_1_.gameSettings.getKeyBinding(this.field_146133_q);
/*     */       }
/*     */       
/*  84 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  85 */       Minecraft.getMinecraft().getTextureManager().bindTexture(button);
/*  86 */       GuiDrawer.drawTexturedQuadFit(this.xPosition, this.yPosition, 45.0D, 100.0D, 0.0D);
/*  87 */       GuiDrawer.drawTexturedQuadFit(this.xPosition + this.width - 2, this.yPosition, 45.0D, 100.0D, 0.0D);
/*     */       
/*  89 */       GuiDrawer.drawTexturedQuadFit(this.xPosition + (int)(this.field_146134_p * (this.width - 8)), this.yPosition, 120.0D, 100.0D, 0.0D);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean mousePressed(Minecraft minecraft, int x, int y)
/*     */   {
/*  99 */     if (super.mousePressed(minecraft, x, y))
/*     */     {
/* 101 */       this.field_146134_p = ((x - (this.xPosition + 4)) / (this.width - 8));
/*     */       
/* 103 */       if (this.field_146134_p < 0.0F)
/*     */       {
/* 105 */         this.field_146134_p = 0.0F;
/*     */       }
/*     */       
/* 108 */       if (this.field_146134_p > 1.0F)
/*     */       {
/* 110 */         this.field_146134_p = 1.0F;
/*     */       }
/*     */       
/* 113 */       minecraft.gameSettings.setOptionFloatValue(this.field_146133_q, this.field_146133_q.denormalizeValue(this.field_146134_p));
/* 114 */       this.displayString = minecraft.gameSettings.getKeyBinding(this.field_146133_q);
/* 115 */       this.field_146135_o = true;
/* 116 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 120 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mouseReleased(int p_146118_1_, int p_146118_2_)
/*     */   {
/* 129 */     this.field_146135_o = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiOptionSliderPala.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */