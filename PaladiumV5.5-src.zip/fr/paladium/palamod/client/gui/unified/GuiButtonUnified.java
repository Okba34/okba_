/*    */ package fr.paladium.palamod.client.gui.unified;
/*    */ 
/*    */ import fr.paladium.palamod.client.gui.GlStateManager;
/*    */ import fr.paladium.palamod.client.gui.GlStateManager.DestFactor;
/*    */ import fr.paladium.palamod.client.gui.GlStateManager.SourceFactor;
/*    */ import fr.paladium.palamod.libs.LibRessources;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiButtonUnified extends net.minecraft.client.gui.GuiButton
/*    */ {
/*    */   int style;
/*    */   UnifiedItem item;
/* 16 */   ResourceLocation guiElement = new ResourceLocation(LibRessources.GUI_ELEMENTS);
/*    */   
/*    */   public GuiButtonUnified(int buttonId, int x, int y, UnifiedItem item) {
/* 19 */     this(buttonId, x, y, 0, item);
/*    */   }
/*    */   
/*    */   public GuiButtonUnified(int buttonId, int x, int y, int style, UnifiedItem item) {
/* 23 */     super(buttonId, x, y, 22, 22, "");
/* 24 */     this.style = style;
/* 25 */     this.item = item;
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*    */   {
/* 30 */     if (this.visible) {
/* 31 */       net.minecraft.client.gui.FontRenderer fontrenderer = mc.fontRenderer;
/* 32 */       mc.getTextureManager().bindTexture(this.guiElement);
/* 33 */       GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
/* 34 */       this.field_146123_n = ((mouseX >= this.xPosition) && (mouseY >= this.yPosition) && (mouseX < this.xPosition + this.width) && (mouseY < this.yPosition + this.height));
/*    */       
/* 36 */       int i = getHoverState(this.field_146123_n);
/* 37 */       GlStateManager.enableBlend();
/* 38 */       GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*    */       
/*    */ 
/* 41 */       GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*    */       
/* 43 */       if (!this.field_146123_n) {
/* 44 */         drawTexturedModalRect(this.xPosition, this.yPosition, LibRessources.X_UNIFIED_BUTTON_1, LibRessources.Y_UNIFIED_BUTTON_1, 22, 22);
/*    */       }
/*    */       else
/*    */       {
/* 48 */         drawTexturedModalRect(this.xPosition, this.yPosition, LibRessources.X_UNIFIED_BUTTON_1, LibRessources.Y_UNIFIED_BUTTON_1 + 22, 22, 22);
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 55 */       mc.getTextureManager().bindTexture(this.item.getIcon());
/* 56 */       GL11.glPushMatrix();
/* 57 */       GL11.glTranslated(this.xPosition + 5, this.yPosition + 5, 0.0D);
/*    */       
/* 59 */       GL11.glScalef(0.7F, 0.7F, 1.0F);
/* 60 */       drawTexturedModalRect(0, 0, this.item.getCoords()[0], this.item.getCoords()[1], 16, 16);
/*    */       
/* 62 */       GL11.glPopMatrix();
/*    */       
/* 64 */       mouseDragged(mc, mouseX, mouseY);
/* 65 */       int j = 14737632;
/*    */       
/* 67 */       if (this.packedFGColour != 0) {
/* 68 */         j = this.packedFGColour;
/* 69 */       } else if (!this.enabled) {
/* 70 */         j = 10526880;
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 75 */       drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, j);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean getHovered()
/*    */   {
/* 81 */     return this.field_146123_n;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\GuiButtonUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */