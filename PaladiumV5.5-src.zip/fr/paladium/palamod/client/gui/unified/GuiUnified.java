/*     */ package fr.paladium.palamod.client.gui.unified;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.tools.bar.GuiBarUnified;
/*     */ import fr.paladium.palamod.common.gui.ContainerUnified;
/*     */ import fr.paladium.palamod.common.gui.ModGuiUnified;
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class GuiUnified extends GuiContainer
/*     */ {
/*     */   ContainerUnified container;
/*     */   int centerX;
/*     */   int centerY;
/*     */   ResourceLocation location;
/*     */   FontRenderer fr;
/*     */   ArrayList<GuiBarUnified> barList;
/*     */   
/*     */   public GuiUnified(ContainerUnified container)
/*     */   {
/*  28 */     super(container);
/*  29 */     this.container = container;
/*  30 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*  31 */     this.width = 256;
/*  32 */     this.height = 166;
/*  33 */     this.xSize = 282;
/*  34 */     this.barList = new ArrayList();
/*     */   }
/*     */   
/*     */   public GuiUnified(ContainerUnified container, String location) {
/*  38 */     this(container);
/*  39 */     this.location = new ResourceLocation(location);
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  44 */     super.initGui();
/*  45 */     this.centerX = (-13 + (this.width - 256) / 2);
/*  46 */     this.centerY = ((this.height - 166) / 2);
/*     */     
/*  48 */     initButtons();
/*     */   }
/*     */   
/*     */   public void initButtons() {
/*  52 */     this.buttonList.clear();
/*     */     
/*     */ 
/*  55 */     int currentY = 0;
/*  56 */     for (UnifiedItem item : ModGuiUnified.getAllItems()) {
/*  57 */       this.buttonList.add(new GuiButtonUnified(item.getGuiID(), this.centerX + 256 + 4, currentY + this.centerY, item));
/*     */       
/*     */ 
/*  60 */       currentY += 26;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY)
/*     */   {
/*  66 */     if (this.location != null) {
/*  67 */       this.mc.getTextureManager().bindTexture(this.location);
/*  68 */       drawTexturedModalRect(this.centerX, this.centerY, 0, 0, 256, 166);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
/*     */   {
/*  75 */     super.drawGuiContainerForegroundLayer(mouseX, mouseY);
/*  76 */     for (GuiBarUnified bar : this.barList) {
/*  77 */       bar.drawBar();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/*  83 */     super.actionPerformed(button);
/*  84 */     if (((button instanceof GuiButtonUnified)) && 
/*  85 */       (button.id != getGuiId())) {
/*  86 */       PacketOpenGui packet = new PacketOpenGui();
/*  87 */       packet.setInformations((byte)button.id);
/*  88 */       CommonProxy.packetPipeline.sendToServer(packet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks)
/*     */   {
/*  95 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*  96 */     for (GuiBarUnified bar : this.barList) {
/*  97 */       bar.drawHover(mouseX, mouseY, this.centerX, this.centerY);
/*     */     }
/*  99 */     for (Object btn : this.buttonList) {
/* 100 */       if (((btn instanceof GuiButtonUnified)) && (((GuiButtonUnified)btn).getHovered())) {
/* 101 */         ArrayList<String> list = new ArrayList();
/* 102 */         list.add(((GuiButtonUnified)btn).item.getName());
/* 103 */         drawHoveringText(list, mouseX, mouseY, this.fr);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getGuiId() {
/* 109 */     return this.container.getGuiId();
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\GuiUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */