/*    */ package fr.paladium.palamod.client.gui.unified;
/*    */ 
/*    */ import fr.paladium.palamod.client.gui.tools.list.GuiList;
/*    */ import fr.paladium.palamod.common.gui.ContainerUnified;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.inventory.GuiInventory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuiInventoryUnified
/*    */   extends GuiUnified
/*    */ {
/* 21 */   final int PAY = 0;
/* 22 */   final int SETHOME = 1;
/*    */   
/*    */   float oldMouseX;
/*    */   
/*    */   float oldMouseY;
/*    */   GuiList homeList;
/*    */   boolean homeInitialized;
/*    */   
/*    */   public GuiInventoryUnified(ContainerUnified container, String location)
/*    */   {
/* 32 */     super(container, location);
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 37 */     super.initGui();
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY)
/*    */   {
/* 42 */     super.drawGuiContainerBackgroundLayer(partialTicks, mouseX, mouseY);
/* 43 */     GuiInventory.func_147046_a(this.centerX + 51, this.centerY + 75, 30, this.centerX + 51 - this.oldMouseX, this.centerY + 75 - 50 - this.oldMouseY, this.mc.thePlayer);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void drawScreen(int mouseX, int mouseY, float partialTicks)
/*    */   {
/* 50 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
/*    */   {
/* 55 */     super.drawGuiContainerForegroundLayer(mouseX, mouseY);
/*    */   }
/*    */   
/*    */   protected void actionPerformed(GuiButton button)
/*    */   {
/* 60 */     super.actionPerformed(button);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\GuiInventoryUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */