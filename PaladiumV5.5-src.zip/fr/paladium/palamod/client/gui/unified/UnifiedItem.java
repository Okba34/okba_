/*    */ package fr.paladium.palamod.client.gui.unified;
/*    */ 
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class UnifiedItem
/*    */ {
/*    */   ResourceLocation icon;
/*    */   String name;
/*    */   int GuiID;
/*    */   int x;
/*    */   int y;
/*    */   int[] coords;
/*    */   
/*    */   public UnifiedItem(ResourceLocation icon, int x, int y, String name, int GuiID, int[] coords) {
/* 15 */     this.icon = icon;
/* 16 */     this.name = name;
/* 17 */     this.GuiID = GuiID;
/* 18 */     this.x = x;
/* 19 */     this.y = y;
/* 20 */     this.coords = coords;
/*    */   }
/*    */   
/*    */   public ResourceLocation getIcon() {
/* 24 */     return this.icon;
/*    */   }
/*    */   
/*    */   public void setIcon(ResourceLocation icon) {
/* 28 */     this.icon = icon;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 36 */     this.name = name;
/*    */   }
/*    */   
/*    */   public int getGuiID() {
/* 40 */     return this.GuiID;
/*    */   }
/*    */   
/*    */   public void setGuiID(int guiID) {
/* 44 */     this.GuiID = guiID;
/*    */   }
/*    */   
/*    */   public int[] getCoords() {
/* 48 */     return this.coords;
/*    */   }
/*    */   
/*    */   public void setCoords(int[] coords) {
/* 52 */     this.coords = coords;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\UnifiedItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */