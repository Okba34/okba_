/*     */ package fr.paladium.palamod.client.gui.unified;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.tools.bar.GuiBarUnified;
/*     */ import fr.paladium.palamod.client.local.LocalValues;
/*     */ import fr.paladium.palamod.job.Job;
/*     */ import fr.paladium.palamod.job.ModJobs;
/*     */ import fr.paladium.palamod.libs.LibRessources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiJobUnified extends GuiUnified
/*     */ {
/*     */   public GuiJobUnified(fr.paladium.palamod.common.gui.ContainerUnified container, String location)
/*     */   {
/*  19 */     super(container, location);
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  24 */     super.initGui();
/*  25 */     this.barList.clear();
/*     */     
/*  27 */     for (Map.Entry<Integer, Job> j : ModJobs.jobs.entrySet()) {
/*  28 */       this.barList.add(new GuiBarUnified(0, 0, 58, LibRessources.UNIFIED_BAR_GREEN, 1.0D, 0, 0));
/*     */     }
/*     */     
/*  31 */     this.barList.add(new GuiBarUnified(4, 13, 150, LibRessources.UNIFIED_BAR_GREEN, 1.6D, 0, 8));
/*     */     
/*  33 */     LocalValues.initJobs();
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY)
/*     */   {
/*  38 */     super.drawGuiContainerForegroundLayer(mouseX, mouseY);
/*     */     
/*  40 */     int currentX = 0;
/*  41 */     int currentY = 0;
/*     */     
/*  43 */     this.fr.drawStringWithShadow(I18n.format("gui.jobs", new Object[0]), 
/*  44 */       (176 - this.fr.getStringWidth(I18n.format("gui.jobs", new Object[0]))) / 2, 8, 16777215);
/*     */     
/*     */ 
/*  47 */     int totalXP = 0;
/*  48 */     int maxXP = 0;
/*  49 */     int totalLevel = 0;
/*     */     
/*  51 */     for (Map.Entry<Integer, Job> j : ModJobs.jobs.entrySet()) {
/*  52 */       int x = currentX + 5;
/*  53 */       int y = currentY + 40;
/*     */       
/*  55 */       GL11.glPushMatrix();
/*     */       
/*  57 */       int xp = LocalValues.getXPJob(((Integer)j.getKey()).intValue());
/*  58 */       int level = ((Job)j.getValue()).getLevel(xp);
/*     */       
/*  60 */       totalXP += xp;
/*  61 */       maxXP += ((Job)j.getValue()).getXPForLevel(20);
/*  62 */       totalLevel += level;
/*     */       
/*  64 */       double textScale = 0.6D;
/*     */       
/*  66 */       int centeredText = (int)((58.0D - this.fr.getStringWidth(I18n.format("misc.level", new Object[0]) + " : " + level) * textScale) / 2.0D);
/*     */       
/*  68 */       double yTranslate = y + 32 + 2 + (int)(LibRessources.HEIGHT_UNIFIED_BAR * ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).getSize());
/*     */       
/*  70 */       GL11.glTranslated(x + centeredText, yTranslate, 0.0D);
/*  71 */       GL11.glScaled(textScale, textScale, 0.0D);
/*  72 */       this.fr.drawStringWithShadow(I18n.format("misc.level", new Object[0]) + " : " + level, 0, 0, 16777215);
/*     */       
/*  74 */       GL11.glTranslated(-x - centeredText, -yTranslate, 0.0D);
/*     */       
/*  76 */       double textScale2 = 1.2D;
/*     */       
/*  78 */       centeredText = (int)((58.0D - this.fr.getStringWidth(I18n.format(((Job)j.getValue()).getDisplayName(), new Object[0])) * textScale2 * textScale) / 2.0D);
/*     */       
/*  80 */       yTranslate = y + 32 - 2 - LibRessources.HEIGHT_UNIFIED_BAR * ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).getSize() - 10.0D;
/*     */       
/*  82 */       GL11.glTranslated(x + centeredText, yTranslate, 0.0D);
/*  83 */       GL11.glScaled(textScale2, textScale2, 0.0D);
/*  84 */       this.fr.drawStringWithShadow(I18n.format(((Job)j.getValue()).getDisplayName(), new Object[0]), 0, 0, 16777215);
/*  85 */       GL11.glPopMatrix();
/*     */       
/*  87 */       ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).setScaledBar(((Job)j.getValue()).getSubLevel(xp), ((Job)j.getValue()).getTotalXPLevel(level));
/*  88 */       ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).setPosition(x, y + 32);
/*     */       
/*  90 */       if (level >= 20) {
/*  91 */         ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).setType(LibRessources.UNIFIED_BAR_MAGENTA);
/*     */       } else {
/*  93 */         ((GuiBarUnified)this.barList.get(((Integer)j.getKey()).intValue() - 1)).setType(LibRessources.UNIFIED_BAR_GREEN);
/*     */       }
/*  95 */       int[] coords = ((Job)j.getValue()).getCoords();
/*  96 */       this.mc.renderEngine.bindTexture(((Job)j.getValue()).getLogo());
/*  97 */       drawTexturedModalRect(x + 18, y + 1, coords[1], coords[0], 20, 20);
/*     */       
/*     */ 
/* 100 */       if (((Integer)j.getKey()).intValue() / 4.0D == 1.0D) {
/* 101 */         currentX = 0;
/* 102 */         currentY += 60;
/*     */       } else {
/* 104 */         currentX += 63;
/*     */       }
/*     */     }
/*     */     
/* 108 */     int maxLevel = 20 * (this.barList.size() - 1);
/* 109 */     double textSize = 0.8D;
/* 110 */     String totalLevelText = I18n.format("misc.level", new Object[0]) + " : " + totalLevel + "/" + maxLevel;
/*     */     
/* 112 */     int centeredText = (int)((256.0D - this.fr.getStringWidth(totalLevelText) * textSize) / 2.0D - 24.0D);
/*     */     
/* 114 */     GL11.glPushMatrix();
/*     */     
/* 116 */     GL11.glScaled(textSize, textSize, 1.0D);
/* 117 */     this.fr.drawStringWithShadow(totalLevelText, centeredText, 31, 16777215);
/* 118 */     GL11.glPopMatrix();
/*     */     
/* 120 */     ((GuiBarUnified)this.barList.get(this.barList.size() - 1)).setScaledBar(totalLevel, maxXP);
/* 121 */     if (totalXP >= maxXP) {
/* 122 */       ((GuiBarUnified)this.barList.get(this.barList.size() - 1)).setType(LibRessources.UNIFIED_BAR_MAGENTA);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\GuiJobUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */