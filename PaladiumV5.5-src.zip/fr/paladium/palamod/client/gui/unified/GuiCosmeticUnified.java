/*   */ package fr.paladium.palamod.client.gui.unified;
/*   */ 
/*   */ import fr.paladium.palamod.common.gui.ContainerUnified;
/*   */ 
/*   */ public class GuiCosmeticUnified extends GuiUnified
/*   */ {
/*   */   public GuiCosmeticUnified(ContainerUnified container, String location) {
/* 8 */     super(container, location);
/*   */   }
/*   */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\unified\GuiCosmeticUnified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */