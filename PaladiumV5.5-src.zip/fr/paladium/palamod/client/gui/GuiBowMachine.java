/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.paladium.inventory.BowMachineContainer;
/*    */ import fr.paladium.palamod.paladium.logic.BowMachineLogic;
/*    */ import fr.paladium.palamod.util.BowHelper;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiBowMachine
/*    */   extends GuiContainer
/*    */ {
/* 18 */   ResourceLocation background = new ResourceLocation("palamod", "textures/gui/BowMachine.png");
/*    */   BowMachineLogic tile;
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiBowMachine(BowMachineLogic tile, InventoryPlayer inventory)
/*    */   {
/* 24 */     super(new BowMachineContainer(tile, inventory));
/* 25 */     this.tile = tile;
/* 26 */     this.ySize = 166;
/* 27 */     this.xSize = 176;
/* 28 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 33 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 34 */     this.mc.getTextureManager().bindTexture(this.background);
/* 35 */     int k = (this.width - this.xSize) / 2;
/* 36 */     int l = (this.height - this.ySize) / 2;
/* 37 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*    */     
/* 39 */     if (this.tile.isBurning()) {
/* 40 */       int i1 = this.tile.getCookProgressScaled(48);
/* 41 */       drawTexturedModalRect(k + 101, l + 35, 176, 0, i1 + 1, 16);
/*    */     }
/*    */     
/* 44 */     this.fr.drawStringWithShadow("Bow Machine", k + 79, l + 7, -1);
/* 45 */     this.fr.drawStringWithShadow("§l§nModifiers", k + 10, l + 9, -1);
/*    */     
/* 47 */     ItemStack stack = this.tile.getStackInSlot(1);
/*    */     
/* 49 */     if (stack != null) {
/* 50 */       int[] modifiers = BowHelper.getModifiers(stack);
/* 51 */       if (modifiers != null) {
/* 52 */         if (modifiers.length == 1) {
/* 53 */           this.fr.drawStringWithShadow("§1 Modifier", k + 10, l + 21, -1);
/*    */         } else
/* 55 */           this.fr.drawStringWithShadow("§c" + modifiers.length + " Modifiers", k + 10, l + 21, -1);
/* 56 */         for (int i = 0; i < modifiers.length; i++) {
/* 57 */           this.fr.drawStringWithShadow("- " + BowHelper.getModifierName(modifiers[i]), k + 10, l + 32 + i * 11, -1);
/*    */         }
/*    */       }
/*    */       else {
/* 61 */         this.fr.drawStringWithShadow("§0 Modifiers", k + 10, l + 21, -1);
/*    */       }
/*    */     }
/*    */     else {
/* 65 */       this.fr.drawStringWithShadow("§ No bow", k + 10, l + 21, -1);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiBowMachine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */