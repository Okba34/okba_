/*     */ package fr.paladium.palamod.client.gui.custom;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.GuiButtonPala;
/*     */ import fr.paladium.palamod.util.GuiDrawer;
/*     */ import java.awt.Desktop;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiMainMenu;
/*     */ import net.minecraft.client.gui.GuiOptions;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.achievement.GuiAchievements;
/*     */ import net.minecraft.client.gui.achievement.GuiStats;
/*     */ import net.minecraft.client.multiplayer.WorldClient;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Session;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiInGameMenu extends GuiScreen
/*     */ {
/*  26 */   private ResourceLocation background = new ResourceLocation("palamod", "textures/gui/LOGO.png");
/*     */   private int xSize;
/*     */   private int ySize;
/*     */   
/*     */   public GuiInGameMenu() {
/*  31 */     this.xSize = 500;
/*  32 */     this.ySize = 200;
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  37 */     int k = (this.width - this.xSize) / 2;
/*  38 */     int l = (this.height - this.ySize) / 2;
/*     */     
/*  40 */     this.buttonList.add(new GuiButtonPala(0, k + (this.xSize - 150) / 2, l + 170, 150, 20, !this.mc.isIntegratedServerRunning() ? I18n.format("menu.disconnect", new Object[0]) : I18n.format("menu.returnToMenu", new Object[0]), true));
/*  41 */     if (!this.mc.isIntegratedServerRunning()) {
/*  42 */       ((GuiButton)this.buttonList.get(0)).displayString = I18n.format("menu.disconnect", new Object[0]);
/*     */     }
/*  44 */     this.buttonList.add(new GuiButtonPala(1, k + (this.xSize - 150) / 2, l + 5, 150, 20, I18n.format("menu.returnToGame", new Object[0])));
/*     */     
/*  46 */     this.buttonList.add(new GuiButtonPala(2, k + 50, l + 90, 100, 20, I18n.format("gui.achievements", new Object[0])));
/*  47 */     this.buttonList.add(new GuiButtonPala(3, k + 50, l + 110, 100, 20, I18n.format("gui.stats", new Object[0])));
/*     */     
/*  49 */     this.buttonList.add(new GuiButtonPala(4, k + this.xSize - 130, l + 90, 100, 20, I18n.format("menu.options", new Object[0])));
/*  50 */     this.buttonList.add(new GuiButtonPala(5, k + this.xSize - 130, l + 110, 100, 20, I18n.format("TeamSpeak", new Object[0])));
/*     */   }
/*     */   
/*     */ 
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/*  56 */     switch (button.id)
/*     */     {
/*     */     case 0: 
/*  59 */       button.enabled = false;
/*  60 */       this.mc.theWorld.sendQuittingDisconnectingPacket();
/*  61 */       this.mc.loadWorld((WorldClient)null);
/*  62 */       this.mc.displayGuiScreen(new GuiMainMenu());
/*  63 */       break;
/*     */     
/*     */     case 1: 
/*  66 */       this.mc.displayGuiScreen((GuiScreen)null);
/*  67 */       this.mc.setIngameFocus();
/*  68 */       break;
/*     */     
/*     */     case 2: 
/*  71 */       if (this.mc.thePlayer != null) {
/*  72 */         this.mc.displayGuiScreen(new GuiAchievements(this, this.mc.thePlayer.getStatFileWriter()));
/*     */       }
/*     */       break;
/*     */     case 3: 
/*  76 */       if (this.mc.thePlayer != null) {
/*  77 */         this.mc.displayGuiScreen(new GuiStats(this, this.mc.thePlayer.getStatFileWriter()));
/*     */       }
/*     */       break;
/*     */     case 4: 
/*  81 */       this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
/*  82 */       break;
/*     */     
/*     */     case 5: 
/*     */       try
/*     */       {
/*  87 */         Desktop.getDesktop().browse(new URI("ts3server://ts.paladium-pvp.fr/?nickname=" + Minecraft.getMinecraft().getSession().getUsername()));
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*  91 */         e.printStackTrace();
/*     */       }
/*     */       catch (URISyntaxException e)
/*     */       {
/*  95 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawDefaultBackground()
/*     */   {
/* 104 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 105 */     int k = (this.width - this.xSize) / 2;
/* 106 */     int l = (this.height - this.ySize) / 2;
/* 107 */     this.mc.getTextureManager().bindTexture(this.background);
/* 108 */     GuiDrawer.drawTexturedQuadFit(k + 120, l + 20, 275.0D, 175.0D, 0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void drawScreen(int x, int y, float par3)
/*     */   {
/* 115 */     drawDefaultBackground();
/*     */     
/* 117 */     super.drawScreen(x, y, par3);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\custom\GuiInGameMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */