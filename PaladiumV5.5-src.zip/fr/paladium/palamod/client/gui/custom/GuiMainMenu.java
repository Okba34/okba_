/*     */ package fr.paladium.palamod.client.gui.custom;
/*     */ 
/*     */ import cpw.mods.fml.client.FMLClientHandler;
/*     */ import fr.paladium.palamod.client.gui.GuiButtonPala;
/*     */ import java.awt.Desktop;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.Clip;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiConfirmOpenLink;
/*     */ import net.minecraft.client.gui.GuiOptions;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiYesNoCallback;
/*     */ import net.minecraft.client.renderer.OpenGlHelper;
/*     */ import net.minecraft.client.renderer.Tessellator;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.client.shader.Framebuffer;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.util.Session;
/*     */ import net.minecraft.world.storage.ISaveFormat;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ import org.lwjgl.opengl.ContextCapabilities;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GLContext;
/*     */ import org.lwjgl.util.glu.Project;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiMainMenu
/*     */   extends GuiScreen
/*     */   implements GuiYesNoCallback
/*     */ {
/*  49 */   private static final Logger logger = ;
/*  50 */   private static final Random rand = new Random();
/*     */   private float updateCounter;
/*     */   private String splashText;
/*     */   private GuiButton buttonResetDemo;
/*     */   private int panoramaTimer;
/*     */   private Clip clip;
/*     */   private DynamicTexture viewportTexture;
/*  57 */   private final Object field_104025_t = new Object();
/*     */   private String field_92025_p;
/*     */   private String field_146972_A;
/*     */   private String field_104024_v;
/*  61 */   public static boolean play = true;
/*  62 */   public static String mute = "Mute/Play";
/*  63 */   private static final ResourceLocation minecraftTitleTextures = new ResourceLocation("palamod:textures/gui/LOGO.png");
/*     */   
/*  65 */   private static final ResourceLocation[] titlePanoramaPaths = { new ResourceLocation("palamod:textures/gui/bg.png"), new ResourceLocation("palamod:textures/gui/bg.png"), new ResourceLocation("palamod:textures/gui/bg.png"), new ResourceLocation("palamod:textures/gui/bg.png"), new ResourceLocation("palamod:textures/gui/bg.png"), new ResourceLocation("palamod:textures/gui/bg.png") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public static final String field_96138_a = "Please click " + EnumChatFormatting.UNDERLINE + "here" + EnumChatFormatting.RESET + " for more information.";
/*     */   private int field_92024_r;
/*     */   private int field_92023_s;
/*     */   private int field_92022_t;
/*     */   private int field_92021_u;
/*     */   private int field_92020_v;
/*     */   private int field_92019_w;
/*     */   private AudioInputStream audioIn;
/*     */   private ResourceLocation field_110351_G;
/*     */   private static final String __OBFID = "CL_00001154";
/*     */   
/*     */   public GuiMainMenu()
/*     */   {
/*  85 */     this.field_146972_A = field_96138_a;
/*  86 */     this.splashText = "missingno";
/*  87 */     BufferedReader bufferedreader = null;
/*     */     
/*  89 */     this.updateCounter = rand.nextFloat();
/*  90 */     this.field_92025_p = "";
/*     */     
/*  92 */     if ((!GLContext.getCapabilities().OpenGL20) && (!OpenGlHelper.func_153193_b())) {
/*  93 */       this.field_92025_p = I18n.format("title.oldgl1", new Object[0]);
/*  94 */       this.field_146972_A = I18n.format("title.oldgl2", new Object[0]);
/*  95 */       this.field_104024_v = "https://help.mojang.com/customer/portal/articles/325948?ref=game";
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateScreen() {
/* 100 */     this.panoramaTimer += 1;
/*     */   }
/*     */   
/*     */   public boolean doesGuiPauseGame() {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void keyTyped(char p_73869_1_, int p_73869_2_) {}
/*     */   
/*     */   public void initGui()
/*     */   {
/* 112 */     this.viewportTexture = new DynamicTexture(256, 256);
/* 113 */     this.field_110351_G = this.mc.getTextureManager().getDynamicTextureLocation("background", this.viewportTexture);
/* 114 */     Calendar calendar = Calendar.getInstance();
/* 115 */     calendar.setTime(new Date());
/*     */     
/*     */ 
/*     */ 
/* 119 */     boolean flag = true;
/* 120 */     int i = this.height / 4 + 48;
/*     */     
/* 122 */     if (!this.mc.isDemo())
/*     */     {
/* 124 */       addSingleplayerMultiplayerButtons(i, 24);
/*     */     }
/*     */     
/* 127 */     this.buttonList.add(new GuiButtonPala(0, this.width / 2 - 100, 182, 98, 20, 
/* 128 */       I18n.format("menu.options", new Object[0])));
/* 129 */     this.buttonList.add(new GuiButtonPala(4, this.width / 2 + 2, 182, 98, 20, 
/* 130 */       I18n.format("menu.quit", new Object[0])));
/*     */     
/*     */ 
/*     */ 
/* 134 */     synchronized (this.field_104025_t) {
/* 135 */       this.field_92023_s = this.fontRendererObj.getStringWidth(this.field_92025_p);
/* 136 */       this.field_92024_r = this.fontRendererObj.getStringWidth(this.field_146972_A);
/* 137 */       int j = Math.max(this.field_92023_s, this.field_92024_r);
/* 138 */       this.field_92022_t = ((this.width - j) / 2);
/* 139 */       this.field_92021_u = (((GuiButtonPala)this.buttonList.get(0)).yPosition - 24);
/* 140 */       this.field_92020_v = (this.field_92022_t + j);
/* 141 */       this.field_92019_w = (this.field_92021_u + 24);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addSingleplayerMultiplayerButtons(int x, int y) {
/* 146 */     this.buttonList.add(new GuiButtonPala(65, this.width / 2 - 160, 110, 40, 30, "Site Web")
/*     */     {
/*     */       public void mouseReleased(int x, int y) {
/*     */         try {
/* 150 */           Desktop.getDesktop().browse(new URI("https://paladium-pvp.fr/"));
/*     */         } catch (IOException e) {
/* 152 */           e.printStackTrace();
/*     */         } catch (URISyntaxException e) {
/* 154 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 157 */     });
/* 158 */     this.buttonList.add(new GuiButtonPala(64, this.width / 2 + 120, 110, 40, 30, "Teamspeak")
/*     */     {
/*     */       public void mouseReleased(int x, int y) {
/*     */         try {
/* 162 */           Desktop.getDesktop().browse(new URI("ts3server://ts.paladium-pvp.fr/?nickname=" + 
/* 163 */             Minecraft.getMinecraft().getSession().getUsername()));
/*     */         } catch (IOException e) {
/* 165 */           e.printStackTrace();
/*     */         } catch (URISyntaxException e) {
/* 167 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 170 */     });
/* 171 */     this.buttonList.add(new GuiButtonPala(20, this.width / 2 - 20, 30, 40, 30, I18n.format("PALADIUM", new Object[0])) {});
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/* 191 */     if (button.id == 0) {
/* 192 */       this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
/*     */     }
/* 194 */     if ((button.id != 5) || 
/*     */     
/*     */ 
/* 197 */       (button.id == 1)) {
/*     */       try {
/* 199 */         Class oclass = Class.forName("java.awt.Desktop");
/* 200 */         Object object = oclass.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
/* 201 */         oclass.getMethod("browse", new Class[] { URI.class }).invoke(object, new Object[] { new URI("https://www.youtube.com/watch?v=N9ciqYfHlUY") });
/*     */       }
/*     */       catch (Throwable throwable) {
/* 204 */         logger.error("Couldn't open link", throwable);
/*     */       }
/*     */     }
/*     */     
/* 208 */     if ((button.id != 2) || 
/*     */     
/*     */ 
/* 211 */       (button.id == 4)) {
/* 212 */       this.mc.shutdown();
/*     */     }
/*     */     
/* 215 */     if ((button.id != 6) || (
/*     */     
/*     */ 
/* 218 */       (button.id != 11) || (
/*     */       
/*     */ 
/* 221 */       (button.id != 12) || 
/*     */       
/*     */ 
/* 224 */       (button.id == 20)))) {
/* 225 */       FMLClientHandler.instance().connectToServerAtStartup("proxy.paladium-pvp.fr", 25565);
/*     */     }
/*     */     
/* 228 */     if (button.id == 21) {
/* 229 */       this.fontRendererObj.setUnicodeFlag(false);
/*     */       try {
/* 231 */         Class oclass = Class.forName("java.awt.Desktop");
/* 232 */         Object object = oclass.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
/* 233 */         oclass.getMethod("browse", new Class[] { URI.class }).invoke(object, new Object[] { new URI("http://www.paladium-pvp.fr") });
/*     */       }
/*     */       catch (Throwable throwable) {
/* 236 */         logger.error("Couldn't open link", throwable);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void confirmClicked(boolean p_73878_1_, int id) {
/* 242 */     if ((p_73878_1_) && (id == 12)) {
/* 243 */       ISaveFormat isaveformat = this.mc.getSaveLoader();
/* 244 */       isaveformat.flushCache();
/* 245 */       this.mc.displayGuiScreen(this);
/* 246 */     } else if (id == 13) {
/* 247 */       if (p_73878_1_) {
/*     */         try {
/* 249 */           Class oclass = Class.forName("java.awt.Desktop");
/* 250 */           Object object = oclass.getMethod("getDesktop", new Class[0]).invoke(null, new Object[0]);
/* 251 */           oclass.getMethod("browse", new Class[] { URI.class }).invoke(object, new Object[] { new URI(this.field_104024_v) });
/*     */         }
/*     */         catch (Throwable throwable) {
/* 254 */           logger.error("Couldn't open link", throwable);
/*     */         }
/*     */       }
/*     */       
/* 258 */       this.mc.displayGuiScreen(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private void drawPanorama(int x, int y, float partialTick) {
/* 263 */     Tessellator tessellator = Tessellator.instance;
/* 264 */     GL11.glMatrixMode(5889);
/* 265 */     GL11.glPushMatrix();
/* 266 */     GL11.glLoadIdentity();
/* 267 */     Project.gluPerspective(120.0F, 1.0F, 0.05F, 10.0F);
/* 268 */     GL11.glMatrixMode(5888);
/* 269 */     GL11.glPushMatrix();
/* 270 */     GL11.glLoadIdentity();
/* 271 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 272 */     GL11.glRotatef(180.0F, 1.0F, 0.0F, 0.0F);
/* 273 */     GL11.glRotatef(90.0F, 0.0F, 0.0F, 1.0F);
/* 274 */     GL11.glEnable(3042);
/* 275 */     GL11.glDisable(3008);
/* 276 */     GL11.glDisable(2884);
/* 277 */     GL11.glDepthMask(false);
/* 278 */     OpenGlHelper.glBlendFunc(770, 771, 1, 0);
/* 279 */     byte b0 = 8;
/*     */     
/* 281 */     for (int k = 0; k < b0 * b0; k++) {
/* 282 */       GL11.glPushMatrix();
/* 283 */       float f1 = (k % b0 / b0 - 0.5F) / 64.0F;
/* 284 */       float f2 = (k / b0 / b0 - 0.5F) / 64.0F;
/* 285 */       float f3 = 0.0F;
/* 286 */       GL11.glTranslatef(f1, f2, f3);
/* 287 */       GL11.glRotatef(MathHelper.sin((this.panoramaTimer + partialTick) / 400.0F) * 25.0F + 20.0F, 1.0F, 0.0F, 0.0F);
/*     */       
/* 289 */       GL11.glRotatef(-(this.panoramaTimer + partialTick) * 0.1F, 0.0F, 1.0F, 0.0F);
/*     */       
/* 291 */       for (int l = 0; l < 6; l++) {
/* 292 */         GL11.glPushMatrix();
/*     */         
/* 294 */         if (l == 1) {
/* 295 */           GL11.glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
/*     */         }
/*     */         
/* 298 */         if (l == 2) {
/* 299 */           GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
/*     */         }
/*     */         
/* 302 */         if (l == 3) {
/* 303 */           GL11.glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
/*     */         }
/*     */         
/* 306 */         if (l == 4) {
/* 307 */           GL11.glRotatef(90.0F, 1.0F, 0.0F, 0.0F);
/*     */         }
/*     */         
/* 310 */         if (l == 5) {
/* 311 */           GL11.glRotatef(-90.0F, 1.0F, 0.0F, 0.0F);
/*     */         }
/*     */         
/* 314 */         this.mc.getTextureManager().bindTexture(titlePanoramaPaths[l]);
/* 315 */         tessellator.startDrawingQuads();
/* 316 */         tessellator.setColorRGBA_I(16777215, 255 / (k + 1));
/* 317 */         float f4 = 0.0F;
/* 318 */         tessellator.addVertexWithUV(-1.0D, -1.0D, 1.0D, 0.0F + f4, 0.0F + f4);
/* 319 */         tessellator.addVertexWithUV(1.0D, -1.0D, 1.0D, 1.0F - f4, 0.0F + f4);
/* 320 */         tessellator.addVertexWithUV(1.0D, 1.0D, 1.0D, 1.0F - f4, 1.0F - f4);
/* 321 */         tessellator.addVertexWithUV(-1.0D, 1.0D, 1.0D, 0.0F + f4, 1.0F - f4);
/* 322 */         tessellator.draw();
/* 323 */         GL11.glPopMatrix();
/*     */       }
/*     */       
/* 326 */       GL11.glPopMatrix();
/* 327 */       GL11.glColorMask(true, true, true, false);
/*     */     }
/*     */     
/* 330 */     tessellator.setTranslation(0.0D, 0.0D, 0.0D);
/* 331 */     GL11.glColorMask(true, true, true, true);
/* 332 */     GL11.glMatrixMode(5889);
/* 333 */     GL11.glPopMatrix();
/* 334 */     GL11.glMatrixMode(5888);
/* 335 */     GL11.glPopMatrix();
/* 336 */     GL11.glDepthMask(true);
/* 337 */     GL11.glEnable(2884);
/* 338 */     GL11.glEnable(2929);
/*     */   }
/*     */   
/*     */   private void rotateAndBlurSkybox(float partialTick) {
/* 342 */     this.mc.getTextureManager().bindTexture(this.field_110351_G);
/* 343 */     GL11.glTexParameteri(3553, 10241, 9729);
/* 344 */     GL11.glTexParameteri(3553, 10240, 9729);
/* 345 */     GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, 256, 256);
/* 346 */     GL11.glEnable(3042);
/* 347 */     OpenGlHelper.glBlendFunc(770, 771, 1, 0);
/* 348 */     GL11.glColorMask(true, true, true, false);
/* 349 */     Tessellator tessellator = Tessellator.instance;
/* 350 */     tessellator.startDrawingQuads();
/* 351 */     GL11.glDisable(3008);
/* 352 */     byte b0 = 3;
/*     */     
/* 354 */     for (int i = 0; i < b0; i++) {
/* 355 */       tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F / (i + 1));
/* 356 */       int j = this.width;
/* 357 */       int k = this.height;
/* 358 */       float f1 = (i - b0 / 2) / 256.0F;
/* 359 */       tessellator.addVertexWithUV(j, k, this.zLevel, 0.0F + f1, 1.0D);
/* 360 */       tessellator.addVertexWithUV(j, 0.0D, this.zLevel, 1.0F + f1, 1.0D);
/* 361 */       tessellator.addVertexWithUV(0.0D, 0.0D, this.zLevel, 1.0F + f1, 0.0D);
/* 362 */       tessellator.addVertexWithUV(0.0D, k, this.zLevel, 0.0F + f1, 0.0D);
/*     */     }
/*     */     
/* 365 */     tessellator.draw();
/* 366 */     GL11.glEnable(3008);
/* 367 */     GL11.glColorMask(true, true, true, true);
/*     */   }
/*     */   
/*     */   private void renderSkybox(int x, int y, float partialTick) {
/* 371 */     this.mc.getFramebuffer().unbindFramebuffer();
/* 372 */     GL11.glViewport(0, 0, 256, 256);
/* 373 */     drawPanorama(x, y, partialTick);
/* 374 */     rotateAndBlurSkybox(partialTick);
/* 375 */     rotateAndBlurSkybox(partialTick);
/* 376 */     rotateAndBlurSkybox(partialTick);
/* 377 */     rotateAndBlurSkybox(partialTick);
/* 378 */     rotateAndBlurSkybox(partialTick);
/* 379 */     rotateAndBlurSkybox(partialTick);
/* 380 */     rotateAndBlurSkybox(partialTick);
/* 381 */     this.mc.getFramebuffer().bindFramebuffer(true);
/* 382 */     GL11.glViewport(0, 0, this.mc.displayWidth, this.mc.displayHeight);
/* 383 */     Tessellator tessellator = Tessellator.instance;
/* 384 */     tessellator.startDrawingQuads();
/* 385 */     float f1 = this.width > this.height ? 120.0F / this.width : 120.0F / this.height;
/* 386 */     float f2 = this.height * f1 / 256.0F;
/* 387 */     float f3 = this.width * f1 / 256.0F;
/* 388 */     tessellator.setColorRGBA_F(1.0F, 1.0F, 1.0F, 1.0F);
/* 389 */     int k = this.width;
/* 390 */     int l = this.height;
/* 391 */     tessellator.addVertexWithUV(0.0D, l, this.zLevel, 0.5F - f2, 0.5F + f3);
/* 392 */     tessellator.addVertexWithUV(k, l, this.zLevel, 0.5F - f2, 0.5F - f3);
/*     */     
/* 394 */     tessellator.addVertexWithUV(k, 0.0D, this.zLevel, 0.5F + f2, 0.5F - f3);
/* 395 */     tessellator.addVertexWithUV(0.0D, 0.0D, this.zLevel, 0.5F + f2, 0.5F + f3);
/* 396 */     tessellator.draw();
/*     */   }
/*     */   
/* 399 */   public static void drawTexturedQuadFit(double x, double y, double width, double height, double zLevel) { Tessellator tessellator = Tessellator.instance;
/* 400 */     tessellator.startDrawingQuads();
/* 401 */     tessellator.addVertexWithUV(x + 0.0D, y + height, zLevel, 0.0D, 1.0D);
/* 402 */     tessellator.addVertexWithUV(x + width, y + height, zLevel, 1.0D, 1.0D);
/* 403 */     tessellator.addVertexWithUV(x + width, y + 0.0D, zLevel, 1.0D, 0.0D);
/* 404 */     tessellator.addVertexWithUV(x + 0.0D, y + 0.0D, zLevel, 0.0D, 0.0D);
/* 405 */     tessellator.draw();
/*     */   }
/*     */   
/*     */   public void drawScreen(int x, int y, float partialTick) {
/* 409 */     GL11.glDisable(3008);
/* 410 */     renderSkybox(x, y, partialTick);
/* 411 */     GL11.glEnable(3008);
/* 412 */     Tessellator tessellator = Tessellator.instance;
/* 413 */     short short1 = 274;
/* 414 */     int k = this.width / 2 - short1 / 2;
/* 415 */     byte b0 = 30;
/* 416 */     drawGradientRect(0, 0, this.width, this.height, -2130706433, 16777215);
/* 417 */     drawGradientRect(0, 0, this.width, this.height, 0, Integer.MIN_VALUE);
/* 418 */     GL11.glPushMatrix();
/* 419 */     this.mc.renderEngine.bindTexture(minecraftTitleTextures);
/*     */     
/* 421 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 422 */     drawTexturedQuadFit(k + 8, b0 + 25, 256.0D, 144.0D, 0.0D);
/*     */     
/*     */ 
/* 425 */     GL11.glPopMatrix();
/* 426 */     tessellator.setColorOpaque_I(-1);
/* 427 */     GL11.glPushMatrix();
/* 428 */     GL11.glTranslatef(this.width / 2 + 90, 70.0F, 0.0F);
/* 429 */     GL11.glRotatef(-20.0F, 0.0F, 0.0F, 1.0F);
/* 430 */     GL11.glPopMatrix();
/* 431 */     this.fontRendererObj.setUnicodeFlag(true);
/* 432 */     String s = "Paladium 5.5";
/* 433 */     drawString(this.fontRendererObj, s, this.width - this.fontRendererObj.getStringWidth(s) - 2, this.height - 20, -120000);
/*     */     
/* 435 */     String s1 = "Copyright Paladium - Mojang AB.";
/* 436 */     drawString(this.fontRendererObj, s1, this.width - this.fontRendererObj.getStringWidth(s1) - 2, this.height - 10, 40536);
/*     */     
/*     */ 
/* 439 */     if ((this.field_92025_p != null) && (this.field_92025_p.length() > 0)) {
/* 440 */       drawRect(this.field_92022_t - 2, this.field_92021_u - 2, this.field_92020_v + 2, this.field_92019_w - 1, 1428160512);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 445 */     super.drawScreen(x, y, partialTick);
/* 446 */     FontRenderer v2 = Minecraft.getMinecraft().fontRenderer;
/* 447 */     if (Keyboard.isKeyDown(61))
/*     */     {
/* 449 */       v2.drawStringWithShadow("x: 666", 30, 30, 16711680);
/* 450 */       v2.drawStringWithShadow("y: 666", 30, 40, 16711680);
/* 451 */       v2.drawStringWithShadow("z: 666", 30, 50, 16711680);
/* 452 */       v2.drawStringWithShadow("fps: 666", 30, 60, 16711680);
/*     */       
/* 454 */       if ((Keyboard.isKeyDown(50)) && (Keyboard.isKeyDown(25))) {
/* 455 */         v2.drawStringWithShadow("Sam54 et HeavenIsALie sont des beau gosses", 50, 100, 16711680);
/*     */       }
/*     */     }
/* 458 */     Staff[] staffs = { new Staff(new int[] { 19, 18, 32 }, new String[] { "Redshift est le plus beau", "C'est la blague que Sam a fait", "Et Heaven a beaucoup ri" }), new Staff(new int[] { 25, 46, 23 }, new String[] { "PCI: L'api prï¿½fï¿½rï¿½e de ceux qui ne savent pas dï¿½velopper" }), new Staff(new int[] { 35, 23, 31 }, new String[] { "Oh hiss la saucisse", "C'est la blague que heaven a fait", "Et Sam a beaucoup ri" }) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 467 */     for (Staff staff : staffs) {
/* 468 */       boolean correct = true;
/* 469 */       for (int key : staff.keys) {
/* 470 */         if (!Keyboard.isKeyDown(key)) {
/* 471 */           correct = false;
/*     */         }
/*     */       }
/*     */       
/* 475 */       if (correct) {
/* 476 */         for (int i = 0; i < staff.phrases.length; i++)
/* 477 */           v2.drawStringWithShadow(staff.phrases[i], 30, 30 + i * 10, 16711680);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Staff {
/* 483 */     public int[] keys = null;
/* 484 */     public String[] phrases = null;
/*     */     
/*     */     public Staff(int[] pKeys, String[] pPhrases) {
/* 487 */       this.phrases = pPhrases;
/* 488 */       this.keys = pKeys;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void mouseClicked(int p_73864_1_, int p_73864_2_, int p_73864_3_) {
/* 493 */     super.mouseClicked(p_73864_1_, p_73864_2_, p_73864_3_);
/* 494 */     Object object = this.field_104025_t;
/*     */     
/* 496 */     synchronized (this.field_104025_t) {
/* 497 */       if ((this.field_92025_p.length() > 0) && (p_73864_1_ >= this.field_92022_t) && (p_73864_1_ <= this.field_92020_v) && (p_73864_2_ >= this.field_92021_u) && (p_73864_2_ <= this.field_92019_w))
/*     */       {
/* 499 */         GuiConfirmOpenLink guiconfirmopenlink = new GuiConfirmOpenLink(this, this.field_104024_v, 13, true);
/* 500 */         guiconfirmopenlink.func_146358_g();
/* 501 */         this.mc.displayGuiScreen(guiconfirmopenlink);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\custom\GuiMainMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */