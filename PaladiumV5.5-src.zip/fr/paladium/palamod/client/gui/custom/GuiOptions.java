/*     */ package fr.paladium.palamod.client.gui.custom;
/*     */ 
/*     */ import fr.paladium.palamod.client.gui.GuiButtonPala;
/*     */ import fr.paladium.palamod.client.gui.GuiOptionSliderPala;
/*     */ import fr.paladium.palamod.util.GuiDrawer;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiControls;
/*     */ import net.minecraft.client.gui.GuiLanguage;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.gui.GuiScreenOptionsSounds;
/*     */ import net.minecraft.client.gui.GuiScreenResourcePacks;
/*     */ import net.minecraft.client.gui.GuiVideoSettings;
/*     */ import net.minecraft.client.gui.ScreenChatOptions;
/*     */ import net.minecraft.client.gui.stream.GuiStreamOptions;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.client.settings.GameSettings.Options;
/*     */ import net.minecraft.client.stream.IStream;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class GuiOptions extends GuiScreen
/*     */ {
/*  26 */   private ResourceLocation background = new ResourceLocation("palamod", "textures/gui/LOGO.png");
/*     */   private GuiScreen previousGui;
/*     */   private GameSettings settings;
/*     */   
/*     */   public GuiOptions(GuiScreen prev, GameSettings setting)
/*     */   {
/*  32 */     this.previousGui = prev;
/*  33 */     this.settings = setting;
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  38 */     int i = 0;
/*  39 */     int centerX = this.width / 2;
/*  40 */     int centerY = this.height / 6;
/*     */     
/*  42 */     GameSettings.Options options = GameSettings.Options.FOV;
/*     */     
/*  44 */     this.buttonList.add(new GuiButtonPala(0, centerX - 155, centerY + 80, 150, 20, I18n.format("options.sounds", new Object[0])));
/*  45 */     this.buttonList.add(new GuiButtonPala(1, centerX - 155, centerY + 100, 150, 20, I18n.format("options.video", new Object[0])));
/*  46 */     this.buttonList.add(new GuiButtonPala(2, centerX - 155, centerY + 120, 150, 20, I18n.format("options.language", new Object[0])));
/*  47 */     this.buttonList.add(new GuiButtonPala(3, centerX - 155, centerY + 140, 150, 20, I18n.format("options.resourcepack", new Object[0])));
/*     */     
/*  49 */     this.buttonList.add(new GuiOptionSliderPala(4, centerX + 5, centerY + 80, options, false));
/*  50 */     this.buttonList.add(new GuiButtonPala(5, centerX + 5, centerY + 100, 150, 20, I18n.format("options.stream", new Object[0])));
/*  51 */     this.buttonList.add(new GuiButtonPala(6, centerX + 5, centerY + 120, 150, 20, I18n.format("options.controls", new Object[0])));
/*  52 */     this.buttonList.add(new GuiButtonPala(7, centerX + 5, centerY + 140, 150, 20, I18n.format("options.multiplayer.title", new Object[0])));
/*     */     
/*  54 */     this.buttonList.add(new GuiButtonPala(8, centerX - 50, centerY + 160, 100, 20, I18n.format("gui.done", new Object[0]), true));
/*     */   }
/*     */   
/*     */ 
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/*  60 */     switch (button.id)
/*     */     {
/*     */     case 0: 
/*  63 */       changeOption(new GuiScreenOptionsSounds(this, this.settings));
/*  64 */       break;
/*     */     
/*     */     case 1: 
/*  67 */       changeOption(new GuiVideoSettings(this, this.settings));
/*  68 */       break;
/*     */     
/*     */     case 2: 
/*  71 */       changeOption(new GuiLanguage(this, this.settings, this.mc.getLanguageManager()));
/*  72 */       break;
/*     */     
/*     */     case 3: 
/*  75 */       changeOption(new GuiScreenResourcePacks(this));
/*  76 */       break;
/*     */     
/*     */     case 5: 
/*  79 */       this.mc.gameSettings.saveOptions();
/*  80 */       IStream istream = this.mc.func_152346_Z();
/*     */       
/*  82 */       if ((istream.func_152936_l()) && (istream.func_152928_D())) {
/*  83 */         this.mc.displayGuiScreen(new GuiStreamOptions(this, this.settings));
/*     */       } else
/*  85 */         net.minecraft.client.gui.stream.GuiStreamUnavailable.func_152321_a(this);
/*  86 */       break;
/*     */     
/*     */     case 6: 
/*  89 */       changeOption(new GuiControls(this, this.settings));
/*  90 */       break;
/*     */     
/*     */     case 7: 
/*  93 */       changeOption(new ScreenChatOptions(this, this.settings));
/*  94 */       break;
/*     */     
/*     */     case 8: 
/*  97 */       changeOption(this.previousGui);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   private void changeOption(GuiScreen gui)
/*     */   {
/* 104 */     this.mc.gameSettings.saveOptions();
/* 105 */     this.mc.displayGuiScreen(gui);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawDefaultBackground()
/*     */   {
/* 111 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 112 */     int centerX = this.width / 2;
/* 113 */     int centerY = this.height / 6;
/* 114 */     this.mc.getTextureManager().bindTexture(this.background);
/* 115 */     GuiDrawer.drawTexturedQuadFit(centerX - 125, centerY - 40, 250.0D, 150.0D, 0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawScreen(int x, int y, float par3)
/*     */   {
/* 121 */     drawDefaultBackground();
/*     */     
/* 123 */     super.drawScreen(x, y, par3);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\custom\GuiOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */