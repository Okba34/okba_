/*     */ package fr.paladium.palamod.client.gui;
/*     */ 
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.network.packets.PacketGuardianWhitelist;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.entity.EntityClientPlayerMP;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiTextField;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.client.settings.KeyBinding;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class GuiGuardianWhitelist extends GuiContainer
/*     */ {
/*     */   GuiTextField usernameInput;
/*     */   FontRenderer fontRendererObj;
/*     */   ItemStack stack;
/*  24 */   final ResourceLocation background = new ResourceLocation("palamod:textures/gui/GuardianWhitelist.png");
/*     */   
/*     */   public GuiGuardianWhitelist(ItemStack stack, InventoryPlayer inventory) {
/*  27 */     super(new fr.paladium.palamod.common.gui.ContainerGuardianWhitelist(inventory));
/*  28 */     this.stack = stack;
/*  29 */     this.fontRendererObj = Minecraft.getMinecraft().fontRenderer;
/*  30 */     this.xSize = 176;
/*  31 */     this.ySize = 147;
/*     */   }
/*     */   
/*     */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*     */   {
/*  36 */     this.mc.renderEngine.bindTexture(this.background);
/*  37 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  38 */     int x = (this.width - this.xSize) / 2;
/*  39 */     int y = (this.height - this.ySize) / 2;
/*  40 */     drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
/*  41 */     this.usernameInput.drawTextBox();
/*     */   }
/*     */   
/*     */   public void initGui()
/*     */   {
/*  46 */     super.initGui();
/*  47 */     int x = (this.width - this.xSize) / 2;
/*  48 */     int y = (this.height - this.ySize) / 2;
/*  49 */     this.buttonList.add(new GuiButton(0, x + 4, y + 37, 50, 20, "Add"));
/*  50 */     this.buttonList.add(new GuiButton(1, x + 59, y + 37, 50, 20, "Remove"));
/*  51 */     this.usernameInput = new GuiTextField(this.fontRendererObj, x + 5, y + 20, 165, 15);
/*  52 */     this.usernameInput.setFocused(false);
/*  53 */     this.usernameInput.setCanLoseFocus(true);
/*  54 */     this.usernameInput.setText("");
/*     */   }
/*     */   
/*     */   public void onGuiClosed()
/*     */   {
/*  59 */     org.lwjgl.input.Keyboard.enableRepeatEvents(false);
/*     */   }
/*     */   
/*     */   protected void mouseClicked(int par1, int par2, int par3)
/*     */   {
/*  64 */     super.mouseClicked(par1, par2, par3);
/*  65 */     this.usernameInput.mouseClicked(par1, par2, par3);
/*     */   }
/*     */   
/*     */   protected void keyTyped(char par1, int pressedKey)
/*     */   {
/*  70 */     if ((pressedKey == 1) || ((!this.usernameInput.isFocused()) && 
/*  71 */       (pressedKey == this.mc.gameSettings.keyBindInventory.getKeyCode()))) {
/*  72 */       this.mc.thePlayer.closeScreen();
/*     */     }
/*  74 */     this.usernameInput.textboxKeyTyped(par1, pressedKey);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawGuiContainerForegroundLayer(int param1, int param2)
/*     */   {
/*  80 */     this.fontRendererObj.drawString("Guardian Whitelist", 5, 8, 4210752);
/*     */   }
/*     */   
/*     */   public void updateScreen()
/*     */   {
/*  85 */     super.updateScreen();
/*  86 */     this.usernameInput.updateCursorCounter();
/*     */   }
/*     */   
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/*  91 */     switch (button.id) {
/*     */     case 0: 
/*  93 */       PacketGuardianWhitelist packet = new PacketGuardianWhitelist();
/*  94 */       packet.addInformations(this.usernameInput.getText(), true);
/*  95 */       CommonProxy.packetPipeline.sendToServer(packet);
/*  96 */       this.mc.thePlayer.closeScreen();
/*  97 */       return;
/*     */     case 1: 
/*  99 */       PacketGuardianWhitelist packet1 = new PacketGuardianWhitelist();
/* 100 */       packet1.addInformations(this.usernameInput.getText(), false);
/* 101 */       CommonProxy.packetPipeline.sendToServer(packet1);
/* 102 */       this.mc.thePlayer.closeScreen();
/* 103 */       return;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiGuardianWhitelist.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */