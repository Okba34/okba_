/*     */ package fr.paladium.palamod.client.gui;
/*     */ 
/*     */ import fr.paladium.palamod.entities.mobs.EntityCamera;
/*     */ import fr.paladium.palamod.network.PacketPipeline;
/*     */ import fr.paladium.palamod.network.packets.PacketCamera;
/*     */ import fr.paladium.palamod.proxy.CommonProxy;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.GuiButton;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class GuiCameraTablet extends GuiScreen
/*     */ {
/*  18 */   public static final ResourceLocation texture = new ResourceLocation("palamod", "textures/gui/camera.png");
/*     */   
/*     */   private EntityPlayer player;
/*     */   private ItemStack stack;
/*     */   private GuiButton delete1;
/*     */   
/*     */   public GuiCameraTablet(EntityPlayer myPlayer)
/*     */   {
/*  26 */     this.player = myPlayer;
/*  27 */     this.stack = this.player.getHeldItem();
/*  28 */     this.xSize = 150;
/*  29 */     this.ySize = 100;
/*     */     
/*  31 */     if (!this.stack.hasTagCompound())
/*     */     {
/*  33 */       this.stack.setTagCompound(new NBTTagCompound());
/*     */       
/*  35 */       this.stack.getTagCompound().setBoolean("cam1", false);
/*  36 */       this.stack.getTagCompound().setBoolean("cam2", false);
/*  37 */       this.stack.getTagCompound().setBoolean("cam3", false);
/*     */     } }
/*     */   
/*     */   private GuiButton delete2;
/*     */   private GuiButton delete3;
/*     */   private int xSize;
/*     */   private int ySize;
/*  44 */   public void initGui() { int k = (this.width - this.xSize) / 2;
/*  45 */     int l = (this.height - this.ySize) / 2;
/*  46 */     int posX = k + this.xSize - 10;
/*     */     
/*  48 */     int tmp = getButtonSize(getCoordonates(1));
/*  49 */     this.buttonList.add(this.delete1 = new GuiButton(0, posX - tmp, l + 10, tmp, 20, "Delete"));
/*  50 */     this.delete1.enabled = (!getCoordonates(1).equals("Undefined"));
/*     */     
/*  52 */     tmp = getButtonSize(getCoordonates(2));
/*  53 */     this.buttonList.add(this.delete2 = new GuiButton(1, posX - tmp, l + 40, tmp, 20, "Delete"));
/*  54 */     this.delete2.enabled = (!getCoordonates(2).equals("Undefined"));
/*     */     
/*  56 */     tmp = getButtonSize(getCoordonates(3));
/*  57 */     this.buttonList.add(this.delete3 = new GuiButton(2, posX - tmp, l + 70, tmp, 20, "Delete"));
/*  58 */     this.delete3.enabled = (!getCoordonates(3).equals("Undefined"));
/*     */   }
/*     */   
/*     */   private int getButtonSize(String text)
/*     */   {
/*  63 */     return 125 - this.fontRendererObj.getStringWidth(text);
/*     */   }
/*     */   
/*     */   private String getCoordonates(int id)
/*     */   {
/*  68 */     NBTTagCompound compound = this.stack.getTagCompound();
/*  69 */     if ((id == 1) && (compound.getBoolean("cam1")))
/*  70 */       return compound.getInteger("cam1X") + " â€¢ " + compound.getInteger("cam1Y") + " â€¢ " + compound.getInteger("cam1Z");
/*  71 */     if ((id == 2) && (compound.getBoolean("cam2")))
/*  72 */       return compound.getInteger("cam2X") + " â€¢ " + compound.getInteger("cam2Y") + " â€¢ " + compound.getInteger("cam2Z");
/*  73 */     if ((id == 3) && (compound.getBoolean("cam3"))) {
/*  74 */       return compound.getInteger("cam3X") + " â€¢ " + compound.getInteger("cam3Y") + " â€¢ " + compound.getInteger("cam3Z");
/*     */     }
/*  76 */     return "Undefined";
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawDefaultBackground()
/*     */   {
/*  82 */     org.lwjgl.opengl.GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  83 */     this.mc.getTextureManager().bindTexture(texture);
/*  84 */     int k = (this.width - this.xSize) / 2;
/*  85 */     int l = (this.height - this.ySize) / 2;
/*  86 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawScreen(int par1, int par2, float par3)
/*     */   {
/*  92 */     drawDefaultBackground();
/*     */     
/*  94 */     int k = (this.width - this.xSize) / 2;
/*  95 */     int l = (this.height - this.ySize) / 2;
/*  96 */     int end = k + this.xSize - 5;
/*     */     
/*  98 */     this.fontRendererObj.drawString(getCoordonates(1), k + 10, l + 15, 65280);
/*  99 */     this.fontRendererObj.drawString(getCoordonates(2), k + 10, l + 45, 65535);
/* 100 */     this.fontRendererObj.drawString(getCoordonates(3), k + 10, l + 75, 16711935);
/*     */     
/* 102 */     super.drawScreen(par1, par2, par3);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void actionPerformed(GuiButton button)
/*     */   {
/* 108 */     if (button == this.delete1)
/*     */     {
/* 110 */       this.stack.getTagCompound().setBoolean("cam1", false);
/* 111 */       this.delete1.enabled = false;
/*     */     }
/* 113 */     else if (button == this.delete2)
/*     */     {
/* 115 */       this.stack.getTagCompound().setBoolean("cam2", false);
/* 116 */       this.delete2.enabled = false;
/*     */     }
/* 118 */     else if (button == this.delete3)
/*     */     {
/* 120 */       this.stack.getTagCompound().setBoolean("cam3", false);
/* 121 */       this.delete3.enabled = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void onGuiClosed()
/*     */   {
/* 128 */     EntityCamera.destroyCamera();
/* 129 */     PacketCamera packet = new PacketCamera();
/* 130 */     packet.addInformations(this.stack.getTagCompound());
/* 131 */     CommonProxy.packetPipeline.sendToServer(packet);
/* 132 */     super.onGuiClosed();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean doesGuiPauseGame()
/*     */   {
/* 138 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiCameraTablet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */