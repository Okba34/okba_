/*    */ package fr.paladium.palamod.client.gui.button;
/*    */ 
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.util.DisplayHelper;
/*    */ import fr.paladium.palamod.util.GuardianHelper;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonGuardianChest
/*    */   extends GuiButton
/*    */ {
/* 16 */   ResourceLocation buttonLogo = new ResourceLocation("textures/items/bed.png");
/* 17 */   ResourceLocation buttonLogoHover = new ResourceLocation("textures/items/arrow.png");
/* 18 */   ResourceLocation buttonDisabled = new ResourceLocation("textures/items/apple.png");
/*    */   EntityGuardianGolem golem;
/*    */   int x;
/*    */   int y;
/*    */   
/*    */   public ButtonGuardianChest(int id, int x, int y, String text, EntityGuardianGolem golem) {
/* 24 */     super(id, x, y, text);
/* 25 */     this.x = x;
/* 26 */     this.y = y;
/* 27 */     this.golem = golem;
/* 28 */     this.width = 16;
/* 29 */     this.height = 16;
/* 30 */     this.xPosition = x;
/* 31 */     this.yPosition = y;
/*    */   }
/*    */   
/*    */   public void drawButton(Minecraft mc, int mouseX, int mouseY)
/*    */   {
/* 36 */     if (!GuardianHelper.hasUpgrade(this.golem, 5)) {
/* 37 */       mc.renderEngine.bindTexture(this.buttonDisabled);
/* 38 */       return;
/*    */     }
/* 40 */     if ((mouseX > this.x) && (mouseX < this.x + 16) && (mouseY > this.y) && (mouseY < this.y + 16)) {
/* 41 */       mc.renderEngine.bindTexture(this.buttonLogo);
/*    */     } else
/* 43 */       mc.renderEngine.bindTexture(this.buttonLogoHover);
/* 44 */     DisplayHelper.drawTexturedQuadFit(this.x, this.y, 16.0D, 16.0D, 0.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\button\ButtonGuardianChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */