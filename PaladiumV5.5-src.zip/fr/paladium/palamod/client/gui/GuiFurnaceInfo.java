/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ 
/*    */ public class GuiFurnaceInfo extends GuiContainer
/*    */ {
/*    */   FontRenderer fr;
/*    */   
/*    */   public GuiFurnaceInfo()
/*    */   {
/* 14 */     super(new fr.paladium.palamod.common.gui.ContainerEmpty());
/* 15 */     this.ySize = 166;
/* 16 */     this.xSize = 200;
/* 17 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 22 */     int k = (this.width - 50) / 2;
/* 23 */     int l = (this.height - 100) / 2;
/* 24 */     this.buttonList.add(new GuiButton(1, k, l + 50, 50, 20, "OK"));
/* 25 */     super.initGui();
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 30 */     int k1 = (this.width - this.fr.getStringWidth("Les fours sont actuellement desactives !")) / 2;
/* 31 */     int l1 = (this.height - this.ySize) / 2 + 50;
/* 32 */     int k2 = (this.width - this.fr.getStringWidth("Si vous voulez cuire des choses, utilisez la commande /furnace")) / 2;
/* 33 */     int k3 = (this.width - this.fr.getStringWidth("qui cuit le contenu de votre main !")) / 2;
/*    */     
/* 35 */     this.fr.drawStringWithShadow("Les fours sont actuellement desactives !", k1, l1, 16777215);
/* 36 */     this.fr.drawStringWithShadow("Si vous voulez cuire des choses, utilisez la commande /furnace", k2 + 5, l1 + 10, 16777215);
/* 37 */     this.fr.drawStringWithShadow("qui cuit le contenu de votre main !", k3 + 5, l1 + 20, 16777215);
/*    */   }
/*    */   
/*    */   protected void actionPerformed(GuiButton button)
/*    */   {
/* 42 */     if (button.id == 1) {
/* 43 */       this.mc.thePlayer.closeScreen();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiFurnaceInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */