/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.renderer.OpenGlHelper;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class CustomGuiButton extends GuiButton
/*    */ {
/*    */   public ResourceLocation buttonTexture;
/*    */   
/*    */   public CustomGuiButton(int id, int width, int height, String displayString, String textureName)
/*    */   {
/* 16 */     super(id, width, height, displayString);
/* 17 */     this.buttonTexture = new ResourceLocation("palamod:textures/gui/" + textureName);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void drawButton(Minecraft minecraft, int xCoord, int yCoord)
/*    */   {
/* 25 */     if (this.visible)
/*    */     {
/* 27 */       FontRenderer fontrenderer = minecraft.fontRenderer;
/* 28 */       minecraft.getTextureManager().bindTexture(this.buttonTexture);
/* 29 */       GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 30 */       this.field_146123_n = ((xCoord >= this.xPosition) && (yCoord >= this.yPosition) && (xCoord < this.xPosition + this.width) && (yCoord < this.yPosition + this.height));
/* 31 */       int k = getHoverState(this.field_146123_n);
/* 32 */       GL11.glEnable(3042);
/* 33 */       OpenGlHelper.glBlendFunc(770, 771, 1, 0);
/* 34 */       GL11.glBlendFunc(770, 771);
/* 35 */       drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + k * 20, this.width / 2, this.height);
/* 36 */       drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + k * 20, this.width / 2, this.height);
/* 37 */       mouseDragged(minecraft, xCoord, yCoord);
/* 38 */       int l = 14737632;
/*    */       
/* 40 */       if (this.packedFGColour != 0)
/*    */       {
/* 42 */         l = this.packedFGColour;
/*    */       }
/* 44 */       else if (!this.enabled)
/*    */       {
/* 46 */         l = 10526880;
/*    */       }
/* 48 */       else if (this.field_146123_n)
/*    */       {
/* 50 */         l = 16777120;
/*    */       }
/*    */       
/* 53 */       drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, l);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\CustomGuiButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */