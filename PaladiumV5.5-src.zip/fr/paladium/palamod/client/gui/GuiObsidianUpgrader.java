/*     */ package fr.paladium.palamod.client.gui;
/*     */ 
/*     */ import fr.paladium.palamod.common.gui.ContainerObsidianUpgrader;
/*     */ import fr.paladium.palamod.items.ItemObsidianUpgrade.Upgrade;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader;
/*     */ import fr.paladium.palamod.tiles.TileEntityObsidianUpgrader.Id;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.FontRenderer;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.client.renderer.texture.TextureManager;
/*     */ import net.minecraft.client.resources.I18n;
/*     */ import net.minecraft.entity.player.InventoryPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuiObsidianUpgrader
/*     */   extends GuiContainer
/*     */ {
/*  25 */   public static final ResourceLocation texture = new ResourceLocation("palamod", "textures/gui/container/obsidianUpgrader.png");
/*     */   private TileEntityObsidianUpgrader tileMachine;
/*     */   private IInventory playerInv;
/*     */   
/*     */   public GuiObsidianUpgrader(TileEntityObsidianUpgrader tile, InventoryPlayer inventory)
/*     */   {
/*  31 */     super(new ContainerObsidianUpgrader(tile, inventory));
/*     */     
/*  33 */     this.tileMachine = tile;
/*  34 */     this.playerInv = inventory;
/*  35 */     this.xSize = 210;
/*  36 */     this.ySize = 183;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawGuiContainerBackgroundLayer(float partialRenderTick, int x, int y)
/*     */   {
/*  42 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  43 */     this.mc.getTextureManager().bindTexture(texture);
/*     */     
/*  45 */     int k = (this.width - this.xSize) / 2;
/*  46 */     int l = (this.height - this.ySize) / 2;
/*  47 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/*     */     
/*  49 */     if (this.tileMachine.hasObsidian().booleanValue())
/*     */     {
/*  51 */       double h = this.tileMachine.getObsidian() * 55 / 64;
/*  52 */       int i = (int)h;
/*  53 */       int j = 91 - i;
/*  54 */       drawTexturedModalRect(k + 65, l + j, 0, 184, 55, i);
/*     */     }
/*  56 */     if (this.tileMachine.isBurning(TileEntityObsidianUpgrader.Id.input).booleanValue())
/*     */     {
/*  58 */       int i = this.tileMachine.getProgress(TileEntityObsidianUpgrader.Id.input, 29);
/*  59 */       drawTexturedModalRect(k + 31, l + 53, 210, 0, i, 16);
/*     */     }
/*  61 */     if (this.tileMachine.isBurning(TileEntityObsidianUpgrader.Id.output).booleanValue())
/*     */     {
/*  63 */       int i = this.tileMachine.getProgress(TileEntityObsidianUpgrader.Id.output, 29);
/*  64 */       drawTexturedModalRect(k + 149, l + 53, 210, 0, i, 16);
/*     */     }
/*  66 */     if (this.tileMachine.isBurning(TileEntityObsidianUpgrader.Id.obsi).booleanValue())
/*     */     {
/*  68 */       int i = this.tileMachine.getProgress(TileEntityObsidianUpgrader.Id.obsi, 18);
/*  69 */       drawTexturedModalRect(k + 78, l + 13, 210, 17, 7, i);
/*     */     }
/*  71 */     if (this.tileMachine.isBurning(TileEntityObsidianUpgrader.Id.fuel).booleanValue())
/*     */     {
/*  73 */       int i = this.tileMachine.getProgress(TileEntityObsidianUpgrader.Id.fuel, 13);
/*  74 */       int j = 13 - i;
/*  75 */       drawTexturedModalRect(k + 91, l + 14 + j, 218, 17 + j, 14, i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void drawGuiContainerForegroundLayer(int x, int y)
/*     */   {
/*  82 */     String tileName = I18n.format(this.tileMachine.getInventoryName(), new Object[0]);
/*  83 */     this.fontRendererObj.drawString(tileName, (this.xSize - this.fontRendererObj.getStringWidth(tileName)) / 2, 5, 3087688);
/*  84 */     String invName = I18n.format(this.playerInv.getInventoryName(), new Object[0]);
/*  85 */     this.fontRendererObj.drawString(invName, (this.xSize - this.fontRendererObj.getStringWidth(invName)) / 2, this.ySize - 90, 3087688);
/*  86 */     drawToolTip(x, y);
/*     */   }
/*     */   
/*     */   private void drawToolTip(int x, int y)
/*     */   {
/*  91 */     int k = (this.width - this.xSize) / 2;
/*  92 */     int l = (this.height - this.ySize) / 2;
/*     */     
/*  94 */     if ((x >= k + 65) && (y >= l + 36) && (x <= k + 120) && (y <= l + 91))
/*     */     {
/*  96 */       List list = new ArrayList();
/*  97 */       list.add(this.tileMachine.getObsidian() + " Obsidians");
/*  98 */       if (this.tileMachine.isUpgraded(ItemObsidianUpgrade.Upgrade.Explode).booleanValue())
/*  99 */         list.add(EnumChatFormatting.DARK_PURPLE + "Explode");
/* 100 */       if (this.tileMachine.isUpgraded(ItemObsidianUpgrade.Upgrade.Fake).booleanValue())
/* 101 */         list.add(EnumChatFormatting.DARK_PURPLE + "Fake");
/* 102 */       if (this.tileMachine.isUpgraded(ItemObsidianUpgrade.Upgrade.TwoLife).booleanValue())
/* 103 */         list.add(EnumChatFormatting.DARK_PURPLE + "TwoLifes");
/* 104 */       if (this.tileMachine.isUpgraded(ItemObsidianUpgrade.Upgrade.Camouflage).booleanValue())
/* 105 */         list.add(EnumChatFormatting.DARK_PURPLE + "Camouflage");
/* 106 */       drawHoveringText(list, x - 110, y - 30, this.fontRendererObj);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiObsidianUpgrader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */