/*      */ package fr.paladium.palamod.client.gui;
/*      */ 
/*      */ import cpw.mods.fml.relauncher.Side;
/*      */ import cpw.mods.fml.relauncher.SideOnly;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import javax.annotation.Nullable;
/*      */ import net.minecraft.client.renderer.OpenGlHelper;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.opengl.GL14;
/*      */ import org.lwjgl.opengl.GLContext;
/*      */ import org.lwjgl.util.vector.Quaternion;
/*      */ 
/*      */ @SideOnly(Side.CLIENT)
/*      */ public class GlStateManager
/*      */ {
/*   19 */   private static final FloatBuffer BUF_FLOAT_16 = BufferUtils.createFloatBuffer(16);
/*   20 */   private static final FloatBuffer BUF_FLOAT_4 = BufferUtils.createFloatBuffer(4);
/*   21 */   private static final AlphaState alphaState = new AlphaState(null);
/*   22 */   private static final BooleanState lightingState = new BooleanState(2896);
/*   23 */   private static final BooleanState[] lightState = new BooleanState[8];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   41 */   private static final FloatBuffer COLOR_BUFFER = net.minecraft.client.renderer.GLAllocation.createDirectFloatBuffer(4);
/*      */   
/*      */   public static FloatBuffer setColorBuffer(float p_745210, float p_745211, float p_745212, float p_745213)
/*      */   {
/*   45 */     COLOR_BUFFER.clear();
/*   46 */     COLOR_BUFFER.put(p_745210).put(p_745211).put(p_745212).put(p_745213);
/*   47 */     COLOR_BUFFER.flip();
/*   48 */     return COLOR_BUFFER;
/*      */   }
/*      */   
/*      */   public static void pushAttrib()
/*      */   {
/*   53 */     GL11.glPushAttrib(8256);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void popAttrib() {}
/*      */   
/*      */ 
/*      */   public static void disableAlpha()
/*      */   {
/*   63 */     alphaState.alphaTest.setDisabled();
/*      */   }
/*      */   
/*      */   public static void enableAlpha()
/*      */   {
/*   68 */     alphaState.alphaTest.setEnabled();
/*      */   }
/*      */   
/*      */   public static void alphaFunc(int func, float ref)
/*      */   {
/*   73 */     if ((func != alphaState.func) || (ref != alphaState.ref))
/*      */     {
/*   75 */       alphaState.func = func;
/*   76 */       alphaState.ref = ref;
/*   77 */       GL11.glAlphaFunc(func, ref);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void enableLighting()
/*      */   {
/*   83 */     lightingState.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableLighting()
/*      */   {
/*   88 */     lightingState.setDisabled();
/*      */   }
/*      */   
/*      */   public static void enableLight(int light)
/*      */   {
/*   93 */     lightState[light].setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableLight(int light)
/*      */   {
/*   98 */     lightState[light].setDisabled();
/*      */   }
/*      */   
/*      */   public static void enableColorMaterial()
/*      */   {
/*  103 */     colorMaterialState.colorMaterial.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableColorMaterial()
/*      */   {
/*  108 */     colorMaterialState.colorMaterial.setDisabled();
/*      */   }
/*      */   
/*      */   public static void colorMaterial(int face, int mode)
/*      */   {
/*  113 */     if ((face != colorMaterialState.face) || (mode != colorMaterialState.mode))
/*      */     {
/*  115 */       colorMaterialState.face = face;
/*  116 */       colorMaterialState.mode = mode;
/*  117 */       GL11.glColorMaterial(face, mode);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glLight(int light, int pname, FloatBuffer params)
/*      */   {
/*  123 */     GL11.glLight(light, pname, params);
/*      */   }
/*      */   
/*      */   public static void glLightModel(int pname, FloatBuffer params)
/*      */   {
/*  128 */     GL11.glLightModel(pname, params);
/*      */   }
/*      */   
/*      */   public static void glNormal3f(float nx, float ny, float nz)
/*      */   {
/*  133 */     GL11.glNormal3f(nx, ny, nz);
/*      */   }
/*      */   
/*      */   public static void disableDepth()
/*      */   {
/*  138 */     depthState.depthTest.setDisabled();
/*      */   }
/*      */   
/*      */   public static void enableDepth()
/*      */   {
/*  143 */     depthState.depthTest.setEnabled();
/*      */   }
/*      */   
/*      */   public static void depthFunc(int depthFunc)
/*      */   {
/*  148 */     if (depthFunc != depthState.depthFunc)
/*      */     {
/*  150 */       depthState.depthFunc = depthFunc;
/*  151 */       GL11.glDepthFunc(depthFunc);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void depthMask(boolean flagIn)
/*      */   {
/*  157 */     if (flagIn != depthState.maskEnabled)
/*      */     {
/*  159 */       depthState.maskEnabled = flagIn;
/*  160 */       GL11.glDepthMask(flagIn);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void disableBlend()
/*      */   {
/*  166 */     blendState.blend.setDisabled();
/*      */   }
/*      */   
/*      */   public static void enableBlend()
/*      */   {
/*  171 */     blendState.blend.setEnabled();
/*      */   }
/*      */   
/*      */   public static void blendFunc(SourceFactor srcFactor, DestFactor dstFactor)
/*      */   {
/*  176 */     blendFunc(srcFactor.factor, dstFactor.factor);
/*      */   }
/*      */   
/*      */   public static void blendFunc(int srcFactor, int dstFactor)
/*      */   {
/*  181 */     if ((srcFactor != blendState.srcFactor) || (dstFactor != blendState.dstFactor))
/*      */     {
/*  183 */       blendState.srcFactor = srcFactor;
/*  184 */       blendState.dstFactor = dstFactor;
/*  185 */       GL11.glBlendFunc(srcFactor, dstFactor);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void tryBlendFuncSeparate(SourceFactor srcFactor, DestFactor dstFactor, SourceFactor srcFactorAlpha, DestFactor dstFactorAlpha)
/*      */   {
/*  191 */     tryBlendFuncSeparate(srcFactor.factor, dstFactor.factor, srcFactorAlpha.factor, dstFactorAlpha.factor);
/*      */   }
/*      */   
/*      */   public static void tryBlendFuncSeparate(int srcFactor, int dstFactor, int srcFactorAlpha, int dstFactorAlpha)
/*      */   {
/*  196 */     if ((srcFactor != blendState.srcFactor) || (dstFactor != blendState.dstFactor) || (srcFactorAlpha != blendState.srcFactorAlpha) || (dstFactorAlpha != blendState.dstFactorAlpha))
/*      */     {
/*  198 */       blendState.srcFactor = srcFactor;
/*  199 */       blendState.dstFactor = dstFactor;
/*  200 */       blendState.srcFactorAlpha = srcFactorAlpha;
/*  201 */       blendState.dstFactorAlpha = dstFactorAlpha;
/*  202 */       OpenGlHelper.glBlendFunc(srcFactor, dstFactor, srcFactorAlpha, dstFactorAlpha);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glBlendEquation(int blendEquation)
/*      */   {
/*  208 */     GL14.glBlendEquation(blendEquation);
/*      */   }
/*      */   
/*      */   public static void enableOutlineMode(int p_187431_0_)
/*      */   {
/*  213 */     BUF_FLOAT_4.put(0, (p_187431_0_ >> 16 & 0xFF) / 255.0F);
/*  214 */     BUF_FLOAT_4.put(1, (p_187431_0_ >> 8 & 0xFF) / 255.0F);
/*  215 */     BUF_FLOAT_4.put(2, (p_187431_0_ >> 0 & 0xFF) / 255.0F);
/*  216 */     BUF_FLOAT_4.put(3, (p_187431_0_ >> 24 & 0xFF) / 255.0F);
/*  217 */     glTexEnv(8960, 8705, BUF_FLOAT_4);
/*  218 */     glTexEnvi(8960, 8704, 34160);
/*  219 */     glTexEnvi(8960, 34161, 7681);
/*  220 */     glTexEnvi(8960, 34176, 34166);
/*  221 */     glTexEnvi(8960, 34192, 768);
/*  222 */     glTexEnvi(8960, 34162, 7681);
/*  223 */     glTexEnvi(8960, 34184, 5890);
/*  224 */     glTexEnvi(8960, 34200, 770);
/*      */   }
/*      */   
/*      */   public static void disableOutlineMode()
/*      */   {
/*  229 */     glTexEnvi(8960, 8704, 8448);
/*  230 */     glTexEnvi(8960, 34161, 8448);
/*  231 */     glTexEnvi(8960, 34162, 8448);
/*  232 */     glTexEnvi(8960, 34176, 5890);
/*  233 */     glTexEnvi(8960, 34184, 5890);
/*  234 */     glTexEnvi(8960, 34192, 768);
/*  235 */     glTexEnvi(8960, 34200, 770);
/*      */   }
/*      */   
/*      */   public static void enableFog()
/*      */   {
/*  240 */     fogState.fog.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableFog()
/*      */   {
/*  245 */     fogState.fog.setDisabled();
/*      */   }
/*      */   
/*      */   public static void setFog(FogMode fogMode)
/*      */   {
/*  250 */     setFog(fogMode.capabilityId);
/*      */   }
/*      */   
/*      */   private static void setFog(int param)
/*      */   {
/*  255 */     if (param != fogState.mode)
/*      */     {
/*  257 */       fogState.mode = param;
/*  258 */       GL11.glFogi(2917, param);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void setFogDensity(float param)
/*      */   {
/*  264 */     if (param != fogState.density)
/*      */     {
/*  266 */       fogState.density = param;
/*  267 */       GL11.glFogf(2914, param);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void setFogStart(float param)
/*      */   {
/*  273 */     if (param != fogState.start)
/*      */     {
/*  275 */       fogState.start = param;
/*  276 */       GL11.glFogf(2915, param);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void setFogEnd(float param)
/*      */   {
/*  282 */     if (param != fogState.end)
/*      */     {
/*  284 */       fogState.end = param;
/*  285 */       GL11.glFogf(2916, param);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glFog(int pname, FloatBuffer param)
/*      */   {
/*  291 */     GL11.glFog(pname, param);
/*      */   }
/*      */   
/*      */   public static void glFogi(int pname, int param)
/*      */   {
/*  296 */     GL11.glFogi(pname, param);
/*      */   }
/*      */   
/*      */   public static void enableCull()
/*      */   {
/*  301 */     cullState.cullFace.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableCull()
/*      */   {
/*  306 */     cullState.cullFace.setDisabled();
/*      */   }
/*      */   
/*      */   public static void cullFace(CullFace cullFace)
/*      */   {
/*  311 */     cullFace(cullFace.mode);
/*      */   }
/*      */   
/*      */   private static void cullFace(int mode)
/*      */   {
/*  316 */     if (mode != cullState.mode)
/*      */     {
/*  318 */       cullState.mode = mode;
/*  319 */       GL11.glCullFace(mode);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glPolygonMode(int face, int mode)
/*      */   {
/*  325 */     GL11.glPolygonMode(face, mode);
/*      */   }
/*      */   
/*      */   public static void enablePolygonOffset()
/*      */   {
/*  330 */     polygonOffsetState.polygonOffsetFill.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disablePolygonOffset()
/*      */   {
/*  335 */     polygonOffsetState.polygonOffsetFill.setDisabled();
/*      */   }
/*      */   
/*      */   public static void doPolygonOffset(float factor, float units)
/*      */   {
/*  340 */     if ((factor != polygonOffsetState.factor) || (units != polygonOffsetState.units))
/*      */     {
/*  342 */       polygonOffsetState.factor = factor;
/*  343 */       polygonOffsetState.units = units;
/*  344 */       GL11.glPolygonOffset(factor, units);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void enableColorLogic()
/*      */   {
/*  350 */     colorLogicState.colorLogicOp.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableColorLogic()
/*      */   {
/*  355 */     colorLogicState.colorLogicOp.setDisabled();
/*      */   }
/*      */   
/*      */   public static void colorLogicOp(LogicOp logicOperation)
/*      */   {
/*  360 */     colorLogicOp(logicOperation.opcode);
/*      */   }
/*      */   
/*      */   public static void colorLogicOp(int opcode)
/*      */   {
/*  365 */     if (opcode != colorLogicState.opcode)
/*      */     {
/*  367 */       colorLogicState.opcode = opcode;
/*  368 */       GL11.glLogicOp(opcode);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void enableTexGenCoord(TexGen texGen)
/*      */   {
/*  374 */     texGenCoord(texGen).textureGen.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableTexGenCoord(TexGen texGen)
/*      */   {
/*  379 */     texGenCoord(texGen).textureGen.setDisabled();
/*      */   }
/*      */   
/*      */   public static void texGen(TexGen texGen, int param)
/*      */   {
/*  384 */     TexGenCoord glstatemanager$texgencoord = texGenCoord(texGen);
/*      */     
/*  386 */     if (param != glstatemanager$texgencoord.param)
/*      */     {
/*  388 */       glstatemanager$texgencoord.param = param;
/*  389 */       GL11.glTexGeni(glstatemanager$texgencoord.coord, 9472, param);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void texGen(TexGen texGen, int pname, FloatBuffer params)
/*      */   {
/*  395 */     GL11.glTexGen(texGenCoord(texGen).coord, pname, params);
/*      */   }
/*      */   
/*      */   private static TexGenCoord texGenCoord(TexGen texGen)
/*      */   {
/*  400 */     switch (texGen)
/*      */     {
/*      */     case S: 
/*  403 */       return texGenState.s;
/*      */     case T: 
/*  405 */       return texGenState.t;
/*      */     case R: 
/*  407 */       return texGenState.r;
/*      */     case Q: 
/*  409 */       return texGenState.q;
/*      */     }
/*  411 */     return texGenState.s;
/*      */   }
/*      */   
/*      */ 
/*      */   public static void setActiveTexture(int texture)
/*      */   {
/*  417 */     if (activeTextureUnit != texture - OpenGlHelper.defaultTexUnit)
/*      */     {
/*  419 */       activeTextureUnit = texture - OpenGlHelper.defaultTexUnit;
/*  420 */       OpenGlHelper.setActiveTexture(texture);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void enableTexture2D()
/*      */   {
/*  426 */     textureState[activeTextureUnit].texture2DState.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableTexture2D()
/*      */   {
/*  431 */     textureState[activeTextureUnit].texture2DState.setDisabled();
/*      */   }
/*      */   
/*      */   public static void glTexEnv(int p_187448_0_, int p_187448_1_, FloatBuffer p_187448_2_)
/*      */   {
/*  436 */     GL11.glTexEnv(p_187448_0_, p_187448_1_, p_187448_2_);
/*      */   }
/*      */   
/*      */   public static void glTexEnvi(int p_187399_0_, int p_187399_1_, int p_187399_2_)
/*      */   {
/*  441 */     GL11.glTexEnvi(p_187399_0_, p_187399_1_, p_187399_2_);
/*      */   }
/*      */   
/*      */   public static void glTexEnvf(int p_187436_0_, int p_187436_1_, float p_187436_2_)
/*      */   {
/*  446 */     GL11.glTexEnvf(p_187436_0_, p_187436_1_, p_187436_2_);
/*      */   }
/*      */   
/*      */   public static void glTexParameterf(int p_187403_0_, int p_187403_1_, float p_187403_2_)
/*      */   {
/*  451 */     GL11.glTexParameterf(p_187403_0_, p_187403_1_, p_187403_2_);
/*      */   }
/*      */   
/*      */   public static void glTexParameteri(int p_187421_0_, int p_187421_1_, int p_187421_2_)
/*      */   {
/*  456 */     GL11.glTexParameteri(p_187421_0_, p_187421_1_, p_187421_2_);
/*      */   }
/*      */   
/*      */   public static int glGetTexLevelParameteri(int p_187411_0_, int p_187411_1_, int p_187411_2_)
/*      */   {
/*  461 */     return GL11.glGetTexLevelParameteri(p_187411_0_, p_187411_1_, p_187411_2_);
/*      */   }
/*      */   
/*      */   public static int generateTexture()
/*      */   {
/*  466 */     return GL11.glGenTextures();
/*      */   }
/*      */   
/*      */   public static void deleteTexture(int texture)
/*      */   {
/*  471 */     GL11.glDeleteTextures(texture);
/*      */     
/*  473 */     for (TextureState glstatemanager$texturestate : textureState)
/*      */     {
/*  475 */       if (glstatemanager$texturestate.textureName == texture)
/*      */       {
/*  477 */         glstatemanager$texturestate.textureName = -1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static void bindTexture(int texture)
/*      */   {
/*  484 */     if (texture != textureState[activeTextureUnit].textureName)
/*      */     {
/*  486 */       textureState[activeTextureUnit].textureName = texture;
/*  487 */       GL11.glBindTexture(3553, texture);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glTexImage2D(int p_187419_0_, int p_187419_1_, int p_187419_2_, int p_187419_3_, int p_187419_4_, int p_187419_5_, int p_187419_6_, int p_187419_7_, @Nullable IntBuffer p_187419_8_)
/*      */   {
/*  493 */     GL11.glTexImage2D(p_187419_0_, p_187419_1_, p_187419_2_, p_187419_3_, p_187419_4_, p_187419_5_, p_187419_6_, p_187419_7_, p_187419_8_);
/*      */   }
/*      */   
/*      */   public static void glTexSubImage2D(int p_187414_0_, int p_187414_1_, int p_187414_2_, int p_187414_3_, int p_187414_4_, int p_187414_5_, int p_187414_6_, int p_187414_7_, IntBuffer p_187414_8_)
/*      */   {
/*  498 */     GL11.glTexSubImage2D(p_187414_0_, p_187414_1_, p_187414_2_, p_187414_3_, p_187414_4_, p_187414_5_, p_187414_6_, p_187414_7_, p_187414_8_);
/*      */   }
/*      */   
/*      */   public static void glCopyTexSubImage2D(int p_187443_0_, int p_187443_1_, int p_187443_2_, int p_187443_3_, int p_187443_4_, int p_187443_5_, int p_187443_6_, int p_187443_7_)
/*      */   {
/*  503 */     GL11.glCopyTexSubImage2D(p_187443_0_, p_187443_1_, p_187443_2_, p_187443_3_, p_187443_4_, p_187443_5_, p_187443_6_, p_187443_7_);
/*      */   }
/*      */   
/*      */   public static void glGetTexImage(int p_187433_0_, int p_187433_1_, int p_187433_2_, int p_187433_3_, IntBuffer p_187433_4_)
/*      */   {
/*  508 */     GL11.glGetTexImage(p_187433_0_, p_187433_1_, p_187433_2_, p_187433_3_, p_187433_4_);
/*      */   }
/*      */   
/*      */   public static void enableNormalize()
/*      */   {
/*  513 */     normalizeState.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableNormalize()
/*      */   {
/*  518 */     normalizeState.setDisabled();
/*      */   }
/*      */   
/*      */   public static void shadeModel(int mode)
/*      */   {
/*  523 */     if (mode != activeShadeModel)
/*      */     {
/*  525 */       activeShadeModel = mode;
/*  526 */       GL11.glShadeModel(mode);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void enableRescaleNormal()
/*      */   {
/*  532 */     rescaleNormalState.setEnabled();
/*      */   }
/*      */   
/*      */   public static void disableRescaleNormal()
/*      */   {
/*  537 */     rescaleNormalState.setDisabled();
/*      */   }
/*      */   
/*      */   public static void viewport(int x, int y, int width, int height)
/*      */   {
/*  542 */     GL11.glViewport(x, y, width, height);
/*      */   }
/*      */   
/*      */   public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha)
/*      */   {
/*  547 */     if ((red != colorMaskState.red) || (green != colorMaskState.green) || (blue != colorMaskState.blue) || (alpha != colorMaskState.alpha))
/*      */     {
/*  549 */       colorMaskState.red = red;
/*  550 */       colorMaskState.green = green;
/*  551 */       colorMaskState.blue = blue;
/*  552 */       colorMaskState.alpha = alpha;
/*  553 */       GL11.glColorMask(red, green, blue, alpha);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void clearDepth(double depth)
/*      */   {
/*  559 */     if (depth != clearState.depth)
/*      */     {
/*  561 */       clearState.depth = depth;
/*  562 */       GL11.glClearDepth(depth);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void clearColor(float red, float green, float blue, float alpha)
/*      */   {
/*  568 */     if ((red != clearState.color.red) || (green != clearState.color.green) || (blue != clearState.color.blue) || (alpha != clearState.color.alpha))
/*      */     {
/*  570 */       clearState.color.red = red;
/*  571 */       clearState.color.green = green;
/*  572 */       clearState.color.blue = blue;
/*  573 */       clearState.color.alpha = alpha;
/*  574 */       GL11.glClearColor(red, green, blue, alpha);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void clear(int mask)
/*      */   {
/*  580 */     GL11.glClear(mask);
/*      */   }
/*      */   
/*      */   public static void matrixMode(int mode)
/*      */   {
/*  585 */     GL11.glMatrixMode(mode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void loadIdentity() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public static void pushMatrix() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public static void popMatrix() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public static void getFloat(int pname, FloatBuffer params)
/*      */   {
/*  605 */     GL11.glGetFloat(pname, params);
/*      */   }
/*      */   
/*      */   public static void ortho(double left, double right, double bottom, double top, double zNear, double zFar)
/*      */   {
/*  610 */     GL11.glOrtho(left, right, bottom, top, zNear, zFar);
/*      */   }
/*      */   
/*      */   public static void rotate(float angle, float x, float y, float z)
/*      */   {
/*  615 */     GL11.glRotatef(angle, x, y, z);
/*      */   }
/*      */   
/*      */   public static void scale(float x, float y, float z)
/*      */   {
/*  620 */     GL11.glScalef(x, y, z);
/*      */   }
/*      */   
/*      */   public static void scale(double x, double y, double z)
/*      */   {
/*  625 */     GL11.glScaled(x, y, z);
/*      */   }
/*      */   
/*      */   public static void translate(float x, float y, float z)
/*      */   {
/*  630 */     GL11.glTranslatef(x, y, z);
/*      */   }
/*      */   
/*      */   public static void translate(double x, double y, double z)
/*      */   {
/*  635 */     GL11.glTranslated(x, y, z);
/*      */   }
/*      */   
/*      */   public static void multMatrix(FloatBuffer matrix)
/*      */   {
/*  640 */     GL11.glMultMatrix(matrix);
/*      */   }
/*      */   
/*      */   public static void rotate(Quaternion p_187444_0_)
/*      */   {
/*  645 */     multMatrix(quatToGlMatrix(BUF_FLOAT_16, p_187444_0_));
/*      */   }
/*      */   
/*      */   public static FloatBuffer quatToGlMatrix(FloatBuffer p_187418_0_, Quaternion p_187418_1_)
/*      */   {
/*  650 */     p_187418_0_.clear();
/*  651 */     float f = p_187418_1_.x * p_187418_1_.x;
/*  652 */     float f1 = p_187418_1_.x * p_187418_1_.y;
/*  653 */     float f2 = p_187418_1_.x * p_187418_1_.z;
/*  654 */     float f3 = p_187418_1_.x * p_187418_1_.w;
/*  655 */     float f4 = p_187418_1_.y * p_187418_1_.y;
/*  656 */     float f5 = p_187418_1_.y * p_187418_1_.z;
/*  657 */     float f6 = p_187418_1_.y * p_187418_1_.w;
/*  658 */     float f7 = p_187418_1_.z * p_187418_1_.z;
/*  659 */     float f8 = p_187418_1_.z * p_187418_1_.w;
/*  660 */     p_187418_0_.put(1.0F - 2.0F * (f4 + f7));
/*  661 */     p_187418_0_.put(2.0F * (f1 + f8));
/*  662 */     p_187418_0_.put(2.0F * (f2 - f6));
/*  663 */     p_187418_0_.put(0.0F);
/*  664 */     p_187418_0_.put(2.0F * (f1 - f8));
/*  665 */     p_187418_0_.put(1.0F - 2.0F * (f + f7));
/*  666 */     p_187418_0_.put(2.0F * (f5 + f3));
/*  667 */     p_187418_0_.put(0.0F);
/*  668 */     p_187418_0_.put(2.0F * (f2 + f6));
/*  669 */     p_187418_0_.put(2.0F * (f5 - f3));
/*  670 */     p_187418_0_.put(1.0F - 2.0F * (f + f4));
/*  671 */     p_187418_0_.put(0.0F);
/*  672 */     p_187418_0_.put(0.0F);
/*  673 */     p_187418_0_.put(0.0F);
/*  674 */     p_187418_0_.put(0.0F);
/*  675 */     p_187418_0_.put(1.0F);
/*  676 */     p_187418_0_.rewind();
/*  677 */     return p_187418_0_;
/*      */   }
/*      */   
/*      */   public static void color(float colorRed, float colorGreen, float colorBlue, float colorAlpha)
/*      */   {
/*  682 */     if ((colorRed != colorState.red) || (colorGreen != colorState.green) || (colorBlue != colorState.blue) || (colorAlpha != colorState.alpha))
/*      */     {
/*  684 */       colorState.red = colorRed;
/*  685 */       colorState.green = colorGreen;
/*  686 */       colorState.blue = colorBlue;
/*  687 */       colorState.alpha = colorAlpha;
/*  688 */       GL11.glColor4f(colorRed, colorGreen, colorBlue, colorAlpha);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void color(float colorRed, float colorGreen, float colorBlue)
/*      */   {
/*  694 */     color(colorRed, colorGreen, colorBlue, 1.0F);
/*      */   }
/*      */   
/*      */   public static void glTexCoord2f(float p_187426_0_, float p_187426_1_)
/*      */   {
/*  699 */     GL11.glTexCoord2f(p_187426_0_, p_187426_1_);
/*      */   }
/*      */   
/*      */   public static void glVertex3f(float p_187435_0_, float p_187435_1_, float p_187435_2_)
/*      */   {
/*  704 */     GL11.glVertex3f(p_187435_0_, p_187435_1_, p_187435_2_);
/*      */   }
/*      */   
/*      */   public static void resetColor()
/*      */   {
/*  709 */     colorState.red = -1.0F;
/*  710 */     colorState.green = -1.0F;
/*  711 */     colorState.blue = -1.0F;
/*  712 */     colorState.alpha = -1.0F;
/*      */   }
/*      */   
/*      */   public static void glNormalPointer(int p_187446_0_, int p_187446_1_, ByteBuffer p_187446_2_)
/*      */   {
/*  717 */     GL11.glNormalPointer(p_187446_0_, p_187446_1_, p_187446_2_);
/*      */   }
/*      */   
/*      */   public static void glTexCoordPointer(int p_187405_0_, int p_187405_1_, int p_187405_2_, int p_187405_3_)
/*      */   {
/*  722 */     GL11.glTexCoordPointer(p_187405_0_, p_187405_1_, p_187405_2_, p_187405_3_);
/*      */   }
/*      */   
/*      */   public static void glTexCoordPointer(int p_187404_0_, int p_187404_1_, int p_187404_2_, ByteBuffer p_187404_3_)
/*      */   {
/*  727 */     GL11.glTexCoordPointer(p_187404_0_, p_187404_1_, p_187404_2_, p_187404_3_);
/*      */   }
/*      */   
/*      */   public static void glVertexPointer(int p_187420_0_, int p_187420_1_, int p_187420_2_, int p_187420_3_)
/*      */   {
/*  732 */     GL11.glVertexPointer(p_187420_0_, p_187420_1_, p_187420_2_, p_187420_3_);
/*      */   }
/*      */   
/*      */   public static void glVertexPointer(int p_187427_0_, int p_187427_1_, int p_187427_2_, ByteBuffer p_187427_3_)
/*      */   {
/*  737 */     GL11.glVertexPointer(p_187427_0_, p_187427_1_, p_187427_2_, p_187427_3_);
/*      */   }
/*      */   
/*      */   public static void glColorPointer(int p_187406_0_, int p_187406_1_, int p_187406_2_, int p_187406_3_)
/*      */   {
/*  742 */     GL11.glColorPointer(p_187406_0_, p_187406_1_, p_187406_2_, p_187406_3_);
/*      */   }
/*      */   
/*      */   public static void glColorPointer(int p_187400_0_, int p_187400_1_, int p_187400_2_, ByteBuffer p_187400_3_)
/*      */   {
/*  747 */     GL11.glColorPointer(p_187400_0_, p_187400_1_, p_187400_2_, p_187400_3_);
/*      */   }
/*      */   
/*      */   public static void glDisableClientState(int p_187429_0_)
/*      */   {
/*  752 */     GL11.glDisableClientState(p_187429_0_);
/*      */   }
/*      */   
/*      */   public static void glEnableClientState(int p_187410_0_)
/*      */   {
/*  757 */     GL11.glEnableClientState(p_187410_0_);
/*      */   }
/*      */   
/*      */   public static void glBegin(int p_187447_0_)
/*      */   {
/*  762 */     GL11.glBegin(p_187447_0_);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void glEnd() {}
/*      */   
/*      */ 
/*      */   public static void glDrawArrays(int p_187439_0_, int p_187439_1_, int p_187439_2_)
/*      */   {
/*  772 */     GL11.glDrawArrays(p_187439_0_, p_187439_1_, p_187439_2_);
/*      */   }
/*      */   
/*      */   public static void glLineWidth(float p_187441_0_)
/*      */   {
/*  777 */     GL11.glLineWidth(p_187441_0_);
/*      */   }
/*      */   
/*      */   public static void callList(int list)
/*      */   {
/*  782 */     GL11.glCallList(list);
/*      */   }
/*      */   
/*      */   public static void glDeleteLists(int p_187449_0_, int p_187449_1_)
/*      */   {
/*  787 */     GL11.glDeleteLists(p_187449_0_, p_187449_1_);
/*      */   }
/*      */   
/*      */   public static void glNewList(int p_187423_0_, int p_187423_1_)
/*      */   {
/*  792 */     GL11.glNewList(p_187423_0_, p_187423_1_);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static void glEndList() {}
/*      */   
/*      */ 
/*      */   public static int glGenLists(int p_187442_0_)
/*      */   {
/*  802 */     return GL11.glGenLists(p_187442_0_);
/*      */   }
/*      */   
/*      */   public static void glPixelStorei(int p_187425_0_, int p_187425_1_)
/*      */   {
/*  807 */     GL11.glPixelStorei(p_187425_0_, p_187425_1_);
/*      */   }
/*      */   
/*      */   public static void glReadPixels(int p_187413_0_, int p_187413_1_, int p_187413_2_, int p_187413_3_, int p_187413_4_, int p_187413_5_, IntBuffer p_187413_6_)
/*      */   {
/*  812 */     GL11.glReadPixels(p_187413_0_, p_187413_1_, p_187413_2_, p_187413_3_, p_187413_4_, p_187413_5_, p_187413_6_);
/*      */   }
/*      */   
/*      */   public static int glGetError()
/*      */   {
/*  817 */     return GL11.glGetError();
/*      */   }
/*      */   
/*      */   public static String glGetString(int p_187416_0_)
/*      */   {
/*  822 */     return GL11.glGetString(p_187416_0_);
/*      */   }
/*      */   
/*      */   public static void glGetInteger(int p_187445_0_, IntBuffer p_187445_1_)
/*      */   {
/*  827 */     GL11.glGetInteger(p_187445_0_, p_187445_1_);
/*      */   }
/*      */   
/*      */   public static int glGetInteger(int p_187397_0_)
/*      */   {
/*  832 */     return GL11.glGetInteger(p_187397_0_);
/*      */   }
/*      */   
/*      */   public static void enableBlendProfile(Profile p_187408_0_)
/*      */   {
/*  837 */     p_187408_0_.apply();
/*      */   }
/*      */   
/*      */   public static void disableBlendProfile(Profile p_187440_0_)
/*      */   {
/*  842 */     p_187440_0_.clean();
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*  847 */     for (int i = 0; i < 8; i++)
/*      */     {
/*  849 */       lightState[i] = new BooleanState(16384 + i);
/*      */     }
/*      */     
/*  852 */     colorMaterialState = new ColorMaterialState(null);
/*  853 */     blendState = new BlendState(null);
/*  854 */     depthState = new DepthState(null);
/*  855 */     fogState = new FogState(null);
/*  856 */     cullState = new CullState(null);
/*  857 */     polygonOffsetState = new PolygonOffsetState(null);
/*  858 */     colorLogicState = new ColorLogicState(null);
/*  859 */     texGenState = new TexGenState(null);
/*  860 */     clearState = new ClearState(null);
/*  861 */     stencilState = new StencilState(null);
/*  862 */     normalizeState = new BooleanState(2977);
/*  863 */     textureState = new TextureState[8];
/*      */     
/*  865 */     for (int j = 0; j < 8; j++)
/*      */     {
/*  867 */       textureState[j] = new TextureState(null); }
/*      */   }
/*      */   
/*  870 */   private static int activeShadeModel = 7425;
/*  871 */   private static final BooleanState rescaleNormalState = new BooleanState(32826);
/*  872 */   private static final ColorMask colorMaskState = new ColorMask(null);
/*  873 */   private static final Color colorState = new Color();
/*      */   private static final ColorMaterialState colorMaterialState;
/*      */   private static final BlendState blendState;
/*      */   private static final DepthState depthState;
/*      */   private static final FogState fogState;
/*      */   private static final CullState cullState;
/*      */   private static final PolygonOffsetState polygonOffsetState;
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class AlphaState
/*      */   {
/*      */     private AlphaState() {
/*  885 */       this.alphaTest = new GlStateManager.BooleanState(3008);
/*  886 */       this.func = 519;
/*  887 */       this.ref = -1.0F;
/*      */     }
/*      */     
/*      */     public GlStateManager.BooleanState alphaTest;
/*      */     public int func;
/*      */     public float ref;
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class BlendState { public GlStateManager.BooleanState blend;
/*      */     public int srcFactor;
/*      */     public int dstFactor;
/*      */     public int srcFactorAlpha;
/*      */     public int dstFactorAlpha;
/*      */     
/*  902 */     private BlendState() { this.blend = new GlStateManager.BooleanState(3042);
/*  903 */       this.srcFactor = 1;
/*  904 */       this.dstFactor = 0;
/*  905 */       this.srcFactorAlpha = 1;
/*  906 */       this.dstFactorAlpha = 0;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class BooleanState
/*      */   {
/*      */     private final int capability;
/*      */     private boolean currentState;
/*      */     
/*      */     public BooleanState(int capabilityIn)
/*      */     {
/*  918 */       this.capability = capabilityIn;
/*      */     }
/*      */     
/*      */     public void setDisabled()
/*      */     {
/*  923 */       setState(false);
/*      */     }
/*      */     
/*      */     public void setEnabled()
/*      */     {
/*  928 */       setState(true);
/*      */     }
/*      */     
/*      */     public void setState(boolean state)
/*      */     {
/*  933 */       if (state != this.currentState)
/*      */       {
/*  935 */         this.currentState = state;
/*      */         
/*  937 */         if (state)
/*      */         {
/*  939 */           GL11.glEnable(this.capability);
/*      */         }
/*      */         else
/*      */         {
/*  943 */           GL11.glDisable(this.capability);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class ClearState
/*      */   {
/*      */     public double depth;
/*      */     public GlStateManager.Color color;
/*      */     
/*      */     private ClearState()
/*      */     {
/*  957 */       this.depth = 1.0D;
/*  958 */       this.color = new GlStateManager.Color(0.0F, 0.0F, 0.0F, 0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class Color
/*      */   {
/*      */     public float red;
/*      */     public float green;
/*      */     public float blue;
/*      */     public float alpha;
/*      */     
/*      */     public Color()
/*      */     {
/*  972 */       this(1.0F, 1.0F, 1.0F, 1.0F);
/*      */     }
/*      */     
/*      */     public Color(float redIn, float greenIn, float blueIn, float alphaIn)
/*      */     {
/*  977 */       this.red = 1.0F;
/*  978 */       this.green = 1.0F;
/*  979 */       this.blue = 1.0F;
/*  980 */       this.alpha = 1.0F;
/*  981 */       this.red = redIn;
/*  982 */       this.green = greenIn;
/*  983 */       this.blue = blueIn;
/*  984 */       this.alpha = alphaIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class ColorLogicState
/*      */   {
/*      */     public GlStateManager.BooleanState colorLogicOp;
/*      */     public int opcode;
/*      */     
/*      */     private ColorLogicState()
/*      */     {
/*  996 */       this.colorLogicOp = new GlStateManager.BooleanState(3058);
/*  997 */       this.opcode = 5379;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class ColorMask
/*      */   {
/*      */     public boolean red;
/*      */     public boolean green;
/*      */     public boolean blue;
/*      */     public boolean alpha;
/*      */     
/*      */     private ColorMask()
/*      */     {
/* 1011 */       this.red = true;
/* 1012 */       this.green = true;
/* 1013 */       this.blue = true;
/* 1014 */       this.alpha = true;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class ColorMaterialState
/*      */   {
/*      */     public GlStateManager.BooleanState colorMaterial;
/*      */     public int face;
/*      */     public int mode;
/*      */     
/*      */     private ColorMaterialState()
/*      */     {
/* 1027 */       this.colorMaterial = new GlStateManager.BooleanState(2903);
/* 1028 */       this.face = 1032;
/* 1029 */       this.mode = 5634;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum CullFace
/*      */   {
/* 1036 */     FRONT(1028), 
/* 1037 */     BACK(1029), 
/* 1038 */     FRONT_AND_BACK(1032);
/*      */     
/*      */     public final int mode;
/*      */     
/*      */     private CullFace(int modeIn)
/*      */     {
/* 1044 */       this.mode = modeIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class CullState
/*      */   {
/*      */     public GlStateManager.BooleanState cullFace;
/*      */     public int mode;
/*      */     
/*      */     private CullState()
/*      */     {
/* 1056 */       this.cullFace = new GlStateManager.BooleanState(2884);
/* 1057 */       this.mode = 1029;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class DepthState
/*      */   {
/*      */     public GlStateManager.BooleanState depthTest;
/*      */     public boolean maskEnabled;
/*      */     public int depthFunc;
/*      */     
/*      */     private DepthState()
/*      */     {
/* 1070 */       this.depthTest = new GlStateManager.BooleanState(2929);
/* 1071 */       this.maskEnabled = true;
/* 1072 */       this.depthFunc = 513;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum DestFactor
/*      */   {
/* 1079 */     CONSTANT_ALPHA(32771), 
/* 1080 */     CONSTANT_COLOR(32769), 
/* 1081 */     DST_ALPHA(772), 
/* 1082 */     DST_COLOR(774), 
/* 1083 */     ONE(1), 
/* 1084 */     ONE_MINUS_CONSTANT_ALPHA(32772), 
/* 1085 */     ONE_MINUS_CONSTANT_COLOR(32770), 
/* 1086 */     ONE_MINUS_DST_ALPHA(773), 
/* 1087 */     ONE_MINUS_DST_COLOR(775), 
/* 1088 */     ONE_MINUS_SRC_ALPHA(771), 
/* 1089 */     ONE_MINUS_SRC_COLOR(769), 
/* 1090 */     SRC_ALPHA(770), 
/* 1091 */     SRC_COLOR(768), 
/* 1092 */     ZERO(0);
/*      */     
/*      */     public final int factor;
/*      */     
/*      */     private DestFactor(int factorIn)
/*      */     {
/* 1098 */       this.factor = factorIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum FogMode
/*      */   {
/* 1105 */     LINEAR(9729), 
/* 1106 */     EXP(2048), 
/* 1107 */     EXP2(2049);
/*      */     
/*      */ 
/*      */     public final int capabilityId;
/*      */     
/*      */     private FogMode(int capabilityIn)
/*      */     {
/* 1114 */       this.capabilityId = capabilityIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class FogState
/*      */   {
/*      */     public GlStateManager.BooleanState fog;
/*      */     public int mode;
/*      */     public float density;
/*      */     public float start;
/*      */     public float end;
/*      */     
/*      */     private FogState()
/*      */     {
/* 1129 */       this.fog = new GlStateManager.BooleanState(2912);
/* 1130 */       this.mode = 2048;
/* 1131 */       this.density = 1.0F;
/* 1132 */       this.end = 1.0F;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum LogicOp
/*      */   {
/* 1139 */     AND(5377), 
/* 1140 */     AND_INVERTED(5380), 
/* 1141 */     AND_REVERSE(5378), 
/* 1142 */     CLEAR(5376), 
/* 1143 */     COPY(5379), 
/* 1144 */     COPY_INVERTED(5388), 
/* 1145 */     EQUIV(5385), 
/* 1146 */     INVERT(5386), 
/* 1147 */     NAND(5390), 
/* 1148 */     NOOP(5381), 
/* 1149 */     NOR(5384), 
/* 1150 */     OR(5383), 
/* 1151 */     OR_INVERTED(5389), 
/* 1152 */     OR_REVERSE(5387), 
/* 1153 */     SET(5391), 
/* 1154 */     XOR(5382);
/*      */     
/*      */     public final int opcode;
/*      */     
/*      */     private LogicOp(int opcodeIn)
/*      */     {
/* 1160 */       this.opcode = opcodeIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class PolygonOffsetState
/*      */   {
/*      */     public GlStateManager.BooleanState polygonOffsetFill;
/*      */     public GlStateManager.BooleanState polygonOffsetLine;
/*      */     public float factor;
/*      */     public float units;
/*      */     
/*      */     private PolygonOffsetState()
/*      */     {
/* 1174 */       this.polygonOffsetFill = new GlStateManager.BooleanState(32823);
/* 1175 */       this.polygonOffsetLine = new GlStateManager.BooleanState(10754);
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static abstract enum Profile
/*      */   {
/* 1182 */     DEFAULT, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1290 */     PLAYER_SKIN, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1302 */     TRANSPARENT_MODEL;
/*      */     
/*      */ 
/*      */     private Profile() {}
/*      */     
/*      */ 
/*      */     public abstract void apply();
/*      */     
/*      */ 
/*      */     public abstract void clean();
/*      */   }
/*      */   
/*      */ 
/*      */   private static final ColorLogicState colorLogicState;
/*      */   
/*      */   private static final TexGenState texGenState;
/*      */   
/*      */   private static final ClearState clearState;
/*      */   
/*      */   private static final StencilState stencilState;
/*      */   
/*      */   private static final BooleanState normalizeState;
/*      */   
/*      */   private static int activeTextureUnit;
/*      */   
/*      */   private static final TextureState[] textureState;
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum SourceFactor
/*      */   {
/* 1332 */     CONSTANT_ALPHA(32771), 
/* 1333 */     CONSTANT_COLOR(32769), 
/* 1334 */     DST_ALPHA(772), 
/* 1335 */     DST_COLOR(774), 
/* 1336 */     ONE(1), 
/* 1337 */     ONE_MINUS_CONSTANT_ALPHA(32772), 
/* 1338 */     ONE_MINUS_CONSTANT_COLOR(32770), 
/* 1339 */     ONE_MINUS_DST_ALPHA(773), 
/* 1340 */     ONE_MINUS_DST_COLOR(775), 
/* 1341 */     ONE_MINUS_SRC_ALPHA(771), 
/* 1342 */     ONE_MINUS_SRC_COLOR(769), 
/* 1343 */     SRC_ALPHA(770), 
/* 1344 */     SRC_ALPHA_SATURATE(776), 
/* 1345 */     SRC_COLOR(768), 
/* 1346 */     ZERO(0);
/*      */     
/*      */     public final int factor;
/*      */     
/*      */     private SourceFactor(int factorIn)
/*      */     {
/* 1352 */       this.factor = factorIn;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class StencilFunc
/*      */   {
/*      */     public int func;
/*      */     public int mask;
/*      */     
/*      */     private StencilFunc()
/*      */     {
/* 1364 */       this.func = 519;
/* 1365 */       this.mask = -1;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class StencilState
/*      */   {
/*      */     public GlStateManager.StencilFunc func;
/*      */     public int mask;
/*      */     public int fail;
/*      */     public int zfail;
/*      */     public int zpass;
/*      */     
/*      */     private StencilState()
/*      */     {
/* 1380 */       this.func = new GlStateManager.StencilFunc(null);
/* 1381 */       this.mask = -1;
/* 1382 */       this.fail = 7680;
/* 1383 */       this.zfail = 7680;
/* 1384 */       this.zpass = 7680;
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   public static enum TexGen
/*      */   {
/* 1391 */     S, 
/* 1392 */     T, 
/* 1393 */     R, 
/* 1394 */     Q;
/*      */     
/*      */     private TexGen() {}
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class TexGenCoord { public GlStateManager.BooleanState textureGen;
/*      */     public int coord;
/* 1402 */     public int param = -1;
/*      */     
/*      */     public TexGenCoord(int coordIn, int capabilityIn)
/*      */     {
/* 1406 */       this.coord = coordIn;
/* 1407 */       this.textureGen = new GlStateManager.BooleanState(capabilityIn);
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class TexGenState
/*      */   {
/*      */     public GlStateManager.TexGenCoord s;
/*      */     public GlStateManager.TexGenCoord t;
/*      */     public GlStateManager.TexGenCoord r;
/*      */     public GlStateManager.TexGenCoord q;
/*      */     
/*      */     private TexGenState()
/*      */     {
/* 1421 */       this.s = new GlStateManager.TexGenCoord(8192, 3168);
/* 1422 */       this.t = new GlStateManager.TexGenCoord(8193, 3169);
/* 1423 */       this.r = new GlStateManager.TexGenCoord(8194, 3170);
/* 1424 */       this.q = new GlStateManager.TexGenCoord(8195, 3171);
/*      */     }
/*      */   }
/*      */   
/*      */   @SideOnly(Side.CLIENT)
/*      */   static class TextureState
/*      */   {
/*      */     public GlStateManager.BooleanState texture2DState;
/*      */     public int textureName;
/*      */     
/*      */     private TextureState()
/*      */     {
/* 1436 */       this.texture2DState = new GlStateManager.BooleanState(3553);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GlStateManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */