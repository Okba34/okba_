/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.common.gui.ContainerEmpty;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketOnlineDetector;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import fr.paladium.palamod.tiles.TileEntityOnlineDetector;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiTextField;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.settings.GameSettings;
/*    */ import net.minecraft.client.settings.KeyBinding;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiOnlineDetector extends GuiContainer
/*    */ {
/*    */   GuiTextField usernameInput;
/*    */   TileEntityOnlineDetector te;
/*    */   FontRenderer fontRendererObj;
/* 23 */   final ResourceLocation background = new ResourceLocation("palamod:textures/gui/OnlineDetector.png");
/*    */   
/*    */   public GuiOnlineDetector(TileEntityOnlineDetector te) {
/* 26 */     super(new ContainerEmpty());
/* 27 */     this.te = te;
/* 28 */     this.fontRendererObj = Minecraft.getMinecraft().fontRenderer;
/* 29 */     this.xSize = 161;
/* 30 */     this.ySize = 70;
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 35 */     super.initGui();
/* 36 */     int x = (this.width - this.xSize) / 2;
/* 37 */     int y = (this.height - this.ySize) / 2;
/* 38 */     this.usernameInput = new GuiTextField(this.fontRendererObj, x + 5, y + 20, 150, 15);
/* 39 */     this.usernameInput.setFocused(false);
/* 40 */     this.usernameInput.setCanLoseFocus(true);
/* 41 */     this.usernameInput.setText(this.te.getPlayerName());
/*    */   }
/*    */   
/*    */   public void onGuiClosed()
/*    */   {
/* 46 */     Keyboard.enableRepeatEvents(false);
/*    */   }
/*    */   
/*    */   protected void mouseClicked(int par1, int par2, int par3)
/*    */   {
/* 51 */     super.mouseClicked(par1, par2, par3);
/* 52 */     this.usernameInput.mouseClicked(par1, par2, par3);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void keyTyped(char par1, int pressedKey)
/*    */   {
/* 58 */     if ((pressedKey == 1) || ((!this.usernameInput.isFocused()) && 
/* 59 */       (pressedKey == this.mc.gameSettings.keyBindInventory.getKeyCode()))) {
/* 60 */       PacketOnlineDetector packet = new PacketOnlineDetector();
/* 61 */       packet.addInformations(this.usernameInput.getText(), this.te);
/* 62 */       CommonProxy.packetPipeline.sendToServer(packet);
/* 63 */       this.mc.thePlayer.closeScreen();
/*    */     }
/* 65 */     this.usernameInput.textboxKeyTyped(par1, pressedKey);
/*    */   }
/*    */   
/*    */ 
/*    */   protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3)
/*    */   {
/* 71 */     this.mc.renderEngine.bindTexture(this.background);
/* 72 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 73 */     int x = (this.width - this.xSize) / 2;
/* 74 */     int y = (this.height - this.ySize) / 2;
/* 75 */     drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
/* 76 */     this.usernameInput.drawTextBox();
/* 77 */     this.fontRendererObj.drawStringWithShadow("Detecting: " + this.te.getPlayerName(), x + (this.xSize / 2 - this.fontRendererObj
/* 78 */       .getStringWidth("Detecting: " + this.te.getPlayerName()) / 2), y + 44, 16777215);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int param1, int param2)
/*    */   {
/* 83 */     this.fontRendererObj.drawString("Online detector", 8, 6, 4210752);
/*    */   }
/*    */   
/*    */   public void updateScreen()
/*    */   {
/* 88 */     super.updateScreen();
/* 89 */     this.usernameInput.updateCursorCounter();
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiOnlineDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */