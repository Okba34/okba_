/*    */ package fr.paladium.palamod.client.gui;
/*    */ 
/*    */ import fr.paladium.palamod.client.gui.button.ButtonGuardianChest;
/*    */ import fr.paladium.palamod.common.gui.ContainerGuardianChest;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import fr.paladium.palamod.network.PacketPipeline;
/*    */ import fr.paladium.palamod.network.packets.PacketOpenGui;
/*    */ import fr.paladium.palamod.proxy.CommonProxy;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.GuiButton;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GuiGuardianChest extends GuiContainer
/*    */ {
/*    */   private EntityGuardianGolem golem;
/* 22 */   private final ResourceLocation background = new ResourceLocation("palamod:textures/gui/GuardianChest.png");
/* 23 */   private final ResourceLocation disabledSlots = new ResourceLocation("palamod:textures/gui/SlotsGui.png");
/*    */   private FontRenderer fr;
/*    */   public float xSizeFloat;
/*    */   public float ySizeFloat;
/*    */   
/*    */   public GuiGuardianChest(EntityGuardianGolem entity, InventoryPlayer inventory) {
/* 29 */     super(new ContainerGuardianChest(entity, inventory));
/* 30 */     this.fr = Minecraft.getMinecraft().fontRenderer;
/* 31 */     this.golem = entity;
/* 32 */     this.xSize = 238;
/* 33 */     this.ySize = 181;
/*    */   }
/*    */   
/*    */   public void initGui()
/*    */   {
/* 38 */     super.initGui();
/* 39 */     int x = (this.width - this.xSize) / 2;
/* 40 */     int y = (this.height - this.ySize) / 2;
/*    */     
/* 42 */     this.buttonList.add(new ButtonGuardianChest(GuiGuardianGolem.CHEST, x + 210, y + 157, "", this.golem));
/*    */   }
/*    */   
/*    */   public void drawScreen(int p_73863_1_, int p_73863_2_, float p_73863_3_) {
/* 46 */     super.drawScreen(p_73863_1_, p_73863_2_, p_73863_3_);
/* 47 */     this.xSizeFloat = p_73863_1_;
/* 48 */     this.ySizeFloat = p_73863_2_;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float p_146976_1_, int p_146976_2_, int p_146976_3_)
/*    */   {
/* 53 */     this.mc.renderEngine.bindTexture(this.background);
/* 54 */     drawDefaultBackground();
/* 55 */     GL11.glPushMatrix();
/* 56 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/* 57 */     int x = (this.width - this.xSize) / 2;
/* 58 */     int y = (this.height - this.ySize) / 2;
/* 59 */     drawTexturedModalRect(x, y, 0, 0, this.xSize, this.ySize);
/* 60 */     float scaledXp = 240.0F * (this.golem.getSubLevel() / this.golem.getRequiredXP());
/* 61 */     drawTexturedModalRect(x + 9, y + 20, 0, 227, (int)scaledXp, 11);
/* 62 */     this.fr.drawStringWithShadow(this.golem.getGuardianName(), x + (this.xSize / 2 - this.fr.getStringWidth(this.golem.getGuardianName()) / 2), y + 7, 182844);
/*    */     
/* 64 */     this.fr.drawString("Niveau " + this.golem.getLevel(), x + (this.xSize / 2 - this.fr
/* 65 */       .getStringWidth("Niveau " + this.golem.getLevel()) / 2), y + 21, 16777215, true);
/* 66 */     GL11.glPopMatrix();
/* 67 */     this.mc.renderEngine.bindTexture(this.disabledSlots);
/* 68 */     for (int i = 0; i < 3; i++) {
/* 69 */       for (int j = 0; j < 9; j++) {
/* 70 */         if (i * 9 + j > this.golem.getMaxChestSlots()) {
/* 71 */           drawTexturedModalRect(x + j * 18 + 38, y + i * 18 + 38, 0, 0, 18, 18);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected void actionPerformed(GuiButton button)
/*    */   {
/* 79 */     super.actionPerformed(button);
/* 80 */     if (button.id == GuiGuardianGolem.CHEST) {
/* 81 */       PacketOpenGui packet = new PacketOpenGui();
/* 82 */       packet.setInformations((byte)7, this.golem.getEntityId(), 0, 0);
/* 83 */       CommonProxy.packetPipeline.sendToServer(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\gui\GuiGuardianChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */