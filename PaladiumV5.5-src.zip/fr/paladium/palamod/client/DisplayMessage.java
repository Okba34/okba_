/*    */ package fr.paladium.palamod.client;
/*    */ 
/*    */ public class DisplayMessage
/*    */ {
/*    */   public String title;
/*    */   public String subTitle;
/*    */   public int time;
/*    */   
/*    */   public DisplayMessage(String message, String subTitle, int time) {
/* 10 */     this.title = message;
/* 11 */     this.subTitle = subTitle;
/* 12 */     this.time = time;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\DisplayMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */