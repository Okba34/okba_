/*    */ package fr.paladium.palamod.client;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import fr.paladium.palamod.entities.mobs.EntityGuardianGolem;
/*    */ import net.minecraft.entity.boss.IBossDisplayData;
/*    */ 
/*    */ @cpw.mods.fml.relauncher.SideOnly(Side.CLIENT)
/*    */ public class CustomBossStatus
/*    */ {
/*    */   public static float healthScale;
/*    */   public static int statusBarTime;
/*    */   public static String bossName;
/*    */   
/*    */   public static void setBossStatus(IBossDisplayData p_82824_0_, boolean p_82824_1_)
/*    */   {
/* 16 */     healthScale = p_82824_0_.getHealth() / p_82824_0_.getMaxHealth();
/* 17 */     statusBarTime = 10;
/* 18 */     if ((p_82824_0_ instanceof EntityGuardianGolem)) {
/* 19 */       bossName = ((EntityGuardianGolem)p_82824_0_).getGuardianName();
/*    */     } else
/* 21 */       bossName = p_82824_0_.func_145748_c_().getFormattedText();
/* 22 */     if ((p_82824_0_.getHealth() == 0.0F) || (p_82824_0_.getHealth() == 0.0F)) {
/* 23 */       healthScale = 1.0F;
/* 24 */       statusBarTime = 0;
/* 25 */       bossName = null;
/*    */     }
/*    */   }
/*    */   
/*    */   public static void update() {
/* 30 */     if (statusBarTime-- <= 0) {
/* 31 */       bossName = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\client\CustomBossStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */