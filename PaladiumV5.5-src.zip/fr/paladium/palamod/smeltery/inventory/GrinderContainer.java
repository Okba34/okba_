/*    */ package fr.paladium.palamod.smeltery.inventory;
/*    */ 
/*    */ import fr.paladium.palamod.common.slot.SlotUpgradeGrinder;
/*    */ import fr.paladium.palamod.smeltery.block.BlockGrinder;
/*    */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.Slot;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class GrinderContainer extends Container
/*    */ {
/*    */   private GrinderLogic tile;
/*    */   
/*    */   public GrinderContainer(InventoryPlayer inventory, GrinderLogic tile)
/*    */   {
/* 18 */     this.tile = tile;
/*    */     
/* 20 */     addSlotToContainer(new fr.paladium.palamod.common.slot.SlotResult(tile, 0, 77, 29));
/* 21 */     addSlotToContainer(new Slot(tile, 1, 23, 20));
/* 22 */     addSlotToContainer(new Slot(tile, 2, 23, 38));
/* 23 */     addSlotToContainer(new Slot(tile, 4, 23, 69));
/* 24 */     addSlotToContainer(new SlotUpgradeGrinder(tile, 5, 77, 69));
/* 25 */     addSlotToContainer(new fr.paladium.palamod.common.slot.SlotGrinder(tile, 6, 125, 12, tile));
/*    */     
/* 27 */     bindPlayerInventory(inventory);
/*    */   }
/*    */   
/*    */   private void bindPlayerInventory(InventoryPlayer inventory)
/*    */   {
/* 32 */     for (int i = 0; i < 3; i++) {
/* 33 */       for (int j = 0; j < 9; j++) {
/* 34 */         addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 23 + j * 18, 91 + i * 18));
/*    */       }
/*    */     }
/*    */     
/* 38 */     for (i = 0; i < 9; i++) {
/* 39 */       addSlotToContainer(new Slot(inventory, i, 23 + i * 18, 149));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean canInteractWith(EntityPlayer player)
/*    */   {
/* 45 */     if (!this.tile.isUseableByPlayer(player)) {
/* 46 */       return false;
/*    */     }
/* 48 */     if (player.worldObj.getWorldTime() % 20L == 0L) {
/* 49 */       return ((BlockGrinder)player.worldObj.getBlock(this.tile.xCoord, this.tile.yCoord, this.tile.zCoord)).isMultiBlockStructure(player.worldObj, this.tile.xCoord, this.tile.yCoord, this.tile.zCoord);
/*    */     }
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   public net.minecraft.item.ItemStack transferStackInSlot(EntityPlayer player, int quantity)
/*    */   {
/* 56 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\inventory\GrinderContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */