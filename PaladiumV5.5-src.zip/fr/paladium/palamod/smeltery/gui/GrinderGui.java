/*    */ package fr.paladium.palamod.smeltery.gui;
/*    */ 
/*    */ import fr.paladium.palamod.smeltery.inventory.GrinderContainer;
/*    */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.client.gui.inventory.GuiContainer;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.util.EnumChatFormatting;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class GrinderGui extends GuiContainer
/*    */ {
/*    */   private GrinderLogic tile;
/* 20 */   private static final ResourceLocation background = new ResourceLocation("palamod:textures/gui/grinder.png");
/*    */   
/*    */   public GrinderGui(InventoryPlayer inventory, GrinderLogic tile) {
/* 23 */     super(new GrinderContainer(inventory, tile));
/*    */     
/* 25 */     this.tile = tile;
/* 26 */     this.ySize = 172;
/* 27 */     this.xSize = 210;
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerBackgroundLayer(float f, int mouseX, int mouseY)
/*    */   {
/* 32 */     GL11.glColor4f(1.0F, 1.5F, 1.0F, 1.0F);
/* 33 */     this.mc.getTextureManager().bindTexture(background);
/*    */     
/* 35 */     int k = (this.width - this.xSize) / 2;
/* 36 */     int l = (this.height - this.ySize) / 2;
/*    */     
/* 38 */     drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
/* 39 */     drawTexturedModalRect(k + 146, l + 12, 51, 172, 53, 54 - (int)this.tile.getScaledPaladium(54));
/*    */     
/* 41 */     GL11.glPushMatrix();
/* 42 */     GL11.glDisable(2896);
/* 43 */     GL11.glEnable(3042);
/* 44 */     GL11.glBlendFunc(770, 771);
/* 45 */     drawTexturedModalRect(k + 147, l + 13, 0, 172, 51, 50);
/* 46 */     GL11.glPopMatrix();
/*    */     
/* 48 */     drawTexturedModalRect(k + 43, l + 27, 210, 0, this.tile.getScaledTool(31), 17);
/* 49 */     drawTexturedModalRect(k + 43, l + 67, 210, 0, this.tile.getScaledUpgrade(31), 17);
/* 50 */     drawTexturedModalRect(k + 124, l + 29, 210, 18, this.tile.getScaledProgress(19), 11);
/*    */     
/* 52 */     this.fontRendererObj.drawString(StatCollector.translateToLocal("crafters.Grinder"), k + 7, l + 6, 4210752);
/* 53 */     this.fontRendererObj.drawString(this.tile.getPaladium() + "/" + this.tile.getMaxPaladium(), k + 163, l + 67, 4210752);
/*    */   }
/*    */   
/*    */   protected void drawGuiContainerForegroundLayer(int x, int y)
/*    */   {
/* 58 */     int k = (this.width - this.xSize) / 2;
/* 59 */     int l = (this.height - this.ySize) / 2;
/*    */     
/* 61 */     if ((x >= k + 147) && (y >= l + 12) && (x <= k + 198) && (y <= l + 63)) {
/* 62 */       List<String> list = new ArrayList();
/* 63 */       list.add(EnumChatFormatting.GOLD + (this.tile.getPaladium() == 1 ? "1 Paladium" : new StringBuilder().append(this.tile.getPaladium()).append(" Paladiums").toString()));
/* 64 */       list.add("Max: 100");
/*    */       
/* 66 */       drawHoveringText(list, x - 200, y - 30, this.fontRendererObj);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\gui\GrinderGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */