/*    */ package fr.paladium.palamod.smeltery.block;
/*    */ 
/*    */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ public class BaseBlockGrinder extends Block
/*    */ {
/*    */   private String unlocalizedName;
/*    */   
/*    */   public BaseBlockGrinder(String unlocalizedName)
/*    */   {
/* 12 */     super(net.minecraft.block.material.Material.rock);
/*    */     
/* 14 */     this.unlocalizedName = unlocalizedName;
/*    */     
/* 16 */     setBlockName(this.unlocalizedName);
/* 17 */     setBlockTextureName("palamod:smeltery/" + this.unlocalizedName);
/*    */     
/* 19 */     setResistance(8.0F);
/* 20 */     setHardness(12.0F);
/*    */     
/* 22 */     setHarvestLevel("pickaxe", 2);
/*    */     
/* 24 */     setStepSound(Block.soundTypeStone);
/*    */     
/* 26 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\block\BaseBlockGrinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */