/*     */ package fr.paladium.palamod.smeltery.block;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.PalaMod;
/*     */ import fr.paladium.palamod.client.creativetab.CreativeTabRegister;
/*     */ import fr.paladium.palamod.smeltery.SmelteryRegister;
/*     */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockContainer;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.client.renderer.texture.IIconRegister;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.IIcon;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ public class BlockGrinder
/*     */   extends BlockContainer
/*     */ {
/*     */   private String unlocalizedName;
/*     */   @SideOnly(Side.CLIENT)
/*     */   private IIcon frontIcon;
/*     */   
/*     */   public BlockGrinder(String unlocalizedName)
/*     */   {
/*  36 */     super(Material.rock);
/*     */     
/*  38 */     this.unlocalizedName = unlocalizedName;
/*     */     
/*  40 */     setBlockName(this.unlocalizedName);
/*  41 */     setBlockTextureName("palamod:smeltery/" + this.unlocalizedName);
/*     */     
/*  43 */     setResistance(20.0F);
/*  44 */     setHardness(3.0F);
/*     */     
/*  46 */     setHarvestLevel("pickaxe", 2);
/*     */     
/*  48 */     setStepSound(Block.soundTypeStone);
/*     */     
/*  50 */     setCreativeTab(CreativeTabRegister.PALADIUM);
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public IIcon getIcon(int side, int metadata)
/*     */   {
/*  56 */     if ((metadata == 0) && (side == 3)) {
/*  57 */       return this.frontIcon;
/*     */     }
/*  59 */     return side != metadata ? this.blockIcon : this.frontIcon;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void registerBlockIcons(IIconRegister iconRegister)
/*     */   {
/*  65 */     this.blockIcon = iconRegister.registerIcon("palamod:smeltery/" + this.unlocalizedName + "_side");
/*  66 */     this.frontIcon = iconRegister.registerIcon("palamod:smeltery/" + this.unlocalizedName + "_front");
/*     */   }
/*     */   
/*     */   public boolean isMultiBlockStructure(World world, int x, int y, int z) {
/*  70 */     if (checkNorth(world, x, y, z)) {
/*  71 */       return true;
/*     */     }
/*  73 */     if (checkEast(world, x, y, z)) {
/*  74 */       return true;
/*     */     }
/*  76 */     if (checkSouth(world, x, y, z)) {
/*  77 */       return true;
/*     */     }
/*  79 */     if (checkWest(world, x, y, z)) {
/*  80 */       return true;
/*     */     }
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean checkNorth(World world, int x, int y, int z) {
/*  86 */     if ((world.getBlock(x + -1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  87 */       (world.getBlock(x + -1, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  88 */       (world.getBlock(x + -1, y + -1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  89 */       (world.getBlock(x + -1, y + 0, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  90 */       (world.getBlock(x + -1, y + 0, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/*  91 */       (world.getBlock(x + -1, y + 0, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  92 */       (world.getBlock(x + -1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  93 */       (world.getBlock(x + -1, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  94 */       (world.getBlock(x + -1, y + 1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  95 */       (world.getBlock(x + 0, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  96 */       (world.getBlock(x + 0, y + -1, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/*  97 */       (world.getBlock(x + 0, y + -1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/*  98 */       (world.getBlock(x + 0, y + 0, z + -1).equals(Blocks.lava)) && 
/*  99 */       (world.getBlock(x + 0, y + 0, z + -2).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 100 */       (world.getBlock(x + 0, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 101 */       (world.getBlock(x + 0, y + 1, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 102 */       (world.getBlock(x + 0, y + 1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 103 */       (world.getBlock(x + 1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 104 */       (world.getBlock(x + 1, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 105 */       (world.getBlock(x + 1, y + -1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 106 */       (world.getBlock(x + 1, y + 0, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 107 */       (world.getBlock(x + 1, y + 0, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 108 */       (world.getBlock(x + 1, y + 0, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 109 */       (world.getBlock(x + 1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 110 */       (world.getBlock(x + 1, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 111 */       (world.getBlock(x + 1, y + 1, z + -2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK))) {
/* 112 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean checkEast(World world, int x, int y, int z) {
/* 143 */     if ((world.getBlock(x + 0, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 144 */       (world.getBlock(x + 1, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 145 */       (world.getBlock(x + 2, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 146 */       (world.getBlock(x + 0, y + 0, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 147 */       (world.getBlock(x + 1, y + 0, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 148 */       (world.getBlock(x + 2, y + 0, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 149 */       (world.getBlock(x + 0, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 150 */       (world.getBlock(x + 1, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 151 */       (world.getBlock(x + 2, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 152 */       (world.getBlock(x + 0, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 153 */       (world.getBlock(x + 1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 154 */       (world.getBlock(x + 2, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 155 */       (world.getBlock(x + 1, y + 0, z + 0).equals(Blocks.lava)) && 
/* 156 */       (world.getBlock(x + 2, y + 0, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 157 */       (world.getBlock(x + 0, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 158 */       (world.getBlock(x + 1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 159 */       (world.getBlock(x + 2, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 160 */       (world.getBlock(x + 0, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 161 */       (world.getBlock(x + 1, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 162 */       (world.getBlock(x + 2, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 163 */       (world.getBlock(x + 0, y + 0, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 164 */       (world.getBlock(x + 1, y + 0, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 165 */       (world.getBlock(x + 2, y + 0, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 166 */       (world.getBlock(x + 0, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 167 */       (world.getBlock(x + 1, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 168 */       (world.getBlock(x + 2, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK))) {
/* 169 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean checkSouth(World world, int x, int y, int z) {
/* 200 */     if ((world.getBlock(x + 1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 201 */       (world.getBlock(x + 1, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 202 */       (world.getBlock(x + 1, y + -1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 203 */       (world.getBlock(x + 1, y + 0, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 204 */       (world.getBlock(x + 1, y + 0, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 205 */       (world.getBlock(x + 1, y + 0, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 206 */       (world.getBlock(x + 1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 207 */       (world.getBlock(x + 1, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 208 */       (world.getBlock(x + 1, y + 1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 209 */       (world.getBlock(x + 0, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 210 */       (world.getBlock(x + 0, y + -1, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 211 */       (world.getBlock(x + 0, y + -1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 212 */       (world.getBlock(x + 0, y + 0, z + 1).equals(Blocks.lava)) && 
/* 213 */       (world.getBlock(x + 0, y + 0, z + 2).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 214 */       (world.getBlock(x + 0, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 215 */       (world.getBlock(x + 0, y + 1, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 216 */       (world.getBlock(x + 0, y + 1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 217 */       (world.getBlock(x + -1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 218 */       (world.getBlock(x + -1, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 219 */       (world.getBlock(x + -1, y + -1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 220 */       (world.getBlock(x + -1, y + 0, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 221 */       (world.getBlock(x + -1, y + 0, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 222 */       (world.getBlock(x + -1, y + 0, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 223 */       (world.getBlock(x + -1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 224 */       (world.getBlock(x + -1, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 225 */       (world.getBlock(x + -1, y + 1, z + 2).equals(SmelteryRegister.GRINDER_FRAME_BLOCK))) {
/* 226 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean checkWest(World world, int x, int y, int z) {
/* 257 */     if ((world.getBlock(x + 0, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 258 */       (world.getBlock(x + -1, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 259 */       (world.getBlock(x + -2, y + -1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 260 */       (world.getBlock(x + 0, y + 0, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 261 */       (world.getBlock(x + -1, y + 0, z + 1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 262 */       (world.getBlock(x + -2, y + 0, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 263 */       (world.getBlock(x + 0, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 264 */       (world.getBlock(x + -1, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 265 */       (world.getBlock(x + -2, y + 1, z + 1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 266 */       (world.getBlock(x + 0, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 267 */       (world.getBlock(x + -1, y + -1, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 268 */       (world.getBlock(x + -2, y + -1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 269 */       (world.getBlock(x + -1, y + 0, z + 0).equals(Blocks.lava)) && 
/* 270 */       (world.getBlock(x + -2, y + 0, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 271 */       (world.getBlock(x + 0, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 272 */       (world.getBlock(x + -1, y + 1, z + 0).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 273 */       (world.getBlock(x + -2, y + 1, z + 0).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 274 */       (world.getBlock(x + 0, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 275 */       (world.getBlock(x + -1, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 276 */       (world.getBlock(x + -2, y + -1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 277 */       (world.getBlock(x + 0, y + 0, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 278 */       (world.getBlock(x + -1, y + 0, z + -1).equals(SmelteryRegister.GRINDER_CASING_BLOCK)) && 
/* 279 */       (world.getBlock(x + -2, y + 0, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 280 */       (world.getBlock(x + 0, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 281 */       (world.getBlock(x + -1, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK)) && 
/* 282 */       (world.getBlock(x + -2, y + 1, z + -1).equals(SmelteryRegister.GRINDER_FRAME_BLOCK))) {
/* 283 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */     return false;
/*     */   }
/*     */   
/*     */   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int p_149727_6_, float p_149727_7_, float p_149727_8_, float p_149727_9_)
/*     */   {
/* 315 */     if (isMultiBlockStructure(world, x, y, z)) {
/* 316 */       if (!world.isRemote) {
/* 317 */         player.openGui(PalaMod.instance, 12, world, x, y, z);
/*     */       }
/* 319 */       return true;
/*     */     }
/* 321 */     return false;
/*     */   }
/*     */   
/*     */   public void breakBlock(World world, int x, int y, int z, Block block, int metadata) {
/* 325 */     TileEntity tileentity = world.getTileEntity(x, y, z);
/* 326 */     if ((tileentity instanceof IInventory)) {
/* 327 */       IInventory inv = (IInventory)tileentity;
/* 328 */       for (int i1 = 0; i1 < inv.getSizeInventory(); i1++) {
/* 329 */         ItemStack itemstack = inv.getStackInSlot(i1);
/*     */         
/* 331 */         if (itemstack != null) {
/* 332 */           float f = world.rand.nextFloat() * 0.8F + 0.1F;
/* 333 */           float f1 = world.rand.nextFloat() * 0.8F + 0.1F;
/*     */           
/*     */           EntityItem entityitem;
/* 336 */           for (float f2 = world.rand.nextFloat() * 0.8F + 0.1F; itemstack.stackSize > 0; world.spawnEntityInWorld(entityitem)) {
/* 337 */             int j1 = world.rand.nextInt(21) + 10;
/*     */             
/* 339 */             if (j1 > itemstack.stackSize) {
/* 340 */               j1 = itemstack.stackSize;
/*     */             }
/*     */             
/* 343 */             itemstack.stackSize -= j1;
/* 344 */             entityitem = new EntityItem(world, x + f, y + f1, z + f2, new ItemStack(itemstack.getItem(), j1, itemstack.getItemDamage()));
/*     */             
/* 346 */             float f3 = 0.05F;
/* 347 */             entityitem.motionX = ((float)world.rand.nextGaussian() * f3);
/* 348 */             entityitem.motionY = ((float)world.rand.nextGaussian() * f3 + 0.2F);
/* 349 */             entityitem.motionZ = ((float)world.rand.nextGaussian() * f3);
/*     */             
/* 351 */             if (itemstack.hasTagCompound()) {
/* 352 */               entityitem.getEntityItem().setTagCompound((NBTTagCompound)itemstack.getTagCompound().copy());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 357 */       world.func_147453_f(x, y, z, block);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase p_149689_5_, ItemStack itemStack)
/*     */   {
/* 363 */     int l = MathHelper.floor_double(p_149689_5_.rotationYaw * 4.0F / 360.0F + 0.5D) & 0x3;
/*     */     
/* 365 */     if (l == 0) {
/* 366 */       world.setBlockMetadataWithNotify(x, y, z, 2, 2);
/*     */     }
/*     */     
/* 369 */     if (l == 1) {
/* 370 */       world.setBlockMetadataWithNotify(x, y, z, 5, 2);
/*     */     }
/*     */     
/* 373 */     if (l == 2) {
/* 374 */       world.setBlockMetadataWithNotify(x, y, z, 3, 2);
/*     */     }
/*     */     
/* 377 */     if (l == 3) {
/* 378 */       world.setBlockMetadataWithNotify(x, y, z, 4, 2);
/*     */     }
/*     */   }
/*     */   
/*     */   public TileEntity createNewTileEntity(World world, int p_149915_2_)
/*     */   {
/* 384 */     GrinderLogic grinderLogic = new GrinderLogic();
/* 385 */     return grinderLogic;
/*     */   }
/*     */   
/*     */   public boolean hasTileEntity()
/*     */   {
/* 390 */     return true;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void randomDisplayTick(World world, int x, int y, int z, Random random)
/*     */   {
/* 396 */     int l = world.getBlockMetadata(x, y, z);
/* 397 */     float f = x + 0.5F;
/* 398 */     float f1 = y + 0.0F + random.nextFloat() * 6.0F / 16.0F;
/* 399 */     float f2 = z + 0.5F;
/* 400 */     float f3 = 0.52F;
/* 401 */     float f4 = random.nextFloat() * 0.6F - 0.3F;
/*     */     
/* 403 */     if (isMultiBlockStructure(world, x, y, z)) {
/* 404 */       if (l == 4) {
/* 405 */         world.spawnParticle("smoke", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 406 */         world.spawnParticle("flame", f - f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 408 */       else if (l == 5) {
/* 409 */         world.spawnParticle("smoke", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/* 410 */         world.spawnParticle("flame", f + f3, f1, f2 + f4, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 412 */       else if (l == 2) {
/* 413 */         world.spawnParticle("smoke", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/* 414 */         world.spawnParticle("flame", f + f4, f1, f2 - f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/* 416 */       else if (l == 3) {
/* 417 */         world.spawnParticle("smoke", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/* 418 */         world.spawnParticle("flame", f + f4, f1, f2 + f3, 0.0D, 0.0D, 0.0D);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\block\BlockGrinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */