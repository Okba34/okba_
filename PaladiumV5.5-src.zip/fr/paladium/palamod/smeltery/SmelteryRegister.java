/*     */ package fr.paladium.palamod.smeltery;
/*     */ 
/*     */ import cpw.mods.fml.common.event.FMLInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPostInitializationEvent;
/*     */ import cpw.mods.fml.common.event.FMLPreInitializationEvent;
/*     */ import cpw.mods.fml.common.registry.GameRegistry;
/*     */ import fr.paladium.palamod.items.ModItems;
/*     */ import fr.paladium.palamod.library.Register;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.paladium.PaladiumRegister;
/*     */ import fr.paladium.palamod.smeltery.block.BaseBlockGrinder;
/*     */ import fr.paladium.palamod.smeltery.block.BlockGrinder;
/*     */ import fr.paladium.palamod.smeltery.crafting.GrinderRecipe;
/*     */ import fr.paladium.palamod.smeltery.logic.GrinderLogic;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ 
/*     */ 
/*     */ public class SmelteryRegister
/*     */   extends Register
/*     */ {
/*     */   public static BlockGrinder GRINDER_BLOCK;
/*     */   public static BaseBlockGrinder GRINDER_CASING_BLOCK;
/*     */   public static BaseBlockGrinder GRINDER_FRAME_BLOCK;
/*     */   
/*     */   public void preInit(FMLPreInitializationEvent event)
/*     */   {
/*  28 */     register();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init(FMLInitializationEvent event)
/*     */   {
/*  35 */     registerRecipes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void postInit(FMLPostInitializationEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */   private void register()
/*     */   {
/*  47 */     registerBlock(GRINDER_BLOCK = new BlockGrinder("grinder_block"));
/*  48 */     registerBlock(GRINDER_CASING_BLOCK = new BaseBlockGrinder("grinder_casing_block"));
/*  49 */     registerBlock(GRINDER_FRAME_BLOCK = new BaseBlockGrinder("grinder_frame_block"));
/*     */     
/*     */ 
/*  52 */     registerTileEntity(GrinderLogic.class, "grinder");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void registerRecipes()
/*     */   {
/*  59 */     registerGrinderRecipes();
/*     */     
/*     */ 
/*  62 */     GameRegistry.addRecipe(new ItemStack(GRINDER_BLOCK), new Object[] { "YYY", "YXY", "YYY", 
/*     */     
/*     */ 
/*     */ 
/*  66 */       Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, 
/*  67 */       Character.valueOf('X'), new ItemStack(PaladiumRegister.PALADIUM_FURNACE) });
/*     */     
/*     */ 
/*  70 */     GameRegistry.addRecipe(new ItemStack(GRINDER_CASING_BLOCK), new Object[] { "Y Y", "Y Y", "Y Y", 
/*     */     
/*     */ 
/*     */ 
/*  74 */       Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT });
/*     */     
/*     */ 
/*  77 */     GameRegistry.addRecipe(new ItemStack(GRINDER_FRAME_BLOCK), new Object[] { "YZY", "   ", "YZY", 
/*     */     
/*     */ 
/*     */ 
/*  81 */       Character.valueOf('Y'), MaterialRegister.PALADIUM_INGOT, 
/*  82 */       Character.valueOf('Z'), MaterialRegister.TITANE_INGOT });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void registerGrinderRecipes()
/*     */   {
/*  91 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternBroadsword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.broadSwordHead), 4);
/*  92 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternPickaxe), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.pickaxeHead), 3);
/*  93 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternFastSword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.fastSwordHead), 1);
/*  94 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternSword), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.swordHead), 2);
/*  95 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternHammer), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.hammerHead), 6);
/*  96 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternShovel), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.shovelHead), 1);
/*  97 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternAxe), new ItemStack(ModItems.paternSocket), new ItemStack(ModItems.axeHead), 3);
/*  98 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.paternIngot), new ItemStack(ModItems.paternSocket), new ItemStack(MaterialRegister.PALADIUM_INGOT), 1);
/*     */     
/*     */ 
/* 101 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.broadSwordHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumBroadsword), 0);
/* 102 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.broadSwordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumBroadsword), 1);
/* 103 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.pickaxeHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumPickaxe), 0);
/* 104 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.swordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumSword), 0);
/* 105 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.fastSwordHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumFastSword), 0);
/* 106 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.fastSwordHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumFastSword), 1);
/* 107 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.hammerHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumHammer), 1);
/* 108 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.hammerHead), new ItemStack(ModItems.paladiumStick), new ItemStack(ModItems.paladiumHammer), 0);
/* 109 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.axeHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumAxe), 0);
/* 110 */     GrinderRecipe.getManager().add(new ItemStack(ModItems.shovelHead), new ItemStack(Items.stick), new ItemStack(ModItems.paladiumShovel), 0);
/*     */     
/*     */ 
/* 113 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.smeltModifier, 0);
/* 114 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.speedModifier, 2);
/* 115 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.fortuneModifier, 1);
/* 116 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.obsidianUpgrade, 6);
/* 117 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumHammer, ModItems.moreUpgrade, 7);
/*     */     
/* 119 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.damageModifier, 3);
/* 120 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.flameModifier, 4);
/* 121 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.knockbackModifier, 5);
/* 122 */     GrinderRecipe.getManager().addUpgrade(ModItems.paladiumBroadsword, ModItems.moreUpgrade, 7);
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\SmelteryRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */