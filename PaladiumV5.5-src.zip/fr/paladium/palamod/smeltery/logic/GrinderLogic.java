/*     */ package fr.paladium.palamod.smeltery.logic;
/*     */ 
/*     */ import cpw.mods.fml.relauncher.Side;
/*     */ import cpw.mods.fml.relauncher.SideOnly;
/*     */ import fr.paladium.palamod.decorative.DecorativeRegister;
/*     */ import fr.paladium.palamod.items.armors.ItemArmorPaladium;
/*     */ import fr.paladium.palamod.items.core.ItemPatern;
/*     */ import fr.paladium.palamod.items.tools.ItemPaladiumPickaxe;
/*     */ import fr.paladium.palamod.items.weapons.ItemPaladiumSword;
/*     */ import fr.paladium.palamod.material.MaterialRegister;
/*     */ import fr.paladium.palamod.smeltery.crafting.GrinderRecipe;
/*     */ import fr.paladium.palamod.util.UpgradeHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ISidedInventory;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.network.NetworkManager;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class GrinderLogic extends TileEntity implements IInventory, ISidedInventory
/*     */ {
/*     */   private ItemStack[] content;
/*     */   private int paladiumAmount;
/*     */   private int maxPaladium;
/*     */   private int workedTimeCreation;
/*     */   private int workedTimeUpgrade;
/*     */   private int timeNeededCreation;
/*     */   private int timeNeededUpgrade;
/*     */   private int timeNeededPaladium;
/*     */   private int workedTimePaladium;
/*     */   
/*     */   public GrinderLogic()
/*     */   {
/*  40 */     this.content = new ItemStack[7];
/*     */     
/*  42 */     this.maxPaladium = 100;
/*  43 */     this.timeNeededCreation = 100;
/*  44 */     this.timeNeededUpgrade = 100;
/*  45 */     this.timeNeededPaladium = 20;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getSizeInventory()
/*     */   {
/*  51 */     return this.content.length;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack getStackInSlot(int slot)
/*     */   {
/*  57 */     return this.content[slot];
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemStack decrStackSize(int slotIndex, int amount)
/*     */   {
/*  63 */     if (this.content[slotIndex] != null)
/*     */     {
/*     */ 
/*     */ 
/*  67 */       if (this.content[slotIndex].stackSize <= amount)
/*     */       {
/*  69 */         ItemStack itemstack = this.content[slotIndex];
/*  70 */         this.content[slotIndex] = null;
/*  71 */         markDirty();
/*  72 */         return itemstack;
/*     */       }
/*     */       
/*     */ 
/*  76 */       ItemStack itemstack = this.content[slotIndex].splitStack(amount);
/*     */       
/*  78 */       if (this.content[slotIndex].stackSize == 0)
/*     */       {
/*  80 */         this.content[slotIndex] = null;
/*     */       }
/*     */       
/*  83 */       markDirty();
/*  84 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  89 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ItemStack getStackInSlotOnClosing(int slotIndex)
/*     */   {
/*  96 */     if (this.content[slotIndex] != null)
/*     */     {
/*  98 */       ItemStack itemstack = this.content[slotIndex];
/*  99 */       this.content[slotIndex] = null;
/* 100 */       return itemstack;
/*     */     }
/*     */     
/*     */ 
/* 104 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setInventorySlotContents(int slotIndex, ItemStack stack)
/*     */   {
/* 111 */     this.content[slotIndex] = stack;
/*     */     
/* 113 */     if ((stack != null) && (stack.stackSize > getInventoryStackLimit()))
/*     */     {
/* 115 */       stack.stackSize = getInventoryStackLimit();
/*     */     }
/*     */     
/* 118 */     markDirty();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getInventoryName()
/*     */   {
/* 124 */     return "Tile.paladiumgrinder";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean hasCustomInventoryName()
/*     */   {
/* 130 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getInventoryStackLimit()
/*     */   {
/* 136 */     return 64;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isUseableByPlayer(EntityPlayer player)
/*     */   {
/* 142 */     return this.worldObj.getTileEntity(this.xCoord, this.yCoord, this.zCoord) == this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void openInventory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeInventory() {}
/*     */   
/*     */ 
/*     */   public boolean isItemValidForSlot(int slot, ItemStack stack)
/*     */   {
/* 156 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public Packet getDescriptionPacket()
/*     */   {
/* 162 */     NBTTagCompound nbtTag = new NBTTagCompound();
/* 163 */     writeToNBT(nbtTag);
/* 164 */     return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord, this.zCoord, 1, nbtTag);
/*     */   }
/*     */   
/*     */   public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity packet)
/*     */   {
/* 169 */     readFromNBT(packet.func_148857_g());
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateEntity()
/*     */   {
/* 175 */     if ((this.content[6] != null) && (this.paladiumAmount < 100))
/*     */     {
/* 177 */       if (this.timeNeededPaladium > this.workedTimePaladium) {
/* 178 */         this.workedTimePaladium += 1;
/*     */       }
/*     */       else {
/* 181 */         consumePaladium();
/* 182 */         this.workedTimePaladium = 0;
/*     */       }
/*     */     }
/*     */     else {
/* 186 */       this.workedTimePaladium = 0;
/*     */     }
/* 188 */     if (canSmeltTool())
/*     */     {
/* 190 */       this.workedTimeCreation += 1;
/* 191 */       if (this.workedTimeCreation >= this.timeNeededCreation)
/*     */       {
/* 193 */         smeltTool();
/* 194 */         this.workedTimeCreation = 0;
/*     */       }
/*     */     }
/*     */     else {
/* 198 */       this.workedTimeCreation = 0;
/*     */     }
/* 200 */     if (canSmeltUpgrade())
/*     */     {
/* 202 */       this.workedTimeUpgrade += 1;
/* 203 */       if (this.workedTimeUpgrade >= this.timeNeededUpgrade)
/*     */       {
/* 205 */         smeltUpgrade();
/* 206 */         this.workedTimeUpgrade = 0;
/*     */       }
/*     */     }
/*     */     else {
/* 210 */       this.workedTimeUpgrade = 0; }
/* 211 */     super.updateEntity();
/*     */   }
/*     */   
/*     */   public boolean canSmeltTool()
/*     */   {
/* 216 */     if ((this.content[1] == null) || (this.content[2] == null) || (this.paladiumAmount == 0)) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     ItemStack itemstack = GrinderRecipe.getManager().getSmeltingResult(new ItemStack[] { this.content[1], this.content[2] });
/*     */     
/* 222 */     if (itemstack == null) {
/* 223 */       return false;
/*     */     }
/* 225 */     if ((this.content[0] != null) && ((this.content[0].getItem() != MaterialRegister.PALADIUM_INGOT) || (this.content[0].stackSize >= 64))) {
/* 226 */       return false;
/*     */     }
/* 228 */     if (GrinderRecipe.getManager().getSmeltingAmmount(itemstack) > this.paladiumAmount) {
/* 229 */       return false;
/*     */     }
/* 231 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canSmeltUpgrade()
/*     */   {
/* 237 */     if ((this.content[4] == null) || (this.content[5] == null)) {
/* 238 */       return false;
/*     */     }
/*     */     
/* 241 */     if (!GrinderRecipe.getManager().isUpgradable(this.content[5].getItem(), this.content[4].getItem())) {
/* 242 */       return false;
/*     */     }
/*     */     
/* 245 */     if (!UpgradeHelper.canApplyUpgrade(this.content[4], GrinderRecipe.getManager().getUpgrade(this.content[4].getItem()), this.content[5])) {
/* 246 */       return false;
/*     */     }
/* 248 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void smeltUpgrade()
/*     */   {
/* 254 */     if ((this.content[4] == null) || (this.content[5] == null)) {
/* 255 */       return;
/*     */     }
/*     */     
/* 258 */     if (!GrinderRecipe.getManager().isUpgradable(this.content[5].getItem(), this.content[4].getItem())) {
/* 259 */       return;
/*     */     }
/*     */     
/* 262 */     int upgrade = GrinderRecipe.getManager().getUpgrade(this.content[4].getItem());
/*     */     
/* 264 */     this.content[4].stackSize -= 1;
/* 265 */     if (this.content[4].stackSize <= 0) {
/* 266 */       this.content[4] = null;
/*     */     }
/*     */     
/* 269 */     UpgradeHelper.applyUpgrade(this.content[5], upgrade);
/* 270 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/* 271 */     markDirty();
/*     */   }
/*     */   
/*     */   public void smeltTool()
/*     */   {
/* 276 */     if ((this.content[1] == null) || (this.content[2] == null)) {
/* 277 */       return;
/*     */     }
/*     */     
/* 280 */     ItemStack itemstack = GrinderRecipe.getManager().getSmeltingResult(new ItemStack[] { this.content[1], this.content[2] });
/* 281 */     if (itemstack == null) {
/* 282 */       return;
/*     */     }
/*     */     
/* 285 */     this.paladiumAmount -= GrinderRecipe.getManager().getSmeltingAmmount(itemstack);
/*     */     
/* 287 */     if ((!(this.content[1].getItem() instanceof ItemPatern)) || (!(this.content[2].getItem() instanceof ItemPatern))) {
/* 288 */       this.content[1].stackSize -= 1;
/* 289 */       this.content[2].stackSize -= 1;
/*     */       
/* 291 */       if (this.content[1].stackSize <= 0) {
/* 292 */         this.content[1] = null;
/*     */       }
/* 294 */       if (this.content[2].stackSize <= 0) {
/* 295 */         this.content[2] = null;
/*     */       }
/*     */     }
/*     */     
/* 299 */     if ((this.content[0] == null) || (this.content[0].getItem() != MaterialRegister.PALADIUM_INGOT)) {
/* 300 */       this.content[0] = itemstack.copy();
/*     */     }
/*     */     else {
/* 303 */       this.content[0].stackSize += 1;
/*     */     }
/* 305 */     this.worldObj.markBlockForUpdate(this.xCoord, this.yCoord, this.zCoord);
/* 306 */     markDirty();
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public float getScaledPaladium(int i)
/*     */   {
/* 312 */     return this.paladiumAmount * i / this.maxPaladium;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getScaledTool(int i)
/*     */   {
/* 318 */     return this.workedTimeCreation * i / this.timeNeededCreation;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getScaledUpgrade(int i)
/*     */   {
/* 324 */     return this.workedTimeUpgrade * i / this.timeNeededUpgrade;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getScaledProgress(int i)
/*     */   {
/* 330 */     return this.workedTimePaladium * i / this.timeNeededPaladium;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getPaladium()
/*     */   {
/* 336 */     return this.paladiumAmount;
/*     */   }
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int getMaxPaladium()
/*     */   {
/* 342 */     return this.maxPaladium;
/*     */   }
/*     */   
/*     */   public void consumePaladium()
/*     */   {
/* 347 */     ItemStack stack = this.content[6].copy();
/* 348 */     int size = stack.stackSize;
/* 349 */     this.content[6] = null;
/* 350 */     int ammount = 0;
/*     */     
/* 352 */     if (stack.getItem() == MaterialRegister.PALADIUM_INGOT) {
/* 353 */       ammount = size;
/*     */     }
/* 355 */     if (stack.getItem() == Item.getItemFromBlock(DecorativeRegister.PALADIUM_BLOCK)) {
/* 356 */       ammount = size * 9;
/*     */     }
/* 358 */     if ((stack.getItem() instanceof ItemArmorPaladium)) {
/* 359 */       ammount = (stack.getMaxDamage() - stack.getItemDamage()) * ((ItemArmorPaladium)stack.getItem()).getCost() / stack.getMaxDamage();
/*     */     }
/* 361 */     if ((stack.getItem() instanceof ItemPaladiumSword)) {
/* 362 */       ammount = (stack.getMaxDamage() - stack.getItemDamage()) * 2 / stack.getMaxDamage();
/*     */     }
/* 364 */     if ((stack.getItem() instanceof ItemPaladiumPickaxe)) {
/* 365 */       ammount = (stack.getMaxDamage() - stack.getItemDamage()) * 3 / stack.getMaxDamage();
/*     */     }
/*     */     
/* 368 */     this.paladiumAmount += ammount;
/*     */     
/* 370 */     if (this.paladiumAmount > this.maxPaladium) {
/* 371 */       this.paladiumAmount = this.maxPaladium;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeToNBT(NBTTagCompound compound)
/*     */   {
/* 378 */     super.writeToNBT(compound);
/* 379 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 381 */     for (int i = 0; i < this.content.length; i++)
/*     */     {
/* 383 */       if (this.content[i] != null)
/*     */       {
/* 385 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 386 */         nbttagcompound1.setByte("Slot", (byte)i);
/* 387 */         this.content[i].writeToNBT(nbttagcompound1);
/* 388 */         nbttaglist.appendTag(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 392 */     compound.setTag("Items", nbttaglist);
/* 393 */     compound.setShort("workedTimeCreation", (short)this.workedTimeCreation);
/* 394 */     compound.setShort("workedTimeUpgrade", (short)this.workedTimeUpgrade);
/* 395 */     compound.setShort("paladiumAmount", (short)this.paladiumAmount);
/*     */   }
/*     */   
/*     */ 
/*     */   public void readFromNBT(NBTTagCompound compound)
/*     */   {
/* 401 */     super.readFromNBT(compound);
/*     */     
/* 403 */     NBTTagList nbttaglist = compound.getTagList("Items", 10);
/* 404 */     this.content = new ItemStack[getSizeInventory()];
/*     */     
/* 406 */     for (int i = 0; i < nbttaglist.tagCount(); i++)
/*     */     {
/* 408 */       NBTTagCompound nbttagcompound1 = nbttaglist.getCompoundTagAt(i);
/* 409 */       int j = nbttagcompound1.getByte("Slot") & 0xFF;
/*     */       
/* 411 */       if ((j >= 0) && (j < this.content.length))
/*     */       {
/* 413 */         this.content[j] = ItemStack.loadItemStackFromNBT(nbttagcompound1);
/*     */       }
/*     */     }
/*     */     
/* 417 */     this.workedTimeCreation = compound.getShort("workedTimeCreation");
/* 418 */     this.workedTimeUpgrade = compound.getShort("workedTimeUpgrade");
/* 419 */     this.paladiumAmount = compound.getShort("paladiumAmount");
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getAccessibleSlotsFromSide(int side)
/*     */   {
/* 425 */     return new int[0];
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canInsertItem(int side, ItemStack stack, int slot)
/*     */   {
/* 431 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canExtractItem(int side, ItemStack stack, int slot)
/*     */   {
/* 437 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\logic\GrinderLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */