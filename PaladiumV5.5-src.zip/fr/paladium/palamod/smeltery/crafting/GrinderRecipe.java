/*    */ package fr.paladium.palamod.smeltery.crafting;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class GrinderRecipe
/*    */ {
/* 12 */   private static final GrinderRecipe instance = new GrinderRecipe();
/*    */   
/* 14 */   private Map<ItemStack, Integer> smeltingAmmount = new HashMap();
/* 15 */   private Map<ItemStack[], ItemStack> smeltingList = new HashMap();
/* 16 */   private Map<Item, Item> upgradeList = new HashMap();
/* 17 */   private Map<Item, Integer> upgradeResult = new HashMap();
/*    */   
/*    */   public void add(ItemStack stack1, ItemStack stack2, ItemStack stack, int ammount) {
/* 20 */     ItemStack[] stackList = { stack1, stack2 };
/*    */     
/* 22 */     this.smeltingAmmount.put(stack, Integer.valueOf(ammount));
/* 23 */     this.smeltingList.put(stackList, stack);
/*    */   }
/*    */   
/*    */   public void addUpgrade(Item tool, Item upgrade, int type) {
/* 27 */     this.upgradeList.put(upgrade, tool);
/* 28 */     this.upgradeResult.put(upgrade, Integer.valueOf(type));
/*    */   }
/*    */   
/*    */   public ItemStack getSmeltingResult(ItemStack[] stack) {
/* 32 */     Iterator<?> iterator = this.smeltingList.entrySet().iterator();
/*    */     Map.Entry<?, ?> entry;
/*    */     do
/*    */     {
/* 36 */       if (!iterator.hasNext()) {
/* 37 */         return null;
/*    */       }
/* 39 */       entry = (Map.Entry)iterator.next();
/* 40 */     } while (!isSameKey(stack, (ItemStack[])entry.getKey()));
/*    */     
/* 42 */     return (ItemStack)entry.getValue();
/*    */   }
/*    */   
/*    */   private boolean isSameKey(ItemStack[] stackList, ItemStack[] stackList2) {
/* 46 */     boolean isSame = false;
/* 47 */     for (int i = 0; i <= 1; i++) {
/* 48 */       if (stackList[i].getItem() == stackList2[i].getItem()) {
/* 49 */         isSame = true;
/*    */       }
/*    */       else {
/* 52 */         return false;
/*    */       }
/*    */     }
/* 55 */     return isSame;
/*    */   }
/*    */   
/*    */   public boolean isUpgradable(Item tool, Item upgrade) {
/* 59 */     return this.upgradeList.containsKey(upgrade);
/*    */   }
/*    */   
/*    */   public int getUpgrade(Item upgrade) {
/* 63 */     return ((Integer)this.upgradeResult.get(upgrade)).intValue();
/*    */   }
/*    */   
/*    */   public Map<ItemStack[], ItemStack> getSmeltingList() {
/* 67 */     return this.smeltingList;
/*    */   }
/*    */   
/*    */   public static GrinderRecipe getManager() {
/* 71 */     return instance;
/*    */   }
/*    */   
/*    */   public int getSmeltingAmmount(ItemStack stack) {
/* 75 */     return ((Integer)this.smeltingAmmount.get(stack)).intValue();
/*    */   }
/*    */   
/*    */   public Map<ItemStack, Integer> getSmeltingAmmount() {
/* 79 */     return this.smeltingAmmount;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\smeltery\crafting\GrinderRecipe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */