/*    */ package fr.paladium.palamod.potion;
/*    */ 
/*    */ import cpw.mods.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.EntityDamageSource;
/*    */ import net.minecraft.util.EntityDamageSourceIndirect;
/*    */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*    */ 
/*    */ public class PotionHandler
/*    */ {
/*    */   @SubscribeEvent(priority=cpw.mods.fml.common.eventhandler.EventPriority.NORMAL)
/*    */   public void imbueHandler(LivingAttackEvent event)
/*    */   {
/* 16 */     if ((!event.entityLiving.worldObj.isRemote) && 
/* 17 */       (!event.isCanceled()) && ((event.source instanceof EntityDamageSource)) && (!(event.source instanceof EntityDamageSourceIndirect)))
/*    */     {
/* 19 */       EntityDamageSource damageSource = (EntityDamageSource)event.source;
/*    */       
/* 21 */       if ((damageSource.getEntity() != null) && ((damageSource.getEntity() instanceof EntityLivingBase))) {
/* 22 */         EntityLivingBase livingEntity = (EntityLivingBase)damageSource.getEntity();
/*    */         
/* 24 */         if ((livingEntity.isPotionActive(ModPotions.potionWither)) && (!livingEntity.isPotionActive(ModPotions.potionPoison))) {
/* 25 */           event.entityLiving.addPotionEffect(new PotionEffect(Potion.wither.id, 100, 1));
/*    */         }
/* 27 */         if ((livingEntity.isPotionActive(ModPotions.potionPoison)) && (!livingEntity.isPotionActive(ModPotions.potionWither))) {
/* 28 */           event.entityLiving.addPotionEffect(new PotionEffect(Potion.poison.id, 100, 1));
/*    */         }
/* 30 */         if (livingEntity.isPotionActive(ModPotions.potionFire)) {
/* 31 */           event.entityLiving.setFire(20);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\potion\PotionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */