/*    */ package fr.paladium.palamod.potion;
/*    */ 
/*    */ import cpw.mods.fml.relauncher.Side;
/*    */ import cpw.mods.fml.relauncher.SideOnly;
/*    */ import fr.paladium.palamod.util.GuiDrawer;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.renderer.texture.TextureManager;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class PotionFireImbue extends Potion
/*    */ {
/* 14 */   ResourceLocation icon = new ResourceLocation("palamod:textures/gui/effects/FireEffect.png");
/*    */   
/*    */   public PotionFireImbue(int par1, boolean par2, int par3) {
/* 17 */     super(par1, par2, par3);
/*    */   }
/*    */   
/*    */   public Potion setIconIndex(int par1, int par2) {
/* 21 */     super.setIconIndex(par1, par2);
/* 22 */     return this;
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void renderInventoryEffect(int x, int y, PotionEffect effect, Minecraft mc)
/*    */   {
/* 28 */     mc.renderEngine.bindTexture(this.icon);
/* 29 */     GuiDrawer.drawTexturedQuadFit(x + 5, y + 5, 20.0D, 20.0D, 1.0D);
/*    */   }
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean hasStatusIcon()
/*    */   {
/* 35 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\potion\PotionFireImbue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */