/*    */ package fr.paladium.palamod.potion;
/*    */ 
/*    */ import fr.paladium.palamod.PalaMod;
/*    */ import java.lang.reflect.Field;
/*    */ import net.minecraft.potion.Potion;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ public class PotionExtender
/*    */ {
/*    */   public static void preInit() {}
/*    */   
/*    */   private static void extendPotionArray()
/*    */   {
/* 15 */     Potion[] potionTypes = null;
/*    */     
/* 17 */     for (Field f : Potion.class.getDeclaredFields()) {
/* 18 */       f.setAccessible(true);
/*    */       try {
/* 20 */         if ((f.getName().equals("potionTypes")) || (f.getName().equals("field_76425_a"))) {
/* 21 */           Field modfield = Field.class.getDeclaredField("modifiers");
/* 22 */           modfield.setAccessible(true);
/* 23 */           modfield.setInt(f, f.getModifiers() & 0xFFFFFFEF);
/*    */           
/* 25 */           potionTypes = (Potion[])f.get(null);
/* 26 */           Potion[] newPotionTypes = new Potion['Ā'];
/* 27 */           System.arraycopy(potionTypes, 0, newPotionTypes, 0, potionTypes.length);
/* 28 */           f.set(null, newPotionTypes);
/*    */         }
/*    */       }
/*    */       catch (Exception e) {
/* 32 */         PalaMod.logger.error("Severe error, please report this to the mod author : ", e);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\potion\PotionExtender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */