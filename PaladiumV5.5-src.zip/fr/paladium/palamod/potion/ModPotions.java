/*    */ package fr.paladium.palamod.potion;
/*    */ 
/*    */ import net.minecraft.potion.Potion;
/*    */ 
/*    */ public class ModPotions {
/*    */   public static PotionWitherImbue potionWither;
/*    */   public static PotionFireImbue potionFire;
/*    */   public static PotionPoisonImbue potionPoison;
/*    */   
/* 10 */   public static void init() { potionWither = (PotionWitherImbue)new PotionWitherImbue(32, false, 0).setIconIndex(0, 0).setPotionName("potion.imbuewither");
/* 11 */     potionFire = (PotionFireImbue)new PotionFireImbue(33, false, 0).setIconIndex(0, 0).setPotionName("potion.imbuefire");
/* 12 */     potionPoison = (PotionPoisonImbue)new PotionPoisonImbue(34, false, 0).setIconIndex(0, 0).setPotionName("potion.imbuepoison");
/*    */   }
/*    */ }


/* Location:              C:\Users\ACER\Desktop\Projet Developement\Dev\Paladium-deobf\PalaModV5.5-deobf.jar!\fr\paladium\palamod\potion\ModPotions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */